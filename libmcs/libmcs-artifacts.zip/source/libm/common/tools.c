/* SPDX-License-Identifier: GTDGmbH */
/* Copyright 2020-2021 by GTD GmbH. */

#include "tools.h"

const float __inff = 1.0f/0.0f;
const double __infd = 1.0/0.0;
