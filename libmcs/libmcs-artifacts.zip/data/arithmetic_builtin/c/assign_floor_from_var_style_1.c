/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    double result;
    double x = 27.8;

    //lilac:A:start:assign variable value as floor of variable #floor #arithmetic
    result = floor(x);
    //lilac:A:stop

    printf("Result: %.0f", result);
    return 0;
}
