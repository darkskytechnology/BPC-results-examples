/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
    double  value = -5.5;
    double absolute_value;

    //lilac:A:start:assign variable value as the absolute value of a variable #absolute-value
    absolute_value = fabs(value);
    //lilac:A:stop

    printf("The absolute value is %.1f", absolute_value);

    return 0;
}

