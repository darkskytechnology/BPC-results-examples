/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

fn main() {

    // lilac:A:start:declare uninitialized double array:L{1}
    let mut foo: [f64; 16] = [0.0; 16];
    // lilac:A:stop

    // lilac:B:start:assign value to an element in an array indexed by HOLE
    foo[
        // lilac:BA:start:integer
        0
        // lilac:BA:stop
    ] = 
    //lilac:BB:start:floating-point literal
    1.0
    //lilac:BB:stop^
    ;
    // lilac:B:stop

    // lilac:C:start:assign value to an element in an array indexed by HOLE
    foo[
        // lilac:CA:start:integer
        1
        // lilac:CA:stop
    ] = 
    //lilac:CB:start:floating-point literal
    2.0
    //lilac:CB:stop^
    ;
    // lilac:C:stop

    let result: f64;

    result = 
        // lilac:D:start:element in an array indexed by HOLE
        foo[
        // lilac:E:start:integer
        0
        // lilac:E:stop
        ]
        // lilac:D:stop^
        ;

    print!("Result: {:.1}", result);
}
