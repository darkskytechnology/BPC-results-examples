/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>

typedef unsigned int u32_t;

// lilac:A:start:declare static constant typedef array using HOLE
static const u32_t foo[] = {
    // lilac:B+:start:integers
    // lilac:BA:start:integer
    5, 
     // lilac:BA:stop
    // lilac:BB:start:integer
    10
     // lilac:BB:stop
    // lilac:B+:stop
};
// lilac:A:stop



int main(int argc, char* argv[]) {

    printf("Result: %d", 
        //lilac:P:start:index value
        foo[0]
        //lilac:P:stop
        );


    return 0;
}
