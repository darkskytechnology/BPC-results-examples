/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

struct other
{
    double val;
};

typedef struct other user_t;

//lilac:A:start:declare function
const char * func_name(
 //lilac:B+:start:(arguments)
 //lilac:BA:start:(arg)
 const char * a,
 //lilac:BA:stop
 //lilac:BB:start:(arg)
 const char * b
 //lilac:BB:stop
 //lilac:B+:stop
) {
  //lilac:C+:start:(return)
  return a;
  //lilac:C+:stop
}
//lilac:A:stop

//lilac:V:start:declare function
const char * no_arg_function() {
  //lilac:VA+:start:(body)
  //lilac:VAA:start:declare variable
  const char * a;
  //lilac:VAA:stop
  //lilac:VAB:start:(return)
  return a;
  //lilac:VAB:stop
  //lilac:VA+:stop
}
//lilac:V:stop

//lilac:W:start:declare function
const char * no_arg_function_void(void) {
  //lilac:WA+:start:(body)
  //lilac:WAA:start:declare variable
  const char * a;
  //lilac:WAA:stop
  //lilac:WAB:start:(return)
  return a;
  //lilac:WAB:stop
  //lilac:WA+:stop
}
//lilac:W:stop

int main(int argc, char *argv[])
{
    return 0;
}