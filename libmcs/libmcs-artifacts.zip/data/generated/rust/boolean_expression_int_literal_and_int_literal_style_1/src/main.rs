/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

fn main()
{
    let var: i32 = 10;
    const test_value: i32 = 10;
    
    let results = (
        //lilac:P:start:(parenthesized expression)
        (
        //lilac:E:start:int_literal and int_literal
        //lilac:L:start_:int_literal
        10 == test_value
        //lilac:L:stop
        &&
        //lilac:R:start:int_literal
        10 == test_value
        //lilac:R:stop^
        //lilac:E:stop
        )
        //lilac:P:stop
    )
    ;

    print!("Operator results: {}", results);
}