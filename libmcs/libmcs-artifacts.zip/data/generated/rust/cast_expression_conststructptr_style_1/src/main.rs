/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[derive(Clone, Default)]
pub struct other {
    pub val: f64,
}

pub type user_t = other;

fn main() {
    let value: Option<std::rc::Rc<std::cell::RefCell<other>>> = Some(std::rc::Rc::new(std::cell::RefCell::new(other::default())));

    let to_void: Option<std::rc::Rc<dyn std::any::Any>> =
    //lilac:A:start:cast expression
      Some(
      //lilac:B:start_3:(variable)
      value
      //lilac:B:stop
      .unwrap()
      as
      std::rc::Rc<dyn std::any::Any>)
      //lilac:A:stop
    ;

    let from_void: Option<std::rc::Rc<std::cell::RefCell<other>>> =
    //lilac:C:start:cast expression
      Some(
      //lilac:D:start_7:(variable)
      to_void
      //lilac:D:stop
      .unwrap().downcast::<std::cell::RefCell<other>>().unwrap())
      //lilac:C:stop
    ;
}