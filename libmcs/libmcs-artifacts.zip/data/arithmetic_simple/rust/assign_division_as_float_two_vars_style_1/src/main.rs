/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[allow(unused_variables)]
#[allow(non_snake_case)]

fn main() -> impl std::process::Termination {
    let argv = std::env::args().collect::<Vec<_>>();
    let argc = argv.len();

    let retcode = move || -> u8 {
        let result: f32;
        let a: f32 = 100.6;
        let b: f32 = 5.2;

        //lilac:A:start:assign variable value as quotient of two variables #division #arithmetic
        result = a / b;
        //lilac:A:stop

        print!("Result: {:.1}", result);
        return 0;
    }();

    return std::process::ExitCode::from(retcode);
}
