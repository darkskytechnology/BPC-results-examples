/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[allow(unused_variables)]
#[allow(non_snake_case)]

//lilac:F:start:declare function
pub fn function_example(
    //lilac:FP+:start:(function arguments)
    //lilac:FPA:start:declare integer variable
    incoming: i32
    //lilac:FPA:stop
    //lilac:FP+:stop
    ) -> i32 {
    //lilac:FM+:start:(function content)

    //lilac:FBR:start:evaluate expression
    10
    //lilac:FBRA:start:(minus)
    -
    //lilac:FBRA:stop
    incoming
    //lilac:FBR:stop
    
    //lilac:FM+:stop
}
//lilac:F:stop

fn main() -> impl std::process::Termination {
    let argv = std::env::args().collect::<Vec<_>>();
    let argc = argv.len();

    let retcode = move || -> u8 {
        //lilac:A:start:declare integer variable and assign value
        let initial: i32 = 2;
        //lilac:A:stop
        //lilac:AA:start:declare integer variable
        let results: i32;
        //lilac:AA:stop
        //lilac:B:start:assign variable function results
        results = function_example(initial);
        //lilac:B:stop
        //lilac:C:start:print string
        print!("Results: {}",
        //lilac:BP+:start:(function arguments)
        //lilac:BBA:start:(variable)
        results
        //lilac:BBA:stop
        //lilac:BP+:stop
        );
        //lilac:C:stop
        //lilac:D:start:return integer
        return
        0;
        //lilac:D:stop
    }();

    return std::process::ExitCode::from(retcode);
}
