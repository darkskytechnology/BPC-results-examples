/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[allow(unused_variables)]
#[allow(non_snake_case)]

//lilac:F:start:(function with double return value)
fn function_example(
    //lilac:FP+:start:(function arguments)
    //lilac:FPA:start:declare double variable
    incoming: f64
    //lilac:FPA:stop
    //lilac:FP+:stop
    ) -> f64 {
    //lilac:FA+:start:(function contents)
    //lilac:FAA:start:return floating-point value
    return 10.11111;
    //lilac:FAA:stop
    //lilac:FA+:stop
}
//lilac:F:stop

fn main() -> impl std::process::Termination {
    let argv = std::env::args().collect::<Vec<_>>();
    let argc = argv.len();

    let retcode = move || -> u8 {
        let initial: f64 = 10.11111;

        //lilac:C:start:print string
        print!("Results: {:.5}",
        //lilac:BP+:start:(function arguments)
        //lilac:BBA:start:(function call)
        function_example(initial)
        //lilac:BBA:stop
        //lilac:BP+:stop
        );
        //lilac:C:stop
        return
        0;
    }();

    return std::process::ExitCode::from(retcode);
}
