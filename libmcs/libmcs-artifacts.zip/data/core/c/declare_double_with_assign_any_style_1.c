/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>

int main(int argc, char *argv[]) {
    //lilac:A:start:declare double variable and assign value
    double i = 
        //lilac:AA:start:floating-point literal
        50.5
        //lilac:AA:stop^
    ;
    //lilac:A:stop
    printf("Double is %.1f",
    i
    );
}
