/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>

//lilac:F:start:declare function
int function_example(
    //lilac:FP+:start:(function arguments)
    //lilac:FPA:start:declare integer variable
    int incoming_a,
    //lilac:FPA:stop
    //lilac:FPB:start:declare integer variable
    int incoming_b
    //lilac:FPB:stop
    //lilac:FP+:stop
    ){
    //lilac:FM+:start:(function content)
    return
    //lilac:FBR:start:evaluate expression
    10
    //lilac:FBRA:start:(minus)
    -
    //lilac:FBRA:stop
    incoming_a
    //lilac:FBRB:start:(plus)
    +
    //lilac:FBRB:stop
    incoming_b
    //lilac:FBR:stop
    ;
    //lilac:FM+:stop
}
//lilac:F:stop


int main(int argc, char *argv[]) {
    //lilac:A:start:declare integer variable and assign value
    int initial = 2;
    //lilac:A:stop
    //lilac:AA:start:declare integer variable
    int results;
    //lilac:AA:stop
    //lilac:B:start:assign variable function results
    results = function_example(
    //lilac:BBP+:start:(function arguments)
    //lilac:BBPA:start:(variable)
    initial,
    //lilac:BBPA:stop
    //lilac:BBPB:start:(integer)
    100
    //lilac:BBPB:stop
    //lilac:BBP+:stop
    );
    //lilac:B:stop
    //lilac:C:start:print string
    printf("Results: %d",
    //lilac:BP+:start:(function arguments)
    //lilac:BBA:start:(variable)
    results
    //lilac:BBA:stop
    //lilac:BP+:stop
    );
    //lilac:C:stop
    //lilac:D:start:return integer
    return
    0;
    //lilac:D:stop
}
