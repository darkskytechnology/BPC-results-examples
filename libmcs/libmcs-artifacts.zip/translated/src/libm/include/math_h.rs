#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/*
 * These macros define the errno and exception behaviour of the library. This
 * library enforces the use of math_errhandling as MATH_ERREXCEPT.
 * See ISO C18 standard §7.12 wrt. math_errhandling.
 */

pub type float_t = f32;

pub type double_t = f64;

/* Global constants that contain infinities. */
/* extern const float __inff; */
/* extern const double __infd; */
/* Double trigonometric functions */
/* extern double acos(double); */
/* extern double asin(double); */
/* extern double atan(double); */
/* extern double atan2(double, double); */
/* extern double cos(double); */
/* extern double sin(double); */
/* extern double tan(double); */
/* Double hyperbolic functions */
/* extern double acosh(double); */
/* extern double asinh(double); */
/* extern double atanh(double); */
/* extern double cosh(double); */
/* extern double sinh(double); */
/* extern double tanh(double); */
/* Double exponential and logarithmic functions */
/* extern double exp(double); */
/* extern double exp2(double); */
/* extern double expm1(double); */
/* extern double frexp(double, int *); */
/* extern int ilogb(double); */
/* extern double ldexp(double, int); */
/* extern double log(double); */
/* extern double log10(double); */
/* extern double log1p(double); */
/* extern double log2(double); */
/* extern double logb(double); */
/* extern double modf(double, double *); */
/* extern double scalbn(double, int); */
/* extern double scalbln(double, long int); */
/* Double power and absolute-value functions */
/* extern double cbrt(double); */
/* extern double fabs(double); */
/* extern double hypot(double, double); */
/* extern double pow(double, double); */
/* extern double sqrt(double); */
/* Double error and gamma functions */
/* extern double erf(double); */
/* extern double erfc(double); */
/* extern double lgamma(double); */
/* extern double tgamma(double); */
/* Double nearest integer functions */
/* extern double ceil(double); */
/* extern double floor(double); */
/* extern double nearbyint(double); */
/* extern double rint(double); */
/* extern long int lrint(double); */
/* extern long long int llrint(double); */
/* extern double round(double); */
/* extern long int lround(double); */
/* extern long long int llround(double); */
/* extern double trunc(double); */
/* Double remainder functions */
/* extern double fmod(double, double); */
/* extern double remainder(double, double); */
/* extern double remquo(double, double, int *); */
/* Double manipulation functions */
/* extern double copysign(double, double); */
/* extern double nan(const char *); */
/* extern double nextafter(double, double); */
/* Double maximum, minimum and positive difference functions */
/* extern double fdim(double, double); */
/* extern double fmax(double, double); */
/* extern double fmin(double, double); */
/* Double float-multiply-add function */
/* extern double fma(double, double, double); */
/* Double Bessel functions */
/* extern double y0(double); */
/* extern double y1(double); */
/* extern double yn(int, double); */
/* extern double j0(double); */
/* extern double j1(double); */
/* extern double jn(int, double); */
/* Float trigonometric functions */
/* extern float acosf(float); */
/* extern float asinf(float); */
/* extern float atanf(float); */
/* extern float atan2f(float, float); */
/* extern float cosf(float); */
/* extern float sinf(float); */
/* extern float tanf(float); */
/* Float hyperbolic functions */
/* extern float acoshf(float); */
/* extern float asinhf(float); */
/* extern float atanhf(float); */
/* extern float coshf(float); */
/* extern float sinhf(float); */
/* extern float tanhf(float); */
/* Float exponential and logarithmic functions */
/* extern float expf(float); */
/* extern float exp2f(float); */
/* extern float expm1f(float); */
/* extern float frexpf(float, int *); */
/* extern int ilogbf(float); */
/* extern float ldexpf(float, int); */
/* extern float logf(float); */
/* extern float log10f(float); */
/* extern float log1pf(float); */
/* extern float log2f(float); */
/* extern float logbf(float); */
/* extern float modff(float, float *); */
/* extern float scalbnf(float, int); */
/* extern float scalblnf(float, long int); */
/* Float power and absolute-value functions */
/* extern float cbrtf(float); */
/* extern float fabsf(float); */
/* extern float hypotf(float, float); */
/* extern float powf(float, float); */
/* extern float sqrtf(float); */
/* Float error and gamma functions */
/* extern float erff(float); */
/* extern float erfcf(float); */
/* extern float lgammaf(float); */
/* extern float tgammaf(float); */
/* Float nearest integer functions */
/* extern float ceilf(float); */
/* extern float floorf(float); */
/* extern float nearbyintf(float); */
/* extern float rintf(float); */
/* extern long int lrintf(float); */
/* extern long long int llrintf(float); */
/* extern float roundf(float); */
/* extern long int lroundf(float); */
/* extern long long int llroundf(float); */
/* extern float truncf(float); */
/* Float remainder functions */
/* extern float fmodf(float, float); */
/* extern float remainderf(float, float); */
/* extern float remquof(float, float, int *); */
/* Float manipulation functions */
/* extern float copysignf(float, float); */
/* extern float nanf(const char *); */
/* extern float nextafterf(float, float); */
/* Float maximum, minimum and positive difference functions */
/* extern float fdimf(float, float); */
/* extern float fmaxf(float, float); */
/* extern float fminf(float, float); */
/* Float float-multiply-add function */
/* extern float fmaf(float, float, float); */
/* signgam global variable used by the lgamma procedures to return the sign of gamma */
/* extern int __signgam; */
/* Internal procedures used by the classification macros */
/* extern int __fpclassifyf(float); */
/* extern int __fpclassifyd(double); */
/* extern int __signbitf(float); */
/* extern int __signbitd(double); */
/* Classification macros */
/* Comparison macros */
