#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: GTDGmbH */
/* Copyright 2017-2022 by GTD GmbH. */

pub fn sqrtf(x: f32) -> f32 {
    let root: f32 = 0.0;

    // __asm__ volatile ("fsqrts %[x], %[root]"
    //                       : [root] "=f" (root)
    //                       : [x] "f" (x));
    unsafe {
        asm!(
            "fsqrts {0}, {1}",
            out(reg) root,
            in(reg) x,
        );
    }

    return root;
}
