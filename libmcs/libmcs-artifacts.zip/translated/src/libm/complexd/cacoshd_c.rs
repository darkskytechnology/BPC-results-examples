#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::clogd_c::clog;
use crate::libm::complexd::csqrtd_c::csqrt;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex hyperbolic arc cosine of :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex cacoshf(float complex z);
 *     double complex cacosh(double complex z);
 *     long double complex cacoshl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``cacosh`` computes the complex hyperbolic inverse cosine (*arc cosine*) of
 * the input value, with a branch cut at values less than :math:`+1` along the
 * real axis.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    cacosh(z) \approx cosh^{-1}(z)
 *
 * Returns
 * =======
 *
 * ``cacosh`` returns the complex hyperbolic inverse cosine of the input value
 * in the output range of a half-strip of non-negative values along the real
 * axis and in the interval :math:`[-\pi i, +\pi i]` along the imaginary axis.
 *
 */
//

// double _Complex cacosh(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//
//     w = clog(z + csqrt(z + 1) * csqrt(z - 1));
//
//     return w;
// }
fn cacosh(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= __volatile_one;
    }

    let w: num_complex::Complex64;

    w = (z
        + (z + num_complex::Complex64::new(1.0, 0.0)).sqrt()
            * (z - num_complex::Complex64::new(1.0, 0.0)).sqrt())
    .ln();

    w
}
