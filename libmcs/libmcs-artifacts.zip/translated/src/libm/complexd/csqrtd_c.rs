#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cabsd_c::cabs;
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
use crate::libm::machine::sparc_v8::mathd::sqrtd_c::sqrt;
use crate::libm::mathd::fabsd_c::fabs;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex square root of :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float complex csqrtf(float complex z);
 *     double complex csqrt(double complex z);
 *     long double complex csqrtl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``csqrt`` computes the complex square root of the input value, with a branch
 * cut along the negative real axis.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    csqrt(z) \approx \sqrt{z}
 *
 * Returns
 * =======
 *
 * ``csqrt`` returns the complex square root of the input value, in the range
 * of the right halfplane (including the imaginary axis).
 *
 */
//

// double _Complex csqrt(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double x, y, r, t, scale;
//
//     x = creal(z);
//     y = cimag(z);
//
//     if (y == 0.0) {
//         if (x == 0.0) {
//             w = __builtin_complex ((double) (0.0), (double) (y));
//         } else {
//             r = fabs(x);
//             r = sqrt(r);
//
//             if (x < 0.0) {
//                 w = __builtin_complex ((double) (0.0), (double) (r));
//             } else {
//                 w = __builtin_complex ((double) (r), (double) (y));
//             }
//         }
//
//         return w;
//     }
//
//     if (x == 0.0) {
//         r = fabs(y);
//         r = sqrt(0.5 * r);
//
//         if (y > 0) {
//             w = __builtin_complex ((double) (r), (double) (r));
//         } else {
//             w = __builtin_complex ((double) (r), (double) (-r));
//         }
//
//         return w;
//     }
//
//     /* Rescale to avoid internal overflow or underflow.  */
//     if ((fabs(x) > 4.0) || (fabs(y) > 4.0)) {
//         x *= 0.25;
//         y *= 0.25;
//         scale = 2.0;
//     } else {
//         x *= 1.8014398509481984e16; /* 2^54 */
//         y *= 1.8014398509481984e16;
//         scale = 7.450580596923828125e-9; /* 2^-27 */
//     }
//
//     w = __builtin_complex ((double) (x), (double) (y));
//     r = cabs(w);
//
//     if (x > 0) {
//         t = sqrt(0.5 * r + 0.5 * x);
//         r = scale * fabs((0.5 * y) / t);
//         t *= scale;
//     } else {
//         r = sqrt(0.5 * r - 0.5 * x);
//         t = scale * fabs((0.5 * y) / r);
//         r *= scale;
//     }
//
//     if (y < 0) {
//         w = __builtin_complex ((double) (t), (double) (-r));
//     } else {
//         w = __builtin_complex ((double) (t), (double) (r));
//     }
//
//     return w;
// }
fn csqrt(z: num_complex::Complex64) -> num_complex::Complex64 {
    let mut z = z;
    #[cfg(__LIBMCS_FPU_DAZ)]
    {
        z *= num_complex::Complex64::new(1.0, 0.0);
    }

    let mut w;
    let x = z.re;
    let y = z.im;
    let r;
    let t;
    let scale;

    if y == 0.0 {
        if x == 0.0 {
            w = num_complex::Complex64::new(0.0, y);
        } else {
            r = x.abs();
            let r = r.sqrt();

            if x < 0.0 {
                w = num_complex::Complex64::new(0.0, r);
            } else {
                w = num_complex::Complex64::new(r, y);
            }
        }

        return w;
    }

    if x == 0.0 {
        r = y.abs();
        let r = (0.5 * r).sqrt();

        if y > 0.0 {
            w = num_complex::Complex64::new(r, r);
        } else {
            w = num_complex::Complex64::new(r, -r);
        }

        return w;
    }

    if x.abs() > 4.0 || y.abs() > 4.0 {
        let x = x * 0.25;
        let y = y * 0.25;
        scale = 2.0;
    } else {
        let x = x * 1.8014398509481984e16;
        let y = y * 1.8014398509481984e16;
        scale = 7.450580596923828125e-9;
    }

    w = num_complex::Complex64::new(x, y);
    r = w.norm();

    if x > 0.0 {
        t = (0.5 * r + 0.5 * x).sqrt();
        r = scale * ((0.5 * y) / t).abs();
        t *= scale;
    } else {
        r = (0.5 * r - 0.5 * x).sqrt();
        t = scale * ((0.5 * y) / r).abs();
        r *= scale;
    }

    if y < 0.0 {
        w = num_complex::Complex64::new(t, -r);
    } else {
        w = num_complex::Complex64::new(t, r);
    }

    w
}
