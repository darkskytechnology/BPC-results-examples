#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
use crate::libm::complexd::internal::ctrigd_c::__redupi;
use crate::libm::mathd::atan2d_c::atan2;
use crate::libm::mathd::logd_c::log;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex arc tangent of :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex catanf(float complex z);
 *     double complex catan(double complex z);
 *     long double complex catanl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``catan`` computes the complex inverse tangent (*arc tangent*) of the input
 * value, with branch cuts outside the interval :math:`[-i, +i]` along the
 * imaginary axis.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    catan(z) \approx tan^{-1}(z)
 *
 * Returns
 * =======
 *
 * ``catan`` returns the complex inverse tangent of the input value in the
 * output range of a strip mathematically unbounded along the imaginary axis
 * and in the interval :math:`[-\frac{\pi}{2}, \frac{\pi}{2}]` radians along
 * the real axis.
 *
 */
//

// double _Complex catan(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double a, t, x, x2, y, tmp;
//
//     x = creal(z);
//     y = cimag(z);
//
//     if ((x == 0.0) && (y > 1.0)) {
//         goto ovrf;
//     }
//
//     x2 = x * x;
//     a = 1.0 - x2 - (y * y);
//
//     if (a == 0.0) {
//         goto ovrf;
//     }
//
//     t = 0.5 * atan2(2.0 * x, a);
//     tmp = __redupi(t);
//
//     t = y - 1.0;
//     a = x2 + (t * t);
//
//     t = y + 1.0;
//     a = (x2 + (t * t)) / a;
//     /* w = tmp + (0.25 * log(a)) * I; */
//     w = __builtin_complex ((double) (tmp), (double) (0.25 * log(a)));
//     return w;
//
// ovrf:
//     w = __builtin_complex ((double) ((__builtin_huge_val ())), (double) ((__builtin_huge_val ())));
//     return w;
// }
fn catan(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(__LIBMCS_FPU_DAZ)]
    let z = z * __volatile_one;

    let mut w;
    let a;
    let t;
    let x = z.re;
    let x2;
    let y = z.im;
    let tmp;

    if x == 0.0 && y > 1.0 {
        return num_complex::Complex64::new(f64::INFINITY, f64::INFINITY);
    }

    x2 = x * x;
    a = 1.0 - x2 - (y * y);

    if a == 0.0 {
        return num_complex::Complex64::new(f64::INFINITY, f64::INFINITY);
    }

    t = 0.5 * (2.0 * x).atan2(a);
    tmp = __redupi(t);

    t = y - 1.0;
    a = x2 + (t * t);

    t = y + 1.0;
    a = (x2 + (t * t)) / a;
    w = num_complex::Complex64::new(tmp, 0.25 * a.ln());
    w
}
