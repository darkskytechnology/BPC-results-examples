#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cabsd_c::cabs;
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
use crate::libm::mathd::atan2d_c::atan2;
use crate::libm::mathd::logd_c::log;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex natural logarithm function,
 * that is :math:`ln(z)`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float complex clogf(float z);
 *     double complex clog(double z);
 *     long double complex clogl(long double z);
 *
 * Description
 * ===========
 *
 * ``clog`` computes the complex natural logarithm of :math:`z`, with a branch
 * cut along the negative real axis.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    clog(z) \approx ln(z)
 *
 * Returns
 * =======
 *
 * ``clog`` returns the complex natural logarithm of the input value in the
 * output range of a strip mathematically unbounded along the real axis and in
 * the interval :math:`[-\pi i, \pi i]` along the imaginary axis.
 *
 */
//

// double _Complex clog(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double p, rr;
//
//     rr = cabs(z);
//     p = log(rr);
//     rr = atan2(cimag(z), creal(z));
//     /* w = p + rr * I; */
//     w = __builtin_complex ((double) (p), (double) (rr));
//     return w;
// }
fn clog(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= __volatile_one;
    }

    let w: num_complex::Complex64;
    let p: f64;
    let rr: f64;

    rr = z.norm();
    p = rr.ln();
    rr = z.im.atan2(z.re);
    // w = p + rr * I;
    w = num_complex::Complex::new(p, rr);
    w
}
