#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cabsd_c::cabs;
use crate::libm::complexd::cargd_c::carg;
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
use crate::libm::mathd::cosd_c::cos;
use crate::libm::mathd::expd_c::exp;
use crate::libm::mathd::logd_c::log;
use crate::libm::mathd::powd_c::pow;
use crate::libm::mathd::sind_c::sin;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the value of complex :math:`x` raised to
 * the power of complex :math:`y`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float complex cpowf(float complex x, float complex y);
 *     double complex cpow(double complex x, double complex y);
 *     long double complex cpowl(long double complex x, long double complex y);
 *
 * Description
 * ===========
 *
 * ``cpow`` computes the value of complex :math:`x` raised to the power of
 * complex :math:`y`, with a branch cut for the first parameter along the
 * negative real axis.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    cpow(x, y) \approx x^y
 *
 * Returns
 * =======
 *
 * ``cpow`` returns the value of complex :math:`x` raised to the power of
 * complex :math:`y`.
 *
 */
//

// double _Complex cpow(double _Complex x, double _Complex y)
// {
//
//
//
//
//
//     double _Complex w;
//     double realz, imagz, result, theta, absx, argx;
//
//     realz = creal(y);
//     imagz = cimag(y);
//     absx = cabs(x);
//
//     if (absx == 0.0) {
//         return __builtin_complex ((double) (0.0), (double) (0.0));
//     }
//
//     argx = carg(x);
//     result = pow(absx, realz);
//     theta = realz * argx;
//
//     if (imagz != 0.0) {
//         result = result * exp(-imagz * argx);
//         theta = theta + imagz * log(absx);
//     }
//
//     /* w = result * cos(theta) + (result * sin(theta)) * I; */
//     w = __builtin_complex ((double) (result * cos(theta)), (double) (result * sin(theta)));
//     return w;
// }
fn cpow(x: num_complex::Complex64, y: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(__LIBMCS_FPU_DAZ)]
    {
        x *= __volatile_one;
        y *= __volatile_one;
    }

    let mut w;
    let realz = y.re;
    let imagz = y.im;
    let absx = x.norm();

    if absx == 0.0 {
        return num_complex::Complex64::new(0.0, 0.0);
    }

    let argx = x.arg();
    let mut result = absx.powf(realz);
    let mut theta = realz * argx;

    if imagz != 0.0 {
        result *= (-imagz * argx).exp();
        theta += imagz * absx.ln();
    }

    w = num_complex::Complex64::new(result * theta.cos(), result * theta.sin());
    return w;
}
