#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::mathd::coshd_c::cosh;
use crate::libm::mathd::expd_c::exp;
use crate::libm::mathd::fabsd_c::fabs;
use crate::libm::mathd::internal::fpclassifyd_c::__fpclassifyd;
use crate::libm::mathd::sinhd_c::sinh;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/* calculate cosh and sinh */

pub fn __ccoshsinh ( 
x : f64 , 

// double *c
let c: *mut f64; 

, 

// double *s
let s: *mut f64; 
) { 
let e : f64 = Default :: default ( ) ;
let ei : f64 = Default :: default ( ) ;


if 

x . abs ( ) 
<= 
0.5 

{ 


c 

= 
cosh ( x ) 
;




s 

= 
sinh ( x ) 
;

}



else { 
e = exp ( x ) ;


if 

__fpclassifyd ( e ) 
!= 
2 

{ 
ei = 0.5 / e ;

}



else { 

ei 
= 
( 
__builtin_huge_val ( ) 
) 
;

}



e = 0.5 * e ;




s 

= 
e - ei 
;




c 

= 
e + ei 
;

}


}


/* Program to subtract nearest integer multiple of PI */
/* extended precision value of PI: */

const DP1 : f64 = 3.14159265160560607910E0 ;


const DP2 : f64 = 1.98418714791870343106E-9 ;


const DP3 : f64 = 1.14423774522196636802E-17 ;


pub fn __redupi ( 
x : f64 
) -> f64 { 
let t : f64 = Default :: default ( ) ;


let i : i64 = Default :: default ( ) ;


t = x / 3.14159265358979323846 ;


if 
t 
>= 
0.0 
{ 
t += 0.5 ;

}



else { 
t -= 0.5 ;

}



i = t ;

/* the multiple */

t = i ;



t 
= 

( 

( 

x 
- 
t * DP1 

) 
- 
t * DP2 

) 
- 
t * DP3 

;


return t ;

}


