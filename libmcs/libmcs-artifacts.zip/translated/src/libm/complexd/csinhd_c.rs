#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
use crate::libm::mathd::cosd_c::cos;
use crate::libm::mathd::coshd_c::cosh;
use crate::libm::mathd::sind_c::sin;
use crate::libm::mathd::sinhd_c::sinh;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex hyperbolic sine of :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex csinhf(float complex z);
 *     double complex csinh(double complex z);
 *     long double complex csinhl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``csinh`` computes the complex hyperbolic sine of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    csinh(z) \approx sinh(z)
 *
 * Returns
 * =======
 *
 * ``csinh`` returns the complex hyperbolic sine of the input value.
 *
 */
//

// double _Complex csinh(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double x, y;
//
//     x = creal(z);
//     y = cimag(z);
//     /* w = sinh(x) * cos(y) + (cosh(x) * sin(y)) * I; */
//     w = __builtin_complex ((double) (sinh(x) * cos(y)), (double) (cosh(x) * sin(y)));
//     return w;
// }
fn csinh(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= num_complex::Complex64::new(1.0, 0.0);
    }

    let x = z.re;
    let y = z.im;
    // w = sinh(x) * cos(y) + (cosh(x) * sin(y)) * I;
    num_complex::Complex64::new(x.sinh() * y.cos(), x.cosh() * y.sin())
}
