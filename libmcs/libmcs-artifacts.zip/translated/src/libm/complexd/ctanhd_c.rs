#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
use crate::libm::mathd::cosd_c::cos;
use crate::libm::mathd::coshd_c::cosh;
use crate::libm::mathd::sind_c::sin;
use crate::libm::mathd::sinhd_c::sinh;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex hyperbolic tangent of :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex ctanhf(float complex z);
 *     double complex ctanh(double complex z);
 *     long double complex ctanhl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``ctanh`` computes the complex hyperbolic tangent of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    ctanh(z) \approx tanh(z)
 *
 * Returns
 * =======
 *
 * ``ctanh`` returns the complex hyperbolic tangent of the input value.
 *
 */
//

// double _Complex ctanh(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double x, y, d;
//
//     x = creal(z);
//     y = cimag(z);
//     d = cosh(2.0 * x) + cos(2.0 * y);
//     /* w = sinh(2.0 * x) / d  + (sin(2.0 * y) / d) * I; */
//     w = __builtin_complex ((double) (sinh(2.0 * x) / d), (double) (sin(2.0 * y) / d));
//
//     return w;
// }
fn ctanh(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= num_complex::Complex64::new(1.0, 0.0);
    }

    let x = z.re;
    let y = z.im;
    let d = (2.0 * x).cosh() + (2.0 * y).cos();
    let w = num_complex::Complex64::new((2.0 * x).sinh() / d, (2.0 * y).sin() / d);

    w
}
