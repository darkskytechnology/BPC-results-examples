#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
use crate::libm::complexd::internal::ctrigd_c::__ccoshsinh;
use crate::libm::mathd::cosd_c::cos;
use crate::libm::mathd::sind_c::sin;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex cosine of :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex ccosf(float complex z);
 *     double complex ccos(double complex z);
 *     long double complex ccosl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``ccos`` computes the complex cosine of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    ccos(z) \approx cos(z)
 *
 * Returns
 * =======
 *
 * ``ccos`` returns the complex cosine of the input value.
 *
 */
//

// double _Complex ccos(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double ch, sh;
//
//     __ccoshsinh(cimag(z), &ch, &sh);
//     /* w = cos(creal(z)) * ch - (sin(creal(z)) * sh) * I; */
//     w = __builtin_complex ((double) (cos(creal(z)) * ch), (double) (-(sin(creal(z)) * sh)));
//     return w;
// }
fn ccos(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(__LIBMCS_FPU_DAZ)]
    let z = z * __volatile_one;

    let mut w;
    let mut ch = 0.0;
    let mut sh = 0.0;

    __ccoshsinh(z.im, &mut ch, &mut sh);
    // w = cos(z.re) * ch - (sin(z.re) * sh) * I;
    w = num_complex::Complex::new(z.re.cos() * ch, -(z.re.sin() * sh));
    w
}
