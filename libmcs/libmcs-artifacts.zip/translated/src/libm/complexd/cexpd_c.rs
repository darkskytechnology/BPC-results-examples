#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
use crate::libm::mathd::cosd_c::cos;
use crate::libm::mathd::expd_c::exp;
use crate::libm::mathd::sind_c::sin;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex exponential function, that
 * is :math:`e` powered by :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float complex cexpf(float z);
 *     double complex cexp(double z);
 *     long double complex cexpl(long double z);
 *
 * Description
 * ===========
 *
 * ``cexp`` computes :math:`e` powered by the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    cexp(z) \approx e^z
 *
 * Returns
 * =======
 *
 * ``cexp`` returns :math:`e` powered by :math:`z`.
 *
 */
//

// double _Complex cexp(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double r, x, y;
//
//     x = creal(z);
//     y = cimag(z);
//     r = exp(x);
//     /* w = r * cos(y) + r * sin(y) * I; */
//     w = __builtin_complex ((double) (r * cos(y)), (double) (r * sin(y)));
//     return w;
// }
fn cexp(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= __volatile_one;
    }

    let mut w: num_complex::Complex64;
    let r: f64;
    let x: f64;
    let y: f64;

    x = z.re;
    y = z.im;
    r = x.exp();
    // w = r * cos(y) + r * sin(y) * I;
    w = num_complex::Complex::new(r * y.cos(), r * y.sin());
    w
}
