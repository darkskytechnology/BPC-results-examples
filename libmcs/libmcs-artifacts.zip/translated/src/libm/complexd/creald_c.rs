#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: PublicDomain */
/* Written by Matthias Drochner <drochner@NetBSD.org>. */
/*
 *
 * This family of functions returns the real part of :math:`z` as a real.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float crealf(float complex z);
 *     double creal(double complex z);
 *     long double creall(long double complex z);
 *
 * Description
 * ===========
 *
 * ``creal`` computes the real part of :math:`z` as a real.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    creal(z) = \Re(z)
 *
 * Returns
 * =======
 *
 * ``creal`` returns the real part of :math:`z` as a real.
 *
 */
//

pub fn creal(z: (f64, f64)) -> f64 {
    // Assuming z is a tuple representing a complex number
    let w = z; // Assign the tuple directly
    w.0 // Return the real part of the complex number
}
