#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: PublicDomain */
/* Written by Matthias Drochner <drochner@NetBSD.org>. */
/*
 *
 * This family of functions evaluates the complex conjugate of :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex conjf(float complex z);
 *     double complex conj(double complex z);
 *     long double complex conjl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``conj`` computes the complex conjugate of :math:`z`.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    conj(z) = \Re(z) - \Im(z) \cdot i
 *
 * Returns
 * =======
 *
 * ``conj`` returns the complex conjugate of :math:`z`.
 *
 */
//
/*
FUNCTION
        <<conj>>, <<conjf>>---complex conjugate

INDEX
        conj
INDEX
        conjf

SYNOPSIS
       #include <complex.h>
       double complex conj(double complex <[z]>);
       float complex conjf(float complex <[z]>);


DESCRIPTION
        These functions compute the complex conjugate of <[z]>,
        by reversing the sign of its imaginary part.

        <<conjf>> is identical to <<conj>>, except that it performs
        its calculations on <<floats complex>>.

RETURNS
        The conj functions return the complex conjugate value.

PORTABILITY
        <<conj>> and <<conjf>> are ISO C99

QUICKREF
        <<conj>> and <<conjf>> are ISO C99

*/

// double _Complex conj(double _Complex z)
// {
//     double_complex w = { .z = z };
//
//     IMAG_PART(w) = -IMAG_PART(w);
//
//     return (w.z);
// }
fn conj(z: num_complex::Complex64) -> num_complex::Complex64 {
    let mut w = double_complex { z };

    w.z.im = -w.z.im;

    return w.z;
}
