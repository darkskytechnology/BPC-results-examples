#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
use crate::libm::mathd::hypotd_c::hypot;
// USE STATEMENTS END
/* SPDX-License-Identifier: PublicDomain */
/* Written by Matthias Drochner <drochner@NetBSD.org>. */
/*
 *
 * This family of functions implements the absolute value ot the complex
 * argument :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float cabsf(float z);
 *     double cabs(double z);
 *     long double cabsl(long double z);
 *
 * Description
 * ===========
 *
 * ``cabs`` computes the absolute value (also called norm, modulus, or
 * magnitude) of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    cabs(z) \approx |z|
 *
 * Returns
 * =======
 *
 * ``cabs`` returns the absolute value of :math:`z`.
 *
 */
//

pub fn cabs(z: (f64, f64)) -> f64 {
    let (real, imag) = z;
    real.hypot(imag)
}
