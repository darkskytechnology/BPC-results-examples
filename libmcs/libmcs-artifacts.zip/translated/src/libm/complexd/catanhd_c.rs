#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::catand_c::catan;
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex hyperbolic arc tangent of
 * :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex catanhf(float complex z);
 *     double complex catanh(double complex z);
 *     long double complex catanhl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``catanh`` computes the complex hyperbolic inverse tangent (*arc tangent*)
 * of the input value, with branch cuts outside the interval :math:`[-1, +1]`
 * along the real axis.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    catanh(z) \approx tanh^{-1}(z)
 *
 * Returns
 * =======
 *
 * ``catanh`` returns the complex hyperbolic inverse tangent of the input value
 * in the output range of a strip mathematically unbounded along the real axis
 * and in the interval :math:`[-\frac{\pi}{2}i, \frac{\pi}{2}i]` along the
 * imaginary axis.
 *
 */
//

// double _Complex catanh(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double _Complex tmp;
//
//     /* w = -1.0 * I * catan(z * I) */
//     tmp = __builtin_complex ((double) (-cimag(z)), (double) (creal(z)));
//     tmp = catan(tmp);
//     w = __builtin_complex ((double) (cimag(tmp)), (double) (-creal(tmp)));
//     return w;
// }
fn catanh(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    let z = z * num_complex::Complex64::new(1.0, 0.0);

    let mut w;
    let mut tmp;

    // w = -1.0 * I * catan(z * I)
    tmp = num_complex::Complex64::new(-z.im, z.re);
    tmp = catan(tmp);
    w = num_complex::Complex64::new(tmp.im, -tmp.re);
    w
}
