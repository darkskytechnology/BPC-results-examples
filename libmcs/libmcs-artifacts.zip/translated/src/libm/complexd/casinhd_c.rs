#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::casind_c::casin;
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex hyperbolic arc sine of
 * :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex casinhf(float complex z);
 *     double complex casinh(double complex z);
 *     long double complex casinhl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``casinh`` computes the complex hyperbolic inverse sine (*arc sine*) of the
 * input value, with branch cuts outside the interval :math:`[-i, +i]` along
 * the imaginary axis.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    casinh(z) \approx sinh^{-1}(z)
 *
 * Returns
 * =======
 *
 * ``casinh`` returns the complex hyperbolic inverse sine of the input value in
 * the output range of a strip mathematically unbounded along the real axis and
 * in the interval :math:`[-\frac{\pi}{2}i, \frac{\pi}{2}i]` along the
 * imaginary axis.
 *
 */
//

// double _Complex casinh(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double _Complex tmp;
//
//     /* w = -1.0 * I * casin(z * I); */
//     tmp = __builtin_complex ((double) (-cimag(z)), (double) (creal(z)));
//     tmp = casin(tmp);
//     w = __builtin_complex ((double) (cimag(tmp)), (double) (-creal(tmp)));
//     return w;
// }
fn casinh(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    let z = z * num_complex::Complex64::new(1.0, 0.0);

    let mut w;
    let mut tmp;

    // w = -1.0 * I * casin(z * I);
    tmp = num_complex::Complex64::new(-z.im, z.re);
    tmp = tmp.asin();
    w = num_complex::Complex64::new(tmp.im, -tmp.re);
    w
}
