#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::mathd::copysignd_c::copysign;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions evaluates the value of the projection of the
 * complex argument :math:`z` onto the Riemann sphere.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex cprojf(float complex z);
 *     double complex cproj(double complex z);
 *     long double complex cprojl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``cproj`` computes the value of the projection of :math:`z` onto the Riemann
 * sphere.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    cproj(z) = \left\{\begin{array}{ll} z, & \Re(z) \neq \pm Inf \wedge \Im(z) \neq \pm Inf \\ +Inf \pm 0i, & otherwise \end{array}\right.
 *
 * Returns
 * =======
 *
 * ``cproj`` returns the value of the projection of :math:`z` onto the Riemann
 * sphere.
 *
 */
//
/*
 * cproj(double complex z)
 *
 * These functions return the value of the projection (not stereographic!)
 * onto the Riemann sphere.
 *
 * z projects to z, except that all complex infinities (even those with one
 * infinite part and one NaN part) project to positive infinity on the real axis.
 * If z has an infinite part, then cproj(z) shall be equivalent to:
 *
 * INFINITY + I * copysign(0.0, cimag(z))
 */

// double _Complex cproj(double _Complex z)
// {
//     double_complex w = { .z = z };
//
//     if (__builtin_isinf_sign (REAL_PART(w)) || __builtin_isinf_sign (IMAG_PART(w))) {
//         REAL_PART(w) = (__builtin_inff ());
//         IMAG_PART(w) = copysign(0.0, cimag(z));
//     }
//
//     return (w.z);
// }
fn cproj(z: num_complex::Complex64) -> num_complex::Complex64 {
    let mut w = z;

    if w.re.is_infinite() || w.im.is_infinite() {
        w.re = f64::INFINITY;
        w.im = z.im.copysign(0.0);
    }

    w
}
