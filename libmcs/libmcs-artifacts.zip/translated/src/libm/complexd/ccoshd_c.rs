#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
use crate::libm::mathd::cosd_c::cos;
use crate::libm::mathd::coshd_c::cosh;
use crate::libm::mathd::sind_c::sin;
use crate::libm::mathd::sinhd_c::sinh;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex hyperbolic cosine of
 * :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex ccoshf(float complex z);
 *     double complex ccosh(double complex z);
 *     long double complex ccoshl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``ccosh`` computes the complex hyperbolic cosine of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    ccosh(z) \approx cosh(z)
 *
 * Returns
 * =======
 *
 * ``ccosh`` returns the complex hyperbolic cosine of the input value.
 *
 */
//

// double _Complex ccosh(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double x, y;
//
//     x = creal(z);
//     y = cimag(z);
//     /* w = cosh(x) * cos(y) + (sinh(x) * sin(y)) * I; */
//     w = __builtin_complex ((double) (cosh(x) * cos(y)), (double) (sinh(x) * sin(y)));
//     return w;
// }
fn ccosh(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= __volatile_one;
    }

    let x = z.re;
    let y = z.im;
    // w = cosh(x) * cos(y) + (sinh(x) * sin(y)) * I;
    let w = num_complex::Complex64::new(x.cosh() * y.cos(), x.sinh() * y.sin());
    w
}
