#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
use crate::libm::complexd::internal::ctrigd_c::__ccoshsinh;
use crate::libm::mathd::cosd_c::cos;
use crate::libm::mathd::sind_c::sin;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex sine of :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex csinf(float complex z);
 *     double complex csin(double complex z);
 *     long double complex csinl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``csin`` computes the complex sine of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    csin(z) \approx sin(z)
 *
 * Returns
 * =======
 *
 * ``csin`` returns the complex sine of the input value.
 *
 */
//

// double _Complex csin(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double ch, sh;
//
//     __ccoshsinh(cimag(z), &ch, &sh);
//     /* w = sin(creal(z)) * ch + (cos(creal(z)) * sh) * I; */
//     w = __builtin_complex ((double) (sin(creal(z)) * ch), (double) (cos(creal(z)) * sh));
//     return w;
// }
fn csin(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(__LIBMCS_FPU_DAZ)]
    {
        z *= __volatile_one;
    }

    let mut w: num_complex::Complex64;
    let (mut ch, mut sh) = (0.0, 0.0);

    __ccoshsinh(z.im, &mut ch, &mut sh);
    // w = sin(z.re) * ch + (cos(z.re) * sh) * I;
    w = num_complex::Complex64::new((z.re).sin() * ch, (z.re).cos() * sh);
    w
}
