#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::clogd_c::clog;
use crate::libm::complexd::creald_c::creal;
use crate::libm::complexd::csqrtd_c::csqrt;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex arc sine of :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex casinf(float complex z);
 *     double complex casin(double complex z);
 *     long double complex casinl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``casin`` computes the complex inverse sine (*arc sine*) of the input value,
 * with branch cuts outside the interval :math:`[-1, +1]` along the real axis.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    casin(z) \approx sin^{-1}(z)
 *
 * Returns
 * =======
 *
 * ``casin`` returns the complex inverse sine of the input value in the output
 * range of a strip mathematically unbounded along the imaginary axis and in
 * the interval :math:`[-\frac{\pi}{2}, \frac{\pi}{2}]` radians along the real
 * axis.
 *
 */
//

// double _Complex casin(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double _Complex ct, zz, z2;
//     double x, y;
//
//     x = creal(z);
//     y = cimag(z);
//
//     ct = __builtin_complex ((double) (-y), (double) (x));
//     /* zz = (x - y) * (x + y) + (2.0 * x * y) * I; */
//     zz = __builtin_complex ((double) ((x - y) * (x + y)), (double) (2.0 * x * y));
//
//     /* zz = 1.0 - creal(zz) - cimag(zz) * I; */
//     zz = __builtin_complex ((double) (1.0 - creal(zz)), (double) (-cimag(zz)));
//     z2 = csqrt(zz);
//
//     zz = ct + z2;
//     zz = clog(zz);
//     /* w = zz * (-1.0 * I); */
//     w = __builtin_complex ((double) (cimag(zz)), (double) (-creal(zz)));
//     return w;
// }
fn casin(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(__LIBMCS_FPU_DAZ)]
    {
        z *= num_complex::Complex64::new(1.0, 0.0);
    }

    let mut w;
    let ct;
    let zz;
    let z2;
    let x = z.re;
    let y = z.im;

    ct = num_complex::Complex64::new(-y, x);
    // zz = (x - y) * (x + y) + (2.0 * x * y) * I;
    zz = num_complex::Complex64::new((x - y) * (x + y), 2.0 * x * y);

    // zz = 1.0 - creal(zz) - cimag(zz) * I;
    zz = num_complex::Complex64::new(1.0 - zz.re, -zz.im);
    z2 = zz.sqrt();

    zz = ct + z2;
    zz = zz.ln();
    // w = zz * (-1.0 * I);
    w = num_complex::Complex64::new(zz.im, -zz.re);
    w
}
