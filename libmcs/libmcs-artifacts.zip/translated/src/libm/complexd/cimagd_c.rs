#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: PublicDomain */
/* Written by Matthias Drochner <drochner@NetBSD.org>. */
/*
 *
 * This family of functions returns the imaginary part of :math:`z` as a real.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float cimagf(float complex z);
 *     double cimag(double complex z);
 *     long double cimagl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``cimag`` computes the imaginary part of :math:`z` as a real.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    cimag(z) = \Im(z)
 *
 * Returns
 * =======
 *
 * ``cimag`` returns the imaginary part of :math:`z` as a real.
 *
 */
//

pub fn cimag(z: (f64, f64)) -> f64 {
    z.1
}
