#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::casind_c::casin;
use crate::libm::complexd::cimagd_c::cimag;
use crate::libm::complexd::creald_c::creal;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/*
 *
 * This family of functions implements the complex arc cosine of :math:`z`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <complex.h>
 *     float complex cacosf(float complex z);
 *     double complex cacos(double complex z);
 *     long double complex cacosl(long double complex z);
 *
 * Description
 * ===========
 *
 * ``cacos`` computes the complex inverse cosine (*arc cosine*) of the input
 * value, with branch cuts outside the interval :math:`[-1, +1]` along the real
 * axis.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    cacos(z) \approx cos^{-1}(z)
 *
 * Returns
 * =======
 *
 * ``cacos`` returns the complex inverse cosine of the input value in the
 * output range of a strip mathematically unbounded along the imaginary axis
 * and in the interval :math:`[0, \pi]` radians along the real axis.
 *
 */
//

// double _Complex cacos(double _Complex z)
// {
//
//
//
//
//     double _Complex w;
//     double _Complex tmp0;
//     double tmp1;
//
//     tmp0 = casin(z);
//     tmp1 = 1.57079632679489661923 - creal(tmp0);
//     /*  w = tmp1 - (cimag(tmp0) * I); */
//     w = __builtin_complex ((double) (tmp1), (double) (-cimag(tmp0)));
//
//     return w;
// }
fn cacos(z: num_complex::Complex64) -> num_complex::Complex64 {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= __volatile_one;
    }

    let tmp0 = z.asin();
    let tmp1 = std::f64::consts::FRAC_PI_2 - tmp0.re;
    let w = num_complex::Complex::new(tmp1, -tmp0.im);

    w
}
