#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zerof;
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathd::expm1d_c::ln2_hi;
use crate::libm::mathd::expm1d_c::ln2_lo;
use crate::libm::mathd::internal::gammad_c::t1;
use crate::libm::mathd::internal::gammad_c::t2;
use crate::libm::mathd::internal::log1pmfd_h::Lg1;
use crate::libm::mathd::internal::log1pmfd_h::Lg2;
use crate::libm::mathd::internal::log1pmfd_h::Lg3;
use crate::libm::mathd::internal::log1pmfd_h::Lg4;
use crate::libm::mathd::internal::log1pmfd_h::Lg5;
use crate::libm::mathd::internal::log1pmfd_h::Lg6;
use crate::libm::mathd::internal::log1pmfd_h::Lg7;
use crate::libm::mathf::frexpf_c::two25;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// ln2_hi = 6.9313812256e-01f, /* 0x3f317180 */
// ln2_lo = 9.0580006145e-06f, /* 0x3717f7d1 */
// two25 = 3.355443200e+07f, /* 0x4c000000 */
// Lg1 = 6.6666668653e-01f, /* 0x3F2AAAAB */
// Lg2 = 4.0000000596e-01f, /* 0x3ECCCCCD */
// Lg3 = 2.8571429849e-01f, /* 0x3E924925 */
// Lg4 = 2.2222198546e-01f, /* 0x3E638E29 */
// Lg5 = 1.8183572590e-01f, /* 0x3E3A3325 */
// Lg6 = 1.5313838422e-01f, /* 0x3E1CD04F */
// Lg7 = 1.4798198640e-01f;
const LN2_HI: f32 = 6.9313812256e-01f32; // 0x3f317180
const LN2_LO: f32 = 9.0580006145e-06f32; // 0x3717f7d1
const TWO25: f32 = 3.355443200e+07f32;  // 0x4c000000
const LG1: f32 = 6.6666668653e-01f32; // 0x3F2AAAAB
const LG2: f32 = 4.0000000596e-01f32; // 0x3ECCCCCD
const LG3: f32 = 2.8571429849e-01f32; // 0x3E924925
const LG4: f32 = 2.2222198546e-01f32; // 0x3E638E29
const LG5: f32 = 1.8183572590e-01f32; // 0x3E3A3325
let (hfsq, f, s, z, R, w, t1, t2, dk): (f32, f32, f32, f32, f32, f32, f32, f32, f32);
const zero : f32 = 0.0 ;

let mut k: i32;
let mut ix: i32;
let mut i: i32;
let mut j: i32;) -> f32 { 
// float hfsq, f, s, z, R, w, t1, t2, dk;
break 

// int32_t k, ix, i, j;
break 

loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
ix 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



k = 0 ;


if 
FLT_UWORD_IS_ZERO ( 

ix 
& 
0x7fffffff 

) 
{ 

__raise_div_by_zerof ( -1.0 ) 

/* log(+-0)=-inf */
}



if 
FLT_UWORD_IS_NAN ( 

ix 
& 
0x7fffffff 

) 
{ /* x = NaN */

return x + x ;

}



if 
ix < 0 
{ 

__raise_invalidf ( ) 

/* log(-#) = NaN */
}



if 
FLT_UWORD_IS_INFINITE ( ix ) 
{ /* x = +Inf */

return x + x ;

}



if 
FLT_UWORD_IS_SUBNORMAL ( ix ) 
{ 
k -= 25 ;


x *= two25 ;

/* subnormal number, scale up x */

loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
ix 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


}



k += 

( 

ix 
>> 
23 

) 
- 
127 

;


ix &= 
0x007fffff 
;



i 
= 

( 

ix 
+ 
( 

0x95f64 
<< 
3 

) 

) 
& 
0x800000 

;


loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

ix 
| 
( 

i 
^ 
0x3f800000 

) 

) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* normalize x or x/2 */

k += 
( 

i 
>> 
23 

) 
;


f = x - 1.0 ;


if 

( 

0x007fffff 
& 
( 
15 + ix 
) 

) 
< 
16 

{ /* |f| < 2**-20 */

if 
f == zero 
{ 
if 
k == 0 
{ 
return zero ;

}



else { 

dk 
= 

k 
as f32 
;




dk * ln2_hi 
+ 
dk * ln2_lo 


}


}




R 
= 

f * f 
* 
( 

0.5 
- 
0.33333333333333333 * f 

) 

;


if 
k == 0 
{ 
return f - R ;

}



else { 

dk 
= 

k 
as f32 
;




dk * ln2_hi 
- 
( 

( 

R 
- 
dk * ln2_lo 

) 
- 
f 

) 


}


}




s 
= 

f 
/ 
( 
2.0 + f 
) 

;



dk 
= 

k 
as f32 
;


z = s * s ;



i 
= 

ix 
- 
( 

0x6147a 
<< 
3 

) 

;


w = z * z ;



j 
= 

( 

0x6b851 
<< 
3 

) 
- 
ix 

;



t1 
= 

w 
* 
( 

Lg2 
+ 

w 
* 
( 

Lg4 
+ 
w * Lg6 

) 


) 

;



t2 
= 

z 
* 
( 

Lg1 
+ 

w 
* 
( 

Lg3 
+ 

w 
* 
( 

Lg5 
+ 
w * Lg7 

) 


) 


) 

;


i |= 
j 
;


R = t2 + t1 ;


if 
i 
> 
0 
{ 

hfsq 
= 
0.5 
* 
f 
* 
f 
;


if 
k == 0 
{ 


f 
- 
( 

hfsq 
- 

s 
* 
( 
hfsq + R 
) 


) 


}



else { 


dk * ln2_hi 
- 
( 

( 

hfsq 
- 
( 


s 
* 
( 
hfsq + R 
) 

+ 
dk * ln2_lo 

) 

) 
- 
f 

) 


}


}



else { 
if 
k == 0 
{ 


f 
- 

s 
* 
( 
f - R 
) 



}



else { 


dk * ln2_hi 
- 
( 

( 


s 
* 
( 
f - R 
) 

- 
dk * ln2_lo 

) 
- 
f 

) 


}


}


}


