#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathf::internal::trigf_c::__cosf;
use crate::libm::mathf::internal::trigf_c::__rem_pio2f;
use crate::libm::mathf::internal::trigf_c::__sinf;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

pub fn sinf ( 
x : f32 
) -> f32 { 
// float y[2], z = 0.0f;
let mut y: [f32; 2] = [0.0; 2];
let mut z: f32 = 0.0; 

let n : int32_t = Default :: default ( ) ;
let ix : int32_t = Default :: default ( ) ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
ix 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* |x| ~< pi/4 */

ix &= 
0x7fffffff 
;


if 
ix 
<= 
0x3f490fd8 
{ 
if 
ix < 0x39800000 
{ /* if x < 2**-12 */

if 
FLT_UWORD_IS_ZERO ( ix ) 
{ /* return x inexact except 0 */

return x ;

}



else { 

__raise_inexactf ( x ) 

}


}




__sinf ( 
x , 

z , 

0 
) 

}


/* sin(Inf or NaN) is NaN */

else if 
! 
FLT_UWORD_IS_FINITE ( ix ) 

{ 
if 
__builtin_isnan ( x ) 
{ 
return x + x ;

}



else { 

__raise_invalidf ( ) 

}


}


/* argument reduction needed */

else { 
n = __rem_pio2f ( 
x , 

y 
) ;


match 

n 
& 
3 

{ 
0 => { 

__sinf ( 
y [ 0 ] 

, 

y [ 1 ] 

, 

1 
) 

}



1 => { 

__cosf ( 
y [ 0 ] 

, 

y [ 1 ] 
) 

}



unsafe { -__sinf(y[0], y[1], 1) }break 

}


_ => { 

// -__cosf(y[0], y[1])
-__cosf(y[0], y[1]) 

}

}


}





