#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::ieee_float_shape_type;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

const two25 : f32 = 3.3554432000e+07 ;

/* 0x4c000000 */

pub fn frexpf ( 
x : f32 , 

// int *eptr
let mut eptr: *mut i32 = std::ptr::null_mut(); 
) -> f32 { 
let _xexp : i32 = 0 ;


let hx : int32_t = Default :: default ( ) ;
let ix : int32_t = Default :: default ( ) ;


assert ! ( 

eptr 
!= 
Some ( 
0 
. unwrap ( ) as std :: rc :: Rc < dyn std :: any :: Any > ) 

) ;


if 

eptr 
== 
Some ( 
0 
. unwrap ( ) as std :: rc :: Rc < dyn std :: any :: Any > ) 

{ 

eptr 
= 
& 
_xexp 

;

}



loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




ix 
= 

0x7fffffff 
& 
hx 

;




eptr 

= 
0 
;


if 

! 
FLT_UWORD_IS_FINITE ( ix ) 

|| 
FLT_UWORD_IS_ZERO ( ix ) 

{ 
return x + x ;

/* 0,inf,nan */
}



if 
FLT_UWORD_IS_SUBNORMAL ( ix ) 
{ /* subnormal */

x *= two25 ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




ix 
= 

hx 
& 
0x7fffffff 

;




eptr 

= 
-25 
;

}



// *eptr += (ix >> 23) - 126;
*eptr += ((ix >> 23) - 126) as isize; 


hx 
= 

( 

hx 
& 
0x807fffff 

) 
| 
0x3f000000 

;


loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 
hx 
) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



return x ;

}


