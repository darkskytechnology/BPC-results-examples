#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_overflowf;
use crate::libm::common::tools_h::__raise_underflowf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathf::frexpf_c::two25;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// two25 = 3.355443200e+07f, /* 0x4c000000 */
// twom25 = 2.9802322388e-08f;
const TWO25: f32 = 3.355443200e+07f; // 0x4c000000
const TWOM25: f32 = 2.9802322388e-08f; 
/* 0x33000000 */

pub fn scalblnf ( 
let n: i64;break 
) -> f32 { 
let k : int32_t = Default :: default ( ) ;
let ix : int32_t = Default :: default ( ) ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
ix 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




k 
= 

( 

ix 
& 
0x7f800000 

) 
>> 
23 

;

/* extract exponent */

if 
k == 0 
{ /* 0 or subnormal x */

if 

( 

ix 
& 
0x7fffffff 

) 
== 
0 

{ 
return x ;

/* +-0 */
}



x *= two25 ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
ix 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




k 
= 

( 

( 

ix 
& 
0x7f800000 

) 
>> 
23 

) 
- 
25 

;

}



if 
k == 0xff 
{ 
return x + x ;

/* NaN or Inf */
}



if 
n 
> 
50000 
{ 

__raise_overflowf ( x ) 

/*overflow*/
}



k = k + n ;


if 
k 
> 
0xfe 
{ 

__raise_overflowf ( x ) 

/*overflow*/
}



if 
n < -50000 
{ 

__raise_underflowf ( x ) 

/*underflow*/
}



if 
k 
> 
0 
{ /* normal result */

loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

( 

ix 
& 
0x807fffff 

) 
| 
( 

k 
<< 
23 

) 

) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



return x ;

}



if 
k 
<= 
-25 
{ 

__raise_underflowf ( x ) 

/*underflow*/
}



k += 25 ;

/* subnormal result */

loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

( 

ix 
& 
0x807fffff 

) 
| 
( 

k 
<< 
23 

) 

) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



return x * twom25 ;

}


