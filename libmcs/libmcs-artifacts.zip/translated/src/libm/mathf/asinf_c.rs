#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::include::math_h::fabsf;
use crate::libm::include::math_h::sqrtf;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::acosd_c::pS0;
use crate::libm::mathd::acosd_c::pS1;
use crate::libm::mathd::acosd_c::pS2;
use crate::libm::mathd::acosd_c::pS3;
use crate::libm::mathd::acosd_c::pS4;
use crate::libm::mathd::acosd_c::pS5;
use crate::libm::mathd::acosd_c::pio2_hi;
use crate::libm::mathd::acosd_c::pio2_lo;
use crate::libm::mathd::acosd_c::qS1;
use crate::libm::mathd::acosd_c::qS2;
use crate::libm::mathd::acosd_c::qS3;
use crate::libm::mathd::acosd_c::qS4;
use crate::libm::mathd::asind_c::pio4_hi;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// one = 1.0000000000e+00f, /* 0x3F800000 */
// pio2_hi = 1.57079637050628662109375f,
// pio2_lo = -4.37113900018624283e-8f,
// pio4_hi = 0.785398185253143310546875f,
// /* coefficient for R(x^2) */
// pS0 = 1.6666667163e-01f, /* 0x3e2aaaab */
// pS1 = -3.2556581497e-01f, /* 0xbea6b090 */
// pS2 = 2.0121252537e-01f, /* 0x3e4e0aa8 */
// pS3 = -4.0055535734e-02f, /* 0xbd241146 */
// pS4 = 7.9153501429e-04f, /* 0x3a4f7f04 */
// pS5 = 3.4793309169e-05f, /* 0x3811ef08 */
// qS1 = -2.4033949375e+00f, /* 0xc019d139 */
// qS2 = 2.0209457874e+00f, /* 0x4001572d */
// qS3 = -6.8828397989e-01f, /* 0xbf303361 */
// qS4 = 7.7038154006e-02f;
static ONE: f32 = 1.0000000000e+00f32; // 0x3F800000
static PIO2_HI: f32 = 1.57079637050628662109375f32;
static PIO2_LO: f32 = -4.37113900018624283e-8f32;
static PIO4_HI: f32 = 0.785398185253143310546875f32;
// coefficient for R(x^2)
let (mut t, mut w, mut p, mut q, mut c, mut r, mut s): (f32, f32, f32, f32, f32, f32, f32);static PS3: f32 = -4.0055535734e-02f32; // 0xbd241146
static PS4: f32 = 7.9153501429e-04f32; // 0x3a4f7f04
static PS5: f32 = 3.4793309169e-05f32; // 0x3811ef08
static QS1: f32 = -2.4033949375e+00f32; // 0xc019d139
static QS2: f32 = 2.0209457874e+00f32; // 0x4001572d
static QS3: f32 = -6.8828397989e-01f32; // 0xbf303361
static QS4: f32 = 7.7038154006e-01f32; // 0x3f4c4229 
/* 0x3d9dc62e */

pub fn asinf ( 
x : f32 
) -> f32 { 
// float t, w, p, q, c, r, s;
break 

let hx : int32_t = Default :: default ( ) ;
let ix : int32_t = Default :: default ( ) ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




ix 
= 

hx 
& 
0x7fffffff 

;


if 
ix == 0x3f800000 
{ /* asin(1)=+-pi/2 with inexact */



x * pio2_hi 
+ 
x * pio2_lo 


}



else if 
ix 
> 
0x3f800000 
{ /* |x|>= 1 */

if 
__builtin_isnan ( x ) 
{ 
return x + x ;

}




__raise_invalidf ( ) 

/* asin(|x|>1) is NaN */
}



else if 
ix < 0x3f000000 
{ /* |x|<0.5 */

if 
ix < 0x32000000 
{ /* if |x| < 2**-27 */

if 
FLT_UWORD_IS_ZERO ( ix ) 
{ /* return x inexact except 0 */

return x ;

}



else { 

__raise_inexactf ( x ) 

}


}



else { 
t = x * x ;



p 
= 

t 
* 
( 

pS0 
+ 

t 
* 
( 

pS1 
+ 

t 
* 
( 

pS2 
+ 

t 
* 
( 

pS3 
+ 

t 
* 
( 

pS4 
+ 
t * pS5 

) 


) 


) 


) 


) 

;



q 
= 

one 
+ 

t 
* 
( 

qS1 
+ 

t 
* 
( 

qS2 
+ 

t 
* 
( 

qS3 
+ 
t * qS4 

) 


) 


) 


;


w = p / q ;




x 
+ 
}}


}



else { /* No action required */

// }
break 
/* 1> |x|>= 0.5 */


w 
= 

one 
- 
x . abs ( ) 

;


t = w * 0.5 ;



p 
= 

t 
* 
( 

pS0 
+ 

t 
* 
( 

pS1 
+ 

t 
* 
( 

pS2 
+ 

t 
* 
( 

pS3 
+ 

t 
* 
( 

pS4 
+ 
t * pS5 

) 


) 


) 


) 


) 

;



q 
= 

one 
+ 

t 
* 
( 

qS1 
+ 

t 
* 
( 

qS2 
+ 

t 
* 
( 

qS3 
+ 
t * qS4 

) 


) 


) 


;


s = t . sqrt ( ) ;


if 
ix 
>= 
0x3F79999A 
{ /* if |x| > 0.975 */

w = p / q ;



t 
= 

pio2_hi 
- 
( 


2.0 
* 
( 

s 
+ 
s * w 

) 

- 
pio2_lo 

) 

;

}



else { 
let iw : i32 ;


w = s ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
w 
) 
;



( 
iw 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

iw 
& 
0xfffff000 

) 
;



( 
w 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




c 
= 

( 

t 
- 
w * w 

) 
/ 
( 
s + w 
) 

;


r = p / q ;



p 
= 

2.0 
* 
s 
* 
r 
- 
( 

pio2_lo 
- 
2.0 * c 

) 

;



q 
= 

pio4_hi 
- 
2.0 * w 

;



t 
= 

pio4_hi 
- 
( 
p - q 
) 

;

}



if 
hx 
> 
0 
{ 
return t ;

}



else { 

- t 

}








