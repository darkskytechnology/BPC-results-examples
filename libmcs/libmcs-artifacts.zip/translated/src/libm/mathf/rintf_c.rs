#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathf::llrintf_c::TWO23;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */

// static const float
// TWO23[2] = {
//      8.3886080000e+06f, /* 0x4b000000 */
//     -8.3886080000e+06f, /* 0xcb000000 */
// };
static TWO23: [f32; 2] = [
    8.388608e6f32, // 0x4b000000
    -8.388608e6f32, // 0xcb000000
]; 

pub fn rintf ( 
x : f32 
) -> f32 { 
let _i0 : int32_t = Default :: default ( ) ;
let _j0 : int32_t = Default :: default ( ) ;
let sx : int32_t = Default :: default ( ) ;


let i : uint32_t = Default :: default ( ) ;
let _i1 : uint32_t = Default :: default ( ) ;
let ix : uint32_t = Default :: default ( ) ;

use std::sync::atomic::{AtomicU32, Ordering};

static W: AtomicU32 = AtomicU32::new(0);

fn get_w() -> f32 {
    f32::from_bits(W.load(Ordering::SeqCst))
}

fn set_w(value: f32) {
    W.store(value.to_bits(), Ordering::SeqCst);
}
// volatile float w;
break 

loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
_i0 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




sx 
= 

( 

_i0 
>> 
31 

) 
& 
1 

;



ix 
= 
( 

_i0 
& 
0x7fffffff 

) 
;



_j0 
= 

( 

ix 
>> 
23 

) 
- 
0x7f 

;


if 
_j0 < 23 
{ 
if 
FLT_UWORD_IS_ZERO ( ix ) 
{ 
return x ;

}



if 
_j0 < 0 
{ 

_i1 
= 
( 

_i0 
& 
0x07fffff 

) 
;


_i0 &= 
0xfff00000 
;


_i0 |= 

( 

( 

_i1 
| 
- _i1 

) 
>> 
9 

) 
& 
0x400000 

;


loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 
_i0 
) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




w 
= 

TWO23 [ sx ] 
+ 
x 

;



t 
= 

w 
- 
TWO23 [ sx ] 

;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
t 
) 
;



( 
_i0 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

( 

_i0 
& 
0x7fffffff 

) 
| 
( 

sx 
<< 
31 

) 

) 
;



( 
t 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



return t ;

}



else { 

i 
= 

( 
0x007fffff 
) 
>> 
_j0 

;


if 

( 
_i0 & i 
) 
== 
0 

{ 
return x ;

/* x is integral */
}



i >>= 
1 
;


if 

( 
_i0 & i 
) 
!= 
0 

{ 

_i0 
= 

( 

_i0 
& 
( 
! i 
) 

) 
| 
( 

( 
0x200000 
) 
>> 
_j0 

) 

;

}


}


}



else { 
if 
! 
FLT_UWORD_IS_FINITE ( ix ) 

{ 
return x + x ;

/* inf or NaN */
}



else { 
return x ;

/* x is integral */
}


}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 
_i0 
) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




w 
= 

TWO23 [ sx ] 
+ 
x 

;




w 
- 
TWO23 [ sx ] 


}


