#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::include::math_h::fabsf;
use crate::libm::include::math_h::fmodf;
use crate::libm::mathd::atan2d_c::zero;
use crate::translate_bpc_vpp;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */

const zero : f32 = 0.0 ;


pub fn remquof ( 
x : f32 , 

y : f32 , 

// int *quo
let quo: *mut i32; 
) -> f32 { 
let _quo : i32 = 0 ;


let hx : int32_t = Default :: default ( ) ;
let hy : int32_t = Default :: default ( ) ;


let sx : uint32_t = Default :: default ( ) ;
let sq : uint32_t = Default :: default ( ) ;


let y_half : f32 = Default :: default ( ) ;


assert ! ( 

quo 
!= 
Some ( 
0 
. unwrap ( ) as std :: rc :: Rc < dyn std :: any :: Any > ) 

) ;


if 

quo 
== 
Some ( 
0 
. unwrap ( ) as std :: rc :: Rc < dyn std :: any :: Any > ) 

{ 

quo 
= 
& 
_quo 

;

}





quo 

= 
0 
;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
y 
) 
;



( 
hy 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




sx 
= 

hx 
& 
0x80000000 

;



sq 
= 

sx 
^ 
( 

hy 
& 
0x80000000 

) 

;


hy &= 
0x7fffffff 
;


hx &= 
0x7fffffff 
;

/* purge off exception values */

if 

FLT_UWORD_IS_NAN ( hx ) 
|| 
FLT_UWORD_IS_NAN ( hy ) 

{ /* x or y is NaN */

return x + y ;

}



else if 

FLT_UWORD_IS_ZERO ( hy ) 
|| 
FLT_UWORD_IS_INFINITE ( hx ) 

{ /* y is 0 or x is inf */


__raise_invalidf ( ) 

}



else { /* No action required */

// }
} 

if 
hy 
<= 
0x7dffffff 
{ 
x = fmodf ( 
x , 

8 * y 
) ;

/* now x < 8y */
}



if 

( 
hx - hy 
) 
== 
0 

{ 


quo 

= 
if 
sq 
{ 
-1 
}

else { 
1 
}


;


return zero * x ;

}



x = x . abs ( ) ;


y = y . abs ( ) ;


_quo = 0 ;


if 

x 
>= 
4 * y 

{ 
x -= 
4 * y 
;


_quo += 4 ;

}



if 

x 
>= 
2 * y 

{ 
x -= 
2 * y 
;


_quo += 2 ;

}



if 
hy < 0x01000000 
{ 
if 

x + x 
> 
y 

{ 
x -= y ;


translate_bpc_vpp ! ( 
_quo 
) ;


if 

x + x 
>= 
y 

{ 
x -= y ;


translate_bpc_vpp ! ( 
_quo 
) ;

}


}


}



else { 
y_half = 0.5 * y ;


if 
x 
> 
y_half 
{ 
x -= y ;


translate_bpc_vpp ! ( 
_quo 
) ;


if 
x 
>= 
y_half 
{ 
x -= y ;


translate_bpc_vpp ! ( 
_quo 
) ;

}


}


}



_quo &= 
0x7 
;




quo 

= 
if 
sq 
{ 
- _quo 
}

else { 
_quo 
}


;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 
hx ^ sx 
) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



return x ;







