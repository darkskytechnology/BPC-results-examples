#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::machine::sparc_v8::mathf::sqrtf_c::sqrtf;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::acoshd_c::ln2;
use crate::libm::mathf::log1pf_c::log1pf;
use crate::libm::mathf::logf_c::logf;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// one = 1.0f,
// ln2 = 6.9314718246e-01f;
const ONE: f32 = 1.0;
const LN2: f32 = 6.9314718246e0;
/* 0x3f317218 */

pub fn acoshf(x: f32) -> f32 {
    let t: f32 = Default::default();

    let hx: i32;

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (hx) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    if hx < 0x3f800000 {
        /* x < 1 */

        if __builtin_isnan(x) {
            return x + x;
        } else {
            __raise_invalidf()
        }
    } else if hx >= 0x4d800000 {
        /* x > 2**28 */

        if !FLT_UWORD_IS_FINITE(hx) {
            /* x is +inf or NaN */

            return x + x;
        } else {
            logf(x) + ln2

            /* acosh(huge)=log(2x) */
        }
    } else if hx == 0x3f800000 {
        return 0.0;

    /* acosh(1) = 0 */
    } else if hx > 0x40000000 {
        /* 2**28 > x > 2 */

        t = x * x;

        logf(2.0 * x - one / (x + sqrtf(t - one)))
    } else {
        /* 1<x<2 */

        t = x - one;

        log1pf(t + sqrtf(2.0 * t + t * t))
    }
}
