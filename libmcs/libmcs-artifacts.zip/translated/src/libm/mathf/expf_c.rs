#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::__raise_overflowf;
use crate::libm::common::tools_h::__raise_underflowf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathd::expd_c::P1;
use crate::libm::mathd::expd_c::P2;
use crate::libm::mathd::expd_c::P3;
use crate::libm::mathd::expd_c::P4;
use crate::libm::mathd::expd_c::P5;
use crate::libm::mathd::expd_c::halF;
use crate::libm::mathd::expd_c::invln2;
use crate::libm::mathd::expd_c::ln2HI;
use crate::libm::mathd::expd_c::ln2LO;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// one = 1.0f,
// zero = 0.0f,
// halF[2] = { 0.5f, -0.5f},
// twom100 = 7.8886090522e-31f, /* 2**-100=0x0d800000 */
// ln2HI[2] = { 6.9314575195e-01f, /* 0x3f317200 */
//              -6.9314575195e-01f, /* 0xbf317200 */
// },
// ln2LO[2] = { 1.4286067653e-06f, /* 0x35bfbe8e */
//              -1.4286067653e-06f, /* 0xb5bfbe8e */
// },
// invln2 = 1.4426950216e+00f, /* 0x3fb8aa3b */
// P1 = 1.6666667163e-01f, /* 0x3e2aaaab */
// P2 = -2.7777778450e-03f, /* 0xbb360b61 */
// P3 = 6.6137559770e-05f, /* 0x388ab355 */
// P4 = -1.6533901999e-06f, /* 0xb5ddea0e */
// P5 = 4.1381369442e-08f;
static ONE: f32 = 1.0;
static ZERO: f32 = 0.0;
static HALF: [f32; 2] = [0.5, -0.5];
static TWOM100: f32 = 7.8886090522e-31; // 2**-100=0x0d800000
static LN2HI: [f32; 2] = [6.9314575195e-01, -6.9314575195e-01]; // 0x3f317200, 0xbf317200
static LN2LO: [f32; 2] = [1.4286067653e-06, -1.4286067653e-06]; // 0x35bfbe8e, 0xb5bfbe8e
let mut y: f32;
let mut hi: f32;
let mut lo: f32;
let mut k: i32 = 0;
let xsb: i32;
let sx: i32;static P5: f32 = 4.1381369; 
/* 0x3331bb4c */

pub fn expf ( 
x : f32 
) -> f32 { /* default IEEE float exp */

// float y, hi, lo, c, t;
break 

// int32_t k = 0, xsb, sx;
break 

let hx : u32 ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
sx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




xsb 
= 

( 

sx 
>> 
31 

) 
& 
1 

;

/* sign bit of x */


hx 
= 

sx 
& 
0x7fffffff 

;

/* high word of |x| */
/* filter out non-finite argument */

if 
FLT_UWORD_IS_NAN ( hx ) 
{ 
return x + x ;

/* NaN */
}



if 
FLT_UWORD_IS_INFINITE ( hx ) 
{ 

if 
( 
xsb == 0 
) 
{ 
x 
}

else { 
zero 
}



}


/* exp(+-inf)={inf,0} */

if 
sx 
> 
FLT_UWORD_LOG_MAX 
{ 

__raise_overflowf ( one ) 

/* overflow */
}



if 

sx < 0 
&& 
hx 
> 
FLT_UWORD_LOG_MIN 

{ 

__raise_underflowf ( zero ) 

/* underflow */
}


/* argument reduction */

if 
hx 
> 
0x3eb17218 
{ /* if  |x| > 0.5 ln2 */

if 
hx < 0x3F851592 
{ /* and |x| < 1.5 ln2 */


hi 
= 

x 
- 
ln2HI [ xsb ] 

;



lo 
= 
ln2LO [ xsb ] 
;



k 
= 
1 
- 
xsb 
- 
xsb 
;

}



else { 

k 
= 

invln2 * x 
+ 
halF [ xsb ] 

;


t = k ;



hi 
= 

x 
- 

t 
* 
ln2HI [ 0 ] 


;

/* t*ln2HI is exact here */


lo 
= 

t 
* 
ln2LO [ 0 ] 

;

}



x = hi - lo ;

}



else if 
hx < 0x34000000 
{ /* when |x|<2**-23 */

if 
x == 0.0 
{ /* return 1 inexact except 0 */

return one ;

}



else { 

__raise_inexactf ( 
}}


}



else { /* No action required */

// }
break 
/* x is now in primary range */

t = x * x ;



c 
= 

x 
- 

t 
* 
( 

P1 
+ 

t 
* 
( 

P2 
+ 

t 
* 
( 

P3 
+ 

t 
* 
( 

P4 
+ 
t * P5 

) 


) 


) 


) 


;


if 
k == 0 
{ 


one 
- 
( 


( 
x * c 
) 
/ 
( 
c - 2.0 
) 

- 
x 

) 


}



else { 

y 
= 

one 
- 
( 

( 

lo 
- 

( 
x * c 
) 
/ 
( 
2.0 - c 
) 


) 
- 
hi 

) 

;

}



if 
k 
>= 
-125 
{ 
let hy : u32 ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
y 
) 
;



( 
hy 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

hy 
+ 
( 

( 

k 
as uint32_t 
) 
<< 
23 

) 

) 
;



( 
y 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* add k to y's exponent */

return y ;

}



else { 
let hy : u32 ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
y 
) 
;



( 
hy 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

hy 
+ 
( 

( 


k 
as uint32_t 
+ 
100 

) 
<< 
23 

) 

) 
;



( 
y 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* add k to y's exponent */

return y * twom100 ;

}








