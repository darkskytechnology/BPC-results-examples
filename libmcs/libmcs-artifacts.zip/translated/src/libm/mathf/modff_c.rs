#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::ieee_float_shape_type;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

pub fn modff ( 
x : f32 , 

// float *iptr
let mut iptr: *mut f32; 
) -> f32 { 
let _xi : f32 = 0.0 ;


let _i0 : int32_t = Default :: default ( ) ;
let _j0 : int32_t = Default :: default ( ) ;


let i : u32 ;


assert ! ( 

iptr 
!= 
Some ( 
0 
. unwrap ( ) as std :: rc :: Rc < dyn std :: any :: Any > ) 

) ;


if 

iptr 
== 
Some ( 
0 
. unwrap ( ) as std :: rc :: Rc < dyn std :: any :: Any > ) 

{ 

iptr 
= 
& 
_xi 

;

}



loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
_i0 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




_j0 
= 

( 

( 

_i0 
>> 
23 

) 
& 
0xff 

) 
- 
0x7f 

;

/* exponent of x */

if 
_j0 < 23 
{ /* integer part in x */

if 
_j0 < 0 
{ /* |x|<1 */

loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

_i0 
& 
0x80000000 

) 
;



( 

iptr 

) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* *iptr = +-0 */

return x ;

}



else { 

i 
= 

( 
0x007fffff 
) 
>> 
_j0 

;


if 

( 
_i0 & i 
) 
== 
0 

{ /* x is integral */



iptr 

= 
x 
;


loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

_i0 
& 
0x80000000 

) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* return +-0 */

return x ;

}



else { 
loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

_i0 
& 
( 
! i 
) 

) 
;



( 

iptr 

) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}





x 
- 

iptr 



}


}


}



else { /* no fraction part */



iptr 

= 
x 
;


if 
__builtin_isnan ( x ) 
{ 



iptr 

= 
x + x 


/* x is NaN, return NaN */
}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

_i0 
& 
0x80000000 

) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* return +-0 */

return x ;

}


}


