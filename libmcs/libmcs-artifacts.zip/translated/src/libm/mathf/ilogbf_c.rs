#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

pub fn ilogbf(x: f32) -> i32 {
    let hx: int32_t = Default::default();
    let ix: int32_t = Default::default();

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (hx) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    hx &= 0x7fffffff;

    if FLT_UWORD_IS_ZERO(hx) {
        let _ = __raise_invalidf();

        -2147483647 - -2147483647

        /* ilogb(0) = special case error */
    } else if FLT_UWORD_IS_SUBNORMAL(hx) {
        {
            ix = -126;

            // hx <<= 8
            hx <<= 8;
        };
        while hx > 0 {
            ix -= 1;

            // hx <<= 1
            hx <<= 1;
        }

        return ix;
    } else if FLT_UWORD_IS_FINITE(hx) {
        (hx >> 23) - 127
    } else if FLT_UWORD_IS_NAN(hx) {
        let _ = __raise_invalidf();

        -2147483647 - -2147483647

        /* NAN */
    } else {
        let _ = __raise_invalidf();

        return 0x7fffffff;

        /* infinite */
    }
}
