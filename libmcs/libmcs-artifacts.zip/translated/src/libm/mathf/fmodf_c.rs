#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathd::fmodd_c::Zero;
use crate::translate_bpc_vmm;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */
/*
 * fmodf(x,y)
 * Return x mod y in exact arithmetic
 * Method: shift and subtract
 */

// static const float Zero[] = {0.0f, -0.0f,};
const ZERO: [f32; 2] = [0.0, -0.0]; 

pub fn fmodf ( 
x : f32 , 

y : f32 
) -> f32 { 
// int32_t n, hx, hy, hz, ix, iy, sx, i;
let mut n: i32;
let mut hx: i32;
let mut hy: i32;
let mut hz: i32;
let mut ix: i32;
let mut iy: i32;
let mut sx: i32;
let mut i: i32; 

loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
y 
) 
;



( 
hy 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




sx 
= 

hx ^= sx;
;

/* sign of x */

// hx ^= sx;
break 
/* |x| */

hy &= 
0x7fffffff 
;

/* |y| */
/* purge off exception values */

if 

! 
FLT_UWORD_IS_FINITE ( hx ) 

|| 
! 
FLT_UWORD_IS_FINITE ( hy ) 


{ /* x or y is +-Inf/NaN */

if 
FLT_UWORD_IS_INFINITE ( hx ) 
{ /* x is +-Inf */


__raise_invalidf ( ) 

}



else if 

FLT_UWORD_IS_NAN ( hx ) 
|| 
FLT_UWORD_IS_NAN ( hy ) 

{ /* x or y is NaN */

return x + y ;

}
fn main() {
    // The original C code seems to be incomplete or malformed.
    // Please provide the complete C code for accurate translation.
}else { /* No action required */

// }
break 
}


}



else if 
FLT_UWORD_IS_ZERO ( hy ) 
{ /* y is +-0 */


__raise_invalidf ( ) 

}
fn main() {
    // The original C code seems to be incomplete or malformed.
    // Assuming the function is empty or the closing brace is misplaced.
    // Here's an empty Rust function as a placeholder.
}else { /* No action required */

// }
break 

if 
hx 
< 
hy 
{ 
return x ;

/* |x|<|y| return x */
}



if 
hx == hy 
{ 

Zero [ 


sx 
as uint32_t 
>> 
31 

] 

/* |x|=|y| return x*0*/
}


/* Note: y cannot be zero if we reach here. */
/* determine ix = ilogb(x) */

if 
FLT_UWORD_IS_SUBNORMAL ( hx ) 
{ /* subnormal x */


{ 
ix = -126 
;


i 
= 
( 

hx 
<< 
8 

) 

}


;
while 
i 
i <<= 1;ix -= 1 ;


// i <<= 1
break 
;
}


}



else { 

ix 
= 

( 

hx 
>> 
23 

) 
- 
127 

;

}


/* determine iy = ilogb(y) */

if 
FLT_UWORD_IS_SUBNORMAL ( hy ) 
{ /* subnormal y */


{ 
iy = -126 
;


i 
= 
( 

hy 
<< 
8 

) 

}


;
while 
i 
>= 
0 
{ 
i <<= 1;// i <<= 1
break 
;
}


}



else { 

iy 
= 

( 

hy 
>> 
23 

) 
- 
127 

;

}


/* set up {hx,lx}, {hy,ly} and align y to x */

if 
ix 
>= 
-126 
{ 

hx 
= 

0x00800000 
| 
( 

0x007fffff 
& 
hx 

) 

;

}



else { /* subnormal x, shift x to normal */

n = -126 - ix ;



hx 
= 
hx << n 
;

}



if 
iy 
>= 
-126 
{ 

hy 
= 

0x00800000 
| 
( 

0x007fffff 
& 
hy 

) 

;

}



else { /* subnormal y, shift y to normal */

n = -126 - iy ;



hy 
= 
hy << n 
;

}


/* fix point fmod */

n = ix - iy ;


while 
( 

translate_bpc_vmm ! ( n ) 
> 
0 

) 
{ 
hz = hx - hy ;


if 
hz < 0 
{ 
hx = hx + hx ;

}



else { 
if 
hz == 0 
{ /* return sign(x)*0 */


Zero [ 


sx 
as uint32_t 
>> 
31 

] 

}



hx = hz + hz ;

}


}



hz = hx - hy ;


if 
hz 
>= 
0 
{ 
hx = hz ;

}


/* convert back to floating value and restore the sign */

if 
hx == 0 
{ /* return sign(x)*0 */


Zero [ 


sx 
as uint32_t 
>> 
31 

] 

}



while hx < 0x00800000 { /* normalize x */

hx = hx + hx ;


iy -= 1 ;

}



if 
iy 
>= 
-126 
{ /* normalize output */


hx 
= 
( 

( 
hx - 0x00800000 
) 
| 
( 

( 
iy + 127 
) 
<< 
23 

) 

) 
;


loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 
hx | sx 
) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


}



else { /* subnormal output */

n = -126 - iy ;


hx >>= 
n 
;


loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 
hx | sx 
) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}






return x ;

/* exact output */






