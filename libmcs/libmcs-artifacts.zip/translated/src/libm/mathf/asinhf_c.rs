#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::include::math_h::fabsf;
use crate::libm::include::math_h::log1pf;
use crate::libm::include::math_h::logf;
use crate::libm::include::math_h::sqrtf;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::acoshd_c::ln2;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// one = 1.0000000000e+00f, /* 0x3F800000 */
// ln2 = 6.9314718246e-01f;
static ONE: f32 = 1.0000000000e+00f; // 0x3F800000
static LN2: f32 = 6.9314718246e-01;
/* 0x3f317218 */

pub fn asinhf(x: f32) -> f32 {
    let t: f32 = Default::default();
    let w: f32 = Default::default();

    let hx: int32_t = Default::default();
    let ix: int32_t = Default::default();

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (hx) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    ix = hx & 0x7fffffff;

    if !FLT_UWORD_IS_FINITE(ix) {
        return x + x;

        /* x is inf or NaN */
    }

    if ix < 0x31800000 {
        /* |x|<2**-28 */

        if FLT_UWORD_IS_ZERO(ix) {
            /* return x inexact except 0 */

            return x;
        } else {
            __raise_inexactf(x)
        }
    }

    if ix > 0x4d800000 {
        /* |x| > 2**28 */

        w = logf(x.abs()) + ln2;
    } else if ix > 0x40000000 {
        /* 2**28 > |x| > 2.0 */

        t = x.abs();

        w = logf(2.0 * t + one / (sqrtf(x * x + one) + t));
    } else {
        /* 2.0 > |x| > 2**-28 */

        t = x * x;

        w = log1pf(x.abs() + t / (one + sqrtf(one + t)));
    }

    if hx > 0 {
        return w;
    } else {
        -w
    }
}
