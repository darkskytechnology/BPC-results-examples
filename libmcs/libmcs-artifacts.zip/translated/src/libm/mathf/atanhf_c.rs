#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zerof;
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::include::math_h::log1pf;
use crate::libm::mathd::acosd_c::one;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

const one: f32 = 1.0;

pub fn atanhf(x: f32) -> f32 {
    let t: f32 = Default::default();

    let hx: int32_t = Default::default();
    let ix: int32_t = Default::default();

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (hx) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    ix = hx & 0x7fffffff;

    if ix > 0x3f800000 {
        /* |x|>1 */

        if __builtin_isnan(x) {
            return x + x;
        } else {
            __raise_invalidf()
        }
    }

    if ix == 0x3f800000 {
        __raise_div_by_zerof(x)
    }

    if ix < 0x31800000 {
        /* x<2**-28 */

        if FLT_UWORD_IS_ZERO(ix) {
            /* return x inexact except 0 */

            return x;
        } else {
            __raise_inexactf(x)
        }
    }

    loop {
        let mut sf_u: ieee_float_shape_type = Default::default();

        sf_u.word = (ix);

        (x) = sf_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    if ix < 0x3f000000 {
        /* x < 0.5 */

        t = x + x;

        t = 0.5 * log1pf(t + t * x / (one - x));
    } else {
        t = 0.5 * log1pf((x + x) / (one - x));
    }

    if hx >= 0 {
        return t;
    } else {
        -t
    }
}
