#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::__raise_overflowf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::expd_c::invln2;
use crate::libm::mathd::expm1d_c::Q1;
use crate::libm::mathd::expm1d_c::Q2;
use crate::libm::mathd::expm1d_c::Q3;
use crate::libm::mathd::expm1d_c::Q4;
use crate::libm::mathd::expm1d_c::Q5;
use crate::libm::mathd::expm1d_c::ln2_hi;
use crate::libm::mathd::expm1d_c::ln2_lo;
use crate::libm::mathd::internal::gammad_c::r1;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// one = 1.0f,
// ln2_hi = 6.9313812256e-01f, /* 0x3f317180 */
// ln2_lo = 9.0580006145e-06f, /* 0x3717f7d1 */
// invln2 = 1.4426950216e+00f, /* 0x3fb8aa3b */
// /* scaled coefficients related to expm1 */
// Q1 = -3.3333335072e-02f, /* 0xbd088889 */
// Q2 = 1.5873016091e-03f, /* 0x3ad00d01 */
// Q3 = -7.9365076090e-05f, /* 0xb8a670cd */
// Q4 = 4.0082177293e-06f, /* 0x36867e54 */
// Q5 = -2.0109921195e-07f;
const ONE: f32 = 1.0;
const LN2_HI: f32 = 6.9313812256e-01; // 0x3f317180
const LN2_LO: f32 = 9.0580006145e-06; // 0x3717f7d1
const INVLN2: f32 = 1.4426950216e+00; // 0x3fb8aa3b
// scaled coefficients related to expm1
let mut y: f32;
let mut hi: f32;
let mut lo: f32;
let mut c: f32;
let mut t: f32;
let mut e: f32;
let mut hxs: f32;
let mut hfx: f32;
let mut r1: f32;const Q4: f32 = 4.0082177293e-06; // 0x36867e54
const Q5: f32 = -2.0109921195e-06; // Placeholder for the missing value 
/* 0xb457edbb */

pub fn expm1f ( 
x : f32 
) -> f32 { 
// float y, hi, lo, c, t, e, hxs, hfx, r1;
break 

let k : int32_t = Default :: default ( ) ;
let xsb : int32_t = Default :: default ( ) ;


let hx : u32 ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




xsb 
= 

hx 
& 
0x80000000 

;

/* sign bit of x */

hx &= 
0x7fffffff 
;

/* high word of |x| */
/* filter out huge and non-finite argument */

if 
hx 
>= 
0x4195b844 
{ /* if |x|>=27*ln2 */

if 
FLT_UWORD_IS_NAN ( hx ) 
{ 
return x + x ;

}



if 
FLT_UWORD_IS_INFINITE ( hx ) 
{ 

if 
( 
xsb == 0 
) 
{ 
x 
}

else { 
- one 
}



}


/* exp(+-inf)={inf,-1} */

if 

xsb == 0 
&& 
hx 
> 
FLT_UWORD_LOG_MAX 

{ /* if x>=o_threshold */

fn __raise_inexactf(one: f32) {
    // Function body is not provided, so we cannot translate it.
    // Ensure that the function is safe and does not perform any unsafe operations.
    // If the function body is available, translate it here while ensuring safety.
}/* overflow */
}



if 
xsb 
!= 
0 
{ /* x < -27*ln2, return -1.0 with inexact */


// -__raise_inexactf(one)
break 

}


}


/* argument reduction */

if 
hx 
> 
0x3eb17218 
{ /* if  |x| > 0.5 ln2 */

if 
hx < 0x3F851592 
{ /* and |x| < 1.5 ln2 */

if 
xsb == 0 
{ 
hi = x - ln2_hi ;


lo = ln2_lo ;


k = 1 ;

}



else { 
hi = x + ln2_hi ;



lo 
= 
- ln2_lo 
;


k = -1 ;

}


}



else { 

k 
= 

invln2 * x 
+ 
if 
( 
xsb == 0 
) 
{ 
0.5 
}

else { 
-0.5 
}



;


t = k ;



hi 
= 

x 
- 
t * ln2_hi 

;

/* t*ln2_hi is exact here */

lo = t * ln2_lo ;

}



x = hi - lo ;



c 
= 

( 
hi - x 
) 
- 
lo 

;

}



else if 
hx < 0x33000000 
{ /* when |x|<2**-25, return x */

if 
x == 0.0 
{ 
return x ;

}



else { /* return x with inexact flags when x!=0 */


__raise_inexactf ( x ) 

}


}



else { 
k = 0 ;

}


/* x is now in primary range */

hfx = 0.5 * x ;


hxs = x * hfx ;



r1 
= 

one 
+ 

hxs 
* 
( 

Q1 
+ 

hxs 
* 
( 

Q2 
+ 

hxs 
* 
( 

Q3 
+ 

hxs 
* 
( 

Q4 
+ 
hxs * Q5 

) 


) 


) 


) 


;



t 
= 

3.0 
- 
r1 * hfx 

;



e 
= 

hxs 
* 
( 

( 
r1 - t 
) 
/ 
( 

6.0 
- 
x * t 

) 

) 

;


if 
k == 0 
{ 


x 
- 
( 

x * e 
- 
hxs 

) 


/* c is 0 */
}



else { 

e 
= 
( 


x 
* 
( 
e - c 
) 

- 
c 

) 
;


e -= hxs ;


if 
k == -1 
{ 



0.5 
* 
( 
x - e 
) 

- 
0.5 


}



if 
k == 1 
{ 
if 
x < -0.25 
{ 


-2.0 
* 
( 

e 
- 
( 
x + 0.5 
) 

) 


}



else { 


one 
+ 

2.0 
* 
( 
x - e 
) 



}


}



if 

k 
<= 
-2 
|| 
k 
> 
56 

{ /* suffice to return exp(x)-1 */

let i : i32 ;



y 
= 

one 
- 
( 
e - x 
) 

;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
y 
) 
;



( 
i 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

i 
+ 
( 

( 

k 
as uint32_t 
) 
<< 
23 

) 

) 
;



( 
y 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* add k to y's exponent */

return y - one ;

}



t = one ;


if 
k < 23 
{ 
let i : i32 ;


loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

0x3f800000 
- 
( 

0x1000000 
>> 
k 

) 

) 
;



( 
t 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* t=1-2^-k */


y 
= 

t 
- 
( 
e - x 
) 

;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
y 
) 
;



( 
i 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

i 
+ 
( 

k 
<< 
23 

) 

) 
;



( 
y 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* add k to y's exponent */
}



else { 
let i : i32 ;


loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 
( 

( 
0x7f - k 
) 
<< 
23 

) 
) 
;



( 
t 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* 2^-k */


y 
= 

x 
- 
( 
e + t 
) 

;


y += one ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
y 
) 
;



( 
i 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

i 
+ 
( 

k 
<< 
23 

) 

) 
;



( 
y 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* add k to y's exponent */
}


}



return y ;

}


