#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zerof;
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::mathf::expf_c::expf;
use crate::libm::mathf::floorf_c::floorf;
use crate::libm::mathf::internal::gammaf_c::__lgammaf;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */
/* __tgammaf(x)
 * Float version the Gamma function. Returns gamma(x)
 *
 * Method: See __lgammaf
 */

pub fn tgammaf ( 
x : f32 
) -> f32 { 
let signgam_local : i32 = 0 ;


let y : f32 = 0.0 ;


if 

__builtin_isnan ( x ) 
!= 
0 

{ /* tgamma(NaN) = NaN */

return x + x ;

}



else if 
x == 0.0 
{ /* tgamma(+-0) = +-Inf */


__raise_div_by_zerof ( x ) 

}



else if 


x . floor ( ) 
== 
x 

&& 
x < 0.0 

{ /* tgamma(negative integer, -Inf) = NaN */


__raise_invalidf ( ) 

}



else { /* No action required */

// }
It seems like you've provided an incomplete input. Could you please provide the full C code that you would like to be translated into Rust? 

y = expf ( 
__lgammaf ( 
x , 

& 
signgam_local 

) 
) ;


if 
signgam_local < 0 
{ 

y 
= 
- y 
;

}



return y ;

}





