#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::ieee_float_shape_type;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */
/*
 * copysignf(float x, float y)
 * copysignf(x,y) returns a value with the magnitude of x and
 * with the sign bit of y.
 */

pub fn copysignf(x: f32, y: f32) -> f32 {
    let ix: uint32_t = Default::default();
    let iy: uint32_t = Default::default();

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (ix) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (y);

        (iy) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    loop {
        let mut sf_u: ieee_float_shape_type = Default::default();

        sf_u.word = ((ix & 0x7fffffff) | (iy & 0x80000000));

        (x) = sf_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    return x;
}
