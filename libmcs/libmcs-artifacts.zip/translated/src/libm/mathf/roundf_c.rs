#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::ieee_float_shape_type;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */

pub fn roundf ( 
x : f32 
) -> f32 { 
let w : u32 ;

/* Most significant word, least significant word. */

let exponent_less_127 : i32 ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
w 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* Extract exponent field. */


exponent_less_127 
= 


( 

( 

w 
& 
0x7f800000 

) 
>> 
23 

) 
as int32_t 
- 
127 

;


if 
exponent_less_127 < 23 
{ 
if 
exponent_less_127 < 0 
{ 
w &= 
0x80000000 
;


if 
exponent_less_127 == -1 
{ /* Result is +1.0 or -1.0. */

w |= 
( 


127 
as uint32_t 
<< 
23 

) 
;

}


}



else { 
let exponent_mask : uint32_t = 

0x007fffff 
>> 
exponent_less_127 

;


if 

( 
w & exponent_mask 
) 
== 
0 

{ /* x has an integral value. */

return x ;

}



w += 

0x00400000 
>> 
exponent_less_127 

;


w &= 
! exponent_mask 
;

}


}



else { 
if 
exponent_less_127 == 128 
{ /* x is NaN or infinite. */

return x + x ;

}



else { 
return x ;

}


}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 
w 
) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



return x ;

}


