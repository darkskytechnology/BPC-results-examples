#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zerof;
use crate::libm::common::tools_h::ieee_float_shape_type;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */
/* float logb(float x)
 * return the binary exponent of non-zero x
 * logbf(0) = -inf, raise divide-by-zero floating point exception
 * logbf(+inf|-inf) = +inf (no signal is raised)
 * logbf(NaN) = NaN (no signal is raised)
 * Per C99 recommendation, a NaN argument is returned unchanged.
 */

pub fn logbf(x: f32) -> f32 {
    let hx: int32_t = Default::default();
    let ix: int32_t = Default::default();

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (hx) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    hx &= 0x7fffffff;

    if FLT_UWORD_IS_ZERO(hx) {
        __raise_div_by_zerof(-1.0)

        /* logbf(0) = -inf */
    }

    if FLT_UWORD_IS_SUBNORMAL(hx) {
        {
            ix = -126;

            // hx <<= 8
            hx <<= 8;
        };
        while hx > 0 {
            ix -= 1;

            // hx <<= 1
            hx <<= 1;
        }

        ix as f32
    } else if !FLT_UWORD_IS_FINITE(hx) {
        /* x = NaN/+-Inf */

        return x * x;
    } else {
        ((hx >> 23) - 127) as f32
    }
}
