#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::include::math_h::expf;
use crate::libm::include::math_h::fabsf;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::erfcd_c::erx;
use crate::libm::mathd::erfd_c::efx8;
use crate::libm::mathd::erfd_c::efx;
use crate::libm::mathf::internal::errorfunctionf_h::__erff_P;
use crate::libm::mathf::internal::errorfunctionf_h::__erff_Q;
use crate::libm::mathf::internal::errorfunctionf_h::__erff_Ra;
use crate::libm::mathf::internal::errorfunctionf_h::__erff_Rb;
use crate::libm::mathf::internal::errorfunctionf_h::__erff_Sa;
use crate::libm::mathf::internal::errorfunctionf_h::__erff_Sb;
use crate::libm::mathf::internal::errorfunctionf_h::__erff_y;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// erx = 8.42697144e-01f, /* 0x3f57bb00 */
// /*
//  * In the domain [0, 2**-14], only the first term in the power series
//  * expansion of erf(x) is used.  The magnitude of the first neglected
//  * terms is less than 2**-42.
//  */
// efx = 1.2837916613e-01f, /* 0x3e0375d4 */
// efx8 = 1.0270333290e+00f;
const ERX: f32 = 8.42697144e-01f32; // 0x3f57bb00
// In the domain [0, 2**-14], only the first term in the power series
// expansion of erf(x) is used. The magnitude of the first neglected
// terms is less than 2**-42.
const EFX: f32 = 1.2837916613e-01f32; // 0x3e0375d4
const EFX8: f32 = 1.0270333290e+00f32; 
/* 0x3f8375d4 */

pub fn erff ( 
let (mut R, mut S, mut P, mut Q, mut s, mut z, mut r): (f32, f32, f32, f32, f32, f32, f32);let ix : int32_t = Default :: default ( ) ;


// float R, S, P, Q, s, z, r;
break 

loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




ix 
= 

hx 
& 
0x7fffffff 

;


if 
! 
FLT_UWORD_IS_FINITE ( ix ) 

{ 
if 
__builtin_isnan ( x ) 
{ /* erf(nan) = nan */

return x + x ;

}



else if 
hx 
> 
0 
{ /* erf(+inf) = +1 */

return 1.0 ;

}



else { /* erf(-inf) = -1 */

return -1.0 ;

}


}



if 
ix < 0x3f580000 
{ /* |x|<0.84375 */

if 
ix < 0x38800000 
{ /* |x|<2**-14 */

if 
ix < 0x04000000 
{ /*avoid underflow */



0.125 
* 
( 

8.0 * x 
+ 
efx8 * x 

) 


}





x 
+ 
efx * x 


}





x 
+ 

x 
* 
__erff_y ( x ) 



}



if 
ix < 0x3fa00000 
{ /* 0.84375 <= |x| < 1.25 */


s 
= 

x . abs ( ) 
- 
one 

;


P = __erff_P ( s ) ;


Q = __erff_Q ( s ) ;


if 
hx 
>= 
0 
{ 


erx 
+ 
P / Q 


}



else { 


- erx 
- 
P / Q 


}


}



if 
ix 
>= 
0x40800000 
{ /* inf>|x|>=4 */

if 
hx 
>= 
0 
{ 

__raise_inexactf ( one ) 

}


-__raise_inexactf(one)// -__raise_inexactf(one)
break 

}


}



x = x . abs ( ) ;



s 
= 

one 
/ 
( 
x * x 
) 

;


if 
ix < 0x4036DB8C 
{ /* |x| < 1/0.35 */

R = __erff_Ra ( s ) ;


S = __erff_Sa ( s ) ;

}



else { /* |x| >= 1/0.35 */

R = __erff_Rb ( s ) ;


S = __erff_Sb ( s ) ;

}



loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
ix 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

ix 
& 
0xffffc000 

) 
;



( 
z 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




r 
= 

expf ( 


- z 
* 
z 

- 
0.5625 

) 
* 
expf ( 


( 
z - x 
) 
* 
( 
z + x 
) 

+ 
R / S 

) 

;


if 
hx 
>= 
0 
{ 


one 
- 
r / x 


}



else { 


r / x 
- 
one 








