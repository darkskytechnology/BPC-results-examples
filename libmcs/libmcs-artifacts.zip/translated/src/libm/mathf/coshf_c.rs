#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_overflowf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::include::math_h::expf;
use crate::libm::include::math_h::expm1f;
use crate::libm::include::math_h::fabsf;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::coshd_c::half;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float one = 1.0f, half = 0.5f;
const ONE: f32 = 1.0;
const HALF: f32 = 0.5;

pub fn coshf(x: f32) -> f32 {
    let t: f32 = Default::default();
    let w: f32 = Default::default();

    let ix: i32;

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (ix) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    ix &= 0x7fffffff;

    /* x is INF or NaN */

    if !FLT_UWORD_IS_FINITE(ix) {
        return x * x;
    }

    /* |x| in [0,0.5*ln2], return 1+expm1(|x|)^2/(2*exp(|x|)) */

    if ix < 0x3eb17218 {
        t = expm1f(x.abs());

        w = one + t;

        if ix < 0x24000000 {
            return w;

            /* cosh(tiny) = 1 */
        }

        one + (t * t) / (w + w)
    }

    /* |x| in [0.5*ln2,22], return (exp(|x|)+1/exp(|x|)/2; */

    if ix < 0x41b00000 {
        t = expf(x.abs());

        half * t + half / t
    }

    /* |x| in [22, log(maxfloat)] return half*exp(|x|) */

    if ix <= FLT_UWORD_LOG_MAX {
        half * expf(x.abs())
    }

    /* |x| in [log(maxfloat), overflowthresold] */

    if ix <= FLT_UWORD_LOG_2MAX {
        w = expf(half * x.abs());

        t = half * w;

        return t * w;
    }

    /* |x| > overflowthresold, cosh(x) overflow */

    __raise_overflowf(1.0)
}
