pub mod errorfunctionf_h;

pub mod fpclassifyf_c;

pub mod gammaf_c;

pub mod gammaf_h;

pub mod log1pmff_h;

pub mod signbitf_c;

pub mod trigf_c;

pub mod trigf_h;

