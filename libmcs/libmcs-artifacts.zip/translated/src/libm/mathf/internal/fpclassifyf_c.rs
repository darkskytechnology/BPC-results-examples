#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::ieee_float_shape_type;
// USE STATEMENTS END
/* SPDX-License-Identifier: RedHat */
/* Copyright (C) 2002,2007 by  Red Hat, Incorporated. All rights reserved. */

pub fn __fpclassifyf(x: f32) -> i32 {
    let w: u32;

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (w) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    w &= 0x7fffffff;

    if w == 0x00000000 {
        return 2;
    } else if w >= 0x00800000 && w <= 0x7f7fffff {
        return 4;
    } else if w <= 0x007fffff {
        return 3;
    } else if w == 0x7f800000 {
        return 1;
    } else {
        return 0;
    }
}
