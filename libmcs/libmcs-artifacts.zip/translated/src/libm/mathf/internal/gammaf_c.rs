#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zerof;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::include::math_h::fabsf;
use crate::libm::include::math_h::floorf;
use crate::libm::include::math_h::logf;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::acosd_c::pi;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathd::coshd_c::half;
use crate::libm::mathd::internal::gammad_c::a0;
use crate::libm::mathd::internal::gammad_c::a10;
use crate::libm::mathd::internal::gammad_c::a11;
use crate::libm::mathd::internal::gammad_c::a1;
use crate::libm::mathd::internal::gammad_c::a2;
use crate::libm::mathd::internal::gammad_c::a3;
use crate::libm::mathd::internal::gammad_c::a4;
use crate::libm::mathd::internal::gammad_c::a5;
use crate::libm::mathd::internal::gammad_c::a6;
use crate::libm::mathd::internal::gammad_c::a7;
use crate::libm::mathd::internal::gammad_c::a8;
use crate::libm::mathd::internal::gammad_c::a9;
use crate::libm::mathd::internal::gammad_c::r1;
use crate::libm::mathd::internal::gammad_c::r2;
use crate::libm::mathd::internal::gammad_c::r3;
use crate::libm::mathd::internal::gammad_c::r4;
use crate::libm::mathd::internal::gammad_c::r5;
use crate::libm::mathd::internal::gammad_c::r6;
use crate::libm::mathd::internal::gammad_c::s0;
use crate::libm::mathd::internal::gammad_c::s1;
use crate::libm::mathd::internal::gammad_c::s2;
use crate::libm::mathd::internal::gammad_c::s3;
use crate::libm::mathd::internal::gammad_c::s4;
use crate::libm::mathd::internal::gammad_c::s5;
use crate::libm::mathd::internal::gammad_c::s6;
use crate::libm::mathd::internal::gammad_c::t0;
use crate::libm::mathd::internal::gammad_c::t10;
use crate::libm::mathd::internal::gammad_c::t11;
use crate::libm::mathd::internal::gammad_c::t12;
use crate::libm::mathd::internal::gammad_c::t13;
use crate::libm::mathd::internal::gammad_c::t14;
use crate::libm::mathd::internal::gammad_c::t1;
use crate::libm::mathd::internal::gammad_c::t2;
use crate::libm::mathd::internal::gammad_c::t3;
use crate::libm::mathd::internal::gammad_c::t4;
use crate::libm::mathd::internal::gammad_c::t5;
use crate::libm::mathd::internal::gammad_c::t6;
use crate::libm::mathd::internal::gammad_c::t7;
use crate::libm::mathd::internal::gammad_c::t8;
use crate::libm::mathd::internal::gammad_c::t9;
use crate::libm::mathd::internal::gammad_c::tc;
use crate::libm::mathd::internal::gammad_c::tf;
use crate::libm::mathd::internal::gammad_c::tt;
use crate::libm::mathd::internal::gammad_c::u0;
use crate::libm::mathd::internal::gammad_c::u1;
use crate::libm::mathd::internal::gammad_c::u2;
use crate::libm::mathd::internal::gammad_c::u3;
use crate::libm::mathd::internal::gammad_c::u4;
use crate::libm::mathd::internal::gammad_c::u5;
use crate::libm::mathd::internal::gammad_c::v1;
use crate::libm::mathd::internal::gammad_c::v2;
use crate::libm::mathd::internal::gammad_c::v3;
use crate::libm::mathd::internal::gammad_c::v4;
use crate::libm::mathd::internal::gammad_c::v5;
use crate::libm::mathd::internal::gammad_c::w0;
use crate::libm::mathd::internal::gammad_c::w1;
use crate::libm::mathd::internal::gammad_c::w2;
use crate::libm::mathd::internal::gammad_c::w3;
use crate::libm::mathd::internal::gammad_c::w4;
use crate::libm::mathd::internal::gammad_c::w5;
use crate::libm::mathd::internal::gammad_c::w6;
use crate::libm::mathf::internal::trigf_c::__cosf;
use crate::libm::mathf::internal::trigf_c::__sinf;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// two23 = 8.3886080000e+06f, /* 0x4b000000 */
// half = 5.0000000000e-01f, /* 0x3f000000 */
// one = 1.0000000000e+00f, /* 0x3f800000 */
// pi = 3.1415927410e+00f, /* 0x40490fdb */
// a0 = 7.7215664089e-02f, /* 0x3d9e233f */
// a1 = 3.2246702909e-01f, /* 0x3ea51a66 */
// a2 = 6.7352302372e-02f, /* 0x3d89f001 */
// a3 = 2.0580807701e-02f, /* 0x3ca89915 */
// a4 = 7.3855509982e-03f, /* 0x3bf2027e */
// a5 = 2.8905137442e-03f, /* 0x3b3d6ec6 */
// a6 = 1.1927076848e-03f, /* 0x3a9c54a1 */
// a7 = 5.1006977446e-04f, /* 0x3a05b634 */
// a8 = 2.2086278477e-04f, /* 0x39679767 */
// a9 = 1.0801156895e-04f, /* 0x38e28445 */
// a10 = 2.5214456400e-05f, /* 0x37d383a2 */
// a11 = 4.4864096708e-05f, /* 0x383c2c75 */
// tc = 1.4616321325e+00f, /* 0x3fbb16c3 */
// tf = -1.2148628384e-01f, /* 0xbdf8cdcd */
// /* tt = -(tail of tf) */
// tt = 6.6971006518e-09f, /* 0x31e61c52 */
// t0 = 4.8383611441e-01f, /* 0x3ef7b95e */
// t1 = -1.4758771658e-01f, /* 0xbe17213c */
// t2 = 6.4624942839e-02f, /* 0x3d845a15 */
// t3 = -3.2788541168e-02f, /* 0xbd064d47 */
// t4 = 1.7970675603e-02f, /* 0x3c93373d */
// t5 = -1.0314224288e-02f, /* 0xbc28fcfe */
// t6 = 6.1005386524e-03f, /* 0x3bc7e707 */
// t7 = -3.6845202558e-03f, /* 0xbb7177fe */
// t8 = 2.2596477065e-03f, /* 0x3b141699 */
// t9 = -1.4034647029e-03f, /* 0xbab7f476 */
// t10 = 8.8108185446e-04f, /* 0x3a66f867 */
// t11 = -5.3859531181e-04f, /* 0xba0d3085 */
// t12 = 3.1563205994e-04f, /* 0x39a57b6b */
// t13 = -3.1275415677e-04f, /* 0xb9a3f927 */
// t14 = 3.3552918467e-04f, /* 0x39afe9f7 */
// u0 = -7.7215664089e-02f, /* 0xbd9e233f */
// u1 = 6.3282704353e-01f, /* 0x3f2200f4 */
// u2 = 1.4549225569e+00f, /* 0x3fba3ae7 */
// u3 = 9.7771751881e-01f, /* 0x3f7a4bb2 */
// u4 = 2.2896373272e-01f, /* 0x3e6a7578 */
// u5 = 1.3381091878e-02f, /* 0x3c5b3c5e */
// v1 = 2.4559779167e+00f, /* 0x401d2ebe */
// v2 = 2.1284897327e+00f, /* 0x4008392d */
// v3 = 7.6928514242e-01f, /* 0x3f44efdf */
// v4 = 1.0422264785e-01f, /* 0x3dd572af */
// v5 = 3.2170924824e-03f, /* 0x3b52d5db */
// s0 = -7.7215664089e-02f, /* 0xbd9e233f */
// s1 = 2.1498242021e-01f, /* 0x3e5c245a */
// s2 = 3.2577878237e-01f, /* 0x3ea6cc7a */
// s3 = 1.4635047317e-01f, /* 0x3e15dce6 */
// s4 = 2.6642270386e-02f, /* 0x3cda40e4 */
// s5 = 1.8402845599e-03f, /* 0x3af135b4 */
// s6 = 3.1947532989e-05f, /* 0x3805ff67 */
// r1 = 1.3920053244e+00f, /* 0x3fb22d3b */
// r2 = 7.2193557024e-01f, /* 0x3f38d0c5 */
// r3 = 1.7193385959e-01f, /* 0x3e300f6e */
// r4 = 1.8645919859e-02f, /* 0x3c98bf54 */
// r5 = 7.7794247773e-04f, /* 0x3a4beed6 */
// r6 = 7.3266842264e-06f, /* 0x36f5d7bd */
// w0 = 4.1893854737e-01f, /* 0x3ed67f1d */
// w1 = 8.3333335817e-02f, /* 0x3daaaaab */
// w2 = -2.7777778450e-03f, /* 0xbb360b61 */
// w3 = 7.9365057172e-04f, /* 0x3a500cfd */
// w4 = -5.9518753551e-04f, /* 0xba1c065c */
// w5 = 8.3633989561e-04f, /* 0x3a5b3dd2 */
// w6 = -1.6309292987e-03f;
static TWO23: f32 = 8.3886080000e+06f32; // 0x4b000000
static HALF: f32 = 5.0000000000e-01f32; // 0x3f000000
static ONE: f32 = 1.0000000000e+00f32; // 0x3f800000
static PI: f32 = 3.1415927410e+00f32; // 0x40490fdb
static A0: f32 = 7.7215664089e-02f32; // 0x3d9e233f
static A1: f32 = 3.2246702909e-01f32; // 0x3ea51a66
static A2: f32 = 6.7352302372e-02f32; // 0x3d89f001
static A3: f32 = 2.0580807701e-02f32; // 0x3ca89915
static A4: f32 = 7.3855509982e-03f32; // 0x3bf2027e
static A5: f32 = 2.8905137442e-03f32; // 0x3b3d6ec6
static A6: f32 = 1.1927076848e-03f32; // 0x3a9c54a1
static A7: f32 = 5.1006977446e-04f32; // 0x3a05b634
static A8: f32 = 2.2086278477e-04f32; // 0x39679767
static A9: f32 = 1.0801156895e-04f32; // 0x38e28445
static A10: f32 = 2.5214456400e-05f32; // 0x37d383a2
static A11: f32 = 4.4864096708e-05f32; // 0x383c2c75
static TC: f32 = 1.4616321325e+00f32; // 0x3fbb16c3
static TF: f32 = -1.2148628384e-01f32; // 0xbdf8cdcd
static TT: f32 = 6.6971006518e-09f32; // 0x31e61c52
static T0: f32 = 4.8383611441e-01f32; // 0x3ef7b95e
static T1: f32 = -1.4758771658e-01f32; // 0xbe17213c
static T2: f32 = 6.4624942839e-02f32; // 0x3d845a15
static T3: f32 = -3.2788541168e-02f32; // 0xbd064d47
static T4: f32 = 1.7970675603e-02f32; // 0x3c93373d
static T5: f32 = -1.0314224288e-02f32; // 0xbc28fcfe
static T6: f32 = 6.1005386524e-03f32; // 0x3bc7e707
static T7: f32 = -3.6845202558e-03f32; // 0xbb7177fe
static T8: f32 = 2.2596477065e-03f32; // 0x3b141699
static T9: f32 = -1.4034647029e-03f32; // 0xbab7f476
static T10: f32 = 8.8108185446e-04f32; // 0x3a66f867
static T11: f32 = -5.3859531181e-04f32; // 0xba0d3085
static T12: f32 = 3.1563205994e-04f32; // 0x39a57b6b
static T13: f32 = -3.1275415677e-04f32; // 0xb9a3f927
static T14: f32 = 3.3552918467e-04f32; // 0x39afe9f7
static U0: f32 = -7.7215664089e-02f32; // 0xbd9e233f
static U1: f32 = 6.3282704353e-01f32; // 0x3f2200f4
static U2: f32 = 1.4549225569e+00f32; // 0x3fba3ae7
static U3: f32 = 9.7771751881e-01f32; // 0x3f7a4bb2
static U4: f32 = 2.2896373272e-01f32; // 0x3e6a7578
static U5: f32 = 1.3381091878e-02f32; // 0x3c5b3c5e
static V1: f32 = 2.4559779167e+00f32; // 0x401d2ebe
static V2: f32 = 2.1284897327e+00f32; // 0x4008392d
static V3: f32 = 7.6928514242e-01f32; // 0x3f44efdf
static V4: f32 = 1.0422264785e-01f32; // 0x3dd572af
static V5: f32 = 3.2170924824e-03f32; // 0x3b52d5db
static S0: f32 = -7.7215664089e-02f32; // 0xbd9e233f
static S1: f32 = 2.1498242021e-01f32; // 0x3e5c245a
static S2: f32 = 3.2577878237e-01f32; // 0x3ea6cc7a
static S3: f32 = 1.4635047317e-01f32; // 0x3e15dce6
static S4: f32 = 2.6642270386e-02f32; // 0x3cda40e4
static S5: f32 = 1.8402845599e-03f32; // 0x3af135b4
static S6: f32 = 3.1947532989e-05f32; // 0x3805ff67
static R1: f32 = 1.3920053244e+00f32; // 0x3fb22d3b
static R2: f32 = 7.2193557024e-01f32; // 0x3f38d0c5
static R3: f32 = 1.7193385959e-01f32; // 0x3e300f6e
static R4: f32 = 1.8645919859e-02f32; // 0x3c98bf54
static R5: f32 = 7.7794247773e-04f32; // 0x3a4beed6
static R6: f32 = 7.3266842264e-06f32; // 0x36f5d7bd
static W0: f32 = 4.1893854737e-01f32; // 0x3ed67f1d
static W1: f32 = 8.3333335817e-02f32; // 0x3daaaaab
static W2: f32 = -2.7777778450e-03f32; // 0xbb360b61
static W3: f32 = 7.9365057172e-04f32; // 0x3a500cfd
static W4: f32 = -5.9518753551e-04f32; // 0xba1c065c
static W5: f32 = 8.3633989561e-04f32; // 0x3a5b3dd2
 
/* 0xbad5c4e8 */

const zero : f32 = 0.0000000000e+00 ;


fn __sin_pif ( 
x : f32 
) -> f32 { 
let y : f32 = Default :: default ( ) ;
let z : f32 = Default :: default ( ) ;


let n : int32_t = Default :: default ( ) ;
let ix : int32_t = Default :: default ( ) ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
ix 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



ix &= 
0x7fffffff 
;


if 
ix < 0x3e800000 
{ 

__sinf ( 
pi * x 

, 

zero , 

0 
) 

}




y 
= 
- x 
;

/* x is assume negative */
/*
     * argument reduction, make sure inexact flag not raised if input
     * is an integer
     */

z = y . floor ( ) ;


if 
z 
!= 
y 
{ /* inexact anyway */

y *= 0.5 ;



y 
= 

2.0 
* 
( 

y 
- 
y . floor ( ) 

) 

;

/* y = |x| mod 2.0 */


n 
= 

( 
y * 4.0 
) 
as int32_t 
;

}



else { 
z = y + two23 ;

/* exact */

loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
z 
) 
;



( 
n 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



n &= 
1 
;


y = n ;


n <<= 
2 
;

}



-__cosf(pi * (y - 1.5f), zero)0 => { 
y = __sinf ( 
pi * y 

, 

zero , 

0 
) ;

}


/* FALLTHRU */

2 => { 
y = __cosf ( 

pi 
* 
( 
0.5 - y 
) 


, 

zero 
) ;

}


/* FALLTHRU */

4 => { 
y = __sinf ( 

pi 
let mut signgamp: Option<i32> = None;) 


let mut t: f32;
let mut y: f32;
let mut z: f32;
let mut nadj: f32 = 0.0;
let mut p: f32;
let mut p1: f32;
let mut p2: f32;
let mut p3: f32;
let mut q: f32;
let mut r: f32;
let mut w: f32;
0 
) ;

}


/* FALLTHRU */

6 => { 

y 
= 
// -__cosf(pi * (y - 1.5f), zero)
break 
;

}


_ => { 
y = __sinf ( 

pi 
* 
( 
y - 2.0 
) 


, 

zero , 

0 
) ;

}

}




- y 

}



pub fn __lgammaf ( 
x : f32 , 

// int *signgamp
break 
) -> f32 { 
// float t, y, z, nadj = 0.0f, p, p1, p2, p3, q, r, w;
break 

let i : int32_t = Default :: default ( ) ;
let hx : int32_t = Default :: default ( ) ;
let ix : int32_t = Default :: default ( ) ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* purge off +-inf, NaN, +-0, and negative arguments */



signgamp 

= 
1 
;
(-x).log10()ix 
= 

hx 
& 
0x7fffffff 

;

-x.log10()>= 
0x7f800000 
{ 
return x * x ;

}



if 
ix == 0 
{ 
if 
hx < 0 
{ 


signgamp 

= 
-1 
;

}




__raise_div_by_zerof ( zero ) 

}



if 
ix < 0x30800000 
{ /* |x|<2**-30, return -log(|x|) */

if 
hx < 0 
{ 


signgamp 

= 
-1 
;



// -logf(-x)
break 

}



else { 

// -logf(x)
break 

}


}



if 
hx < 0 
{ 
if 
ix 
>= 
0x4b000000 
{ /* |x|>=2**23, must be -integer */


__raise_div_by_zerof ( zero ) 

}



t = __sin_pif ( x ) ;


if 
t == zero 
{ 

__raise_div_by_zerof ( zero ) 

/* -integer */
}



nadj = logf ( 

pi 
/ 
fabsf ( 
-x.log10()) ;


if 
t 
< 
zero 
{ 


signgamp 

= 
-1 
;

}




x 
= 
- x 
;

}


/* purge off 1 and 2 */

if 

ix == 0x3f800000 
|| 
ix == 0x40000000 

{ 
r = 0 ;

}


/* for x < 2.0 */

else if 
ix < 0x40000000 
{ 
if 
ix 
<= 
0x3f666666 
{ /* lgamma(x) = lgamma(x+1)-log(x) */


r 
= 
// -logf(x)
break 
;


if 
ix 
>= 
0x3f3b4a20 
{ 
y = one - x ;


i = 0 ;

}



else if 
ix 
>= 
0x3e6d3308 
{ 

y 
= 

x 
- 
( 
tc - one 
) 

;


i = 1 ;

}



else { 
y = x ;


i = 2 ;

}


}



else { 
r = zero ;


if 
ix 
>= 
0x3fdda618 
{ 
y = 2.0 - x ;

/* [1.7316,2] */

i = 0 ;

}



else if 
ix 
>= 
0x3F9da620 
{ 
y = x - tc ;

/* [1.23,1.73] */

i = 1 ;

}



else { 
y = x - one ;


i = 2 ;

}


}



match 
i 
{ /* FALLTHRU */

0 => { 
z = y * y ;



p1 
= 

a0 
+ 

z 
* 
( 

a2 
+ 

z 
* 
( 

a4 
+ 

z 
* 
( 

a6 
+ 

z 
* 
( 

a8 
+ 
z * a10 

) 


) 


) 


) 


;



p2 
= 

z 
* 
( 

a1 
+ 

z 
* 
( 

a3 
+ 

z 
* 
( 

a5 
+ 

z 
* 
( 

a7 
+ 

z 
* 
( 

a9 
+ 
z * a11 

) 


) 


) 


) 


) 

;



p 
= 

y * p1 
+ 
p2 

;


r += 
( 

p 
- 
0.5 * y 

) 
;

}



1 => { 
z = y * y ;


w = z * y ;



p1 
= 

t0 
+ 

w 
* 
( 

t3 
+ 

w 
* 
( 

t6 
+ 

w 
* 
( 

t9 
+ 
w * t12 

) 


) 


) 


;

/* parallel comp */


p2 
= 

t1 
+ 

w 
* 
( 

t4 
+ 

w 
* 
( 

t7 
+ 

w 
* 
( 

t10 
+ 
w * t13 

) 


) 


) 


;



p3 
= 

t2 
+ 

w 
* 
( 

t5 
+ 

w 
* 
( 

t8 
+ 

w 
* 
( 

t11 
+ 
w * t14 

) 


) 


) 


;



p 
= 

z * p1 
- 
( 

tt 
- 

w 
* 
( 

p2 
+ 
y * p3 

) 


) 

;


r += 
( 
tf + p 
) 
;

}



2 => { 

p1 
= 

y 
* 
( 

u0 
+ 

y 
* 
( 

u1 
+ 

y 
* 
( 

u2 
+ 

y 
* 
( 

u3 
+ 

y 
* 
( 

u4 
+ 
y * u5 

) 


) 


) 


) 


) 

;



p2 
= 

one 
+ 

y 
* 
( 

v1 
+ 

y 
* 
( 

v2 
+ 

y 
* 
( 

v3 
+ 

y 
* 
( 

v4 
+ 
y * v5 

) 


) 


) 


) 


;


r += 
( 

-0.5 * y 
+ 
p1 / p2 

) 
;

}


_ => { }

}


}



else if 
ix < 0x41000000 
{ /* x < 8.0 */


i 
= 

x 
as int32_t 
;



y 
= 

x 
- 

i 
as f32 

;



p 
= 

y 
* 
( 

s0 
+ 

y 
* 
( 

s1 
+ 

y 
* 
( 

s2 
+ 

y 
* 
( 

s3 
+ 

y 
* 
( 

s4 
+ 

y 
* 
( 

s5 
+ 
y * s6 

) 


) 


) 


) 


) 


) 

;



q 
= 

one 
+ 

y 
* 
( 

r1 
+ 

y 
* 
( 

r2 
+ 

y 
* 
( 

r3 
+ 

y 
* 
( 

r4 
+ 

y 
* 
( 

r5 
+ 
y * r6 

) 


) 


) 


) 


) 


;



r 
= 

half * y 
+ 
p / q 

;


z = one ;

/* lgamma(1+s) = log(s) + lgamma(s) */

match 
i 
{ 
7 => { 
z *= 
( 
y + 6.0 
) 
;


z *= 
( 
y + 5.0 
) 
;


z *= 
( 
y + 4.0 
) 
;


z *= 
( 
y + 3.0 
) 
;


z *= 
( 
y + 2.0 
) 
;


r += 
logf ( z ) 
;

}


/* FALLTHRU */

6 => { 
z *= 
( 
y + 5.0 
) 
;


z *= 
( 
y + 4.0 
) 
;


z *= 
( 
y + 3.0 
) 
;


z *= 
( 
y + 2.0 
) 
;


r += 
logf ( z ) 
;

}


/* FALLTHRU */

5 => { 
z *= 
( 
y + 4.0 
) 
;


z *= 
( 
y + 3.0 
) 
;


z *= 
( 
y + 2.0 
) 
;


r += 
logf ( z ) 
;

}


/* FALLTHRU */

4 => { 
z *= 
( 
y + 3.0 
) 
;


z *= 
( 
y + 2.0 
) 
;


r += 
logf ( z ) 
;

}


/* FALLTHRU */

3 => { 
z *= 
( 
y + 2.0 
) 
;


r += 
logf ( z ) 
;

}


/* FALLTHRU */
_ => { 
r += 
logf ( z ) 
;

}

}


/* 8.0 <= x < 2**58 */
}



else if 
ix < 0x5c800000 
{ 
t = logf ( x ) ;


z = one / x ;


y = z * z ;



w 
= 

w0 
+ 

z 
* 
( 

w1 
+ 

y 
* 
( 

w2 
+ 

y 
* 
( 

w3 
+ 

y 
* 
( 

w4 
+ 

y 
* 
( 

w5 
+ 
y * w6 

) 


) 


) 


) 


) 


;



r 
= 


( 
x - half 
) 
* 
( 
t - one 
) 

+ 
w 

;

}



else { /* 2**58 <= x <= inf */


r 
= 

x 
* 
( 

logf ( x ) 
- 
one 

) 

;

}



if 
hx < 0 
{ 
r = nadj - r ;

}


return r ;





