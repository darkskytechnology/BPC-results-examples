#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::include::math_h::fabsf;
use crate::libm::include::math_h::floorf;
use crate::libm::include::math_h::scalbnf;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathd::coshd_c::half;
use crate::libm::mathd::internal::trigd_c::C1;
use crate::libm::mathd::internal::trigd_c::C2;
use crate::libm::mathd::internal::trigd_c::C3;
use crate::libm::mathd::internal::trigd_c::PIo2;
use crate::libm::mathd::internal::trigd_c::S1;
use crate::libm::mathd::internal::trigd_c::S2;
use crate::libm::mathd::internal::trigd_c::S3;
use crate::libm::mathd::internal::trigd_c::S4;
use crate::libm::mathd::internal::trigd_c::invpio2;
use crate::libm::mathd::internal::trigd_c::ipio2;
use crate::libm::mathd::internal::trigd_c::pio2_1;
use crate::libm::mathd::internal::trigd_c::pio2_1t;
use crate::libm::mathd::internal::trigd_c::pio2_2;
use crate::libm::mathd::internal::trigd_c::pio2_2t;
use crate::libm::mathd::internal::trigd_c::pio2_3;
use crate::libm::mathd::internal::trigd_c::pio2_3t;
use crate::translate_bpc_mmv;
use crate::translate_bpc_vpp;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */
/* In the float version, the input parameter x contains 8 bit
   integers, not 24 bit integers.  113 bit precision is not supported.  */
/*
 * Constants:
 * The hexadecimal values are the intended ones for the following
 * constants. The decimal values may be used, provided that the
 * compiler will convert from decimal to binary accurately enough
 * to produce the hexadecimal values shown.
 */
/*
 * Single precision array, obtained by cutting pi/2
 * into 8 bits chunks.
 */

// static const float PIo2[] = {
//     1.5703125000e+00f, /* 0x3fc90000 */
//     4.5776367188e-04f, /* 0x39f00000 */
//     2.5987625122e-05f, /* 0x37da0000 */
//     7.5437128544e-08f, /* 0x33a20000 */
//     6.0026650317e-11f, /* 0x2e840000 */
//     7.3896444519e-13f, /* 0x2b500000 */
//     5.3845816694e-15f, /* 0x27c20000 */
//     5.6378512969e-18f, /* 0x22d00000 */
//     8.3009228831e-20f, /* 0x1fc40000 */
//     3.2756352257e-22f, /* 0x1bc60000 */
//     6.3331015649e-25f, /* 0x17440000 */
// };
static PIo2: [f32; 11] = [
    1.5703125000e+00f32, // 0x3fc90000
    4.5776367188e-04f32, // 0x39f00000
    2.5987625122e-05f32, // 0x37da0000
    7.5437128544e-08f32, // 0x33a20000
    6.0026650317e-11f32, // 0x2e840000
    7.3896444519e-13f32, // 0x2b500000
    5.3845816694e-15f32, // 0x27c20000
    5.6378512969e-18f32, // 0x22d00000
    8.3009228831e-20f32, // 0x1fc40000
    3.2756352257e-22f32, // 0x1bc60000
    6.3331015649e-25f32, // 0x17440000
]; 
/*
 * Table of constants for 2/pi, 396 Hex digits (476 decimal) of 2/pi
 *
 * The integer array contains the (8*i)-th to (8*i+7)-th
 * bit of 2/pi after binary point. The corresponding
 * floating value is
 *
 *            ipio2[i] * 2^(-8(i+1)).
 */

static ipio2 : & [ int32_t ] = & [ 
0xA2 , 

0xF9 , 

0x83 , 

0x6E , 

0x4E , 

0x44 , 

0x15 , 

0x29 , 

0xFC , 

0x27 , 

0x57 , 

0xD1 , 

0xF5 , 

0x34 , 

0xDD , 

0xC0 , 

0xDB , 

0x62 , 

0x95 , 

0x99 , 

0x3C , 

0x43 , 

0x90 , 

0x41 , 

0xFE , 

0x51 , 

0x63 , 

0xAB , 

0xDE , 

0xBB , 

0xC5 , 

0x61 , 

0xB7 , 

0x24 , 

0x6E , 

0x3A , 

0x42 , 

0x4D , 

0xD2 , 

0xE0 , 

0x06 , 

0x49 , 

0x2E , 

0xEA , 

0x09 , 

0xD1 , 

0x92 , 

0x1C , 

0xFE , 

0x1D , 

0xEB , 

0x1C , 

0xB1 , 

0x29 , 

0xA7 , 

0x3E , 

0xE8 , 

0x82 , 

0x35 , 

0xF5 , 

0x2E , 

0xBB , 

0x44 , 

0x84 , 

0xE9 , 

0x9C , 

0x70 , 

0x26 , 

0xB4 , 

0x5F , 

0x7E , 

0x41 , 

0x39 , 

0x91 , 

0xD6 , 

0x39 , 

0x83 , 

0x53 , 

0x39 , 

0xF4 , 

0x9C , 

0x84 , 

0x5F , 

0x8B , 

0xBD , 

0xF9 , 

0x28 , 

0x3B , 

0x1F , 

0xF8 , 

0x97 , 

0xFF , 

0xDE , 

0x05 , 

0x98 , 

0x0F , 

0xEF , 

0x2F , 

0x11 , 

0x8B , 

0x5A , 

0x0A , 

0x6D , 

0x1F , 

0x6D , 

0x36 , 

0x7E , 

0xCF , 

0x27 , 

0xCB , 

0x09 , 

0xB7 , 

0x4F , 

0x46 , 

0x3F , 

0x66 , 

0x9E , 

0x5F , 

0xEA , 

0x2D , 

0x75 , 

0x27 , 

0xBA , 

0xC7 , 

0xEB , 

0xE5 , 

0xF1 , 

0x7B , 

0x3D , 

0x07 , 

0x39 , 

0xF7 , 

0x8A , 

0x52 , 

0x92 , 

0xEA , 

0x6B , 

0xFB , 

0x5F , 

0xB1 , 

0x1F , 

0x8D , 

0x5D , 

0x08 , 

0x56 , 

0x03 , 

0x30 , 

0x46 , 

0xFC , 

0x7B , 

0x6B , 

0xAB , 

0xF0 , 

0xCF , 

0xBC , 

0x20 , 

0x9A , 

0xF4 , 

0x36 , 

0x1D , 

0xA9 , 

0xE3 , 

0x91 , 

0x61 , 

0x5E , 

0xE6 , 

0x1B , 

0x08 , 

0x65 , 

0x99 , 

0x85 , 

0x5F , 

0x14 , 

0xA0 , 

0x68 , 

0x40 , 

0x8D , 

0xFF , 

0xD8 , 

0x80 , 

0x4D , 

0x73 , 

0x27 , 

0x31 , 

0x06 , 

0x06 , 

0x15 , 

0x56 , 

0xCA , 

0x73 , 

0xA8 , 

0xC9 , 

0x60 , 

0xE2 , 

0x7B , 

0xC0 , 

0x8C , 

0x6B , 
] ;


const zero : f32 = 0.0 ;


const one : f32 = 1.0 ;


const two8 : f32 = 0x1p+08 ;

/* 2.5600000000e+02f    0x43800000 */

const twon8 : f32 = 0x1p-08 ;

/* 3.9062500000e-03f    0x3b800000 */

// static inline int __rem_pio2f_internal(float *x, float *y, int e0, int nx)
// {
//     int32_t jk = 7; /* precision setting
//                            jk+1 is the initial number of terms of ipio2[] needed in the computation. */
//     int32_t jp = jk; /* stores the initial value of jk until the final result computation */
// 
//     int32_t k; /* number of additional ipio2 terms needed for recomputation */
//     int32_t i, j, m; /* general purpose indices and variables */
//     int32_t jz, jx, jv; /* other specific indices */
//     int32_t carry; /* indicates whether there is a contribution of q when computing the complementary angle */
//     int32_t ih; /* variable that indicates the position of the angle within the resulting quadrant.
//                            If ih is positive then q[] is >= 0.5, hence it acts as the "signbit" of the result,
//                            which will be positive for negative angles within the quadrant. */
// 
// 
//     float q[20] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, /* value of q = x/(pi/2) = x*(2/pi) */
//                       0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
//     int32_t q0; /* the corresponding exponent of q[0]. Note that the exponent for q[i] would be q0-8*i */
// 
//     int32_t n; /* indicates the octant where the angle falls into; it is used to get the quadrant */
//     float z; /* high order fractional part of q, down to the q0 bit */
//     int32_t iq[20] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* lower order 8 bit chunks of fractional part of q in inverted order. */
//                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }; /* iq starts after the q0 bits which are in z                           */
// 
//     float fw; /* temporary variable to compute q, iq, and fq           */
//     float f[20] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, /* ipio2[] terms taken fro computation in floating point */
//                      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
//     float fq[20] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, /* final product of q*pi/2 in fq[0],..,fq[jk];                                */
//                      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 }; /* computing the fractional value [0,1] within the quadrant back into radians */
// 
// 
// 
//     _Bool recompute; /* variable used to signalize that a recomputation is needed as the current selection of ipio2[] terms has led to loss of significance.
//                          The recomputation will take more terms of ipio2[]. */
//     _Bool exhausted; /* variable used to signalize that the available ipio2 precision has been exhausted making no further recomputing possible */
// 
//     jp = jk;
// 
//     /* determine jx,jv,q0, note that 3>q0 */
//     jx = nx - 1;
//     jv = (e0 - 3) / 8;
// 
//     q0 = e0 - 8 * (jv + 1);
// 
//     /* set up f[0] to f[jx+jk] where f[jx+jk] = ipio2[jv+jk] */
//     j = jv - jx;
//     m = jx + jk;
// 
//     for (i = 0; i <= m; i++, j++) {
//         f[i] = (j < 0) ? zero : (float) ipio2[j];
//     }
// 
//     /* compute q[0],q[1],...q[jk] */
//     for (i = 0; i <= jk; i++) {
//         for (j = 0, fw = 0.0f; j <= jx; j++) {
//             fw += x[j] * f[jx + i - j];
//         }
// 
//         q[i] = fw;
//     }
// 
//     jz = jk;
//     do {
//         recompute = 0;
//         exhausted = 0;
// 
//         /* distill the lower part of q[] into iq[] reversingly and leave the higher part in z */
//         for (i = 0, j = jz, z = q[jz]; j > 0; i++, j--) {
//             fw = (float)((int32_t)(twon8 * z));
//             iq[i] = (int32_t)(z - two8 * fw);
//             z = q[j - 1] + fw;
//         }
// 
//         /* compute n */
//         z = scalbnf(z, (int32_t)q0); /* actual value of z */
//         z -= 8.0f * floorf(z * 0.125f); /* trim off integer >= 8 */
//         n = (int32_t) z;
//         z -= (float)n;
//         ih = 0;
// 
//         if (q0 > 0) { /* need iq[jz-1] to determine n */
//             i = (iq[jz - 1] >> (8 - q0));
//             n += i;
//             iq[jz - 1] -= i << (8 - q0);
//             ih = iq[jz - 1] >> (7 - q0);
//         } else if (q0 == 0) {
//             ih = iq[jz - 1] >> 7;
//         } else if (z >= 0.5f) {
//             ih = 2;
//         } else {
//             /* No action required */
//         }
// 
//         /* for the cases that the angle is in the upper side of the quadrant, the complementary is computed */
//         if (ih > 0) { /* q > 0.5 */
//             n += 1;
//             carry = 0;
// 
//             for (i = 0; i < jz ; i++) { /* compute 1-q by computing the complementary of iq */
//                 j = iq[i];
// 
//                 if (carry == 0) {
//                     if (j != 0) {
//                         carry = 1;
//                         iq[i] = 0x100 - j;
//                     }
//                 } else {
//                     iq[i] = 0xff - j;
//                 }
//             }
// 
//             if (q0 > 0) { /* rare case: chance is 1 in 12 */
//                 switch (q0) {
//                 default: /* FALLTHRU */
//                 case 1:
//                     iq[jz - 1] &= 0x7f;
//                     fn __rem_pio2f_internal(x: &mut [f32], y: &mut [f32], e0: i32, nx: i32) -> i32 {
    let jk: i32 = 7; // precision setting
    let mut jp: i32 = jk; // stores the initial value of jk until the final result computation

    let mut k: i32; // number of additional ipio2 terms needed for recomputation
    let mut i: i32;
    let mut j: i32;
    let mut m: i32; // general purpose indices and variables
    let mut jz: i32;
    let mut jx: i32;
    let mut jv: i32; // other specific indices
    let mut carry: i32; // indicates whether there is a contribution of q when computing the complementary angle
    let mut ih: i32; // variable that indicates the position of the angle within the resulting quadrant.

    let mut q: [f32; 20] = [0.0; 20]; // value of q = x/(pi/2) = x*(2/pi)
    let mut q0: i32; // the corresponding exponent of q[0]. Note that the exponent for q[i] would be q0-8*i

    let mut n: i32; // indicates the octant where the angle falls into; it is used to get the quadrant
    let mut z: f32; // high order fractional part of q, down to the q0 bit
    let mut iq: [i32; 20] = [0; 20]; // lower order 8 bit chunks of fractional part of q in inverted order.

    let mut fw: f32; // temporary variable to compute q, iq, and fq
    let mut f: [f32; 20] = [0.0; 20]; // ipio2[] terms taken for computation in floating point
    let mut fq: [f32; 20] = [0.0; 20]; // final product of q*pi/2 in fq[0],..,fq[jk];

    let mut recompute: bool; // variable used to signalize that a recomputation is needed
    let mut exhausted: bool; // variable used to signalize that the available ipio2 precision has been exhausted

    jp = jk;

    // determine jx,jv,q0, note that 3>q0
    jx = nx - 1;
    jv = (e0 - 3) / 8;

    q0 = e0 - 8 * (jv + 1);

    // set up f[0] to f[jx+jk] where f[jx+jk] = ipio2[jv+jk]
    j = jv - jx;
    m = jx + jk;

    for i in 0..=m {
        f[i as usize] = if j < 0 { 0.0 } else { ipio2[j as usize] as f32 };
        j += 1;
    }

    // compute q[0],q[1],...q[jk]
    for i in 0..=jk {
        fw = 0.0;
        for j in 0..=jx {
            fw += x[j as usize] * f[(jx + i - j) as usize];
        }
        q[i as usize] = fw;
    }

    jz = jk;
    loop {
        recompute = false;
        exhausted = false;

        // distill the lower part of q[] into iq[] reversingly and leave the higher part in z
        for i in 0..jz {
            j = jz - i;
            z = q[j as usize];
            fw = (twon8 * z) as i32 as f32;
            iq[i as usize] = (z - two8 * fw) as i32;
            z = q[(j - 1) as usize] + fw;
        }

        // compute n
        z = scalbnf(z, q0);
        z -= 8.0 * (z * 0.125).floor();
        n = z as i32;
        z -= n as f32;
        ih = 0;

        if q0 > 0 {
            i = iq[(jz - 1) as usize] >> (8 - q0);
            n += i;
            iq[(jz - 1) as usize] -= i << (8 - q0);
            ih = iq[(jz - 1) as usize] >> (7 - q0);
        } else if q0 == 0 {
            ih = iq[(jz - 1) as usize] >> 7;
        } else if z >= 0.5 {
            ih = 2;
        }

        if ih > 0 {
            n += 1;
            carry = 0;

            for i in 0..jz {
                j = iq[i as usize];
                if carry == 0 {
                    if j != 0 {
                        carry = 1;
                        iq[i as usize] = 0x100 - j;
                    }
                } else {
                    iq[i as usize] = 0xff - j;
                }
            }

            if q0 > 0 {
                match q0 {
                    1 => iq[(jz - 1) as usize] &= 0x7f,
                    2 => iq[(jz - 1) as usize] &= 0x3f,
                    _ => {}
                }
            }

            if ih == 2 {
                z = 1.0 - z;
                if carry != 0 {
                    z -= scalbnf(1.0, q0);
                }
            }
static HALF: f32 = 5.0000000000e-01f32; // 0x3f000000
static INVPIO2: f32 = 6.3661980629e-01f32; // 0x3f22f984
static PIO2_1: f32 = 1.5707855225e+00f32; // 0x3fc90f80
static PIO2_1T: f32 = 1.0804334124e-05f32; // 0x37354443
static PIO2_2: f32 = 1.0804273188e-05f32; // 0x37354400
static PIO2_2T: f32 = 6.0770999344e-11f32; // 0x2e85a308
static PIO2_3: f32 = 6.0770943833e-11f32; // 0x2e85a300
static PIO2_3T: f32 = 6.1232342629e-17f32;                        break;
                    }
                }

                for i in (jz + 1)..=(jz + k) {
                    if jv + i < 66 && jx + i < 20 {
                        f[(jx + i) as usize] = ipio2[(jv + i) as usize] as f32;
                    } else {
let mut y: *mut f32;                    fw = 0.0;
                    for j in 0..=jx {
                        fw += x[j as usize] * f[(jx + i - j) as usize];
let mut z: f32;
let mut w: f32;
let mut t: f32;
let mut r: f32;
let mut fn: f32;                }

                jz += k;
                recompute = true;
let mut i: i32;
let mut j: i32;
let mut n: i32;
let mut ix: i32;
let mut hx: i32;        if !recompute {
            break;
        }
    }

    if z == 0.0 {
        q0 -= 8;
        for jz in (0..jz).rev() {
            if iq[jz as usize] != 0 {
                break;
            }
            q0 -= 8;
        }
    } else {
        z = scalbnf(z, -q0);
        iq[jz as usize] = z as i32;
    }

    fw = scalbnf(1.0, q0);
    for i in (0..=jz).rev() {
        q[i as usize] = fw * iq[i as usize] as f32;
        fw *= twon8;
    }

    for i in (0..=jz).rev() {
        fw = 0.0;
        for k in 0..=jp.min(jz - i) {
            fw += PIo2[k as usize] * q[(i + k) as usize];
        }
        fq[(jz - i) as usize] = fw;
    }

    fw = 0.0;
    for i in (0..=jz).rev() {
        fw += fq[i as usize];
    }

    y[0] = if ih == 0 { fw } else { -fw };
    fw = fq[0] - fw;

    for i in 1..=jz {
        fw += fq[i as usize];
    }

    y[1] = if ih == 0 { fw } else { -fw };

    n & 7
}
;
// 
//                 case 2:
//                     iq[jz - 1] &= 0x3f;
//                     ;
//                 }
//             }
// 
//             if (ih == 2) { /* compute the complementary of z */
//                 z = one - z;
// 
//                 /* in case that iq[] does have a contribution, subtract the order of magnitude
//                    of this contribution from the complement of z so that z + iq can be computed. */
//                 if (carry != 0) {
//                     z -= scalbnf(one, (int32_t)q0);
//                     /* Given the following decimal example of: z = 0.7 and iq = 0.01 for the angle z + iq = 0.71
//                        the complements would be z = 1 - z = 0.3 and iq = 0.1 - iq = 0.09
//                        now, z needs to be decremented by 0.1; z = z - 0.1 so that z + iq = 0.2 + 0.09 = 0.29
//                        which is the correct complement of the original angle 0.71 */
//                 }
//             }
//         }
// 
//         /* check if recomputation is needed in case of loss of significance in z and iq[] */
//         if (z == zero && !exhausted) {
//             j = 0;
// 
//             for (i = jz - 1; i >= jk; i--) {
//                 j |= iq[i];
//             }
// 
//             if (j == 0) { /* need recomputation */
//                 for (k = 1; (jk - k >= 0) && (iq[jk - k] == 0); k++) { /* k = no. of terms needed */
//                 }
// 
//                 /* add q[jz+1] to q[jz+k]
//                    don't pull more terms of ipio2[] than available
//                    and don't overflow f[] */
//                 for (i = jz + 1; i <= jz + k; i++) {
//                     if ((jv + i < 66) &&
//                         (jx + i < 20)) {
//                         f[jx + i] = (float) ipio2[jv + i];
//                     } else{
//                         exhausted = 1;
//                     }
// 
//                     for (j = 0, fw = 0.0f; j <= jx; j++) {
//                         fw += x[j] * f[jx + i - j];
//                     }
// 
//                     q[i] = fw;
//                 }
// 
//                 jz += k;
//                 recompute = 1;
//             }
//         }
//     /* The original authors of the algorithm Payne and Hanek estimate the
//        amount of needed recomputing to be low. Currently only 2 recomputes
//        are observed at most */
//     } while (recompute);
// 
//     /* chop off zero terms */
//     if (z == 0.0f) {
//         q0 -= 8;
// 
//         for (jz -= 1; jz>=0; --jz) {
//             if (iq[jz]!=0) {
//                 ;
//             }
//             q0 -= 8;
//         }
//     } else { /*  z into 8-bit if necessary */
//         z = scalbnf(z, -(int32_t)q0);
// 
//         iq[jz] = (int32_t) z ;
//     }
// 
//     /* convert integer "bit" chunk to floating-point value */
//     fw = scalbnf(one, (int32_t)q0);
// 
//     for (i = jz; i >= 0; i--) {
//         q[i] = fw * (float)iq[i];
//         fw *= twon8;
//     }
// 
//     /* compute PIo2[0,...,jp]*q[jz,...,0] */
//     for (i = jz; i >= 0; i--) {
//         for (fw = 0.0f, k = 0; k <= jp && k <= jz - i; k++) {
//             fw += PIo2[k] * q[i + k];
//         }
// 
//         fq[jz - i] = fw;
//     }
// 
//     /* compress fq[] into y[] */
//     fw = 0.0f;
// 
//     for (i = jz; i >= 0; i--) {
//         fw += fq[i];
//     }
// 
//     y[0] = (ih == 0) ? fw : -fw;
//     fw = fq[0] - fw;
// 
//     for (i = 1; i <= jz; i++) {
//         fw += fq[i];
//     }
// 
//     y[1] = (ih == 0) ? fw : -fw;
// 
//     return n & 7;
// }
break 
/* __rem_pio2f(x,y)
 *
 * return the remainder of x rem pi/2 in y[0]+y[1]
 * use __rem_pio2f_internal()
 */
/*
 * invpio2:  24 bits of 2/pi
 * pio2_1:   first  17 bit of pi/2
 * pio2_1t:  pi/2 - pio2_1
 * pio2_2:   second 17 bit of pi/2
 * pio2_2t:  pi/2 - (pio2_1+pio2_2)
 * pio2_3:   third  17 bit of pi/2
 * pio2_3t:  pi/2 - (pio2_1+pio2_2+pio2_3)
 */

// static const float
// half = 5.0000000000e-01f, /* 0x3f000000 */
// invpio2 = 6.3661980629e-01f, /* 0x3f22f984 */
// pio2_1 = 1.5707855225e+00f, /* 0x3fc90f80 */
// pio2_1t = 1.0804334124e-05f, /* 0x37354443 */
// pio2_2 = 1.0804273188e-05f, /* 0x37354400 */
// pio2_2t = 6.0770999344e-11f, /* 0x2e85a308 */
// pio2_3 = 6.0770943833e-11f, /* 0x2e85a300 */
// pio2_3t = 6.1232342629e-17f;
break 
/* 0x248d3132 */

pub fn __rem_pio2f ( 
x : f32 , 

// float *y
break 
) -> int32_t { 
// float z, w, t, r, fn;
break 

let mut tx : [ f32 ;
3 ] = [ 0.0 ;
3 ] ;


// int32_t i, j, n, ix, hx;
break 

let e0 : int32_t = Default :: default ( ) ;
let nx : int32_t = Default :: default ( ) ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




ix 
= 

hx 
& 
0x7fffffff 

;


if 
ix 
<= 
0x3f490fd8 
{ /* |x| ~<= pi/4 , no need for reduction */

y [ 
0 
] = 
x 
;


y [ 
1 
] = 
0 
;


return 0 ;

}



if 
ix < 0x4016cbe4 
{ /* |x| < 3pi/4, special case with n=+-1 */
/* 17+17+24 bit pi has sufficient precision and best efficiency */

if 
hx 
> 
0 
{ 
z = x - pio2_1 ;


if 

( 

ix 
& 
0xfffe0000 

) 
!= 
0x3fc80000 

{ /* 17+24 bit pi OK */

y [ 
0 
] = 
z - pio2_1t 
;


y [ 
1 
] = 

( 

z 
- 
y [ 0 ] 

) 
- 
pio2_1t 

;

}



else { /* near pi/2, use 17+17+24 bit pi */

z -= pio2_2 ;


y [ 
0 
] = 
z - pio2_2t 
;


y [ 
1 
] = 

( 

z 
- 
y [ 0 ] 

) 
- 
pio2_2t 

;

}



return 1 ;

}



else { /* negative x */

z = x + pio2_1 ;


if 

( 

ix 
& 
0xfffe0000 

) 
!= 
0x3fc80000 

{ /* 17+24 bit pi OK */

y [ 
0 
] = 
z + pio2_1t 
;


y [ 
1 
] = 

( 

z 
- 
y [ 0 ] 

) 
+ 
pio2_1t 

;

}



else { /* near pi/2, use 17+17+24 bit pi */

z += pio2_2 ;


y [ 
0 
] = 
z + pio2_2t 
;


y [ 
1 
] = 

( 

z 
- 
y [ 0 ] 

) 
+ 
pio2_2t 

;

}



return -1 ;

}


}



if 
ix 
<= 
0x43490f80 
{ /* |x| ~<= 2^7*(pi/2), medium size */

t = x . abs ( ) ;



n 
= 

( 

t * invpio2 
+ 
half 

) 
as int32_t 
;



r#fn 
= 

n 
as f32 
;



r 
= 

t 
- 
r#fn * pio2_1 

;


w = r#fn * pio2_1t ;

/* 1st round good to 40 bit */

{ 
let high : u32 ;



j 
= 

ix 
>> 
23 

;


y [ 
0 
] = 
r - w 
;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
y [ 0 ] 
) 
;



( 
high 
-y[0];

if ( 
0 
== 
0 
) == false { break ;
}
-y[1]


i 
= 

j 
- 
( 

( 

high 
>> 
23 

) 
& 
0xff 

) 

;


if 
i 
> 
8 
{ /* 2nd iteration needed, good to 57 */

t = r ;


w = r#fn * pio2_2 ;


r = t - w ;



w 
= 

r#fn * pio2_2t 
- 
( 

( 
t - r 
) 
- 
w 

) 

;


y [ 
0 
] = 
r - w 
;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
y [ 0 ] 
) 
;



( 
high 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




i 
= 

j 
- 
( 

( 

high 
>> 
23 

) 
& 
0xff 

) 

;


if 
i 
> 
25 
{ /* 3rd iteration need, 74 bits acc */

t = r ;

/* will cover all possible cases */

w = r#fn * pio2_3 ;


r = t - w ;



w 
= 

r#fn * pio2_3t 
- 
( 

( 
t - r 
) 
- 
w 

) 

;


y [ 
0 
] = 
r - w 
;

}


}


}



y [ 
1 
] = 

( 

r 
- 
y [ 0 ] 

) 
- 
w 

;


if 
hx < 0 
{ 
y [ 
0 
] = 
// -y[0]
break 
;


y [ 
1 
] = 
// -y[1]
break 
;



- n 

}



else { 
return n ;

}


}


/*
     * all other (large) arguments
     */

if 
! 
FLT_UWORD_IS_FINITE ( ix ) 

{ 
-y[0]y [ 
1 
] = 
x - x 
;


y [ 
-y[1];

}



else { 
y [ 
1 
] = 
__raise_invalidf ( ) 
;


y [ 
0 
] = 
y [ 1 ] 
static C1: f32 = f32::from_bits(0x3D2AAAA5); // 0.04166664555668830871582031250
static C2: f32 = f32::from_bits(0xBAB60615); // -0.001388731063343584537506103516
static C3: f32 = f32::from_bits(0xCCF47D);return 0 ;

}


/* set z = scalbn(|x|,ilogb(x)-7) */


e0 
= 
let mut hz: f32;
let mut z: f32;
let mut r: f32;
let mut w: f32;( 

ix 
>> 
23 

) 
- 
134 

) 
as int32_t 
;

/* e0 = ilogb(z)-7; */

loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

ix 
- 
( 


e0 
as int32_t 
<< 
23 

) 

) 
;



( 
z 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



i = 0 ;
while 
i < 2 
{ 
tx [ 
i 
] = 

( 
static S1: f32 = -0xaaaaab.0p-26f; // -0.16666667163, 0xBE2AAAAB
static S2: f32 = 0x8888bb.0p-30f; // 0.0083333803341, 0x3C0888BB
static S3: f32 = -0xd02de1.0p-36f; // -0.00019853517006, 0xB9502DE1
static S4: f32 = 0xbe6dbe.0p-42f;;



z 
= 

( 

z 
- 
tx [ i ] 

) 
* 
two8 

;


translate_bpc_vpp ! ( i ) 
}



tx [ 
2 
] = 
z 
;


nx = 3 ;
while 
nx 
> 
1 
{ 
if 

tx [ 
nx - 1 
] 
!= 
zero 

{ 
break ;

}


/* skip zero term */

translate_bpc_mmv ! ( nx ) 
}



n = __rem_pio2f_internal ( 
tx , 

y , 

e0 , 

nx 
) ;


if 
hx < 0 
{ 
y [ 
0 
] = 
// -y[0]
break 
;


y [ 
1 
] = 
// -y[1]
break 
;



- n 

}



return n ;

}



// static const float
// C1 = 0xaaaaa5.0p-28f, /*  0.04166664555668830871582031250,    0x3D2AAAA5 */
// C2 = -0xb60615.0p-33f, /* -0.001388731063343584537506103516,   0xBAB60615 */
// C3 = 0xccf47d.0p-39f;
break 
/*  0.00002443254288664320483803749084, 0x37CCF47C */

pub fn __cosf ( 
x : f32 , 

y : f32 
) -> f32 { 
// float hz, z, r, w;
break 

z = x * x ;



r 
= 

z 
* 
( 

C1 
+ 

z 
* 
( 

C2 
+ 
z * C3 

) 


) 

;


hz = 0.5 * z ;


w = one - hz ;




w 
+ 
( 

( 

( 
one - w 
) 
- 
hz 

) 
+ 
( 

z * r 
- 
x * y 

) 

) 


}



// static const float
// S1 = -0xaaaaab.0p-26f, /* -0.16666667163,      0xBE2AAAAB */
// S2 = 0x8888bb.0p-30f, /*  0.0083333803341,    0x3C0888BB */
// S3 = -0xd02de1.0p-36f, /* -0.00019853517006,   0xB9502DE1 */
// S4 = 0xbe6dbe.0p-42f;
break 
/*  0.0000028376084629, 0x363E6DBE */

pub fn __sinf ( 
x : f32 , 

y : f32 , 

iy : i32 
) -> f32 { 
let z : f32 = Default :: default ( ) ;
let r : f32 = Default :: default ( ) ;
let v : f32 = Default :: default ( ) ;


z = x * x ;


v = z * x ;



r 
= 

S2 
+ 

z 
* 
( 

S3 
+ 
z * S4 

) 


;


if 
iy == 0 
{ 


x 
+ 

v 
* 
( 

S1 
+ 
z * r 

) 



}



else { 


x 
- 
( 

( 


z 
* 
( 

half * y 
- 
v * r 

) 

- 
y 

) 
- 
v * S1 

) 


}


}


}}
