#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::mathd::internal::gammad_c::t1;
use crate::libm::mathd::internal::gammad_c::t2;
use crate::libm::mathd::internal::log1pmfd_h::Lg1;
use crate::libm::mathd::internal::log1pmfd_h::Lg2;
use crate::libm::mathd::internal::log1pmfd_h::Lg3;
use crate::libm::mathd::internal::log1pmfd_h::Lg4;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */

// static const float
// /* |(log(1+s)-log(1-s))/s - Lg(s)| < 2**-34.24 (~[-4.95e-11, 4.97e-11]). */
// Lg1 = 0xaaaaaa.0p-24f, /* 0.66666662693, 0x3F2AAAAA */
// Lg2 = 0xccce13.0p-25f, /* 0.40000972152, 0x3ECCCE13 */
// Lg3 = 0x91e9ee.0p-25f, /* 0.28498786688, 0x3E91E9EE */
// Lg4 = 0xf89e26.0p-26f;
const Lg1: f32 = f32::from_bits(0x3F2AAAAA); // 0.66666662693
const Lg2: f32 = f32::from_bits(0x3ECCCE13); // 0.40000972152
fn __log1pmff(f: f32) -> f32 {
    let hfsq: f32;
    let s: f32;
    let z: f32;
    let R: f32;
    let w: f32;
    let t1: f32;
    let t2: f32;

    s = f / (2.0f32 + f);
    z = s * s;
    w = z * z;
    t1 = w * (Lg2 + w * Lg4);
    t2 = z * (Lg1 + w * Lg3);
    R = t2 + t1;
    hfsq = 0.5f32 * f * f;
    return s * (hfsq + R);
}//     return s * (hfsq + R);
// 
break 
