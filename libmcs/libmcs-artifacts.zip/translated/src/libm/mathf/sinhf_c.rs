#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::__raise_overflowf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathf::expf_c::expf;
use crate::libm::mathf::expm1f_c::expm1f;
use crate::libm::mathf::fabsf_c::fabsf;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

const one: f32 = 1.0;

pub fn sinhf(x: f32) -> f32 {
    let t: f32 = Default::default();
    let w: f32 = Default::default();
    let h: f32 = Default::default();

    let ix: int32_t = Default::default();
    let jx: int32_t = Default::default();

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (jx) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    ix = jx & 0x7fffffff;

    /* x is INF or NaN */

    if !FLT_UWORD_IS_FINITE(ix) {
        return x + x;
    }

    h = 0.5;

    if jx < 0 {
        h = -h;
    }

    /* |x| in [0,22], return sign(x)*0.5*(E+E/(E+1))) */

    if ix < 0x41b00000 {
        /* |x|<22 */

        if ix < 0x31800000 {
            /* |x|<2**-28 */

            if FLT_UWORD_IS_ZERO(ix) {
                /* return x inexact except 0 */

                return x;
            } else {
                __raise_inexactf(x)
            }
        }

        t = expm1f(x.abs());

        if ix < 0x3f800000 {
            h * (2.0 * t - t * t / (t + one))
        }

        h * (t + t / (t + one))
    }

    /* |x| in [22, log(maxfloat)] return 0.5*exp(|x|) */

    if ix <= FLT_UWORD_LOG_MAX {
        h * expf(x.abs())
    }

    /* |x| in [log(maxfloat), overflowthresold] */

    if ix <= FLT_UWORD_LOG_2MAX {
        w = expf(0.5 * x.abs());

        t = h * w;

        return t * w;
    }

    /* |x| > overflowthresold, sinh(x) overflow */

    __raise_overflowf(x)
}
