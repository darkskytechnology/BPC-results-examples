#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zerof;
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathd::log10d_c::ivln10hi;
use crate::libm::mathd::log10d_c::ivln10lo;
use crate::libm::mathd::log10d_c::log10_2hi;
use crate::libm::mathd::log10d_c::log10_2lo;
use crate::libm::mathf::frexpf_c::two25;
use crate::libm::mathf::internal::log1pmff_h::__log1pmff;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// two25 = 3.3554432000e+07f, /* 0x4c000000 */
// ivln10hi = 4.3432617188e-01f, /* 0x3ede6000 */
// ivln10lo = -3.1689971365e-05f, /* 0xb804ead9 */
// log10_2hi = 3.0102920532e-01f, /* 0x3e9a2080 */
// log10_2lo = 7.9034151668e-07f;
static TWO25: f32 = 3.3554432000e+07f; // 0x4c000000
static IVLN10HI: f32 = 4.3432617188e-01f; // 0x3ede6000
static IVLN10LO: f32 = -3.1689971365e-05f; // 0xb804ead9
static LOG10_2HI: f32 = 3.0102920532e-01f; // 0x3e9a2080
static LOG10_2LO: f32 = 7.9034151668e-07; 
/* 0x355427db */

const zero : f32 = 0.0 ;
let (f, hfsq, hi, lo, r, y): (f32, f32, f32, f32, f32, f32);x : f32 
) -> f32 { 
// float f, hfsq, hi, lo, r, y;
break 

let i : int32_t = Default :: default ( ) ;
let k : int32_t = Default :: default ( ) ;
let hx : int32_t = Default :: default ( ) ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



k = 0 ;


if 
FLT_UWORD_IS_ZERO ( 

hx 
& 
0x7fffffff 

) 
{ 

__raise_div_by_zerof ( -1.0 ) 

/* log(+-0)=-inf */
}



if 
FLT_UWORD_IS_NAN ( 

hx 
& 
0x7fffffff 

) 
{ /* x = NaN */

return x + x ;

}



if 
hx < 0 
{ 

__raise_invalidf ( ) 

/* log(-#) = NaN */
}



if 
FLT_UWORD_IS_INFINITE ( hx ) 
{ /* x = +Inf */

return x + x ;

}



if 
FLT_UWORD_IS_SUBNORMAL ( hx ) 
{ 
k -= 25 ;


x *= two25 ;

/* subnormal number, scale up x */

loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


}



if 
hx == 0x3f800000 
{ /* log(1) = +0 */

return zero ;

}



k += 

( 

hx 
>> 
23 

) 
- 
127 

;


hx &= 
0x007fffff 
;



i 
= 

( 

hx 
+ 
( 
0x4afb0d 
) 

) 
& 
0x800000 

;


loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

hx 
| 
( 

i 
^ 
0x3f800000 

) 

) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* normalize x or x/2 */

k += 
( 

i 
>> 
23 

) 
;



y 
= 

k 
as f32 
;


f = x - 1.0 ;



hfsq 
= 
0.5 
* 
f 
* 
f 
;


r = __log1pmff ( f ) ;


hi = f - hfsq ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
hi 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

hx 
& 
0xfffff000 

) 
;



( 
hi 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




lo 
= 


( 
f - hi 
) 
- 
hfsq 

+ 
r 

;







y * log10_2lo 
+ 

( 
lo + hi 
) 
* 
ivln10lo 


+ 
lo * ivln10hi 

+ 
hi * ivln10hi 

+ 
y * log10_2hi 


}


