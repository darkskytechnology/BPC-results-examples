#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexact;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathd::acosd_c::pi;
use crate::libm::mathd::atan2d_c::pi_lo;
use crate::libm::mathd::atan2d_c::pi_o_2;
use crate::libm::mathd::atan2d_c::pi_o_4;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathf::atanf_c::atanf;
use crate::libm::mathf::fabsf_c::fabsf;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// zero = 0.0f,
// pi_o_4 = 7.8539818525e-01f, /* 0x3f490fdb */
// pi_o_2 = 1.5707963705e+00f, /* 0x3fc90fdb */
// pi = 3.1415927410e+00f, /* 0x40490fdb */
// pi_lo = -8.7422776573e-08f;
const ZERO: f32 = 0.0;
const PI_O_4: f32 = 7.8539818525e-01; // 0x3f490fdb
const PI_O_2: f32 = 1.5707963705e+00; // 0x3fc90fdb
const PI: f32 = 3.1415927410e+00; // 0x40490fdb
const PI_LO: f32 = -8.7422776573e-08; 
/* 0xb3bbbd2e */

pub fn atan2f ( 
y : f32 , 

let mut k: i32;
let mut m: i32;
let mut hx: i32;
let mut hy: i32;
let mut ix: i32;
let mut iy: i32;

// int32_t k, m, hx, hy, ix, iy;
break 

loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




ix 
= 

hx 
& 
0x7fffffff 

;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
y 
) 
;



( 
hy 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




iy 
= 

hy 
& 
0x7fffffff 

;


if 

FLT_UWORD_IS_NAN ( ix ) 
|| 
FLT_UWORD_IS_NAN ( iy ) 

{ /* x or y is NaN */

return x + y ;

}



if 
hx == 0x3f800000 
{ 

y . atan ( ) 

/* x=1.0 */
}




m 
= 

( 

( 

hy 
>> 
31 

) 
& 
1 

) 
| 
( 

( 

hx 
>> 
30 

) 
& 
2 

) 

;

/* 2*sign(x)+sign(y) */
/* when y = 0 */

if 
FLT_UWORD_IS_ZERO ( iy ) 
{ 
match 
m 
{ /* FALLTHRU */
/* FALLTHRU */

1 => { 
return y ;

}


/* atan(+-0,+anything)=+-0 */

2 => { 

__raise_inexact ( pi ) 

fn __raise_inexact(pi: f64) {
    // Function body is not provided, so we cannot translate it.
    // Ensure that any unsafe operations are handled properly in Rust.
    // For example, if this function involves FFI or raw pointers, use `unsafe` blocks.
    // If the function is dependent on external C functions or structures, 
    // make sure to provide safe Rust equivalents or bindings.
}/* atan(+0,-anything) = pi */

3 => { 

// -__raise_inexact(pi)
break 

}


/* atan(-0,-anything) =-pi */
_ => { }

}


}


/* when x = 0 */
fn __raise_inexact(pi_o_2: f64) {
    // Function body is not provided, so we cannot translate it.
    // Ensure that any unsafe operations are handled appropriately in Rust.
    // For example, if this function involves FFI or other unsafe code,
    // use `unsafe` blocks as needed.
}{ 

if 
( 
hy < 0 
) 
{ 
// -__raise_inexact(pi_o_2)
break 
}

else { 
__raise_inexact ( pi_o_2 ) 
}



}


/* when x is INF */

if 
FLT_UWORD_IS_INFINITE ( ix ) 
{ 
if 
FLT_UWORD_IS_INFINITE ( iy ) 
{ 
match 
m 
{ /* FALLTHRU */
fn __raise_inexact(pi_o_4: f64) {
    // Function body is not provided, so we assume it does something with pi_o_4
    // In Rust, we need to ensure safety and handle any potential errors or unsafe operations
    // Since the original C code is not provided, we cannot translate the exact functionality
    // However, we can provide a placeholder function that takes a f64 argument
    // and performs a safe operation or logs the value

    // Placeholder for the actual functionality
    println!("Raising inexact with value: {}", pi_o_4);
}__raise_inexact ( pi_o_4 ) 

}


/* atan(+INF,+INF) */

1 => { 

// -__raise_inexact(pi_o_4)
break 

__raise_inexact(3.0f * pi_o_4);/* atan(-INF,+INF) */

2 => { 

__raise_inexact ( 
3.0 * pi_o_4 
) 

}


/*atan(+INF,-INF)*/

3 => { 

// -__raise_inexact(3.0f * pi_o_4)
break 

}


/*atan(-INF,-INF)*/
_ => { }

}


}



else { 
match 
m 
{ /* FALLTHRU */

0 => { 
return zero ;

}


/* atan(+...,+INF) */

1 => { 

- zero 

}
fn __raise_inexact(pi: f64) {
    // The function body is not provided, so we cannot translate it.
    // Ensure that any unsafe operations are handled properly in Rust.
    // For example, if this function involves floating-point operations,
    // consider using Rust's standard library functions for safe handling.
}
2 => { 

__raise_inexact ( pi ) 

}


/* atan(+...,-INF) */

3 => { 

// -__raise_inexact(pi)
break 

}


/* atan(-...,-INF) */
_ => { }

}


fn __raise_inexact(pi_o_2: f64) {
    // Function body is not provided, so we cannot translate the internals.
    // However, we can ensure that the function signature is safe in Rust.
    // Assuming pi_o_2 is a floating-point number, we use f64 for precision.
    // The function does not return anything, so it is a void function in C.
    // In Rust, this is represented by the unit type `()`.
}}


/* when y is INF */

if 
FLT_UWORD_IS_INFINITE ( iy ) 
{ 

if 
( 
hy < 0 
) 
{ 
// -__raise_inexact(pi_o_2)
break 
}

else { 
__raise_inexact ( pi_o_2 ) 
}



}


/* compute y/x */


k 
= 

( 
iy - ix 
) 
>> 
23 

;


if 
k 
> 
26 
{ 
z = __raise_inexact ( pi_o_2 ) ;

/* |y/x| >  2**26 */

m &= 
1 
;

}



else if 

hx < 0 
&& 
k < -26 

{ 
z = 0.0 ;

/* 0 > |y|/x > -2**26 */
}



else { 
z = atanf ( 
fabsf ( 
y / x 
) 
) ;

/* safe to do y/x */
}



match 
m 
{ 
0 => { 
return z ;

}


/* atan(+,+) */

1 => { 

- z 

}


/* atan(-,+) */

2 => { 


pi 
- 
( 
z - pi_lo 
) 


}


/* atan(+,-) */
_ => { /* case 3 */



( 
z - pi_lo 
) 
- 
pi 


}

}

/* atan(-,-) */

}


}
