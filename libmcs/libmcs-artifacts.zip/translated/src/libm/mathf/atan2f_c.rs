#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexact;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::include::math_h::atanf;
use crate::libm::include::math_h::fabsf;
use crate::libm::mathd::acosd_c::pi;
use crate::libm::mathd::atan2d_c::pi_lo;
use crate::libm::mathd::atan2d_c::pi_o_2;
use crate::libm::mathd::atan2d_c::pi_o_4;
use crate::libm::mathd::atan2d_c::zero;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// zero = 0.0f,
// pi_o_4 = 7.8539818525e-01f, /* 0x3f490fdb */
// pi_o_2 = 1.5707963705e+00f, /* 0x3fc90fdb */
// pi = 3.1415927410e+00f, /* 0x40490fdb */
// pi_lo = -8.7422776573e-08f;
static ZERO: f32 = 0.0;
static PI_O_4: f32 = 7.8539818525e-01; // 0x3f490fdb
static PI_O_2: f32 = 1.5707963705e+00; // 0x3fc90fdb
static PI: f32 = 3.1415927410e+00; // 0x40490fdb
static PI_LO: f32 = -8.7422776573e-08; 
/* 0xb3bbbd2e */

pub fn atan2f ( 
y : f32 , 

let (mut k, mut m, mut hx, mut hy, mut ix, mut iy): (i32, i32, i32, i32, i32, i32);

// int32_t k, m, hx, hy, ix, iy;
break 

loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




ix 
= 

hx 
& 
0x7fffffff 

;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
y 
) 
;



( 
hy 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




iy 
= 

hy 
& 
0x7fffffff 

;


if 

FLT_UWORD_IS_NAN ( ix ) 
|| 
FLT_UWORD_IS_NAN ( iy ) 

{ /* x or y is NaN */

return x + y ;

}



if 
hx == 0x3f800000 
{ 

y . atan ( ) 

/* x=1.0 */
}




m 
= 

( 

( 

hy 
>> 
31 

) 
& 
1 

) 
| 
( 

( 

hx 
>> 
30 

) 
& 
2 

) 

;

/* 2*sign(x)+sign(y) */
/* when y = 0 */

if 
FLT_UWORD_IS_ZERO ( iy ) 
{ 
match 
m 
{ /* FALLTHRU */
/* FALLTHRU */

1 => { 
return y ;

}


/* atan(+-0,+anything)=+-0 */

2 => { 

__raise_inexact ( pi ) 

}


/* atan(+0,-anything) = pi */

-__raise_inexact(pi)break 

}


/* atan(-0,-anything) =-pi */
_ => { }

}


}


/* when x = 0 */

if 
FLT_UWORD_IS_ZERO ( ix ) 
{ 

if 
( 
hy < 0 
) 
{ 
// -__raise_inexact(pi_o_2)
-__raise_inexact(pi_o_2) 
}

else { 
__raise_inexact ( pi_o_2 ) 
}



}


/* when x is INF */

if 
FLT_UWORD_IS_INFINITE ( ix ) 
{ 
if 
FLT_UWORD_IS_INFINITE ( iy ) 
{ 
match 
m 
{ /* FALLTHRU */

0 => { 

__raise_inexact ( pi_o_4 ) 

}


/* atan(+INF,+INF) */

1 => { 

// -__raise_inexact(pi_o_4)
-__raise_inexact(pi_o_4) 

}


/* atan(-INF,+INF) */

2 => { 

__raise_inexact ( 
3.0 * pi_o_4 
) 

}


/*atan(+INF,-INF)*/

3 => { 

// -__raise_inexact(3.0f * pi_o_4)
-__raise_inexact(3.0f * pi_o_4) 

}


/*atan(-INF,-INF)*/
_ => { }

}


}



else { 
match 
m 
{ /* FALLTHRU */

0 => { 
return zero ;

}


/* atan(+...,+INF) */

1 => { 

- zero 

}


/* atan(-...,+INF) */

2 => { 

__raise_inexact ( pi ) 

}


/* atan(+...,-INF) */

3 => { 

// -__raise_inexact(pi)
-__raise_inexact(pi) 

}


/* atan(-...,-INF) */
_ => { }

}


}


}


/* when y is INF */

if 
FLT_UWORD_IS_INFINITE ( iy ) 
{ 

if 
( 
hy < 0 
) 
{ 
// -__raise_inexact(pi_o_2)
-__raise_inexact(pi_o_2) 
}

else { 
__raise_inexact ( pi_o_2 ) 
}



}


/* compute y/x */


k 
= 

( 
iy - ix 
) 
>> 
23 

;


if 
k 
> 
26 
{ 
z = __raise_inexact ( pi_o_2 ) ;

/* |y/x| >  2**26 */

m &= 
1 
;

}



else if 

hx < 0 
&& 
k < -26 

{ 
z = 0.0 ;

/* 0 > |y|/x > -2**26 */
}



else { 
z = atanf ( 
fabsf ( 
y / x 
) 
) ;

/* safe to do y/x */
}



match 
m 
{ 
0 => { 
return z ;

}


/* atan(+,+) */

1 => { 

- z 

}


/* atan(-,+) */

2 => { 


pi 
- 
( 
z - pi_lo 
) 


}


/* atan(+,-) */
_ => { /* case 3 */



( 
z - pi_lo 
) 
- 
pi 


}



/* atan(-,-) */




