#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::translate_bpc_vpp;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

pub fn sqrtf(x: f32) -> f32 {
    let z: f32 = Default::default();

    let r: uint32_t = Default::default();
    let hx: uint32_t = Default::default();

    // int32_t ix, s, q, m, t, i;
    let mut ix: i32;
    let mut s: i32;
    let mut q: i32;
    let mut m: i32;
    let mut t: i32;
    let mut i: i32;

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (ix) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    hx = ix & 0x7fffffff;

    /* take care of Inf and NaN */

    if !FLT_UWORD_IS_FINITE(hx) {
        if FLT_UWORD_IS_NAN(hx) {
            /* sqrt(NaN)=NaN */

            return x + x;
        } else if ix > 0 {
            /* sqrt(+inf)=+inf */

            return x;
        } else {
            /* sqrt(-inf)=sNaN */

            __raise_invalidf()
        }
    }

    /* take care of zero and -ves */

    if FLT_UWORD_IS_ZERO(hx) {
        return x;

        /* sqrt(+-0) = +-0 */
    }

    if ix < 0 {
        __raise_invalidf()

        /* sqrt(-ve) = sNaN */
    }

    /* normalize x */

    m = (ix >> 23);

    if FLT_UWORD_IS_SUBNORMAL(hx) {
        /* subnormal x */

        i = 0;
        while (ix & 0x00800000) == 0 {
            ix <<= 1;

            translate_bpc_vpp!(i)
        }

        m -= i - 1;
    }

    m -= 127;

    /* unbias exponent */

    ix = (ix & 0x007fffff) | 0x00800000;

    if 0 < (m & 1) {
        /* odd m, double x to make it even */

        ix += ix;
    }

    m >>= 1;

    /* m = [m/2] */
    /* generate sqrt(x) bit by bit */

    ix += ix;

    q = s = 0;

    /* q = sqrt(x) */

    r = 0x01000000;

    /* r = moving bit from right to left */

    while (r != 0) {
        t = s + r;

        if t <= ix {
            s = t + r;

            ix -= t;

            q += r;
        }

        ix += ix;

        r >>= 1;
    }

    if ix != 0 {
        let _ = __raise_inexactf(x);

        q += (q & 1);
    }

    ix = (q >> 1) + 0x3f000000;

    ix += (m << 23);

    loop {
        let mut sf_u: ieee_float_shape_type = Default::default();

        sf_u.word = (ix);

        (z) = sf_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    return z;
}
