#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_overflowf;
use crate::libm::common::tools_h::__raise_underflowf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathf::frexpf_c::two25;
use crate::libm::mathf::scalblnf_c::twom25;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// two25 = 3.355443200e+07f, /* 0x4c000000 */
// twom25 = 2.9802322388e-08f;
const TWO25: f32 = 3.355443200e+07f; // 0x4c000000
const TWOM25: f32 = 2.9802322388e-08;
/* 0x33000000 */

pub fn scalbnf(x: f32, n: i32) -> f32 {
    let k: int32_t = Default::default();
    let ix: int32_t = Default::default();

    let hx: u32;

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (ix) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    hx = ix & 0x7fffffff;

    k = hx >> 23;

    /* extract exponent */

    if FLT_UWORD_IS_ZERO(hx) {
        return x;
    }

    if !FLT_UWORD_IS_FINITE(hx) {
        return x + x;

        /* NaN or Inf */
    }

    if FLT_UWORD_IS_SUBNORMAL(hx) {
        x *= two25;

        loop {
            let mut gf_u: ieee_float_shape_type = Default::default();

            gf_u.value = (x);

            (ix) = gf_u.word;

            if (0 == 0) == false {
                break;
            }
        }

        k = ((ix & 0x7f800000) >> 23) - 25;

        if n < -50000 {
            __raise_underflowf(x)

            /*underflow*/
        }
    }

    if n > 50000 {
        __raise_overflowf(x)

        /*overflow */
    }

    k = k + n;

    if k > FLT_LARGEST_EXP {
        __raise_overflowf(x)

        /*overflow */
    }

    if k > 0 {
        /* normal result */

        loop {
            let mut sf_u: ieee_float_shape_type = Default::default();

            sf_u.word = ((ix & 0x807fffff) | (k << 23));

            (x) = sf_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        return x;
    }

    if k < FLT_SMALLEST_EXP {
        __raise_underflowf(x)

        /*underflow*/
    }

    k += 25;

    /* subnormal result */

    loop {
        let mut sf_u: ieee_float_shape_type = Default::default();

        sf_u.word = ((ix & 0x807fffff) | (k << 23));

        (x) = sf_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    return x * twom25;
}
