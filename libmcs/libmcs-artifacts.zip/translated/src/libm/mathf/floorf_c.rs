#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::ieee_float_shape_type;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */
/*
 * floorf(x)
 * Return x rounded toward -inf to integral value
 * Method:
 *    Bit twiddling.
 * Exception:
 *    Inexact flag raised if x not equal to floorf(x).
 */

pub fn floorf(x: f32) -> f32 {
    let _i0: int32_t = Default::default();
    let _j0: int32_t = Default::default();

    let i: uint32_t = Default::default();
    let ix: uint32_t = Default::default();

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (_i0) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    ix = (_i0 & 0x7fffffff);

    _j0 = (ix >> 23) - 0x7f;

    if _j0 < 23 {
        if _j0 < 0 {
            /* raise inexact if x != 0 */

            if FLT_UWORD_IS_ZERO(ix) {
                return x;
            }

            let _ = __raise_inexactf(x);

            if _i0 >= 0 {
                _i0 = 0;
            } else {
                _i0 = 0xbf800000 as int32_t;
            }
        } else {
            i = (0x007fffff) >> _j0;

            if (_i0 & i) == 0 {
                /* x is integral */

                return x;
            }

            let _ = __raise_inexactf(x);

            if _i0 < 0 {
                _i0 += (0x00800000) >> _j0;
            }

            _i0 &= (!i);
        }
    } else {
        if !FLT_UWORD_IS_FINITE(ix) {
            return x + x;

        /* inf or NaN */
        } else {
            return x;

            /* x is integral */
        }
    }

    loop {
        let mut sf_u: ieee_float_shape_type = Default::default();

        sf_u.word = (_i0);

        (x) = sf_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    return x;
}
