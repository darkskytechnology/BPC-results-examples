#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* lrint adapted to be llrint for Newlib, 2009 by Craig Howland. */
/*
 * llrintf(x)
 * Return x rounded to integral value according to the prevailing
 * rounding mode.
 * Method:
 *    Using floating addition.
 * Exception:
 *    Inexact flag raised if x not equal to llrintf(x).
 */

// static const float
// /* Adding a float, x, to 2^23 will cause the result to be rounded based on
//    the fractional part of x, according to the implementation's current rounding
//    mode.  2^23 is the smallest float that can be represented using all 23 significant
//    digits. */
// TWO23[2] = {
//      8.3886080000e+06f, /* 0x4b000000 */
//     -8.3886080000e+06f, /* 0xcb000000 */
// };
static TWO23: [f32; 2] = [
fn llrintf(x: f32) -> i64 {
    let mut _j0: i32;
    let sx: i32;
    let mut _i0: u32;
    let t: f32;
    let w: f32;
    let result: i64;

    _i0 = x.to_bits();

    // Extract sign bit.
    sx = (_i0 >> 31) as i32;

    // Extract exponent field.
    _j0 = ((_i0 & 0x7f800000) >> 23) as i32 - 127;

    if _j0 < (std::mem::size_of::<i64>() * 8) as i32 - 1 {
        if _j0 < -1 {
            return 0;
        } else if _j0 >= 23 {
            result = (((_i0 & 0x7fffff) | 0x800000) as i64) << (_j0 - 23);
        } else {
            w = TWO23[sx as usize] + x;
            t = w - TWO23[sx as usize];
            _i0 = t.to_bits();

            // Detect the all-zeros representation of plus and
            // minus zero, which fails the calculation below.
            if (_i0 & !(1u32 << 31)) == 0 {
                return 0;
            }

            _j0 = ((_i0 >> 23) & 0xff) as i32 - 0x7f;
            _i0 &= 0x7fffff;
            _i0 |= 0x800000;
            result = (_i0 >> (23 - _j0)) as i64;
        }
    } else {
        __raise_invalidf();
        if sx != 0 {
            return __MIN_LONG_LONG;
        } else {
            return __MAX_LONG_LONG;
        }
    }

    if sx != 0 { -result } else { result }
}//     return (sx != 0) ? -result : result;
// 
break 
