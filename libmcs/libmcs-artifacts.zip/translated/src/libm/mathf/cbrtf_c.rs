#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathd::cbrtd_c::B1;
use crate::libm::mathd::cbrtd_c::B2;
use crate::libm::mathd::cbrtd_c::C;
use crate::libm::mathd::cbrtd_c::D;
use crate::libm::mathd::cbrtd_c::E;
use crate::libm::mathd::cbrtd_c::F;
use crate::libm::mathd::cbrtd_c::G;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */
/* cbrtf(x)
 * Return cube root of x
 */

// static const uint32_t
// B1 = 709958130, /* B1 = (84+2/3-0.03306235651)*2**23 */
// B2 = 642849266;
const B1: u32 = 709958130; // B1 = (84+2/3-0.03306235651)*2**23
const B2: u32 = 642849266; 
const C: f32 = 5.4285717010e-01f32; // 19/35     = 0x3f0af8b0
const D: f32 = -7.0530611277e-01f32; // -864/1225 = 0xbf348ef1
const E: f32 = 1.4142856598e+00f32; // 99/70     = 0x3fb50750
const F: f32 = 1.6071428061e+00f32; // 45/28     = 0x3fcdb6db
const G: f32 = 3.5714286566e-01f32;break 
/* 5/14      = 0x3eb6db6e */

pub fn cbrtf ( 
x : f32 
) -> f32 { 
let hx : i32 ;


let r : f32 = Default :: default ( ) ;
let s : f32 = Default :: default ( ) ;
let t : f32 = Default :: default ( ) ;


let sign : u32 ;


let high : u32 ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




sign 
= 

hx 
& 
0x80000000 

;

/* sign= sign(x) */

// hx ^= sign;
break 
hx ^= sign;FLT_UWORD_IS_FINITE ( hx ) 

{ 

( 
x + x 
) 

/* cbrt(NaN,INF) is itself */
}



if 
FLT_UWORD_IS_ZERO ( hx ) 
{ 

( 
x 
) 

/* cbrt(0) is itself */
}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 
hx 
) 
;



( 
x 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* x <- |x| */
/* rough cbrt to 5 bits */

if 
FLT_UWORD_IS_SUBNORMAL ( hx ) 
{ /* subnormal number */

loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 
0x4b800000 
) 
;



( 
t 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* set t= 2**24 */

t *= x ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
t 
) 
;



( 
high 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

high / 3 
+ 
B2 

) 
;



( 
t 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


}



else { 
loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

hx / 3 
+ 
B1 

) 
;



( 
t 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


}


/* new cbrt to 23 bits */


r 
= 

t * t 
/ 
x 

;



s 
= 

C 
+ 
r * t 

;


t *= 

G 
+ 

F 
/ 
( 

s + E 
+ 
D / s 

) 


;

/* restore the sign bit */

loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
t 
) 
;



( 
high 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 
high | sign 
) 
;



( 
t 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




( 
t 
) 

}


