#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::machine::sparc_v8::mathf::sqrtf_c::sqrtf;
use crate::libm::mathd::internal::gammad_c::t1;
use crate::libm::mathd::internal::gammad_c::t2;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

pub fn hypotf(x: f32, y: f32) -> f32 {
    // float a = x;
    let a: f32 = x;

    // float b = y;
    let b: f32 = y;

    let t1: f32 = Default::default();
    let t2: f32 = Default::default();

    let _y1: f32 = Default::default();
    let _y2: f32 = Default::default();

    let w: f32 = Default::default();

    // int32_t j, k, ha, hb;
    let mut j: i32;
    let mut k: i32;
    let mut ha: i32;
    let mut hb: i32;

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (ha) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    ha &= 0x7fffffff;

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (y);

        (hb) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    hb &= 0x7fffffff;

    if hb > ha {
        j = ha;

        ha = hb;

        hb = j;
    }

    loop {
        let mut sf_u: ieee_float_shape_type = Default::default();

        sf_u.word = (ha);

        (a) = sf_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    /* a <- |a| */

    loop {
        let mut sf_u: ieee_float_shape_type = Default::default();

        sf_u.word = (hb);

        (b) = sf_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    /* b <- |b| */

    if (ha - hb) > 0xf000000 {
        return a + b;

        /* x/y > 2**30 */
    }

    k = 0;

    if ha > 0x58800000 {
        /* a>2**50 */

        if !FLT_UWORD_IS_FINITE(ha) {
            /* Inf or NaN */

            w = a + b;

            /* for sNaN */

            if FLT_UWORD_IS_INFINITE(ha) {
                w = a;
            }

            if FLT_UWORD_IS_INFINITE(hb) {
                w = b;
            }

            return w;
        }

        /* scale a and b by 2**-68 */

        ha -= 0x22000000;

        hb -= 0x22000000;

        k += 68;

        loop {
            let mut sf_u: ieee_float_shape_type = Default::default();

            sf_u.word = (ha);

            (a) = sf_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        loop {
            let mut sf_u: ieee_float_shape_type = Default::default();

            sf_u.word = (hb);

            (b) = sf_u.value;

            if (0 == 0) == false {
                break;
            }
        }
    }

    if hb < 0x26800000 {
        /* b < 2**-50 */

        if FLT_UWORD_IS_ZERO(hb) {
            return a;
        } else if FLT_UWORD_IS_SUBNORMAL(hb) {
            loop {
                let mut sf_u: ieee_float_shape_type = Default::default();

                sf_u.word = (0x7e800000);

                (t1) = sf_u.value;

                if (0 == 0) == false {
                    break;
                }
            }

            /* t1=2^126 */

            b *= t1;

            a *= t1;

            k -= 126;
        } else {
            /* scale a and b by 2^80 */

            ha += 0x28000000;

            /* a *= 2^80 */

            hb += 0x28000000;

            /* b *= 2^80 */

            k -= 80;

            loop {
                let mut sf_u: ieee_float_shape_type = Default::default();

                sf_u.word = (ha);

                (a) = sf_u.value;

                if (0 == 0) == false {
                    break;
                }
            }

            loop {
                let mut sf_u: ieee_float_shape_type = Default::default();

                sf_u.word = (hb);

                (b) = sf_u.value;

                if (0 == 0) == false {
                    break;
                }
            }
        }
    }

    /* medium size a and b */

    w = a - b;

    if w > b {
        loop {
            let mut sf_u: ieee_float_shape_type = Default::default();

            sf_u.word = (ha & 0xfffff000);

            (t1) = sf_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        t2 = a - t1;

        w = sqrtf(t1 * t1 - (b * (-b) - t2 * (a + t1)));
    } else {
        a = a + a;

        loop {
            let mut sf_u: ieee_float_shape_type = Default::default();

            sf_u.word = (hb & 0xfffff000);

            (_y1) = sf_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        _y2 = b - _y1;

        loop {
            let mut sf_u: ieee_float_shape_type = Default::default();

            sf_u.word = ((ha + 0x00800000) & 0xfffff000);

            (t1) = sf_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        t2 = a - t1;

        w = sqrtf(t1 * _y1 - (w * (-w) - (t1 * _y2 + t2 * b)));
    }

    if k != 0 {
        loop {
            let mut sf_u: ieee_float_shape_type = Default::default();

            sf_u.word = ((0x7F + k) << 23);

            (t1) = sf_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        return t1 * w;
    } else {
        return w;
    }
}
