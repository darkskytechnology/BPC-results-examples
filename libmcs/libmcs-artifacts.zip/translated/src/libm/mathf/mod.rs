pub mod acosf_c;

pub mod acoshf_c;

pub mod asinf_c;

pub mod asinhf_c;

pub mod atan2f_c;

pub mod atanf_c;

pub mod atanhf_c;

pub mod cbrtf_c;

pub mod ceilf_c;

pub mod copysignf_c;

pub mod cosf_c;

pub mod coshf_c;

pub mod erfcf_c;

pub mod erff_c;

pub mod exp2f_c;

pub mod expf_c;

pub mod expm1f_c;

pub mod fabsf_c;

pub mod fdimf_c;

pub mod floorf_c;

pub mod fmaf_c;

pub mod fmaxf_c;

pub mod fminf_c;

pub mod fmodf_c;

pub mod frexpf_c;

pub mod hypotf_c;

pub mod ilogbf_c;

pub mod internal;

pub mod ldexpf_c;

pub mod lgammaf_c;

pub mod llrintf_c;

pub mod llroundf_c;

pub mod log10f_c;

pub mod log1pf_c;

pub mod log2f_c;

pub mod logbf_c;

pub mod logf_c;

pub mod lrintf_c;

pub mod lroundf_c;

pub mod modff_c;

pub mod nanf_c;

pub mod nearbyintf_c;

pub mod nextafterf_c;

pub mod nexttowardf_c;

pub mod powf_c;

pub mod remainderf_c;

pub mod remquof_c;

pub mod rintf_c;

pub mod roundf_c;

pub mod scalblnf_c;

pub mod scalbnf_c;

pub mod sinf_c;

pub mod sinhf_c;

pub mod sqrtf_c;

pub mod tanf_c;

pub mod tanhf_c;

pub mod tgammaf_c;

pub mod truncf_c;

