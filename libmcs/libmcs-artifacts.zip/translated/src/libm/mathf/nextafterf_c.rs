#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_overflowf;
use crate::libm::common::tools_h::__raise_underflowf;
use crate::libm::common::tools_h::ieee_float_shape_type;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

pub fn nextafterf(x: f32, y: f32) -> f32 {
    // int32_t hx, hy, ix, iy;
    let mut hx: i32;
    let mut hy: i32;
    let mut ix: i32;
    let mut iy: i32;

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (hx) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (y);

        (hy) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    ix = hx & 0x7fffffff;

    /* |x| */

    iy = hy & 0x7fffffff;

    /* |y| */

    if FLT_UWORD_IS_NAN(ix) || FLT_UWORD_IS_NAN(iy) {
        return x + y;
    } else if hx == hy {
        return x;

    /* x=y, return x */
    } else if ix == 0 {
        /* x == 0 */

        if ix == iy {
            return x;

            /* x=y, return x */
        }

        loop {
            let mut sf_u: ieee_float_shape_type = Default::default();

            sf_u.word = ((hy & 0x80000000) | 1);

            (x) = sf_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        /* return +-minsubnormal */

        let _ = __raise_underflowf(x);

        return x;
    } else if hx >= 0 {
        /* x > 0 */

        if hx > hy {
            /* x > y, x -= ulp */

            hx -= 1;
        } else {
            /* x < y, x += ulp */

            hx += 1;
        }
    } else {
        /* x < 0 */

        if hy >= 0 || hx > hy {
            /* x < y, x -= ulp */

            hx -= 1;
        } else {
            /* x > y, x += ulp */

            hx += 1;
        }
    }

    hy = hx & 0x7f800000;

    if hy > FLT_UWORD_MAX {
        __raise_overflowf(x)

        /* overflow if x is finite */
    }

    if hy < 0x00800000 {
        /* underflow */

        let _ = __raise_underflowf(x);
    }

    loop {
        let mut sf_u: ieee_float_shape_type = Default::default();

        sf_u.word = (hx);

        (x) = sf_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    return x;
}
