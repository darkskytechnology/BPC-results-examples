#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathf::fabsf_c::fabsf;
use crate::libm::mathf::fmodf_c::fmodf;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

const zero: f32 = 0.0;

pub fn remainderf(x: f32, y: f32) -> f32 {
    let hx: int32_t = Default::default();
    let hy: int32_t = Default::default();

    let sx: u32;

    let y_half: f32 = Default::default();

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (hx) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (y);

        (hy) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    sx = hx & 0x80000000;

    hy &= 0x7fffffff;

    hx &= 0x7fffffff;

    /* purge off exception values */

    if FLT_UWORD_IS_NAN(hx) || FLT_UWORD_IS_NAN(hy) {
        /* x or y is NaN */

        return x + y;
    } else if FLT_UWORD_IS_ZERO(hy) || FLT_UWORD_IS_INFINITE(hx) {
        /* y is 0 or x is inf */

        __raise_invalidf()
    } else {
        /* No action required */

        // }
        // The provided input seems to be incomplete or incorrect. Please provide a complete C function for translation.

        if hy <= FLT_UWORD_HALF_MAX {
            x = fmodf(x, 2 * y);

            /* now x < 2y */
        }

        if (hx - hy) == 0 {
            return zero * x;
        }

        x = x.abs();

        y = y.abs();

        if hy < 0x01000000 {
            if x + x > y {
                x -= y;

                if x + x >= y {
                    x -= y;
                }
            }
        } else {
            y_half = 0.5 * y;

            if x > y_half {
                x -= y;

                if x >= y_half {
                    x -= y;
                }
            }
        }

        loop {
            let mut gf_u: ieee_float_shape_type = Default::default();

            gf_u.value = (x);

            (hx) = gf_u.word;

            if (0 == 0) == false {
                break;
            }
        }

        loop {
            let mut sf_u: ieee_float_shape_type = Default::default();

            sf_u.word = (hx ^ sx);

            (x) = sf_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        return x;
    }
}
