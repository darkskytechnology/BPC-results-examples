#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::ieee_float_shape_type;
// USE STATEMENTS END
/* SPDX-License-Identifier: GTDGmbH */
/* Copyright 2020-2021 by GTD GmbH. */

pub fn nanf(payload: &'static str) -> f32 {
    let _ = payload;

    let x: f32 = Default::default();

    loop {
        let mut sf_u: ieee_float_shape_type = Default::default();

        sf_u.word = (0x7FCF067D);

        (x) = sf_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    return x;
}
