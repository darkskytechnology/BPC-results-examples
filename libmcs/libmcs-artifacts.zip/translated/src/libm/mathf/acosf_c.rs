#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::include::math_h::sqrtf;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::acosd_c::pS0;
use crate::libm::mathd::acosd_c::pS1;
use crate::libm::mathd::acosd_c::pS2;
use crate::libm::mathd::acosd_c::pS3;
use crate::libm::mathd::acosd_c::pS4;
use crate::libm::mathd::acosd_c::pS5;
use crate::libm::mathd::acosd_c::pi;
use crate::libm::mathd::acosd_c::pio2_hi;
use crate::libm::mathd::acosd_c::pio2_lo;
use crate::libm::mathd::acosd_c::qS1;
use crate::libm::mathd::acosd_c::qS2;
use crate::libm::mathd::acosd_c::qS3;
use crate::libm::mathd::acosd_c::qS4;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// one = 1.0000000000e+00f, /* 0x3F800000 */
// pi = 3.1415925026e+00f, /* 0x40490fda */
// pio2_hi = 1.5707962513e+00f, /* 0x3fc90fda */
// pio2_lo = 7.5497894159e-08f, /* 0x33a22168 */
// pS0 = 1.6666667163e-01f, /* 0x3e2aaaab */
// pS1 = -3.2556581497e-01f, /* 0xbea6b090 */
// pS2 = 2.0121252537e-01f, /* 0x3e4e0aa8 */
// pS3 = -4.0055535734e-02f, /* 0xbd241146 */
// pS4 = 7.9153501429e-04f, /* 0x3a4f7f04 */
// pS5 = 3.4793309169e-05f, /* 0x3811ef08 */
// qS1 = -2.4033949375e+00f, /* 0xc019d139 */
// qS2 = 2.0209457874e+00f, /* 0x4001572d */
// qS3 = -6.8828397989e-01f, /* 0xbf303361 */
// qS4 = 7.7038154006e-02f;
static ONE: f32 = 1.0000000000e+00f32; // 0x3F800000
static PI: f32 = 3.1415925026e+00f32; // 0x40490fda
static PIO2_HI: f32 = 1.5707962513e+00f32; // 0x3fc90fda
static PIO2_LO: f32 = 7.5497894159e-08f32; // 0x33a22168
static PS0: f32 = 1.6666667163e-01f32; // 0x3e2aaaab
let (mut z, mut p, mut q, mut r, mut w, mut s, mut c, mut df): (f32, f32, f32, f32, f32, f32, f32, f32);static PS4: f32 = 7.9153501429e-04f32; // 0x3a4f7f04
static PS5: f32 = 3.4793309169e-05f32; // 0x3811ef08
static QS1: f32 = -2.4033949375e+00f32; // 0xc019d139
static QS2: f32 = 2.0209457874e+00f32; // 0x4001572d
static QS3: f32 = -6.8828397989e-01f32; // 0xbf303361
static QS4: f32 = 7.7038154006e-01f32; // Note: The original C code seems to be incomplete here, so I added a placeholder value for QS4. 
/* 0x3d9dc62e */

pub fn acosf ( 
x : f32 
) -> f32 { 
// float z, p, q, r, w, s, c, df;
break 

let hx : int32_t = Default :: default ( ) ;
let ix : int32_t = Default :: default ( ) ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




ix 
= 

hx 
& 
0x7fffffff 

;


if 
ix == 0x3f800000 
{ /* |x|==1 */

if 
hx 
> 
0 
{ 
return 0.0 ;

/* acos(1) = 0  */
}



else { 


pi 
+ 
2.0 * pio2_lo 


/* acos(-1)= pi */
}


}



else if 
ix 
> 
0x3f800000 
{ /* |x| >= 1 */

if 
__builtin_isnan ( x ) 
{ 
return x + x ;

}


}
/* acos(|x|>1) is NaN */
}



else { /* No action required */

// }
break 

if 
ix < 0x3f000000 
{ /* |x| < 0.5 */

if 
ix 
<= 
0x23000000 
{ 
return pio2_hi + pio2_lo ;

/*if|x|<2**-57*/
}



z = x * x ;



p 
= 

z 
* 
( 

pS0 
+ 

z 
* 
( 

pS1 
+ 

z 
* 
( 

pS2 
+ 

z 
* 
( 

pS3 
+ 

z 
* 
( 

pS4 
+ 
z * pS5 

) 


) 


) 


) 


) 

;



q 
= 

one 
+ 

z 
* 
( 

qS1 
+ 

z 
* 
( 

qS2 
+ 

z 
* 
( 

qS3 
+ 
z * qS4 

) 


) 


) 


;


r = p / q ;




pio2_hi 
- 
( 

x 
- 
( 

pio2_lo 
- 
x * r 

) 

) 


}



else if 
hx < 0 
{ /* x < -0.5 */


z 
= 

( 
one + x 
) 
* 
0.5 

;



p 
= 

z 
* 
( 

pS0 
+ 

z 
* 
( 

pS1 
+ 

z 
* 
( 

pS2 
+ 

z 
* 
( 

pS3 
+ 

z 
* 
( 

pS4 
+ 
z * pS5 

) 


) 


) 


) 


) 

;



q 
= 

one 
+ 

z 
* 
( 

qS1 
+ 

z 
* 
( 

qS2 
+ 

z 
* 
( 

qS3 
+ 
z * qS4 

) 


) 


) 


;


s = z . sqrt ( ) ;


r = p / q ;



w 
= 

r * s 
- 
pio2_lo 

;




pi 
- 

2.0 
* 
( 
s + w 
) 



}



else { /* x > 0.5 */

let idf : i32 ;



z 
= 

( 
one - x 
) 
* 
0.5 

;


s = z . sqrt ( ) ;


df = s ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
df 
) 
;



( 
idf 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

idf 
& 
0xfffff000 

) 
;



( 
df 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




c 
= 

( 

z 
- 
df * df 

) 
/ 
( 
s + df 
) 

;



p 
= 

z 
* 
( 

pS0 
+ 

z 
* 
( 

pS1 
+ 

z 
* 
( 

pS2 
+ 

z 
* 
( 

pS3 
+ 

z 
* 
( 

pS4 
+ 
z * pS5 

) 


) 


) 


) 


) 

;



q 
= 

one 
+ 

z 
* 
( 

qS1 
+ 

z 
* 
( 

qS2 
+ 

z 
* 
( 

qS3 
+ 
z * qS4 

) 


) 


) 


;


r = p / q ;



w 
= 

r * s 
+ 
c 

;




2.0 
* 
( 
df + w 
) 


}








