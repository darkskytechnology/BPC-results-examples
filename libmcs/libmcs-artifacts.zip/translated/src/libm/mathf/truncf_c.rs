#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::ieee_float_shape_type;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */

pub fn truncf(x: f32) -> f32 {
    let sb: i32;

    let w: i32;

    let exponent_less_127: i32;

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (w) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    /* Extract sign bit. */

    sb = w & 0x80000000;

    /* Extract exponent field. */

    exponent_less_127 = ((w & 0x7f800000) >> 23) - 127;

    if exponent_less_127 < 23 {
        if exponent_less_127 < 0 {
            /* -1 < x < 1, so result is +0 or -0. */

            loop {
                let mut sf_u: ieee_float_shape_type = Default::default();

                sf_u.word = (sb);

                (x) = sf_u.value;

                if (0 == 0) == false {
                    break;
                }
            }
        } else {
            loop {
                let mut sf_u: ieee_float_shape_type = Default::default();

                sf_u.word = (sb | (w & !(0x007fffff >> exponent_less_127)));

                (x) = sf_u.value;

                if (0 == 0) == false {
                    break;
                }
            }
        }
    } else {
        if exponent_less_127 == 128 {
            /* x is NaN or infinite. */

            return x + x;
        }

        /* All bits in the fraction field are relevant. */
    }

    return x;
}
