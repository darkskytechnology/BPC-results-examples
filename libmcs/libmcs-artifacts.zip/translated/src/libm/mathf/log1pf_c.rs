#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zerof;
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::__raise_invalidf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathd::expm1d_c::ln2_hi;
use crate::libm::mathd::expm1d_c::ln2_lo;
use crate::libm::mathf::internal::log1pmff_h::__log1pmff;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float
// ln2_hi = 6.9313812256e-01f, /* 0x3f317180 */
// ln2_lo = 9.0580006145e-06f;
const LN2_HI: f32 = 6.9313812256e-01f32; // 0x3f317180
const LN2_LO: f32 = 9.0580006145e-06f32; 
/* 0x3717f7d1 */

const zero : f32 = 0.0 ;


pub fn log1pf ( 
let hfsq: f32;
let f: f32;
let c: f32;
let r: f32;
let u: f32;let k: i32;
let hx: i32;
let hu: i32;
let ax: i32; 

// int32_t k, hx, hu, ax;
break 

loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




ax 
= 

hx 
& 
0x7fffffff 

;


k = 1 ;


if 
! 
FLT_UWORD_IS_FINITE ( hx ) 

{ /* x = NaN/+Inf */

return x + x ;

}



if 
hx < 0x3ed413d7 
{ /* x < 0.41422  */

if 
ax 
>= 
0x3f800000 
{ /* x <= -1.0 */

if 
FLT_UWORD_IS_NAN ( ax ) 
{ /* x = NaN */

return x + x ;

}



else if 
x == -1.0 
{ 

__raise_div_by_zerof ( -1.0 ) 

/* log1p(-1)=-inf */
}



else { 

__raise_invalidf ( ) 

/* log1p(x<-1)=NaN */
}


}



if 
ax < 0x31000000 
{ /* |x| < 2**-29 */

if 
ax < 0x24800000 
{ /* |x| < 2**-54 */


__raise_inexactf ( x ) 

}



else { 

__raise_inexactf ( 

x 
- 

x * x 
* 
0.5 


) 

}


}



if 

hx 
> 
0 
|| 

hx 
<= 
( 

0xbe95f61f 
as int32_t 
) 


{ 
k = 0 ;


f = x ;


hu = 1 ;

}


/* -0.2929<x<0.41422 */
}



if 
k 
!= 
0 
{ 
if 
hx < 0x5a000000 
{ 
u = 1.0 + x ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
u 
) 
;



( 
hu 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




k 
= 

( 

hu 
>> 
23 

) 
- 
127 

;

/* correction term */


c 
= 
if 
( 
k 
> 
0 
) 
{ 

1.0 
- 
( 
u - x 
) 

}

else { 

x 
- 
( 
u - 1.0 
) 

}


;


c /= u ;

}



else { 
u = x ;


loop { 
let mut gf_u : ieee_float_shape_type = Default :: default ( ) ;


gf_u . value = 
( 
u 
) 
;



( 
hu 
) 
= 
gf_u . word 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




k 
= 

( 

hu 
>> 
23 

) 
- 
127 

;


c = 0 ;

}



hu &= 
0x007fffff 
;


if 
hu < 0x3504f7 
{ 
loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

hu 
| 
0x3f800000 

) 
;



( 
u 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* normalize u */
}



else { 
k += 1 ;


loop { 
let mut sf_u : ieee_float_shape_type = Default :: default ( ) ;


sf_u . word = 
( 

hu 
| 
0x3f000000 

) 
;



( 
u 
) 
= 
sf_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* normalize u/2 */


hu 
= 

( 
0x00800000 - hu 
) 
>> 
2 

;

}



f = u - 1.0 ;

}




hfsq 
= 
0.5 
* 
f 
* 
f 
;


if 
hu == 0 
{ /* |f| < 2**-20 */

if 
f == zero 
{ 
c += 
k * ln2_lo 
;




k * ln2_hi 
+ 
c 


}




R 
= 

hfsq 
* 
( 

1.0 
- 
0.66666666666666666 * f 

) 

;




k * ln2_hi 
- 
( 

( 

R 
- 
( 

k * ln2_lo 
+ 
c 

) 

) 
- 
f 

) 


}



if 
k == 0 
{ 


f 
- 
( 

hfsq 
- 
__log1pmff ( f ) 

) 


}



else { 


k * ln2_hi 
- 
( 

( 

hfsq 
- 
( 

__log1pmff ( f ) 
+ 
( 

k * ln2_lo 
+ 
c 

) 

) 

) 
- 
f 

) 


}





