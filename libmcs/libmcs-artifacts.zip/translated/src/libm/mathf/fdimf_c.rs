#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: RedHat */
/* Copyright (C) 2002 by  Red Hat, Incorporated. All rights reserved. */

pub fn fdimf(x: f32, y: f32) -> f32 {
    if __builtin_isnan(x) || __builtin_isnan(y) {
        return x * y;
    }

    if x > y {
        x - y
    } else {
        0.0
    }
}
