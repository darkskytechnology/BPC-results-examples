#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::ieee_float_shape_type;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::erfcd_c::two;
use crate::libm::mathf::expm1f_c::expm1f;
use crate::libm::mathf::fabsf_c::fabsf;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* Conversion to float by Ian Lance Taylor, Cygnus Support, ian@cygnus.com. */

// static const float one = 1.0f, two = 2.0f;
const ONE: f32 = 1.0;
const TWO: f32 = 2.0;

pub fn tanhf(x: f32) -> f32 {
    let t: f32 = Default::default();
    let z: f32 = Default::default();

    let jx: int32_t = Default::default();
    let ix: int32_t = Default::default();

    loop {
        let mut gf_u: ieee_float_shape_type = Default::default();

        gf_u.value = (x);

        (jx) = gf_u.word;

        if (0 == 0) == false {
            break;
        }
    }

    ix = jx & 0x7fffffff;

    /* x is INF or NaN */

    if !FLT_UWORD_IS_FINITE(ix) {
        if __builtin_isnan(x) {
            /* tanh(NaN) = NaN */

            return x + x;
        } else if jx >= 0 {
            return one;

        /* tanh(+inf)=+1 */
        } else {
            -one

            /* tanh(-inf)=-1 */
        }
    }

    /* |x| < 22 */

    if ix < 0x41b00000 {
        /* |x|<22 */

        if ix < 0x24000000 {
            /* |x|<2**-55 */

            if FLT_UWORD_IS_ZERO(ix) {
                /* return x inexact except 0 */

                return x;
            } else {
                __raise_inexactf(x)
            }
        }

        if ix >= 0x3f800000 {
            /* |x|>=1  */

            t = expm1f(two * x.abs());

            z = one - two / (t + two);
        } else {
            t = expm1f(-two * x.abs());

            z = -t / (t + two);
        }

    /* |x| > 22, return +-1 */
    } else {
        z = __raise_inexactf(one);

        /* raised inexact flag */
    }

    if (jx >= 0) {
        z
    } else {
        -z
    }
}
