#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zero;
use crate::libm::common::tools_h::__raise_invalid;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathd::frexpd_c::two54;
use crate::libm::mathd::internal::log1pmfd_h::__log1pmf;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the base :math:`10` logarithm.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float log10f(float x);
 *     double log10(double x);
 *     long double logl(long double x);
 *
 * Description
 * ===========
 *
 * ``log10`` computes the base :math:`10` logarithm of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    log10(x) \approx log_{10}(x)
 *
 * Returns
 * =======
 *
 * ``log10`` returns the base :math:`10` logarithm of :math:`x`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when the input value is negative.
 *
 * Raise ``divide by zero`` exception when the input value is zero.
 *
 * Output map
 * ==========
 *
 * +---------------------+---------------+---------------+---------------+---------------+---------------------+---------------+---------------------+---------------+---------------+
 * | **x**               | :math:`-Inf`  | :math:`<0`    | :math:`-0`    | :math:`+0`    | :math:`]0,1[`       | :math:`1`     | :math:`>1`          | :math:`+Inf`  | :math:`NaN`   |
 * +=====================+===============+===============+===============+===============+=====================+===============+=====================+===============+===============+
 * | **log10(x)**        | :math:`qNaN`  | :math:`qNaN`  | :math:`-Inf`                  | :math:`log_{10}(x)` | :math:`+0`    | :math:`log_{10}(x)` | :math:`+Inf`  | :math:`qNaN`  |
 * +---------------------+---------------+---------------+---------------+---------------+---------------------+---------------+---------------------+---------------+---------------+
 *
 */
//

// static const double
// two54 = 1.80143985094819840000e+16, /* 0x43500000, 0x00000000 */
// ivln10hi = 4.34294481878168880939e-01, /* 0x3FDBCB7B, 0x15200000 */
// ivln10lo = 2.50829467116452752298e-11, /* 0x3DBB9438, 0xCA9AADD5 */
// log10_2hi = 3.01029995663611771306e-01, /* 0x3FD34413, 0x509F6000 */
// log10_2lo = 3.69423907715893078616e-13;
const TWO54: f64 = 1.80143985094819840000e+16; // 0x43500000, 0x00000000
const IVLN10HI: f64 = 4.34294481878168880939e-01; // 0x3FDBCB7B, 0x15200000
const IVLN10LO: f64 = 2.50829467116452752298e-11; // 0x3DBB9438, 0xCA9AADD5
const LOG10_2HI: f64 = 3.01029995663611771306e-01; // 0x3FD34413, 0x509F6000
const LOG10_2LO: f64 = 3.69423907715893078616e-1; 
/* 0x3D59FEF3, 0x11F12B36 */

const zero : f64 = 0.0 ;
let mut f: f64;
let mut hfsq: f64;
let mut hi: f64;
let mut lo: f64;
let mut r: f64;
let mut val_hi: f64;
let mut val_lo: f64;
let mut w: f64;
let mut y: f64;
let mut y2: f64;x : f64 
) -> f64 { 
// double f, hfsq, hi, lo, r, val_hi, val_lo, w, y, y2;
break 

let i : int32_t = Default :: default ( ) ;
let k : int32_t = Default :: default ( ) ;
let hx : int32_t = Default :: default ( ) ;


let lx : u32 ;


loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

ew_u . parts 
. msw 
;



( 
lx 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



k = 0 ;


if 
hx < 0x00100000 
{ /* x < 2**-1022  */

if 

( 

( 

hx 
& 
0x7fffffff 

) 
| 
lx 

) 
== 
0 

{ 

__raise_div_by_zero ( -1.0 ) 

/* log(+-0)=-inf */
}



if 
hx < 0 
{ 
if 
__builtin_isnan ( x ) 
{ 
return x + x ;

}



else { 

__raise_invalid ( ) 

/* log(-#) = NaN */
}


}



k -= 54 ;


x *= two54 ;

/* subnormal number, scale up x */

loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


}



if 
hx 
>= 
0x7ff00000 
{ /* x = NaN/+-Inf */

return x + x ;

}



if 

hx == 0x3ff00000 
&& 
lx == 0 

{ /* log(1) = +0 */

return zero ;

}



k += 

( 

hx 
>> 
20 

) 
- 
1023 

;


hx &= 
0x000fffff 
;



i 
= 

( 
hx + 0x95f64 
) 
& 
0x100000 

;


loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
x 
) 
;




sh_u . parts 
. msw 
= 
( 

hx 
| 
( 

i 
^ 
0x3ff00000 

) 

) 
;



( 
x 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* normalize x or x/2 */

k += 
( 

i 
>> 
20 

) 
;



y 
= 

k 
as f64 
;


f = x - 1.0 ;



hfsq 
= 
0.5 
* 
f 
* 
f 
;


r = __log1pmf ( f ) ;


hi = f - hfsq ;


loop { 
let mut sl_u : ieee_double_shape_type = Default :: default ( ) ;


sl_u . value = 
( 
hi 
) 
;




sl_u . parts 
. lsw 
= 
( 
0 
) 
;



( 
hi 
) 
= 
sl_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




lo 
= 


( 
f - hi 
) 
- 
hfsq 

+ 
r 

;


val_hi = hi * ivln10hi ;


y2 = y * log10_2hi ;



val_lo 
= 


y * log10_2lo 
+ 

( 
lo + hi 
) 
* 
ivln10lo 


+ 
lo * ivln10hi 

;

/*
     * Extra precision in for adding y*log10_2hi is not strictly needed
     * since there is no very large cancellation near x = sqrt(2) or
     * x = 1/sqrt(2), but we do it anyway since it costs little on CPUs
     * with some parallelism and it reduces the error for many args.
     */

w = y2 + val_hi ;


val_lo += 

( 
y2 - w 
) 
+ 
val_hi 

;


val_hi = w ;


return val_lo + val_hi ;

}


