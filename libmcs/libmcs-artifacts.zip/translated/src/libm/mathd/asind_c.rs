#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexact;
use crate::libm::common::tools_h::__raise_invalid;
use crate::libm::machine::sparc_v8::mathd::sqrtd_c::sqrt;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::acosd_c::pS0;
use crate::libm::mathd::acosd_c::pS1;
use crate::libm::mathd::acosd_c::pS2;
use crate::libm::mathd::acosd_c::pS3;
use crate::libm::mathd::acosd_c::pS4;
use crate::libm::mathd::acosd_c::pS5;
use crate::libm::mathd::acosd_c::pio2_hi;
use crate::libm::mathd::acosd_c::pio2_lo;
use crate::libm::mathd::acosd_c::qS1;
use crate::libm::mathd::acosd_c::qS2;
use crate::libm::mathd::acosd_c::qS3;
use crate::libm::mathd::acosd_c::qS4;
use crate::libm::mathd::fabsd_c::fabs;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the arc sine of :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float asinf(float x);
 *     double asin(double x);
 *     long double asinl(long double x);
 *
 * Description
 * ===========
 *
 * ``asin`` computes the inverse sine (*arc sine*) of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    asin(x) \approx sin^{-1}(x)
 *
 * Returns
 * =======
 *
 * ``asin`` returns value in radians, in the range :math:`[-\frac{\pi}{2},
 * \frac{\pi}{2}]`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when the input value is not in the
 * interval :math:`[-1, 1]`.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+--------------+---------------------+--------------+--------------+---------------------+--------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<-1`  | :math:`\in [-1,-0[` | :math:`-0`   | :math:`+0`   | :math:`\in ]+0,+1]` | :math:`>+1`  | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+==============+=====================+==============+==============+=====================+==============+==============+==============+
 * | **asin(x)**         | :math:`qNaN` | :math:`qNaN` | :math:`sin^{-1} x`  | :math:`x`                   | :math:`sin^{-1} x`  | :math:`qNaN` | :math:`qNaN` | :math:`qNaN` |
 * +---------------------+--------------+--------------+---------------------+--------------+--------------+---------------------+--------------+--------------+--------------+
 *
 */
//

// static const double
// one = 1.00000000000000000000e+00, /* 0x3FF00000, 0x00000000 */
// pio2_hi = 1.57079632679489655800e+00, /* 0x3FF921FB, 0x54442D18 */
// pio2_lo = 6.12323399573676603587e-17, /* 0x3C91A626, 0x33145C07 */
// pio4_hi = 7.85398163397448278999e-01, /* 0x3FE921FB, 0x54442D18 */
// /* coefficient for R(x^2) */
// pS0 = 1.66666666666666657415e-01, /* 0x3FC55555, 0x55555555 */
// pS1 = -3.25565818622400915405e-01, /* 0xBFD4D612, 0x03EB6F7D */
// pS2 = 2.01212532134862925881e-01, /* 0x3FC9C155, 0x0E884455 */
// pS3 = -4.00555345006794114027e-02, /* 0xBFA48228, 0xB5688F3B */
// pS4 = 7.91534994289814532176e-04, /* 0x3F49EFE0, 0x7501B288 */
// pS5 = 3.47933107596021167570e-05, /* 0x3F023DE1, 0x0DFDF709 */
// qS1 = -2.40339491173441421878e+00, /* 0xC0033A27, 0x1C8A2D4B */
// qS2 = 2.02094576023350569471e+00, /* 0x40002AE5, 0x9C598AC8 */
// qS3 = -6.88283971605453293030e-01, /* 0xBFE6066C, 0x1B8D0159 */
// qS4 = 7.70381505559019352791e-02;
static ONE: f64 = 1.00000000000000000000e+00; // 0x3FF00000, 0x00000000
static PIO2_HI: f64 = 1.57079632679489655800e+00; // 0x3FF921FB, 0x54442D18
static PIO2_LO: f64 = 6.12323399573676603587e-17; // 0x3C91A626, 0x33145C07
static PIO4_HI: f64 = 7.85398163397448278999e-01; // 0x3FE921FB, 0x54442D18
// coefficient for R(x^2)
let mut t: f64;
let mut w: f64;
let mut p: f64;
let mut q: f64;
let mut c: f64;
let mut r: f64;
let mut s: f64;static PS3: f64 = -4.00555345006794114027e-02; // 0xBFA48228, 0xB5688F3B
static PS4: f64 = 7.91534994289814532176e-04; // 0x3F49EFE0, 0x7501B288
static PS5: f64 = 3.47933107596021167570e-05; // 0x3F023DE1, 0x0DFDF709
static QS1: f64 = -2.40339491173441421878e+00; // 0xC0033A27, 0x1C8A2D4B
static QS2: f64 = 2.02094576023350569471e+00; // 0x40002AE5, 0x9C598AC8
static QS3: f64 = -6.88283971605453293030e-01; // 0xBFE6066C, 0x1B8D0159
// Note: The original C code seems to be incomplete, as it ends abruptly. The Rust translation reflects the same state. 
/* 0x3FB3B8C5, 0xB12E9282 */

pub fn asin ( 
x : f64 
) -> f64 { 
// double t, w, p, q, c, r, s;
break 

let hx : int32_t = Default :: default ( ) ;
let ix : int32_t = Default :: default ( ) ;


loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




ix 
= 

hx 
& 
0x7fffffff 

;


if 
ix 
>= 
0x3ff00000 
{ /* |x|>= 1 */

let lx : u32 ;


loop { 
let mut gl_u : ieee_double_shape_type = Default :: default ( ) ;


gl_u . value = 
( 
x 
) 
;



( 
lx 
) 
= 

gl_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



if 

( 

( 
ix - 0x3ff00000 
) 
| 
lx 

) 
== 
0 

{ /* asin(1)=+-pi/2 with inexact */



x * pio2_hi 
+ 
x * pio2_lo 


}



if 
__builtin_isnan ( x ) 
{ 
return x + x ;

}




__raise_invalid ( ) 

/* asin(|x|>1) is NaN */
}



else if 
ix < 0x3fe00000 
{ /* |x|<0.5 */

if 
ix < 0x3e500000 
{ /* if |x| < 2**-26 */

if 
x == 0.0 
{ /* return x inexact except 0 */

return x ;

}



else { 

__raise_inexact ( x ) 

}


}



else { 
t = x * x ;



p 
= 

t 
* 
( 

pS0 
+ 

t 
* 
( 

pS1 
+ 

t 
* 
( 

pS2 
+ 

t 
* 
( 

pS3 
+ 

t 
* 
( 

pS4 
+ 
t * pS5 

) 


) 


) 


) 


) 

;



q 
= 

one 
+ 

t 
* 
( 

qS1 
+ 

t 
* 
( 

qS2 
+ 

t 
* 
( 

qS3 
+ 
t * qS4 

) 


) 


) 


;


w = p / q ;
{
  "rust_function": "// The provided input seems to be incomplete or malformed. 
// Please provide a complete C function for translation."
}
x 
+ 
x * w 


}


}



else { /* No action required */

// }
break 
/* 1> |x|>= 0.5 */


w 
= 

one 
- 
x . abs ( ) 

;


t = w * 0.5 ;



p 
= 

t 
* 
( 

pS0 
+ 

t 
* 
( 

pS1 
+ 

t 
* 
( 

pS2 
+ 

t 
* 
( 

pS3 
+ 

t 
* 
( 

pS4 
+ 
t * pS5 

) 


) 


) 


) 


) 

;



q 
= 

one 
+ 

t 
* 
( 

qS1 
+ 

t 
* 
( 

qS2 
+ 

t 
* 
( 

qS3 
+ 
t * qS4 

) 


) 


) 


;


s = t . sqrt ( ) ;


if 
ix 
>= 
0x3FEF3333 
{ /* if |x| > 0.975 */

w = p / q ;



t 
= 

pio2_hi 
- 
( 


2.0 
* 
( 

s 
+ 
s * w 

) 

- 
pio2_lo 

) 

;

}



else { 
w = s ;


loop { 
let mut sl_u : ieee_double_shape_type = Default :: default ( ) ;


sl_u . value = 
( 
w 
) 
;




sl_u . parts 
. lsw 
= 
( 
0 
) 
;



( 
w 
) 
= 
sl_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




c 
= 

( 

t 
- 
w * w 

) 
/ 
( 
s + w 
) 

;


r = p / q ;



p 
= 

2.0 
* 
s 
* 
r 
- 
( 

pio2_lo 
- 
2.0 * c 

) 

;



q 
= 

pio4_hi 
- 
2.0 * w 

;



t 
= 

pio4_hi 
- 
( 
p - q 
) 

;

}



if 
hx 
> 
0 
{ 
return t ;

}



else { 

- t 

}


}





