#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexact;
use crate::libm::machine::sparc_v8::mathd::sqrtd_c::sqrt;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::acoshd_c::ln2;
use crate::libm::mathd::fabsd_c::fabs;
use crate::libm::mathd::log1pd_c::log1p;
use crate::libm::mathd::logd_c::log;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions implements the hyperbolic arc sine of :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float asinhf(float x);
 *     double asinh(double x);
 *     long double asinhl(long double x);
 *
 * Description
 * ===========
 *
 * ``asinh`` computes the hyperbolic inverse sine (*hyperbolic arc sine*) of
 * the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    asinh(x) \approx sinh^{-1}(x) = ln \left( x + \sqrt{x^2+1} \right)
 *
 * Returns
 * =======
 *
 * ``asinh`` returns the hyperbolic inverse sine.
 *
 * Exceptions
 * ==========
 *
 * Does not raise overflow, division by zero, and invalid exceptions.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +---------------------+----------------------+----------------------+--------------+--------------+----------------------+----------------------+----------------------+
 * | **x**               | :math:`-Inf`         | :math:`<0`           | :math:`-0`   | :math:`+0`   | :math:`>0`           | :math:`+Inf`         | :math:`NaN`          |
 * +=====================+======================+======================+==============+==============+======================+======================+======================+
 * | **asinh(x)**        | :math:`-Inf`         | :math:`sinh^{-1}(x)` | :math:`x`                   | :math:`sinh^{-1}(x)` | :math:`+Inf`         | :math:`qNaN`         |
 * +---------------------+----------------------+----------------------+--------------+--------------+----------------------+----------------------+----------------------+
 *
 */
//

// static const double
// one = 1.00000000000000000000e+00, /* 0x3FF00000, 0x00000000 */
// ln2 = 6.93147180559945286227e-01;
const ONE: f64 = 1.00000000000000000000e+00; // 0x3FF00000, 0x00000000
const LN2: f64 = 6.93147180559945286227e-0;
/* 0x3FE62E42, 0xFEFA39EF */

pub fn asinh(x: f64) -> f64 {
    let t: f64 = Default::default();
    let w: f64 = Default::default();

    let hx: int32_t = Default::default();
    let ix: int32_t = Default::default();

    loop {
        let mut gh_u: ieee_double_shape_type = Default::default();

        gh_u.value = (x);

        (hx) = gh_u.parts.msw;

        if (0 == 0) == false {
            break;
        }
    }

    ix = hx & 0x7fffffff;

    if ix >= 0x7ff00000 {
        return x + x;

        /* x is inf or NaN */
    }

    if ix < 0x3e300000 {
        /* |x|<2**-28 */

        if x == 0.0 {
            /* return x inexact except 0 */

            return x;
        } else {
            __raise_inexact(x)
        }
    }

    if ix > 0x41b00000 {
        /* |x| > 2**28 */

        w = log(x.abs()) + ln2;
    } else if ix > 0x40000000 {
        /* 2**28 > |x| > 2.0 */

        t = x.abs();

        w = log(2.0 * t + one / (sqrt(x * x + one) + t));
    } else {
        /* 2.0 > |x| > 2**-28 */

        t = x * x;

        w = log1p(x.abs() + t / (one + sqrt(one + t)));
    }

    if hx > 0 {
        return w;
    } else {
        -w
    }
}
