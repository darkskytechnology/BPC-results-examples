#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexact;
use crate::libm::common::tools_h::__raise_overflow;
use crate::libm::common::tools_h::__raise_underflow;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::atan2d_c::zero;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the exponential function, that is
 * :math:`e` powered by :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float expf(float x);
 *     double exp(double x);
 *     long double expl(long double x);
 *
 * Description
 * ===========
 *
 * ``exp`` computes :math:`e` powered by the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    exp(x) \approx e^x
 *
 * Returns
 * =======
 *
 * ``exp`` returns :math:`e` powered by :math:`x`, in the range
 * :math:`\mathbb{F}^{+}_0`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``overflow`` exception when the magnitude of the input value is too
 * large.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<0`   | :math:`-0`   | :math:`+0`   | :math:`>0`   | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+==============+==============+==============+==============+==============+==============+
 * | **exp(x)**          | :math:`+0`   | :math:`e^x`  | :math:`+1`                  | :math:`e^x`  | :math:`+Inf` | :math:`qNaN` |
 * +---------------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+
 *
 */
//

// static const double
// one = 1.0,
// zero = 0.0,
// halF[2] = {0.5, -0.5,},
// twom1000 = 9.33263618503218878990e-302, /* 2**-1000=0x01700000,0*/
// o_threshold = 7.09782712893383973096e+02, /* 0x40862E42, 0xFEFA39EF */
// u_threshold = -7.45133219101941108420e+02, /* 0xc0874910, 0xD52D3051 */
// ln2HI[2] = {
//                6.93147180369123816490e-01, /* 0x3fe62e42, 0xfee00000 */
//               -6.93147180369123816490e-01, /* 0xbfe62e42, 0xfee00000 */
// },
// ln2LO[2] = {
//                1.90821492927058770002e-10, /* 0x3dea39ef, 0x35793c76 */
//               -1.90821492927058770002e-10, /* 0xbdea39ef, 0x35793c76 */
// },
// invln2 = 1.44269504088896338700e+00, /* 0x3ff71547, 0x652b82fe */
// P1 = 1.66666666666666019037e-01, /* 0x3FC55555, 0x5555553E */
// P2 = -2.77777777770155933842e-03, /* 0xBF66C16C, 0x16BEBD93 */
// P3 = 6.61375632143793436117e-05, /* 0x3F11566A, 0xAF25DE2C */
// P4 = -1.65339022054652515390e-06, /* 0xBEBBBD41, 0xC5D26BF1 */
// P5 = 4.13813679705723846039e-08;
const ONE: f64 = 1.0;
const ZERO: f64 = 0.0;
const HALF: [f64; 2] = [0.5, -0.5];
const TWOM1000: f64 = 9.33263618503218878990e-302; // 2**-1000=0x01700000,0
const O_THRESHOLD: f64 = 7.09782712893383973096e+02; // 0x40862E42, 0xFEFA39EF
const U_THRESHOLD: f64 = -7.45133219101941108420e+02; // 0xc0874910, 0xD52D3051
const LN2HI: [f64; 2] = [
    6.93147180369123816490e-01, // 0x3fe62e42, 0xfee00000
    -6.93147180369123816490e-01, // 0xbfe62e42, 0xfee00000
];
const LN2LO: [f64; 2] = [
    1.90821492927058770002e-10, // 0x3dea39ef, 0x35793c76
    -1.90821492927058770002e-10, // 0xbdea39ef, 0x35793c76
];
const INVLN2: f64 = 1.44269504088896338700e+00; // 0x3ff71547, 0x652b82fe
const P1: f64 = 1.66666666666666019037e-01; // 0x3FC55555, 0x5555553E
const P2: f64 = -2.77777777770155933842e-03; // 0xBF66C16C, 0x16BEBD93
const P3: f64 = 6.61375632143793436117e-05; // 0x3F11566A, 0xAF25DE2C
const P4: f64 = -1.65339022054652515390e-06; // 0xBEBBBD41, 0xC5D26BF1
const P5: f64 = 4.138136797057238; 
/* 0x3E663769, 0x72BEA4D0 */

pub fn exp ( 
x : f64 
) -> f64 { /* default IEEE double exp */

let y : f64 = Default :: default ( ) ;
let c : f64 = Default :: default ( ) ;
let t : f64 = Default :: default ( ) ;


let hi : f64 = 0.0 ;


let lo : f64 = 0.0 ;


let k : i32 = 0 ;


let xsb : i32 ;


let hx : u32 ;


loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




xsb 
= 

( 

hx 
>> 
31 

) 
& 
1 

;

/* sign bit of x */

hx &= 
0x7fffffff 
;

/* high word of |x| */
/* filter out non-finite argument */

if 
hx 
>= 
0x40862E42 
{ /* if |x|>=709.78... */

if 
hx 
>= 
0x7ff00000 
{ 
let lx : u32 ;


loop { 
let mut gl_u : ieee_double_shape_type = Default :: default ( ) ;


gl_u . value = 
( 
x 
) 
;



( 
lx 
) 
= 

gl_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



if 

( 

( 

hx 
& 
0xfffff 

) 
| 
lx 

) 
!= 
0 

{ 
return x + x ;

/* NaN */
}



else { /* exp(+-inf)={inf,0} */


if 
( 
xsb == 0 
) 
{ 
x 
}

else { 
zero 
}



}


}



if 
x 
> 
o_threshold 
{ 

__raise_overflow ( one ) 

/* overflow */
}



if 
x 
< 
u_threshold 
{ 

__raise_underflow ( zero ) 

/* underflow */
}


}


/* argument reduction */

if 
hx 
> 
0x3fd62e42 
{ /* if  |x| > 0.5 ln2 */

if 
hx < 0x3FF0A2B2 
{ /* and |x| < 1.5 ln2 */


hi 
= 

x 
- 
ln2HI [ xsb ] 

;



lo 
= 
ln2LO [ xsb ] 
;



k 
= 
1 
- 
xsb 
- 
xsb 
;

}



else { 

k 
= 

invln2 * x 
+ 
halF [ xsb ] 

;


t = k ;



hi 
= 

x 
- 

t 
* 
ln2HI [ 0 ] 


;

/* t*ln2HI is exact here */


lo 
= 

t 
* 
ln2LO [ 0 ] 

;

}



x = hi - lo ;

}



else if 
hx < 0x3df00000 
{ /* when |x|<2**-32 */

if 
x == 0.0 
{ /* return 1 inexact except 0 */

return one ;
It seems like you've provided an incomplete input. Could you please provide the full C code that you would like to be translated into Rust?

else { 

__raise_inexact ( 
one + x 
) 

}


}



else { /* No action required */

// }
break 
/* x is now in primary range */

t = x * x ;



c 
= 

x 
- 

t 
* 
( 

P1 
+ 

t 
* 
( 

P2 
+ 

t 
* 
( 

P3 
+ 

t 
* 
( 

P4 
+ 
t * P5 

) 


) 


) 


) 


;


if 
k == 0 
{ 


one 
- 
( 


( 
x * c 
) 
/ 
( 
c - 2.0 
) 

- 
x 

) 


}



else { 

y 
= 

one 
- 
( 

( 

lo 
- 

( 
x * c 
) 
/ 
( 
2.0 - c 
) 


) 
- 
hi 

) 

;

}



if 
k 
>= 
-1021 
{ 
let hy : u32 ;


loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
y 
) 
;



( 
hy 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
y 
) 
;




sh_u . parts 
. msw 
= 
( 

hy 
+ 
( 

( 

k 
as uint32_t 
) 
<< 
20 

) 

) 
;



( 
y 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* add k to y's exponent */

return y ;

}



else { 
let hy : u32 ;


loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
y 
) 
;



( 
hy 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
y 
) 
;




sh_u . parts 
. msw 
= 
( 

hy 
+ 
( 

( 


k 
as uint32_t 
+ 
1000 

) 
<< 
20 

) 

) 
;



( 
y 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* add k to y's exponent */

return y * twom1000 ;

}


}


}


