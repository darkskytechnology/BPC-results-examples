#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zero;
use crate::libm::common::tools_h::__raise_invalid;
use crate::libm::machine::sparc_v8::mathd::sqrtd_c::sqrt;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathd::cosd_c::cos;
use crate::libm::mathd::internal::besseld_h::invsqrtpi;
use crate::libm::mathd::sind_c::sin;
use crate::libm::mathd::y0d_c::y0;
use crate::libm::mathd::y1d_c::y1;
use crate::translate_bpc_vpp;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the Bessel function of the second kind
 * of order :math:`n`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     double yn(int n, double x);
 *
 * Description
 * ===========
 *
 * ``yn`` computes the Bessel value of :math:`x` of the second kind of order
 * :math:`n`.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    yn(n, x) = Y_{n}(x)
 *
 * Notice that the mathematical function represented by the procedure ``yn`` is
 * not :math:`y_n` (which is the spherical version of the Bessel function) but
 * :math:`Y_n`. See `Wikipedia
 * <https://en.wikipedia.org/wiki/Bessel_function>`_ for more information.
 *
 * Returns
 * =======
 *
 * ``yn`` returns the Bessel value of :math:`x` of the second kind of order
 * :math:`n`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when :math:`x` is negative.
 *
 * Raise ``divide by zero`` exception when :math:`x` is zero.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +--------------------------+-------------------------------+-------------------------------+
 * | yn(n,x)                  | n                                                             |
 * +--------------------------+-------------------------------+-------------------------------+
 * | x                        | :math:`<0`                    | :math:`>0`                    |
 * +==========================+===============================+===============================+
 * | :math:`-Inf`             | :math:`qNaN`                                                  |
 * +--------------------------+                                                               +
 * | :math:`<0`               |                                                               |
 * +--------------------------+-------------------------------+-------------------------------+
 * | :math:`-0`               | :math:`-Inf`                                                  |
 * +--------------------------+                                                               +
 * | :math:`+0`               |                                                               |
 * +--------------------------+-------------------------------+-------------------------------+
 * | :math:`>0`               | :math:`(-1)^n \cdot Y_{n}(x)` | :math:`Y_{n}(x)`              |
 * +--------------------------+-------------------------------+-------------------------------+
 * | :math:`+Inf`             | :math:`+0`                                                    |
 * +--------------------------+-------------------------------+-------------------------------+
 * | :math:`NaN`              | :math:`qNaN`                                                  |
 * +--------------------------+-------------------------------+-------------------------------+
 *
 */
//

pub fn yn ( 
n : i32 , 

x : f64 
) -> f64 { 
// int32_t i, hx, ix, lx;
let mut i: i32;
let mut hx: i32;
let mut ix: i32;
let mut lx: i32; 

let sign : i32 ;


let a : f64 = Default :: default ( ) ;
let b : f64 = Default :: default ( ) ;
let temp : f64 = Default :: default ( ) ;


loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

ew_u . parts 
. msw 
;



( 
lx 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




ix 
= 

0x7fffffff 
& 
hx 

;

/* if Y(n,NaN) is NaN */

if 
__builtin_isnan ( x ) 
{ /* yn(n,NaN) = NaN */

return x + x ;

}



if 

( 
ix | lx 
) 
== 
0 

{ /* yn(n,+-0) = +Inf */


__raise_div_by_zero ( -1.0 ) 

}



if 
hx < 0 
{ /* yn(n,<0) = NaN, y1(n,-Inf) = NaN */


__raise_invalid ( ) 

}



sign = 1 ;


if 
n < 0 
{ 

n 
= 
- n 
;



sign 
= 

1 
- 
( 

( 

n 
& 
1 

) 
<< 
1 

) 

;

}



if 
n == 0 
{ 

( 
y0 ( x ) 
) 

}



if 
n == 1 
{ 

( 

sign 
* 
y1 ( x ) 

) 

}



if 
ix == 0x7ff00000 
{ /* yn(n,+Inf) = +0.0 */

return zero ;

}



if 
ix 
>= 
0x52D00000 
{ /* x > 2**302 */
/* (x >> n**2)
         *        Jn(x) = cos(x-(2n+1)*pi/4)*sqrt(2/x*pi)
         *        Yn(x) = sin(x-(2n+1)*pi/4)*sqrt(2/x*pi)
         *        Let s=sin(x), c=cos(x),
         *        xn=x-(2n+1)*pi/4, sqt2 = sqrt(2),then
         *
         *           n    sin(xn)*sqt2    cos(xn)*sqt2
         *        ----------------------------------
         *           0     s-c         c+s
         *           1    -s-c         -c+s
         *           2    -s+c        -c-s
         *           3     s+c         c-s
         */

match 

n 
& 
3 

{ /* FALLTHRU */

0 => { 

temp 
= 

x . sin ( ) 
- 
x . cos ( ) 

;

}



1 => { 
-x.sin()
// -sin(x)
break 
- 
x . cos ( ) 

;

}



2 => { 

temp 
= 

// -sin(x)
-x.sin() 
+ 
x . cos ( ) 

;

}



3 => { 

temp 
= 

x . sin ( ) 
+ 
x . cos ( ) 

;

}


_ => { }

}




b 
= 

invsqrtpi * temp 
/ 
x . sqrt ( ) 

;

}



else { 
let high : u32 ;


a = y0 ( x ) ;


b = y1 ( x ) ;

/* quit if b is -inf */

loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
b 
) 
;



( 
high 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



i = 1 ;
while 

i 
< 
n 
&& 
high 
!= 
0xfff00000 

{ 
temp = b ;



b 
= 


( 


( 
i + i 
) 
as f64 
/ 
x 

) 
* 
b 

- 
a 

;


loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
b 
) 
;



( 
high 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



a = temp ;


translate_bpc_vpp ! ( i ) 
}


}



if 
sign 
> 
0 
{ 
return b ;

}



else { 

- b 

}


}


