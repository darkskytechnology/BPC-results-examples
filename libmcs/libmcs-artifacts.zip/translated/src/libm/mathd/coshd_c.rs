#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_overflow;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::expd_c::exp;
use crate::libm::mathd::expm1d_c::expm1;
use crate::libm::mathd::fabsd_c::fabs;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions implements the hyperbolic cosine of :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float coshf(float x);
 *     double cosh(double x);
 *     long double coshl(long double x);
 *
 * Description
 * ===========
 *
 * ``cosh`` computes the hyperbolic cosine of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    cosh(x) \approx cosh(x) = \frac{e^x+e^{-x}}{2}
 *
 * Returns
 * =======
 *
 * ``cosh`` returns the hyperbolic cosine, in the range :math:`\mathbb{F}_{>=1}`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``overflow`` exception when the magnitude of the input value is too large.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+-----------------+--------------+--------------+-----------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<0`      | :math:`-0`   | :math:`+0`   | :math:`>0`      | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+=================+==============+==============+=================+==============+==============+
 * | **cosh(x)**         | :math:`+Inf` | :math:`cosh(x)` | :math:`1`                   | :math:`cosh(x)` | :math:`+Inf` | :math:`qNaN` |
 * +---------------------+--------------+-----------------+--------------+--------------+-----------------+--------------+--------------+
 *
 */
//

// static const double one = 1.0, half = 0.5;
const ONE: f64 = 1.0;
const HALF: f64 = 0.5;

pub fn cosh(x: f64) -> f64 {
    let t: f64 = Default::default();
    let w: f64 = Default::default();

    let ix: i32;

    let lx: u32;

    /* High word of |x|. */

    loop {
        let mut gh_u: ieee_double_shape_type = Default::default();

        gh_u.value = (x);

        (ix) = gh_u.parts.msw;

        if (0 == 0) == false {
            break;
        }
    }

    ix &= 0x7fffffff;

    /* x is INF or NaN */

    if ix >= 0x7ff00000 {
        return x * x;
    }

    /* |x| in [0,0.5*ln2], return 1+expm1(|x|)^2/(2*exp(|x|)) */

    if ix < 0x3fd62e43 {
        t = expm1(x.abs());

        w = one + t;

        if ix < 0x3c800000 {
            return w;

            /* cosh(tiny) = 1 */
        }

        one + (t * t) / (w + w)
    }

    /* |x| in [0.5*ln2,22], return (exp(|x|)+1/exp(|x|)/2; */

    if ix < 0x40360000 {
        t = exp(x.abs());

        half * t + half / t
    }

    /* |x| in [22, log(maxdouble)] return half*exp(|x|) */

    if ix < 0x40862E42 {
        half * exp(x.abs())
    }

    /* |x| in [log(maxdouble), overflowthresold] */

    loop {
        let mut gl_u: ieee_double_shape_type = Default::default();

        gl_u.value = (x);

        (lx) = gl_u.parts.lsw;

        if (0 == 0) == false {
            break;
        }
    }

    if ix < 0x408633CE || (ix == 0x408633ce && lx <= 0x8fb9f87d as uint32_t) {
        w = exp(half * x.abs());

        t = half * w;

        return t * w;
    }

    /* |x| > overflowthresold, cosh(x) overflow */

    __raise_overflow(1.0)
}
