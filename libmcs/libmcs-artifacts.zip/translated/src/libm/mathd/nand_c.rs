#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: GTDGmbH */
/* Copyright 2020-2021 by GTD GmbH. */
/*
 *
 * This family of functions returns a predefined ``NaN``.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float nanf(const char *payload);
 *     double nan(const char *payload);
 *     long double nanl(const char *payload);
 *
 * Description
 * ===========
 *
 * ``nan`` produces a fixed ``qNaN`` regardless of input.
 *
 * The return ``qNaN`` is ``0x7FF80000000D067D`` as ``double`` (float: ``0x7FCF067D``).
 *
 * This procedure is not C standard compliant as the payload parameter is
 * ignored. If your platform/toolchain provides ``strtod`` as a workaround the
 * call ``strtod("NAN(char-sequence)", NULL);`` can be used as a replacement if
 * that functionality is wanted (same with ``strtof`` and ``strtold``).
 *
 * Returns
 * =======
 *
 * ``nan`` returns a ``qNaN``.
 *
 * Exceptions
 * ==========
 *
 * Does not raise exceptions.
 *
 */
//

pub fn nan(payload: &'static str) -> f64 {
    let _ = payload;

    let x: f64 = Default::default();

    loop {
        let mut iw_u: ieee_double_shape_type = Default::default();

        iw_u.parts.msw = (0x7FF80000);

        iw_u.parts.lsw = (0x000D067D);

        (x) = iw_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    return x;
}
