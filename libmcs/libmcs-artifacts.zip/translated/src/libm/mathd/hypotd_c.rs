#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::machine::sparc_v8::mathd::sqrtd_c::sqrt;
use crate::libm::mathd::internal::gammad_c::t1;
use crate::libm::mathd::internal::gammad_c::t2;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions implements the hypothenuse of a rightangled triangle.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float hypotf(float x, float y);
 *     double hypot(double x, double y);
 *     long double hypotl(long double x, long double y);
 *
 * Description
 * ===========
 *
 * ``hypot`` computes the length of the hypothenuse of a rightangled triangle
 * where the legs have the lengths :math:`x` and :math:`y`.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    hypot(x, y) \approx \sqrt{x^2 + y^2}
 *
 * Returns
 * =======
 *
 * ``hypot`` returns the length of the hypothenuse of a rightangled triangle.
 *
 * Exceptions
 * ==========
 *
 * Raise ``overflow`` exception when the magnitude of the input values is too
 * large.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | hypot(x,y)               | x                                                                                                         |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | y                        | :math:`-Inf`             | :math:`\in \mathbb{F}`   | :math:`+Inf`             | :math:`NaN`              |
 * +==========================+==========================+==========================+==========================+==========================+
 * | :math:`-Inf`             | :math:`+Inf`             | :math:`+Inf`             | :math:`+Inf`             | :math:`+Inf`             |
 * +--------------------------+                          +--------------------------+                          +--------------------------+
 * | :math:`\in \mathbb{F}`   |                          | :math:`\sqrt{x^2 + y^2}` |                          | :math:`qNaN`             |
 * +--------------------------+                          +--------------------------+                          +--------------------------+
 * | :math:`+Inf`             |                          | :math:`+Inf`             |                          | :math:`+Inf`             |
 * +--------------------------+                          +--------------------------+                          +--------------------------+
 * | :math:`NaN`              |                          | :math:`qNaN`             |                          | :math:`qNaN`             |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 *
 */
//

pub fn hypot(x: f64, y: f64) -> f64 {
    let a: f64 = x;

    let b: f64 = y;

    let t1: f64 = Default::default();
    let t2: f64 = Default::default();

    let _y1: f64 = Default::default();
    let _y2: f64 = Default::default();

    let w: f64 = Default::default();

    // int32_t j, k, ha, hb;
    let mut j: i32;
    let mut k: i32;
    let mut ha: i32;
    let mut hb: i32;

    loop {
        let mut gh_u: ieee_double_shape_type = Default::default();

        gh_u.value = (x);

        (ha) = gh_u.parts.msw;

        if (0 == 0) == false {
            break;
        }
    }

    ha &= 0x7fffffff;

    loop {
        let mut gh_u: ieee_double_shape_type = Default::default();

        gh_u.value = (y);

        (hb) = gh_u.parts.msw;

        if (0 == 0) == false {
            break;
        }
    }

    hb &= 0x7fffffff;

    if hb > ha {
        a = y;

        b = x;

        j = ha;

        ha = hb;

        hb = j;
    } else {
        a = x;

        b = y;
    }

    loop {
        let mut sh_u: ieee_double_shape_type = Default::default();

        sh_u.value = (a);

        sh_u.parts.msw = (ha);

        (a) = sh_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    /* a <- |a| */

    loop {
        let mut sh_u: ieee_double_shape_type = Default::default();

        sh_u.value = (b);

        sh_u.parts.msw = (hb);

        (b) = sh_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    /* b <- |b| */

    if (ha - hb) > 0x3c00000 {
        return a + b;

        /* x/y > 2**60 */
    }

    k = 0;

    if ha > 0x5f300000 {
        /* a>2**500 */

        if ha >= 0x7ff00000 {
            /* Inf or NaN */

            let low: u32;

            w = a + b;

            /* for sNaN */

            loop {
                let mut gl_u: ieee_double_shape_type = Default::default();

                gl_u.value = (a);

                (low) = gl_u.parts.lsw;

                if (0 == 0) == false {
                    break;
                }
            }

            if ((ha & 0xfffff) | low) == 0 {
                w = a;
            }

            loop {
                let mut gl_u: ieee_double_shape_type = Default::default();

                gl_u.value = (b);

                (low) = gl_u.parts.lsw;

                if (0 == 0) == false {
                    break;
                }
            }

            if ((hb ^ 0x7ff00000) | low) == 0 {
                w = b;
            }

            return w;
        }

        /* scale a and b by 2**-600 */

        ha -= 0x25800000;

        hb -= 0x25800000;

        k += 600;

        loop {
            let mut sh_u: ieee_double_shape_type = Default::default();

            sh_u.value = (a);

            sh_u.parts.msw = (ha);

            (a) = sh_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        loop {
            let mut sh_u: ieee_double_shape_type = Default::default();

            sh_u.value = (b);

            sh_u.parts.msw = (hb);

            (b) = sh_u.value;

            if (0 == 0) == false {
                break;
            }
        }
    }

    if hb < 0x20b00000 {
        /* b < 2**-500 */

        if hb <= 0x000fffff {
            /* subnormal b or 0 */

            let low: u32;

            loop {
                let mut gl_u: ieee_double_shape_type = Default::default();

                gl_u.value = (b);

                (low) = gl_u.parts.lsw;

                if (0 == 0) == false {
                    break;
                }
            }

            if (hb | low) == 0 {
                return a;
            }

            t1 = 0;

            loop {
                let mut sh_u: ieee_double_shape_type = Default::default();

                sh_u.value = (t1);

                sh_u.parts.msw = (0x7fd00000);

                (t1) = sh_u.value;

                if (0 == 0) == false {
                    break;
                }
            }

            /* t1=2^1022 */

            b *= t1;

            a *= t1;

            k -= 1022;
        } else {
            /* scale a and b by 2^600 */

            ha += 0x25800000;

            /* a *= 2^600 */

            hb += 0x25800000;

            /* b *= 2^600 */

            k -= 600;

            loop {
                let mut sh_u: ieee_double_shape_type = Default::default();

                sh_u.value = (a);

                sh_u.parts.msw = (ha);

                (a) = sh_u.value;

                if (0 == 0) == false {
                    break;
                }
            }

            loop {
                let mut sh_u: ieee_double_shape_type = Default::default();

                sh_u.value = (b);

                sh_u.parts.msw = (hb);

                (b) = sh_u.value;

                if (0 == 0) == false {
                    break;
                }
            }
        }
    }

    /* medium size a and b */

    w = a - b;

    if w > b {
        t1 = 0;

        loop {
            let mut sh_u: ieee_double_shape_type = Default::default();

            sh_u.value = (t1);

            sh_u.parts.msw = (ha);

            (t1) = sh_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        t2 = a - t1;

        w = sqrt(t1 * t1 - (b * (-b) - t2 * (a + t1)));
    } else {
        a = a + a;

        _y1 = 0;

        loop {
            let mut sh_u: ieee_double_shape_type = Default::default();

            sh_u.value = (_y1);

            sh_u.parts.msw = (hb);

            (_y1) = sh_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        _y2 = b - _y1;

        t1 = 0;

        loop {
            let mut sh_u: ieee_double_shape_type = Default::default();

            sh_u.value = (t1);

            sh_u.parts.msw = (ha + 0x00100000);

            (t1) = sh_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        t2 = a - t1;

        w = sqrt(t1 * _y1 - (w * (-w) - (t1 * _y2 + t2 * b)));
    }

    if k != 0 {
        t1 = 0.0;

        loop {
            let mut sh_u: ieee_double_shape_type = Default::default();

            sh_u.value = (t1);

            sh_u.parts.msw = ((0x3FF + k) << 20);

            (t1) = sh_u.value;

            if (0 == 0) == false {
                break;
            }
        }

        return t1 * w;
    } else {
        return w;
    }
}
