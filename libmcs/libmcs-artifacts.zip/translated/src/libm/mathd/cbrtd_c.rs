#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the cubic root of :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float cbrtf(float x);
 *     double cbrt(double x);
 *     long double cbrtl(long double x);
 *
 * Description
 * ===========
 *
 * ``cbrt`` computes the cubic root of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    cbrt(x) \approx \sqrt[3]{x}
 *
 * Returns
 * =======
 *
 * ``cbrt`` returns the cubic root of the input value.
 *
 * Exceptions
 * ==========
 *
 * Does not raise exceptions.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+---------------------+--------------+--------------+---------------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<0`          | :math:`-0`   | :math:`+0`   | :math:`>0`          | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+=====================+==============+==============+=====================+==============+==============+
 * | **cbrt(x)**         | :math:`-Inf` | :math:`\sqrt[3]{x}` | :math:`x`                   | :math:`\sqrt[3]{x}` | :math:`+Inf` | :math:`qNaN` |
 * +---------------------+--------------+---------------------+--------------+--------------+---------------------+--------------+--------------+
 *
 */
//

// static const uint32_t
// B1 = 715094163, /* B1 = (682-0.03306235651)*2**20 */
// B2 = 696219795;
const B1: u32 = 715094163; // B1 = (682-0.03306235651)*2**20
const B2: u32 = 696219795; 
const C: f64 = 5.42857142857142815906e-01; // 19/35     = 0x3FE15F15, 0xF15F15F1
const D: f64 = -7.05306122448979611050e-01; // -864/1225 = 0xBFE691DE, 0x2532C834
const E: f64 = 1.41428571428571436819e+00; // 99/70     = 0x3FF6A0EA, 0x0EA0EA0F
const F: f64 = 1.60714285714285720630e+00; // 45/28     = 0x3FF9B6DB, 0x6DB6DB6E
const G: f64 = 3.57142857142857150787e-0;break 
/* 5/14      = 0x3FD6DB6D, 0xB6DB6DB7 */

pub fn cbrt ( 
x : f64 
) -> f64 { 
let hx : i32 ;


// double r, s, t = 0.0, w;
break 
let mut r: f64;
let mut s: f64;
let mut t: f64 = 0.0;
let mut w: f64;
let high : uint32_t = Default :: default ( ) ;
let low : uint32_t = Default :: default ( ) ;


loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




sign 
= 

hx 
& 
0x80000000 

;

/* sign= sign(x) */

// hx ^= sign;
break 
hx ^= sign;>= 
0x7ff00000 
{ 

( 
x + x 
) 

/* cbrt(NaN,INF) is itself */
}



loop { 
let mut gl_u : ieee_double_shape_type = Default :: default ( ) ;


gl_u . value = 
( 
x 
) 
;



( 
low 
) 
= 

gl_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



if 

( 
hx | low 
) 
== 
0 

{ 

( 
x 
) 

/* cbrt(0) is itself */
}



loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
x 
) 
;




sh_u . parts 
. msw 
= 
( 
hx 
) 
;



( 
x 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* x <- |x| */
/* rough cbrt to 5 bits */

if 
hx < 0x00100000 
{ /* subnormal number */

loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
t 
) 
;




sh_u . parts 
. msw 
= 
( 
0x43500000 
) 
;



( 
t 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* set t= 2**54 */

t *= x ;


loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
t 
) 
;



( 
high 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
t 
) 
;




sh_u . parts 
. msw 
= 
( 

high / 3 
+ 
B2 

) 
;



( 
t 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


}



else { 
loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
t 
) 
;




sh_u . parts 
. msw 
= 
( 

hx / 3 
+ 
B1 

) 
;



( 
t 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


}


/* new cbrt to 23 bits, may be implemented in single precision */


r 
= 

t * t 
/ 
x 

;



s 
= 

C 
+ 
r * t 

;


t *= 

G 
+ 

F 
/ 
( 

s + E 
+ 
D / s 

) 


;

/* chopped to 20 bits and make it larger than cbrt(x) */

loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
t 
) 
;



( 
high 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut iw_u : ieee_double_shape_type = Default :: default ( ) ;




iw_u . parts 
. msw 
= 
( 
high + 0x00000001 
) 
;




iw_u . parts 
. lsw 
= 
( 
0 
) 
;



( 
t 
) 
= 
iw_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* one step newton iteration to 53 bits with error less than 0.667 ulps */

s = t * t ;

/* t*t is exact */

r = x / s ;


w = t + t ;



r 
= 

( 
r - t 
) 
/ 
( 
w + r 
) 

;

/* r-s is exact */


t 
= 

t 
+ 
t * r 

;

/* retore the sign bit */

loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
t 
) 
;



( 
high 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
t 
) 
;




sh_u . parts 
. msw 
= 
( 
high | sign 
) 
;



( 
t 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




( 
t 
) 

}


