#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zero;
use crate::libm::common::tools_h::__raise_invalid;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathd::frexpd_c::two54;
use crate::libm::mathd::internal::log1pmfd_h::__log1pmf;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the base :math:`2` logarithm.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float log2f(float x);
 *     double log2(double x);
 *     long double logl(long double x);
 *
 * Description
 * ===========
 *
 * ``log2`` computes the base :math:`2` logarithm of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    log2(x) \approx log_{2}(x)
 *
 * Returns
 * =======
 *
 * ``log2`` returns the base :math:`2` logarithm of :math:`x`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when the input value is negative.
 *
 * Raise ``divide by zero`` exception when the input value is zero.
 *
 * Output map
 * ==========
 *
 * +---------------------+---------------+---------------+---------------+---------------+---------------------+---------------+---------------------+---------------+---------------+
 * | **x**               | :math:`-Inf`  | :math:`<0`    | :math:`-0`    | :math:`+0`    | :math:`]0,1[`       | :math:`1`     | :math:`>1`          | :math:`+Inf`  | :math:`NaN`   |
 * +=====================+===============+===============+===============+===============+=====================+===============+=====================+===============+===============+
 * | **log2(x)**         | :math:`qNaN`  | :math:`qNaN`  | :math:`-Inf`                  | :math:`log_{2}(x)`  | :math:`+0`    | :math:`log_{2}(x)`  | :math:`+Inf`  | :math:`qNaN`  |
 * +---------------------+---------------+---------------+---------------+---------------+---------------------+---------------+---------------------+---------------+---------------+
 *
 */
//

// static const double
// two54 = 1.80143985094819840000e+16, /* 0x43500000, 0x00000000 */
// ivln2hi = 1.44269504072144627571e+00, /* 0x3ff71547, 0x65200000 */
// ivln2lo = 1.67517131648865118353e-10;
static TWO54: f64 = 1.80143985094819840000e+16; // 0x43500000, 0x00000000
static IVLN2HI: f64 = 1.44269504072144627571e+00; // 0x3ff71547, 0x65200000
static IVLN2LO: f64 = 1.67517131648865118353e0; 
/* 0x3de705fc, 0x2eefa200 */

const zero : f64 = 0.0 ;


let mut f: f64;
let mut hfsq: f64;
let mut hi: f64;
let mut lo: f64;
let mut r: f64;
let mut val_hi: f64;
let mut val_lo: f64;
let mut w: f64;
let mut y: f64;// double f, hfsq, hi, lo, r, val_hi, val_lo, w, y;
break 

let i : int32_t = Default :: default ( ) ;
let k : int32_t = Default :: default ( ) ;
let hx : int32_t = Default :: default ( ) ;


let lx : u32 ;


loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

ew_u . parts 
. msw 
;



( 
lx 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



k = 0 ;


if 
hx < 0x00100000 
{ /* x < 2**-1022  */

if 

( 

( 

hx 
& 
0x7fffffff 

) 
| 
lx 

) 
== 
0 

{ 

__raise_div_by_zero ( -1.0 ) 

/* log(+-0)=-inf */
}



if 
hx < 0 
{ 
if 
__builtin_isnan ( x ) 
{ 
return x + x ;

}



else { 

__raise_invalid ( ) 

/* log(-#) = NaN */
}


}



k -= 54 ;


x *= two54 ;

/* subnormal number, scale up x */

loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


}



if 
hx 
>= 
0x7ff00000 
{ /* x = NaN/+-Inf */

return x + x ;

}



if 

hx == 0x3ff00000 
&& 
lx == 0 

{ /* log(1) = +0 */

return zero ;

}



k += 

( 

hx 
>> 
20 

) 
- 
1023 

;


hx &= 
0x000fffff 
;



i 
= 

( 
hx + 0x95f64 
) 
& 
0x100000 

;


loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
x 
) 
;




sh_u . parts 
. msw 
= 
( 

hx 
| 
( 

i 
^ 
0x3ff00000 

) 

) 
;



( 
x 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* normalize x or x/2 */

k += 
( 

i 
>> 
20 

) 
;



y 
= 

k 
as f64 
;


f = x - 1.0 ;



hfsq 
= 
0.5 
* 
f 
* 
f 
;


r = __log1pmf ( f ) ;

/*
     * f-hfsq must (for args near 1) be evaluated in extra precision
     * to avoid a large cancellation when x is near sqrt(2) or 1/sqrt(2).
     * This is fairly efficient since f-hfsq only depends on f, so can
     * be evaluated in parallel with R.  Not combining hfsq with R also
     * keeps R small (though not as small as a true `lo' term would be),
     * so that extra precision is not needed for terms involving R.
     *
     * Compiler bugs involving extra precision used to break Dekker's
     * theorem for spitting f-hfsq as hi+lo, unless double_t was used
     * or the multi-precision calculations were avoided when double_t
     * has extra precision.  These problems are now automatically
     * avoided as a side effect of the optimization of combining the
     * Dekker splitting step with the clear-low-bits step.
     *
     * y must (for args near sqrt(2) and 1/sqrt(2)) be added in extra
     * precision to avoid a very large cancellation when x is very near
     * these values.  Unlike the above cancellations, this problem is
     * specific to base 2.  It is strange that adding +-1 is so much
     * harder than adding +-ln2 or +-log10_2.
     *
     * This uses Dekker's theorem to normalize y+val_hi, so the
     * compiler bugs are back in some configurations, sigh.  And I
     * don't want to used double_t to avoid them, since that gives a
     * pessimization and the support for avoiding the pessimization
     * is not yet available.
     *
     * The multi-precision calculations for the multiplications are
     * routine.
     */

hi = f - hfsq ;


loop { 
let mut sl_u : ieee_double_shape_type = Default :: default ( ) ;


sl_u . value = 
( 
hi 
) 
;




sl_u . parts 
. lsw 
= 
( 
0 
) 
;



( 
hi 
) 
= 
sl_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




lo 
= 


( 
f - hi 
) 
- 
hfsq 

+ 
r 

;


val_hi = hi * ivln2hi ;



val_lo 
= 


( 
lo + hi 
) 
* 
ivln2lo 

+ 
lo * ivln2hi 

;


w = y + val_hi ;


val_lo += 

( 
y - w 
) 
+ 
val_hi 

;


val_hi = w ;


return val_lo + val_hi ;




