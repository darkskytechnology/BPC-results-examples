#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: RedHat */
/* Copyright (C) 2002 by  Red Hat, Incorporated. All rights reserved. */
/*
 *
 * This family of functions detemines the maximum value of :math:`x` and :math:`y`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float fmaxf(float x, float y);
 *     double fmax(double x, double y);
 *     long double fmaxl(long double x, long double y);
 *
 * Description
 * ===========
 *
 * ``fmax`` computes the maximum value of :math:`x` and :math:`y`.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    fmax(x, y) = \left\{\begin{array}{ll} x, & x > y \\ y, & otherwise \end{array}\right.
 *
 * Returns
 * =======
 *
 * ``fmax`` returns the maximum value of :math:`x` and :math:`y`.
 *
 * Exceptions
 * ==========
 *
 * Does not raise exceptions.
 *
 * Output map
 * ==========
 *
 * +-------------+--------------+-------------------+-------------+-------------+-------------------+-------------+-------------+-------------+
 * | fmax(x,y)   | x                                                                                                                          |
 * +-------------+--------------+-------------------+-------------+-------------+-------------------+-------------+-------------+-------------+
 * | y           | :math:`-Inf` | :math:`<0`        | :math:`-0`  | :math:`+0`  | :math:`>0`        | :math:`+Inf`| :math:`qNaN`| :math:`sNaN`|
 * +=============+==============+===================+=============+=============+===================+=============+=============+=============+
 * | :math:`-Inf`| :math:`y`    | :math:`x`         | :math:`x`                 | :math:`x`         | :math:`x`   | :math:`x`   | :math:`qNaN`|
 * +-------------+              +-------------------+                           +                   +             +             +             +
 * | :math:`<0`  |              | :math:`fmax(x, y)`|                           |                   |             |             |             |
 * +-------------+              +-------------------+-------------+-------------+                   +             +             +             +
 * | :math:`-0`  |              | :math:`y`                                     |                   |             |             |             |
 * +-------------+              +                                               +                   +             +             +             +
 * | :math:`+0`  |              |                                               |                   |             |             |             |
 * +-------------+              +                                               +-------------------+             +             +             +
 * | :math:`>0`  |              |                                               | :math:`fmax(x, y)`|             |             |             |
 * +-------------+              +                                               +-------------------+-------------+             +             +
 * | :math:`+Inf`|              |                                               | :math:`y`                       |             |             |
 * +-------------+--------------+-------------------+-------------+-------------+-------------------+-------------+             +             +
 * | :math:`qNaN`| :math:`y`                                                                                      |             |             |
 * +-------------+--------------+-------------------+-------------+-------------+-------------------+-------------+-------------+             +
 * | :math:`sNaN`| :math:`qNaN`                                                                                                 |             |
 * +-------------+--------------+-------------------+-------------+-------------+-------------------+-------------+-------------+-------------+
 *
 */
//

pub fn fmax(x: f64, y: f64) -> f64 {
    if __builtin_isnan(x) || __builtin_isnan(y) {
        return x * y;
    }

    if x > y {
        x
    } else {
        y
    }
}
