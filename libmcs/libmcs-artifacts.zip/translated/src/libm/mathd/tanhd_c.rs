#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexact;
use crate::libm::include::math_h::expm1;
use crate::libm::include::math_h::fabs;
use crate::libm::mathd::acosd_c::one;
use crate::libm::mathd::erfcd_c::two;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions implements the hyperbolic tangent of :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float tanhf(float x);
 *     double tanh(double x);
 *     long double tanhl(long double x);
 *
 * Description
 * ===========
 *
 * ``tanh`` computes the hyperbolic tangent of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    tanh(x) \approx tanh(x) = \frac{e^x-e^{-x}}{e^x+e^{-x}}
 *
 * Returns
 * =======
 *
 * ``tanh`` returns the hyperbolic tangent, in the range :math:`[-1, 1]`.
 *
 * Exceptions
 * ==========
 *
 * Does not raise overflow, division by zero, and invalid exceptions.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+-----------------+--------------+--------------+-----------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<0`      | :math:`-0`   | :math:`+0`   | :math:`>0`      | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+=================+==============+==============+=================+==============+==============+
 * | **tanh(x)**         | :math:`-1`   | :math:`tanh(x)` | :math:`x`                   | :math:`tanh(x)` | :math:`+1`   | :math:`qNaN` |
 * +---------------------+--------------+-----------------+--------------+--------------+-----------------+--------------+--------------+
 *
 */
//

// static const double one = 1.0, two = 2.0;
const ONE: f64 = 1.0;
const TWO: f64 = 2.0;

pub fn tanh(x: f64) -> f64 {
    let t: f64 = Default::default();
    let z: f64 = Default::default();

    let jx: int32_t = Default::default();
    let ix: int32_t = Default::default();

    /* High word of |x|. */

    loop {
        let mut gh_u: ieee_double_shape_type = Default::default();

        gh_u.value = (x);

        (jx) = gh_u.parts.msw;

        if (0 == 0) == false {
            break;
        }
    }

    ix = jx & 0x7fffffff;

    /* x is INF or NaN */

    if ix >= 0x7ff00000 {
        if __builtin_isnan(x) {
            /* tanh(NaN) = NaN */

            return x + x;
        } else if jx >= 0 {
            return one;

        /* tanh(+inf)=+1 */
        } else {
            -one

            /* tanh(-inf)=-1 */
        }
    }

    /* |x| < 22 */

    if ix < 0x40360000 {
        /* |x|<22 */

        if ix < 0x3c800000 {
            /* |x|<2**-55 */

            if x == 0.0 {
                /* return x inexact except 0 */

                return x;
            } else {
                __raise_inexact(x)
            }
        }

        if ix >= 0x3ff00000 {
            /* |x|>=1  */

            t = expm1(two * x.abs());

            z = one - two / (t + two);
        } else {
            t = expm1(-two * x.abs());

            z = -t / (t + two);
        }

    /* |x| > 22, return +-1 */
    } else {
        z = __raise_inexact(one);

        /* raised inexact flag */
    }

    if (jx >= 0) {
        z
    } else {
        -z
    }
}
