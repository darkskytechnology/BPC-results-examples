#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zero;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions computes the binary exponent of the input value.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float logbf(float x);
 *     double logb(double x);
 *     long double logbl(long double x);
 *
 * Description
 * ===========
 *
 * ``logb`` computes the binary exponent of the input value.
 *
 * ``logb`` and :ref:`ilogb` have the same functionality, but ``logb`` returns
 * the binary exponent as a floating-point value while :ref:`ilogb` returns a
 * signed integer.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    logb(x) \approx \lfloor {\log_2 |x|} \rfloor
 *
 * Returns
 * =======
 *
 * ``logb`` returns the binary exponent of the input value.
 *
 * Exceptions
 * ==========
 *
 * Raise ``divide by zero`` exception when the input value is zero.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+--------------------------------------+--------------+--------------+--------------------------------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<0`                           | :math:`-0`   | :math:`+0`   | :math:`>0`                           | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+======================================+==============+==============+======================================+==============+==============+
 * | **logb(x)**         | :math:`+Inf` | :math:`\lfloor {\log_2 |x|} \rfloor` | :math:`-Inf`                | :math:`\lfloor {\log_2 |x|} \rfloor` | :math:`+Inf` | :math:`qNaN` |
 * +---------------------+--------------+--------------------------------------+--------------+--------------+--------------------------------------+--------------+--------------+
 *
 */
//

pub fn logb(x: f64) -> f64 {
    let hx: int32_t = Default::default();
    let lx: int32_t = Default::default();
    let ix: int32_t = Default::default();

    loop {
        let mut ew_u: ieee_double_shape_type = Default::default();

        ew_u.value = (x);

        (hx) = ew_u.parts.msw;

        (lx) = ew_u.parts.lsw;

        if (0 == 0) == false {
            break;
        }
    }

    hx &= 0x7fffffff;

    /* high |x| */

    if hx < 0x00100000 {
        /* 0 or subnormal */

        if (hx | lx) == 0 {
            __raise_div_by_zero(-1.0)

            /* logb(0) = -inf */
        } else {
            /* subnormal x */

            if hx == 0 {
                ix = -1043;
                while lx > 0 {
                    ix -= 1;

                    // lx <<= 1
                    lx <<= 1;
                }
            } else {
                {
                    ix = -1022;

                    // hx <<= 11
                    hx <<= 11;
                };
                while hx > 0 {
                    ix -= 1;

                    // hx <<= 1
                    hx <<= 1;
                }
            }
        }

        ix as f64
    } else if hx < 0x7ff00000 {
        (hx >> 20) - 1023

        /* normal # */
    } else {
        return x * x;

        /* x = NaN/+-Inf */
    }
}
