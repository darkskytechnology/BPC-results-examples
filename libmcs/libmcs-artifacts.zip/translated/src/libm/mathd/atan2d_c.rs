#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexact;
use crate::libm::include::math_h::atan;
use crate::libm::include::math_h::fabs;
use crate::libm::mathd::acosd_c::pi;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions implements the arc tanget of :math:`\frac{y}{x}`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float atan2f(float y, float x);
 *     double atan2(double y, double x);
 *     long double atan2l(long double y, long double x);
 *
 * Description
 * ===========
 *
 * ``atan2`` computes the inverse tangent (*arc tangent*) of the division of
 * the input values.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    atan2(y, x) \approx \left\{\begin{array}{ll}
 *                        tan^{-1}\left(\frac{y}{x}\right), & x > 0  \ *                        tan^{-1}\left(\frac{y}{x}\right) + \pi, & x < 0 \wedge y > 0  \ *                        tan^{-1}\left(\frac{y}{x}\right) - \pi, & x < 0 \wedge y < 0 \end{array}\right.
ht.
 *
 * For the other cases (which do not need formulae) refer to the output map below.
 *
 * Returns
 * =======
 *
 * ``atan2`` returns value in radians, in the range :math:`[-\pi, \pi]`.
 *
 * Exceptions
 * ==========
 *
 * Does not raise overflow, division by zero, and invalid exceptions. Does not raise ``divide-by-zero``
 * exception even if argument :math:`x` is zero.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +--------------+--------------------------+-----------------------------------+--------------+--------------+-----------------------------------+--------------------------+--------------+
 * | atan2(y,x)   | y                                                                                                                                                                        |
 * +--------------+--------------------------+-----------------------------------+--------------+--------------+-----------------------------------+--------------------------+--------------+
 * | x            | :math:`-Inf`             | :math:`<0`                        | :math:`-0`   | :math:`+0`   | :math:`>0`                        | :math:`+Inf`             | :math:`NaN`  |
 * +==============+==========================+===================================+==============+==============+===================================+==========================+==============+
 * | :math:`-Inf` | :math:`-\frac{3}{4} \pi` | :math:`-\pi`                                     | :math:`+\pi`                                     | :math:`+\frac{3}{4} \pi` | :math:`qNaN` |
 * +--------------+--------------------------+-----------------------------------+--------------+--------------+-----------------------------------+--------------------------+              +
 * | :math:`<0`   | :math:`-\frac{\pi}{2}`   | :math:`tan^{-1}(\frac{y}{x})-\pi` | :math:`-\pi` | :math:`+\pi` | :math:`tan^{-1}(\frac{y}{x})+\pi` | :math:`+\frac{\pi}{2}`   |              |
 * +--------------+                          +-----------------------------------+              +              +-----------------------------------+                          +              +
 * | :math:`-0`   |                          | :math:`-\frac{\pi}{2}`            |              |              | :math:`+\frac{\pi}{2}`            |                          |              |
 * +--------------+                          +                                   +--------------+--------------+                                   +                          +              +
 * | :math:`+0`   |                          |                                   | :math:`-0`   | :math:`+0`   |                                   |                          |              |
 * +--------------+                          +-----------------------------------+              +              +-----------------------------------+                          +              +
 * | :math:`>0`   |                          | :math:`tan^{-1}(\frac{y}{x})`     |              |              | :math:`tan^{-1}(\frac{y}{x})`     |                          |              |
 * +--------------+--------------------------+-----------------------------------+--------------+--------------+-----------------------------------+--------------------------+              +
 * | :math:`+Inf` | :math:`-\frac{\pi}{4}`   | :math:`-0`                                       | :math:`+0`                                       | :math:`+\frac{\pi}{4}`   |              |
 * +--------------+--------------------------+-----------------------------------+--------------+--------------+-----------------------------------+--------------------------+--------------+
 * | :math:`NaN`  | :math:`qNaN`                                                                                                                                                             |
 * +--------------+--------------------------+-----------------------------------+--------------+--------------+-----------------------------------+--------------------------+--------------+
 *
 */
//

// static const double
// zero = 0.0,
// pi_o_4 = 7.8539816339744827900E-01, /* 0x3FE921FB, 0x54442D18 */
// pi_o_2 = 1.5707963267948965580E+00, /* 0x3FF921FB, 0x54442D18 */
// pi = 3.1415926535897931160E+00, /* 0x400921FB, 0x54442D18 */
// pi_lo = 1.2246467991473531772E-16;
static ZERO: f64 = 0.0;
static PI_O_4: f64 = 7.8539816339744827900E-01; // 0x3FE921FB, 0x54442D18
static PI_O_2: f64 = 1.5707963267948965580E+00; // 0x3FF921FB, 0x54442D18
static PI: f64 = 3.1415926535897931160E+00; // 0x400921FB, 0x54442D18
static PI_LO: f64 = 1.2246467991473531772E-1;
/* 0x3CA1A626, 0x33145C07 */

pub fn atan2(y: f64, x: f64) -> f64 {
    let (mut k, mut m, mut hx, mut hy, mut ix, mut iy): (i32, i32, i32, i32, i32, i32);
    let mut lx: u32 = 0;
    let mut ly: u32 = 0;
    {
        let ew_u = ieee_double_shape_type { value: x };
        hx = ew_u.parts.msw;
        lx = ew_u.parts.lsw;
    }
    ix = hx & 0x7fffffff;
    {
        let ew_u = ieee_double_shape_type { value: y };
        hy = ew_u.parts.msw;
        ly = ew_u.parts.lsw;
    }
    iy = hy & 0x7fffffff;
    if (ix | ((lx | -lx) >> 31)) > 0x7ff00000 || (iy | ((ly | -ly) >> 31)) > 0x7ff00000 {
        return x + y;
    }
    if hx == 0x3ff00000 && lx == 0 {
        return atan(y);
    }
    m = ((hy >> 31) & 1) | ((hx >> 30) & 2);
    if (iy | ly) == 0 {
        match m {
            1 => return y,
            2 => return __raise_inexact(pi),
            _ => return -__raise_inexact(pi),
        }
    }
    if (ix | lx) == 0 {
        if hy < 0 {
            return -__raise_inexact(pi_o_2);
        } else {
            return __raise_inexact(pi_o_2);
        }
    }
    if ix == 0x7ff00000 {
        if iy == 0x7ff00000 {
            match m {
                0 => return __raise_inexact(pi_o_4),
                1 => return -__raise_inexact(pi_o_4),
                2 => return __raise_inexact(3.0 * pi_o_4),
                _ => return -__raise_inexact(3.0 * pi_o_4),
            }
        } else {
            match m {
                0 => return 0.0,
                1 => return -0.0,
                2 => return __raise_inexact(pi),
                _ => return -__raise_inexact(pi),
            }
        }
    }
    if iy == 0x7ff00000 {
        if hy < 0 {
            return -__raise_inexact(pi_o_2);
        } else {
            return __raise_inexact(pi_o_2);
        }
    }
    k = (iy - ix) >> 20;
    let z: f64;
    if k > 60 {
        z = __raise_inexact(pi_o_2);
        m &= 1;
    } else if hx < 0 && k < -60 {
        z = 0.0;
    } else {
        z = atan(fabs(y / x));
    }
    match m {
        0 => return z,
        1 => return -z,
        2 => return pi - (z - pi_lo),
        _ => return (z - pi_lo) - pi,
    }
}
