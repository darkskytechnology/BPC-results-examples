#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: RedHat */
/* Copyright (C) 2002 by  Red Hat, Incorporated. All rights reserved. */
/*
 *
 * This macro returns a non-zero value if the sign bit of :math:`x` is set. It
 * can be called with ``float``, ``double`` or ``long double`` input. This
 * macro is implemented in ``math.h``.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     int signbit(x);
 *
 * Description
 * ===========
 *
 * ``signbit`` returns a non-zero value if the sign bit of :math:`x` is set.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    signbit(x) = \left\{\begin{array}{ll} 1, & x \in \mathbb{F}^{-} \ *                                          0, & otherwise \end{array}\right.
.
 *
 * Returns
 * =======
 *
 * ``signbit`` returns :math:`1` if the sign bit of :math:`x` is set, otherwise
 * :math:`0`.
 *
 * Exceptions
 * ==========
 *
 * Does not raise exceptions.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+
 * | **x**               | :math:`-NaN` | :math:`-Inf` | :math:`<0`   | :math:`-0`   | :math:`+0`   | :math:`>0`   | :math:`+Inf` | :math:`+NaN` |
 * +=====================+==============+==============+==============+==============+==============+==============+==============+==============+
 * | **signbit(x)**      | :math:`1`                                                 | :math:`0`                                                 |
 * +---------------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+
 *
 */
//

pub fn __signbitd(x: f64) -> i32 {
    let msw: u32;

    loop {
        let mut gh_u: ieee_double_shape_type = Default::default();

        gh_u.value = (x);

        (msw) = gh_u.parts.msw;

        if (0 == 0) == false {
            break;
        }
    }

    (msw & 0x80000000) != 0
}
