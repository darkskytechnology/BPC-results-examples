#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::mathd::internal::gammad_c::t1;
use crate::libm::mathd::internal::gammad_c::t2;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 * __log1pmf(f):
 * Return log(1+f) - f for 1+f in ~[sqrt(2)/2, sqrt(2)].
 */

// static const double
// Lg1 = 6.666666666666735130e-01, /* 0x3FE5555555555593 */
// Lg2 = 3.999999999940941908e-01, /* 0x3FD999999997FA04 */
// Lg3 = 2.857142874366239149e-01, /* 0x3FD2492494229359 */
// Lg4 = 2.222219843214978396e-01, /* 0x3FCC71C51D8E78AF */
// Lg5 = 1.818357216161805012e-01, /* 0x3FC7466496CB03DE */
// Lg6 = 1.531383769920937332e-01, /* 0x3FC39A09D078C69F */
// Lg7 = 1.479819860511658591e-01;
const Lg1: f64 = 6.666666666666735130e-01;  // 0x3FE5555555555593
const Lg2: f64 = 3.999999999940941908e-01;  // 0x3FD999999997FA04
const Lg3: f64 = 2.857142874366239149e-01;  // 0x3FD2492494229359
const Lg4: f64 = 2.222219843214978396e-01;  // 0x3FCC71C51D8E78AF
const Lg5: f64 = 1.818357216161805012e-01;  // 0x3FC7466496CB03DE
const Lg6: f64 = 1.531383769920937332e-01;  // 0x3FC39A09D078C69F
fn __log1pmf(f: f64) -> f64 {
    let hfsq: f64;
    let s: f64;
    let z: f64;
    let R: f64;
    let w: f64;
    let t1: f64;
    let t2: f64;

    s = f / (2.0 + f);
    z = s * s;
    w = z * z;
    t1 = w * (Lg2 + w * (Lg4 + w * Lg6));
    t2 = z * (Lg1 + w * (Lg3 + w * (Lg5 + w * Lg7)));
    R = t2 + t1;
    hfsq = 0.5 * f * f;
    return s * (hfsq + R);
}//     t2 = z * (Lg1 + w * (Lg3 + w * (Lg5 + w * Lg7)));
//     R = t2 + t1;
//     hfsq = 0.5 * f * f;
//     return s * (hfsq + R);
// 
break 
