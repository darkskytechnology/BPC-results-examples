#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: RedHat */
/* Copyright (C) 2002,2007 by  Red Hat, Incorporated. All rights reserved. */
/*
 *
 * This macro is used to classify :math:`x`. It can be called with ``float``,
 * ``double`` or ``long double`` input. This macro is implemented in
 * ``math.h``.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     int fpclassify(x);
 *
 * Description
 * ===========
 *
 * ``fpclassify`` returns different constants depending on whether the input is
 * subnormal, normal, zero, infinite or :math:`NaN`.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    fpclassify(x) = \left\{\begin{array}{ll} FP\_ZERO, & x = \pm 0.0 \ *                                             FP\_SUBNORMAL, & x \in \mathbb{S} \ *                                             FP\_INFINITE, & x = \pm Inf \ *                                             FP\_NAN, & x = NaN \ *                                             FP\_NORMAL, & otherwise \end{array}\right.
\right.
 *
 * Returns
 * =======
 *
 * ``fpclassify`` returns constant values, see ``math.h`` for their specific values.
 *
 * Exceptions
 * ==========
 *
 * Does not raise exceptions.
 *
 * Output map
 * ==========
 *
 * +---------------------+-----------------+------------------------------+------------------------------+-------------+------------------------------+------------------------------+-----------------+-------------+
 * | **x**               | :math:`-Inf`    | :math:`<0 \notin \mathbb{S}` | :math:`<0 \in \mathbb{S}`    | :math:`±0`  | :math:`>0 \in \mathbb{S}`    | :math:`>0 \notin \mathbb{S}` | :math:`+Inf`    | :math:`NaN` |
 * +=====================+=================+==============================+==============================+=============+==============================+==============================+=================+=============+
 * | **fpclassify(x)**   | ``FP_INFINITE`` | ``FP_NORMAL``                | ``FP_SUBNORMAL``             | ``FP_ZERO`` | ``FP_SUBNORMAL``             | ``FP_NORMAL``                | ``FP_INFINITE`` | ``FP_NAN``  |
 * +---------------------+-----------------+------------------------------+------------------------------+-------------+------------------------------+------------------------------+-----------------+-------------+
 *
 */
//

pub fn __fpclassifyd(x: f64) -> i32 {
    let msw: uint32_t = Default::default();
    let lsw: uint32_t = Default::default();

    loop {
        let mut ew_u: ieee_double_shape_type = Default::default();

        ew_u.value = (x);

        (msw) = ew_u.parts.msw;

        (lsw) = ew_u.parts.lsw;

        if (0 == 0) == false {
            break;
        }
    }

    msw &= 0x7fffffff;

    if msw == 0x00000000 && lsw == 0x00000000 {
        return 2;
    } else if msw >= 0x00100000 && msw <= 0x7fefffff {
        return 4;
    } else if msw <= 0x000fffff {
        /* zero is already handled above */

        return 3;
    } else if msw == 0x7ff00000 && lsw == 0x00000000 {
        return 1;
    } else {
        return 0;
    }
}
