#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions copies the sign of :math:`y` onto :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float copysignf(float x, float y);
 *     double copysign(double x, double y);
 *     long double copysignl(long double x, long double y);
 *
 * Description
 * ===========
 *
 * ``copysign`` computes the value with the magnitude of :math:`x` and sign of
 * :math:`y`.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    copysign(x, y) = |x| \cdot sgn\ y
 *
 * Returns
 * =======
 *
 * ``copysign`` returns the value with the magnitude of :math:`x` and sign of
 * :math:`y`.
 *
 * Exceptions
 * ==========
 *
 * Does not raise exceptions.
 *
 * Does not raise ``invalid operation`` exception on ``sNaN`` input.
 *
 * Output map
 * ==========
 *
 * +--------------------------+--------------------------+--------------------------+
 * | copysign(x,y)            | x                                                   |
 * +--------------------------+--------------------------+--------------------------+
 * | y                        | :math:`\neq NaN`         | :math:`NaN`              |
 * +==========================+==========================+==========================+
 * | :math:`-NaN`             | :math:`-|x|`             | :math:`qNaN`             |
 * +--------------------------+                          +                          +
 * | :math:`-Inf`             |                          |                          |
 * +--------------------------+                          +                          +
 * | :math:`<0`               |                          |                          |
 * +--------------------------+                          +                          +
 * | :math:`-0`               |                          |                          |
 * +--------------------------+--------------------------+                          +
 * | :math:`+0`               | :math:`|x|`              |                          |
 * +--------------------------+                          +                          +
 * | :math:`>0`               |                          |                          |
 * +--------------------------+                          +                          +
 * | :math:`+Inf`             |                          |                          |
 * +--------------------------+                          +                          +
 * | :math:`+NaN`             |                          |                          |
 * +--------------------------+--------------------------+--------------------------+
 *
 */
//

pub fn copysign(x: f64, y: f64) -> f64 {
    let hx: uint32_t = Default::default();
    let hy: uint32_t = Default::default();

    loop {
        let mut gh_u: ieee_double_shape_type = Default::default();

        gh_u.value = (x);

        (hx) = gh_u.parts.msw;

        if (0 == 0) == false {
            break;
        }
    }

    loop {
        let mut gh_u: ieee_double_shape_type = Default::default();

        gh_u.value = (y);

        (hy) = gh_u.parts.msw;

        if (0 == 0) == false {
            break;
        }
    }

    loop {
        let mut sh_u: ieee_double_shape_type = Default::default();

        sh_u.value = (x);

        sh_u.parts.msw = ((hx & 0x7fffffff) | (hy & 0x80000000));

        (x) = sh_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    return x;
}
