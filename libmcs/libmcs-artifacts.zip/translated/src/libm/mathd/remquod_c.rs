#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_invalid;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathd::fabsd_c::fabs;
use crate::libm::mathd::fmodd_c::fmod;
use crate::translate_bpc_vpp;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the floating-point remainder :math:`x * REM\ y` and puts the quotient (or rather its sign and 3 least significant
t
 * bits) into the outpointer.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float remquof(float x, float y, int *quo);
 *     double remquo(double x, double y, int *quo);
 *     long double remquol(long double x, long double y, int *quo);
 *
 * Description
 * ===========
 *
 * ``remquo`` computes the floating-point remainder :math:`r = x\ REM\ y = x -
 * n \cdot y` of their arguments :math:`x` and :math:`y`, where :math:`n` is
 * the integral value nearest to :math:`\frac{x}{y}`.
 *
 * The 3 least significant bits of :math:`n` and its sign are then put into the
 * output pointer :math:`*quo`.
 *
 * ``remquo`` and ``remainder`` are functionally equivalent concerning the
 * return value, ``remquo`` only adds an additional output.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    remquo(x, y) = x - n \cdot y \wedge n \in \mathbb{Z} \wedge remquo(x, y) \in \left [-\left | \frac{y}{2} \right |,\left | \frac{y}{2} \right | \right ] \wedge quo = n
 *
 * Returns
 * =======
 *
 * ``remquo`` returns the floating-point remainder :math:`x\ REM\ y`. The sign
 * and 3 least significant bits of quotient :math:`n` is put into :math:`*quo`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when :math:`x` is infinite or
 * :math:`y` is zero.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | remquo(x,y)              | x                                                                                                                                                                                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | y                        | :math:`-Inf`             | :math:`<0`               | :math:`-0`               | :math:`+0`               | :math:`>0`               | :math:`+Inf`             | :math:`NaN`              |
 * +==========================+==========================+==========================+==========================+==========================+==========================+==========================+==========================+
 * | :math:`-Inf`             | :math:`qNaN`             | :math:`x`                                                                                                 | :math:`qNaN`             | :math:`qNaN`             |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`<0`               |                          | :math:`x\ REM\ y`        | :math:`x`                                           | :math:`x\ REM\ y`        |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`-0`               |                          | :math:`qNaN`                                                                                              |                          |                          |
 * +--------------------------+                          +                                                                                                           +                          +                          +
 * | :math:`+0`               |                          |                                                                                                           |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`>0`               |                          | :math:`x\ REM\ y`        | :math:`x`                                           | :math:`x\ REM\ y`        |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`+Inf`             |                          | :math:`x`                                                                                                 |                          |                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+                          +
 * | :math:`NaN`              | :math:`qNaN`                                                                                                                                                    |                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 *
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | :math:`*quo`             | x                                                                                                                                                                                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | y                        | :math:`-Inf`             | :math:`<0`               | :math:`-0`               | :math:`+0`               | :math:`>0`               | :math:`+Inf`             | :math:`NaN`              |
 * +==========================+==========================+==========================+==========================+==========================+==========================+==========================+==========================+
 * | :math:`-Inf`             | :math:`0`                | :math:`0`                                                                                                 | :math:`0`                | :math:`0`                |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`<0`               |                          | :math:`n`                | :math:`0`                                           | :math:`n`                |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`-0`               |                          | :math:`0`                                                                                                 |                          |                          |
 * +--------------------------+                          +                                                                                                           +                          +                          +
 * | :math:`+0`               |                          |                                                                                                           |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`>0`               |                          | :math:`n`                | :math:`0`                                           | :math:`n`                |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`+Inf`             |                          | :math:`0`                                                                                                 |                          |                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+                          +
 * | :math:`NaN`              | :math:`0`                                                                                                                                                       |                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 *
 */
//

const zero : f64 = 0.0 ;


pub fn remquo ( 
x : f64 , 

y : f64 , 

// int *quo
let quo: *mut i32 = std::ptr::null_mut(); 
) -> f64 { 
let _quo : i32 = 0 ;


let hx : int32_t = Default :: default ( ) ;
let hy : int32_t = Default :: default ( ) ;


// uint32_t sx, sq, lx, ly;
let mut sx: u32;
let mut sq: u32;
let mut lx: u32;
let mut ly: u32; 

let y_half : f64 = Default :: default ( ) ;


assert ! ( 

quo 
!= 
Some ( 
0 
. unwrap ( ) as std :: rc :: Rc < dyn std :: any :: Any > ) 

) ;


if 

quo 
== 
Some ( 
0 
. unwrap ( ) as std :: rc :: Rc < dyn std :: any :: Any > ) 

{ 

quo 
= 
& 
_quo 

;

}





quo 

= 
0 
;


loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

ew_u . parts 
. msw 
;



( 
lx 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
y 
) 
;



( 
hy 
) 
= 

ew_u . parts 
. msw 
;



( 
ly 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




sx 
= 

hx 
& 
0x80000000 

;



sq 
= 

sx 
^ 
( 

hy 
& 
0x80000000 

) 

;


hy &= 
0x7fffffff 
;


hx &= 
0x7fffffff 
;

/* purge off exception values */

if 

( 
hx 
>= 
0x7ff00000 
) 
|| 
( 
hy 
>= 
0x7ff00000 
) 

{ /* x or y not finite */

if 

__builtin_isnan ( x ) 
|| 
__builtin_isnan ( y ) 

{ /* x or y is NaN */

return x + y ;

}



else if 
hx == 0x7ff00000 
{ /* x is infinite */


__raise_invalid ( ) 

}

fn main() {
    // The provided input seems to be incomplete or malformed.
    // Please provide a complete C function or code snippet for translation.
}
// }
break 
}


}



else if 

( 
hy | ly 
) 
== 
0 

{ /* y = 0 */


__raise_invalid ( ) 

}

fn main() {
    // The provided input seems to be incomplete or malformed.
    // Please provide a complete C function or code snippet for translation.
}
// }
break 

if 
hy 
<= 
0x7fbfffff 
{ 
x = fmod ( 
x , 

8 * y 
) ;

/* now x < 8y */
}



if 

( 

( 
hx - hy 
) 
| 
( 
lx - ly 
) 

) 
== 
0 

{ /* x equals y */



quo 

= 
if 
sq 
{ 
-1 
}

else { 
1 
}


;


return zero * x ;

}



x = x . abs ( ) ;


y = y . abs ( ) ;


_quo = 0 ;


if 

x 
>= 
4 * y 

{ 
x -= 
4 * y 
;


_quo += 4 ;

}



if 

x 
>= 
2 * y 

{ 
x -= 
2 * y 
;


_quo += 2 ;

}



if 
hy < 0x00200000 
{ 
if 

x + x 
> 
y 

{ 
x -= y ;


translate_bpc_vpp ! ( 
_quo 
) ;


if 

x + x 
>= 
y 

{ 
x -= y ;


translate_bpc_vpp ! ( 
_quo 
) ;

}


}


}



else { 
y_half = 0.5 * y ;


if 
x 
> 
y_half 
{ 
x -= y ;


translate_bpc_vpp ! ( 
_quo 
) ;


if 
x 
>= 
y_half 
{ 
x -= y ;


translate_bpc_vpp ! ( 
_quo 
) ;

}


}


}



_quo &= 
0x7 
;




quo 

= 
if 
sq 
{ 
- _quo 
}

else { 
_quo 
}


;


loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
x 
) 
;




sh_u . parts 
. msw 
= 
( 
hx ^ sx 
) 
;



( 
x 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;






return x ;







