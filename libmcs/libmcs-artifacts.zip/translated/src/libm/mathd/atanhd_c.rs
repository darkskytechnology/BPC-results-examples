#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zero;
use crate::libm::common::tools_h::__raise_inexact;
use crate::libm::common::tools_h::__raise_invalid;
use crate::libm::include::math_h::log1p;
use crate::libm::mathd::acosd_c::one;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions implements the hyperbolic arc tangent of :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float atanhf(float x);
 *     double atanh(double x);
 *     long double atanhl(long double x);
 *
 * Description
 * ===========
 *
 * ``atanh`` computes the hyperbolic inverse tangent (*hyperbolic arc tangent*)
 * of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    atanh(x) \approx tanh^{-1}(x) = \frac{1}{2} ln \left( \frac{1+x}{1-x} \right)
 *
 * Returns
 * =======
 *
 * ``atanh`` returns the hyperbolic inverse tangent.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when the input value is not in the
 * interval :math:`[-1, 1]`.
 *
 * Raise ``divide by zero`` exception when the input value is :math:`-1` or
 * :math:`+1`.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+--------------+--------------+---------------------+--------------+--------------+---------------------+--------------+--------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<-1`  | :math:`-1`   | :math:`\in ]-1,-0[` | :math:`-0`   | :math:`+0`   | :math:`\in ]+0,+1[` | :math:`+1`   | :math:`>+1`  | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+==============+==============+=====================+==============+==============+=====================+==============+==============+==============+==============+
 * | **atanh(x)**        | :math:`qNaN` | :math:`qNaN` | :math:`-Inf` | :math:`tanh^{-1} x` | :math:`x`                   | :math:`tanh^{-1} x` | :math:`+Inf` | :math:`qNaN` | :math:`qNaN` | :math:`qNaN` |
 * +---------------------+--------------+--------------+--------------+---------------------+--------------+--------------+---------------------+--------------+--------------+--------------+--------------+
 *
 */
//

const one: f64 = 1.0;

pub fn atanh(x: f64) -> f64 {
    let t: f64 = Default::default();

    let hx: int32_t = Default::default();
    let ix: int32_t = Default::default();

    let lx: u32;

    loop {
        let mut ew_u: ieee_double_shape_type = Default::default();

        ew_u.value = (x);

        (hx) = ew_u.parts.msw;

        (lx) = ew_u.parts.lsw;

        if (0 == 0) == false {
            break;
        }
    }

    ix = hx & 0x7fffffff;

    if (ix | ((lx | (-lx)) >> 31)) > 0x3ff00000 {
        /* |x|>1 */

        if __builtin_isnan(x) {
            return x + x;
        } else {
            __raise_invalid()
        }
    }

    if ix == 0x3ff00000 {
        __raise_div_by_zero(x)
    }

    if ix < 0x3e300000 {
        /* x<2**-28 */

        if x == 0.0 {
            /* return x inexact except 0 */

            return x;
        } else {
            __raise_inexact(x)
        }
    }

    loop {
        let mut sh_u: ieee_double_shape_type = Default::default();

        sh_u.value = (x);

        sh_u.parts.msw = (ix);

        (x) = sh_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    if ix < 0x3fe00000 {
        /* x < 0.5 */

        t = x + x;

        t = 0.5 * log1p(t + t * x / (one - x));
    } else {
        t = 0.5 * log1p((x + x) / (one - x));
    }

    if hx >= 0 {
        return t;
    } else {
        -t
    }
}
