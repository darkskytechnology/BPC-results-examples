#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the nearest integer value to :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float roundf(float x);
 *     double round(double x);
 *     long double roundl(long double x);
 *
 * Description
 * ===========
 *
 * ``round`` computes the nearest integer value to :math:`x`. Half-way cases
 * are rounded away from zero (which is the only difference to
 * :ref:`nearbyint`, :ref:`rint`).
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    round(x) = \lfloor x \rceil
 *
 * Returns
 * =======
 *
 * ``round`` returns the nearest integer value to :math:`x`.
 *
 * Exceptions
 * ==========
 *
 * Does not raise exceptions.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+--------------------------+--------------+--------------+--------------------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<0`               | :math:`-0`   | :math:`+0`   | :math:`>0`               | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+==========================+==============+==============+==========================+==============+==============+
 * | **round(x)**        | :math:`-Inf` | :math:`\lfloor x \rceil` | :math:`x`                   | :math:`\lfloor x \rceil` | :math:`+Inf` | :math:`qNaN` |
 * +---------------------+--------------+--------------------------+--------------+--------------+--------------------------+--------------+--------------+
 *
 */
//

pub fn round ( 
x : f64 
) -> f64 { /* Most significant word, least significant word. */

let msw : int32_t = Default :: default ( ) ;
let exponent_less_1023 : int32_t = Default :: default ( ) ;


let lsw : u32 ;


loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
x 
) 
;



( 
msw 
) 
= 

ew_u . parts 
. msw 
;



( 
lsw 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* Extract exponent field. */


exponent_less_1023 
= 

( 

( 

msw 
& 
0x7ff00000 

) 
>> 
20 

) 
- 
1023 

;


if 
exponent_less_1023 < 20 
{ 
if 
exponent_less_1023 < 0 
{ 
msw &= 
0x80000000 
;


if 
exponent_less_1023 == -1 
{ /* Result is +1.0 or -1.0. */

msw |= 
( 


1023 
as int32_t 
<< 
20 

) 
;

}



lsw = 0 ;

}



else { 
let exponent_mask : uint32_t = 

0x000fffff 
>> 
exponent_less_1023 

;


if 


( 
msw & exponent_mask 
) 
== 
0 

&& 
lsw == 0 

{ /* x in an integral value. */

return x ;

}



msw += 

0x00080000 
>> 
exponent_less_1023 

;


msw &= 
! exponent_mask 
;


lsw = 0 ;

}


}



else if 
exponent_less_1023 
> 
51 
{ 
if 
exponent_less_1023 == 1024 
{ /* x is NaN or infinite. */

return x + x ;

}



else { 
return x ;

}


}



else { 
let exponent_mask : uint32_t = 

0xffffffff 
>> 
( 
exponent_less_1023 - 20 
) 

;


let tmp : u32 ;


if 

( 
lsw & exponent_mask 
) 
== 
0 

{ /* x is an integral value. */

return x ;

}




tmp 
= 

lsw 
+ 
( 

1 
<< 
( 
51 - exponent_less_1023 
) 

) 

;


if 
tmp 
< 
lsw 
{ 
msw += 1 ;

}



lsw = tmp ;


lsw &= 
! exponent_mask 
;

}



loop { 
let mut iw_u : ieee_double_shape_type = Default :: default ( ) ;




iw_u . parts 
. msw 
= 
( 
msw 
) 
;




iw_u . parts 
. lsw 
= 
( 
lsw 
) 
;



( 
x 
) 
= 
iw_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



return x ;

}


