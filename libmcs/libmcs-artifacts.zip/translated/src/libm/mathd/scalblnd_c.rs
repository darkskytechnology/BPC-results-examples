#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_overflow;
use crate::libm::common::tools_h::__raise_underflow;
use crate::libm::mathd::frexpd_c::two54;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions multiplies the input value :math:`x` by an integral
 * power of :math:`2`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float scalblnf(float x, int n);
 *     double scalbln(double x, int n);
 *     long double scalblnl(long double x, int n);
 *
 * Description
 * ===========
 *
 * ``scalbln`` multiplies the input value :math:`x` by an integral power of
 * :math:`2`.
 *
 * ``scalbln`` and :ref:`scalbn` have the same functionality. The difference is
 * that :ref:`scalbn` uses an ``int`` for :math:`n`.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    scalbln(x, n) \approx x \cdot 2^{n}
 *
 * Returns
 * =======
 *
 * ``scalbln`` returns the input value :math:`x` multiplied by :math:`2`
 * powered by the input value :math:`n`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``overflow`` exception if the result overflows.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +---------------------+-------------------------+-------------------------+-------------------------+
 * | scalbln(x,n)        | n                                                                           |
 * +---------------------+-------------------------+-------------------------+-------------------------+
 * | x                   | :math:`<0`              | :math:`0`               | :math:`>0`              |
 * +=====================+=========================+=========================+=========================+
 * | :math:`-Inf`        | :math:`x`               | :math:`x`               | :math:`x`               |
 * +---------------------+-------------------------+                         +-------------------------+
 * | :math:`<0`          | :math:`x \cdot 2^{n}`   |                         | :math:`x \cdot 2^{n}`   |
 * +---------------------+-------------------------+                         +-------------------------+
 * | :math:`-0`          | :math:`x`               |                         | :math:`x`               |
 * +---------------------+                         +                         +                         +
 * | :math:`+0`          |                         |                         |                         |
 * +---------------------+-------------------------+                         +-------------------------+
 * | :math:`>0`          | :math:`x \cdot 2^{n}`   |                         | :math:`x \cdot 2^{n}`   |
 * +---------------------+-------------------------+                         +-------------------------+
 * | :math:`+Inf`        | :math:`x`               |                         | :math:`x`               |
 * +---------------------+-------------------------+-------------------------+-------------------------+
 * | :math:`NaN`         | :math:`qNaN`                                                                |
 * +---------------------+-------------------------+-------------------------+-------------------------+
 *
 */
//

// static const double
// two54 = 1.80143985094819840000e+16, /* 0x43500000, 0x00000000 */
// twom54 = 5.55111512312578270212e-17;
const TWO54: f64 = 1.80143985094819840000e+16; // 0x43500000, 0x00000000
const TWOM54: f64 = 5.55111512312578270212e-1; 
/* 0x3C900000, 0x00000000 */

pub fn scalbln ( 
let n: i64;break 
) -> f64 { 
let k : int32_t = Default :: default ( ) ;
let hx : int32_t = Default :: default ( ) ;
let lx : int32_t = Default :: default ( ) ;


loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

ew_u . parts 
. msw 
;



( 
lx 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




k 
= 

( 

hx 
& 
0x7ff00000 

) 
>> 
20 

;

/* extract exponent */

if 
k == 0 
{ /* 0 or subnormal x */

if 

( 

lx 
| 
( 

hx 
& 
0x7fffffff 

) 

) 
== 
0 

{ 
return x ;

/* +-0 */
}



x *= two54 ;


loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




k 
= 

( 

( 

hx 
& 
0x7ff00000 

) 
>> 
20 

) 
- 
54 

;

}



if 
k == 0x7ff 
{ 
return x + x ;

/* NaN or Inf */
}



if 
n 
> 
50000 
{ 

__raise_overflow ( x ) 

/*overflow*/
}



k = k + n ;


if 
k 
> 
0x7fe 
{ 

__raise_overflow ( x ) 

/*overflow*/
}



if 
n < -50000 
{ 

__raise_underflow ( x ) 

/*underflow*/
}



if 
k 
> 
0 
{ /* normal result */

loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
x 
) 
;




sh_u . parts 
. msw 
= 
( 

( 

hx 
& 
0x800fffff 

) 
| 
( 

k 
<< 
20 

) 

) 
;



( 
x 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



return x ;

}



if 
k 
<= 
-54 
{ 

__raise_underflow ( x ) 

/*underflow*/
}



k += 54 ;

/* subnormal result */

loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
x 
) 
;




sh_u . parts 
. msw 
= 
( 

( 

hx 
& 
0x800fffff 

) 
| 
( 

k 
<< 
20 

) 

) 
;



( 
x 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



return x * twom54 ;

}


