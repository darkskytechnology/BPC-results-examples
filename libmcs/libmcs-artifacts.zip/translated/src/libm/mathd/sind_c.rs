#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexact;
use crate::libm::common::tools_h::__raise_invalid;
use crate::libm::mathd::internal::trigd_c::__cos;
use crate::libm::mathd::internal::trigd_c::__rem_pio2;
use crate::libm::mathd::internal::trigd_c::__sin;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the sine of :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float sinf(float x);
 *     double sin(double x);
 *     long double sinl(long double x);
 *
 * Description
 * ===========
 *
 * ``sin`` computes the sine of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    sin(x) \approx sin(x)
 *
 * Returns
 * =======
 *
 * ``sin`` returns the sine of the input value, in the range :math:`[-1, 1]`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when the input value is infinite.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +---------------------+----------------+----------------+----------------+----------------+----------------+----------------+----------------+
 * | **x**               | :math:`-Inf`   | :math:`<0`     | :math:`-0`     | :math:`+0`     | :math:`>0`     | :math:`+Inf`   | :math:`NaN`    |
 * +=====================+================+================+================+================+================+================+================+
 * | **sin(x)**          | :math:`qNaN`   | :math:`sin(x)` | :math:`x`                       | :math:`sin(x)` | :math:`qNaN`   | :math:`qNaN`   |
 * +---------------------+----------------+----------------+----------------+----------------+----------------+----------------+----------------+
 *
 */
//

pub fn sin ( 
x : f64 
) -> f64 { 
// double y[2], z = 0.0;
let mut y: [f64; 2] = [0.0; 2];
let mut z: f64 = 0.0; 

let n : int32_t = Default :: default ( ) ;
let ix : int32_t = Default :: default ( ) ;

/* High word of x. */

loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
x 
) 
;



( 
ix 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* |x| ~< pi/4 */

ix &= 
0x7fffffff 
;


if 
ix 
<= 
0x3fe921fb 
{ 
if 
ix < 0x3e500000 
{ /* |x| < 2**-26 */

if 
x == 0.0 
{ /* return x inexact except 0 */

return x ;

}



else { 

__raise_inexact ( x ) 

}


}




__sin ( 
x , 

z , 

0 
) 

}


/* sin(Inf or NaN) is NaN */

else if 
ix 
>= 
0x7ff00000 
{ 
if 
__builtin_isnan ( x ) 
{ 
return x + x ;

}



else { 

__raise_invalid ( ) 

}


}


/* argument reduction needed */

else { 
n = __rem_pio2 ( 
x , 

y 
) ;


match 

n 
& 
3 

{ 
0 => { 

__sin ( 
y [ 0 ] 

, 

y [ 1 ] 

, 

1 
) 

}



1 => { 

__cos ( 
y [ 0 ] 

, 

y [ 1 ] 
) 

}



-__sin(y[0], y[1], 1)break 

}


_ => { 

// -__cos(y[0], y[1])
unsafe { -__cos(y[0], y[1]) } 

}

}


}





