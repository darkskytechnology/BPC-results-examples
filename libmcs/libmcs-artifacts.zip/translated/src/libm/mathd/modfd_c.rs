#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions splits the input value into integral and fractional
 * part.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float modff(float x, float *iptr);
 *     double modf(double x, double *iptr);
 *     long double modfl(long double x, long double *iptr);
 *
 * Description
 * ===========
 *
 * ``modf`` splits the input value into integral and fractional part, each of
 * which have the same sign.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    modf(x) = x - iptr \wedge \left\{\begin{array}{ll} iptr = \lfloor x \rfloor, & x \geq 0  \\ iptr = \lceil x \rceil, & otherwise \end{array}\right.
 *
 * Returns
 * =======
 *
 * ``modf`` returns the fractional part of :math:`x` in the range
 * :math:`]-1.0,1.0[` and puts the integral part into the output pointer
 * :math:`*iptr`.
 *
 * Exceptions
 * ==========
 *
 * Does not raise exceptions.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+----------------------------------+--------------+--------------+----------------------------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<0`                       | :math:`-0`   | :math:`+0`   | :math:`>0`                       | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+==================================+==============+==============+==================================+==============+==============+
 * | **modf(x)**         | :math:`-0`   | :math:`x - \lceil x \rceil`      | :math:`x`                   | :math:`x - \lfloor x \rfloor`    | :math:`+0`   | :math:`qNaN` |
 * +---------------------+--------------+----------------------------------+--------------+--------------+----------------------------------+--------------+              +
 * | :math:`*iptr`       | :math:`-Inf` | :math:`\lceil x \rceil`          | :math:`x`                   | :math:`\lfloor x \rfloor`        | :math:`+Inf` |              |
 * +---------------------+--------------+----------------------------------+--------------+--------------+----------------------------------+--------------+--------------+
 *
 */
//

pub fn modf ( 
x : f64 , 

// double *iptr
let mut iptr: *mut f64 = std::ptr::null_mut(); 
) -> f64 { 
let _xi : f64 = 0.0 ;


let _i0 : int32_t = Default :: default ( ) ;
let _i1 : int32_t = Default :: default ( ) ;
let _j0 : int32_t = Default :: default ( ) ;


let i : u32 ;


assert ! ( 

iptr 
!= 
Some ( 
0 
. unwrap ( ) as std :: rc :: Rc < dyn std :: any :: Any > ) 

) ;


if 

iptr 
== 
Some ( 
0 
. unwrap ( ) as std :: rc :: Rc < dyn std :: any :: Any > ) 

{ 

iptr 
= 
& 
_xi 

;

}



loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
x 
) 
;



( 
_i0 
) 
= 

ew_u . parts 
. msw 
;



( 
_i1 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




_j0 
= 

( 

( 

_i0 
>> 
20 

) 
& 
0x7ff 

) 
- 
0x3ff 

;

/* exponent of x */

if 
_j0 < 20 
{ /* integer part in high x */

if 
_j0 < 0 
{ /* |x|<1 */

loop { 
let mut iw_u : ieee_double_shape_type = Default :: default ( ) ;




iw_u . parts 
. msw 
= 
( 

_i0 
& 
0x80000000 

) 
;




iw_u . parts 
. lsw 
= 
( 
0 
) 
;



( 

iptr 

) 
= 
iw_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* *iptr = +-0 */

return x ;

}



else { 

i 
= 

( 
0x000fffff 
) 
>> 
_j0 

;


if 

( 

( 
_i0 & i 
) 
| 
_i1 

) 
== 
0 

{ /* x is integral */



iptr 

= 
x 
;


loop { 
let mut iw_u : ieee_double_shape_type = Default :: default ( ) ;




iw_u . parts 
. msw 
= 
( 

_i0 
& 
0x80000000 

) 
;




iw_u . parts 
. lsw 
= 
( 
0 
) 
;



( 
x 
) 
= 
iw_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* return +-0 */

return x ;

}



else { 
loop { 
let mut iw_u : ieee_double_shape_type = Default :: default ( ) ;




iw_u . parts 
. msw 
= 
( 

_i0 
& 
( 
! i 
) 

) 
;




iw_u . parts 
. lsw 
= 
( 
0 
) 
;



( 

iptr 

) 
= 
iw_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}





x 
- 

iptr 



}


}


}



else if 
_j0 
> 
51 
{ /* no fraction part */



iptr 

= 
x 
;


if 
__builtin_isnan ( x ) 
{ 



iptr 

= 
x + x 


/* x is NaN, return NaN */
}



loop { 
let mut iw_u : ieee_double_shape_type = Default :: default ( ) ;




iw_u . parts 
. msw 
= 
( 

_i0 
& 
0x80000000 

) 
;




iw_u . parts 
. lsw 
= 
( 
0 
) 
;



( 
x 
) 
= 
iw_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* return +-0 */

return x ;

}



else { /* fraction part in low x */


i 
= 

( 

( 
0xffffffff 
) 
as uint32_t 
) 
>> 
( 
_j0 - 20 
) 

;


if 

( 
_i1 & i 
) 
== 
0 

{ /* x is integral */



iptr 

= 
x 
;


loop { 
let mut iw_u : ieee_double_shape_type = Default :: default ( ) ;




iw_u . parts 
. msw 
= 
( 

_i0 
& 
0x80000000 

) 
;




iw_u . parts 
. lsw 
= 
( 
0 
) 
;



( 
x 
) 
= 
iw_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* return +-0 */

return x ;

}



else { 
loop { 
let mut iw_u : ieee_double_shape_type = Default :: default ( ) ;




iw_u . parts 
. msw 
= 
( 
_i0 
) 
;




iw_u . parts 
. lsw 
= 
( 

_i1 
& 
( 
! i 
) 

) 
;



( 

iptr 

) 
= 
iw_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}





x 
- 

iptr 



}


}


}


}
