pub mod acosd_c;

pub mod acoshd_c;

pub mod asind_c;

pub mod asinhd_c;

pub mod atan2d_c;

pub mod atand_c;

pub mod atanhd_c;

pub mod cbrtd_c;

pub mod ceild_c;

pub mod copysignd_c;

pub mod cosd_c;

pub mod coshd_c;

pub mod erfcd_c;

pub mod erfd_c;

pub mod exp2d_c;

pub mod expd_c;

pub mod expm1d_c;

pub mod fabsd_c;

pub mod fdimd_c;

pub mod floord_c;

pub mod fmad_c;

pub mod fmaxd_c;

pub mod fmind_c;

pub mod fmodd_c;

pub mod frexpd_c;

pub mod hypotd_c;

pub mod ilogbd_c;

pub mod internal;

pub mod j0d_c;

pub mod j1d_c;

pub mod jnd_c;

pub mod ldexpd_c;

pub mod lgammad_c;

pub mod llrintd_c;

pub mod llroundd_c;

pub mod log10d_c;

pub mod log1pd_c;

pub mod log2d_c;

pub mod logbd_c;

pub mod logd_c;

pub mod lrintd_c;

pub mod lroundd_c;

pub mod modfd_c;

pub mod nand_c;

pub mod nearbyintd_c;

pub mod nextafterd_c;

pub mod nexttowardd_c;

pub mod powd_c;

pub mod remainderd_c;

pub mod remquod_c;

pub mod rintd_c;

pub mod roundd_c;

pub mod scalblnd_c;

pub mod scalbnd_c;

pub mod sind_c;

pub mod sinhd_c;

pub mod sqrtd_c;

pub mod tand_c;

pub mod tanhd_c;

pub mod tgammad_c;

pub mod truncd_c;

pub mod y0d_c;

pub mod y1d_c;

pub mod ynd_c;

