#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zero;
use crate::libm::common::tools_h::__raise_invalid;
use crate::libm::mathd::atan2d_c::zero;
use crate::libm::mathd::expm1d_c::ln2_hi;
use crate::libm::mathd::expm1d_c::ln2_lo;
use crate::libm::mathd::frexpd_c::two54;
use crate::libm::mathd::internal::gammad_c::t1;
use crate::libm::mathd::internal::gammad_c::t2;
use crate::libm::mathd::internal::log1pmfd_h::Lg1;
use crate::libm::mathd::internal::log1pmfd_h::Lg2;
use crate::libm::mathd::internal::log1pmfd_h::Lg3;
use crate::libm::mathd::internal::log1pmfd_h::Lg4;
use crate::libm::mathd::internal::log1pmfd_h::Lg5;
use crate::libm::mathd::internal::log1pmfd_h::Lg6;
use crate::libm::mathd::internal::log1pmfd_h::Lg7;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the natural logarithm.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float logf(float x);
 *     double log(double x);
 *     long double logl(long double x);
 *
 * Description
 * ===========
 *
 * ``log`` computes the natural logarithm of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    log(x) \approx ln(x)
 *
 * Returns
 * =======
 *
 * ``log`` returns the natural logarithm of :math:`x`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when the input value is negative.
 *
 * Raise ``divide by zero`` exception when the input value is zero.
 *
 * Output map
 * ==========
 *
 * +---------------------+---------------+---------------+---------------+---------------+---------------+---------------+---------------+---------------+---------------+
 * | **x**               | :math:`-Inf`  | :math:`<0`    | :math:`-0`    | :math:`+0`    | :math:`]0,1[` | :math:`1`     | :math:`>1`    | :math:`+Inf`  | :math:`NaN`   |
 * +=====================+===============+===============+===============+===============+===============+===============+===============+===============+===============+
 * | **log(x)**          | :math:`qNaN`  | :math:`qNaN`  | :math:`-Inf`                  | :math:`ln(x)` | :math:`+0`    | :math:`ln(x)` | :math:`+Inf`  | :math:`qNaN`  |
 * +---------------------+---------------+---------------+---------------+---------------+---------------+---------------+---------------+---------------+---------------+
 *
 */
//

// static const double
// ln2_hi = 6.93147180369123816490e-01, /* 3fe62e42 fee00000 */
// ln2_lo = 1.90821492927058770002e-10, /* 3dea39ef 35793c76 */
// two54 = 1.80143985094819840000e+16, /* 43500000 00000000 */
// Lg1 = 6.666666666666735130e-01, /* 3FE55555 55555593 */
// Lg2 = 3.999999999940941908e-01, /* 3FD99999 9997FA04 */
// Lg3 = 2.857142874366239149e-01, /* 3FD24924 94229359 */
// Lg4 = 2.222219843214978396e-01, /* 3FCC71C5 1D8E78AF */
// Lg5 = 1.818357216161805012e-01, /* 3FC74664 96CB03DE */
// Lg6 = 1.531383769920937332e-01, /* 3FC39A09 D078C69F */
// Lg7 = 1.479819860511658591e-01;
const LN2_HI: f64 = 6.93147180369123816490e-01;  // 3fe62e42 fee00000
const LN2_LO: f64 = 1.90821492927058770002e-10;  // 3dea39ef 35793c76
const TWO54: f64 = 1.80143985094819840000e+16;  // 43500000 00000000
const LG1: f64 = 6.666666666666735130e-01;    // 3FE55555 55555593
const LG2: f64 = 3.999999999940941908e-01;    // 3FD99999 9997FA04
const LG3: f64 = 2.857142874366239149e-01;    // 3FD24924 94229359
const LG4: f64 = 2.222219843214978396e-01;    // 3FCC71C5 1D8E78AF
const LG5: f64 = 1.818357216161805012e-01;    // 3FC74664 96CB03DE
let hfsq: f64;
let f: f64;
let s: f64;
let mut k: i32;
let mut hx: i32;
let mut i: i32;
let mut j: i32;let t1: f64;
let t2: f64;
let dk: f64;
const zero : f64 = 0.0 ;


pub fn log ( 
x : f64 
) -> f64 { 
// double hfsq, f, s, z, R, w, t1, t2, dk;
break 

// int32_t k, hx, i, j;
break 

let lx : u32 ;


loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

ew_u . parts 
. msw 
;



( 
lx 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



k = 0 ;


if 
hx < 0x00100000 
{ /* x < 2**-1022  */

if 

( 

( 

hx 
& 
0x7fffffff 

) 
| 
lx 

) 
== 
0 

{ 

__raise_div_by_zero ( -1.0 ) 

/* log(+-0)=-inf */
}



if 
hx < 0 
{ 
if 
__builtin_isnan ( x ) 
{ 
return x + x ;

}



else { 

__raise_invalid ( ) 

/* log(-#) = NaN */
}


}



k -= 54 ;


x *= two54 ;

/* subnormal number, scale up x */

loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


}



if 
hx 
>= 
0x7ff00000 
{ /* x = NaN/+-Inf */

return x + x ;

}



k += 

( 

hx 
>> 
20 

) 
- 
1023 

;


hx &= 
0x000fffff 
;



i 
= 

( 
hx + 0x95f64 
) 
& 
0x100000 

;


loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
x 
) 
;




sh_u . parts 
. msw 
= 
( 

hx 
| 
( 

i 
^ 
0x3ff00000 

) 

) 
;



( 
x 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* normalize x or x/2 */

k += 
( 

i 
>> 
20 

) 
;


f = x - 1.0 ;


if 

( 

0x000fffff 
& 
( 
2 + hx 
) 

) 
< 
3 

{ /* |f| < 2**-20 */

if 
f == zero 
{ 
if 
k == 0 
{ 
return zero ;

}



else { 

dk 
= 

k 
as f64 
;




dk * ln2_hi 
+ 
dk * ln2_lo 


}


}




R 
= 

f * f 
* 
( 

0.5 
- 
0.33333333333333333 * f 

) 

;


if 
k == 0 
{ 
return f - R ;

}



else { 

dk 
= 

k 
as f64 
;




dk * ln2_hi 
- 
( 

( 

R 
- 
dk * ln2_lo 

) 
- 
f 

) 


}


}




s 
= 

f 
/ 
( 
2.0 + f 
) 

;



dk 
= 

k 
as f64 
;


z = s * s ;


i = hx - 0x6147a ;


w = z * z ;


j = 0x6b851 - hx ;



t1 
= 

w 
* 
( 

Lg2 
+ 

w 
* 
( 

Lg4 
+ 
w * Lg6 

) 


) 

;



t2 
= 

z 
* 
( 

Lg1 
+ 

w 
* 
( 

Lg3 
+ 

w 
* 
( 

Lg5 
+ 
w * Lg7 

) 


) 


) 

;


i |= 
j 
;


R = t2 + t1 ;


if 
i 
> 
0 
{ 

hfsq 
= 
0.5 
* 
f 
* 
f 
;


if 
k == 0 
{ 


f 
- 
( 

hfsq 
- 

s 
* 
( 
hfsq + R 
) 


) 


}



else { 


dk * ln2_hi 
- 
( 

( 

hfsq 
- 
( 


s 
* 
( 
hfsq + R 
) 

+ 
dk * ln2_lo 

) 

) 
- 
f 

) 


}


}



else { 
if 
k == 0 
{ 


f 
- 

s 
* 
( 
f - R 
) 



}



else { 


dk * ln2_hi 
- 
( 

( 


s 
* 
( 
f - R 
) 

- 
dk * ln2_lo 

) 
- 
f 

) 


}


}


}


