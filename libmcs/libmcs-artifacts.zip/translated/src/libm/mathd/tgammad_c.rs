#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_div_by_zero;
use crate::libm::common::tools_h::__raise_invalid;
use crate::libm::mathd::expd_c::exp;
use crate::libm::mathd::floord_c::floor;
use crate::libm::mathd::internal::gammad_c::__lgamma;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the gamma function of :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float tgammaf(float x);
 *     double tgamma(double x);
 *     long double tgammal(long double x);
 *
 * Description
 * ===========
 *
 * ``tgamma`` computes the gamma function of :math:`x`.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    tgamma(x) \approx \Gamma(x) = \int_{0}^{\infty}e^{-t}t^{x-1}dt
 *
 * Returns
 * =======
 *
 * ``tgamma`` returns the gamma function of :math:`x`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when the input value is a negative
 * integer or negative infinity.
 *
 * Raise ``divide by zero`` exception when the input value is zero.
 *
 * Raise ``overflow`` exception when the magnitude of the input value is too
 * large or too small.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+---------------------------------------+-----------------------------+--------------+--------------+-------------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<0\ \wedge\ \notin \mathbb{Z}` | :math:`\in \mathbb{Z}_{<0}` | :math:`-0`   | :math:`+0`   | :math:`>0`        | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+=======================================+=============================+==============+==============+===================+==============+==============+
 * | **tgamma(x)**       | :math:`qNaN` | :math:`\Gamma(x)`                     | :math:`qNaN`                | :math:`-Inf` | :math:`+Inf` | :math:`\Gamma(x)` | :math:`+Inf` | :math:`qNaN` |
 * +---------------------+--------------+---------------------------------------+-----------------------------+--------------+--------------+-------------------+--------------+--------------+
 *
 */
//

pub fn tgamma ( 
x : f64 
) -> f64 { 
let signgam_local : i32 = 0 ;


let y : f64 = 0.0 ;


if 

__builtin_isnan ( x ) 
!= 
0 

{ /* tgamma(NaN) = NaN */

return x + x ;

}



else if 
x == 0.0 
{ /* tgamma(+-0) = +-Inf */


__raise_div_by_zero ( x ) 

}



else if 


floor ( x ) 
== 
x 

&& 
x < 0.0 

{ /* tgamma(negative integer, -Inf) = NaN */


__raise_invalid ( ) 

}



else { /* No action required */

// }
It seems like you've provided an incomplete input. Could you please provide the full C code that you would like to be translated into Rust? 

y = exp ( 
__lgamma ( 
x , 

& 
signgam_local 

) 
) ;


if 
signgam_local < 0 
{ 

y 
= 
- y 
;

}



return y ;

}





