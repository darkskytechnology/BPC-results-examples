#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexact;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions implements rounding towards positive infinity of
 * :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float ceilf(float x);
 *     double ceil(double x);
 *     long double ceill(long double x);
 *
 * Description
 * ===========
 *
 * ``ceil`` computes the input value rounded towards positive infinity.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    ceil(x) = \lceil x \rceil
 *
 * Returns
 * =======
 *
 * ``ceil`` returns the input value rounded towards positive infinity.
 *
 * Exceptions
 * ==========
 *
 * Does not raise exceptions.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+-------------------------+--------------+--------------+-------------------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<0`              | :math:`-0`   | :math:`+0`   | :math:`>0`              | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+=========================+==============+==============+=========================+==============+==============+
 * | **ceil(x)**         | :math:`-Inf` | :math:`\lceil x \rceil` | :math:`x`                   | :math:`\lceil x \rceil` | :math:`+Inf` | :math:`qNaN` |
 * +---------------------+--------------+-------------------------+--------------+--------------+-------------------------+--------------+--------------+
 *
 */
//

pub fn ceil(x: f64) -> f64 {
    let _i0: int32_t = Default::default();
    let _i1: int32_t = Default::default();
    let _j0: int32_t = Default::default();

    let i: uint32_t = Default::default();
    let j: uint32_t = Default::default();

    loop {
        let mut ew_u: ieee_double_shape_type = Default::default();

        ew_u.value = (x);

        (_i0) = ew_u.parts.msw;

        (_i1) = ew_u.parts.lsw;

        if (0 == 0) == false {
            break;
        }
    }

    _j0 = ((_i0 >> 20) & 0x7ff) - 0x3ff;

    if _j0 < 20 {
        if _j0 < 0 {
            /* raise inexact if x != 0 */

            if ((_i0 & 0x7fffffff) | _i1) == 0 {
                return x;
            }

            let _ = __raise_inexact(x);

            if _i0 < 0 {
                /* return 0*sign(x) if |x|<1 */

                _i0 = 0x80000000 as int32_t;

                _i1 = 0;
            } else {
                _i0 = 0x3ff00000;

                _i1 = 0;
            }
        } else {
            i = (0x000fffff) >> _j0;

            if ((_i0 & i) | _i1) == 0 {
                return x;

                /* x is integral */
            }

            let _ = __raise_inexact(x);

            /* raise inexact flag */

            if _i0 > 0 {
                _i0 += (0x00100000) >> _j0;
            }

            _i0 &= (!i);

            _i1 = 0;
        }
    } else if _j0 > 51 {
        if _j0 == 0x400 {
            return x + x;

        /* inf or NaN */
        } else {
            return x;

            /* x is integral */
        }
    } else {
        i = (0xffffffff as uint32_t) >> (_j0 - 20);

        if (_i1 & i) == 0 {
            return x;

            /* x is integral */
        }

        let _ = __raise_inexact(x);

        /* raise inexact flag */

        if _i0 > 0 {
            if _j0 == 20 {
                _i0 += 1;
            } else {
                j = _i1 + (1 << (52 - _j0));

                if j < _i1 as uint32_t {
                    _i0 += 1;

                    /* got a carry */
                }

                _i1 = j;
            }
        }

        _i1 &= (!i);
    }

    loop {
        let mut iw_u: ieee_double_shape_type = Default::default();

        iw_u.parts.msw = (_i0);

        iw_u.parts.lsw = (_i1);

        (x) = iw_u.value;

        if (0 == 0) == false {
            break;
        }
    }

    return x;
}
