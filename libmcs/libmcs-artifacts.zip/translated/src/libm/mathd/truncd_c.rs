#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions implements the nearest integer value towards zero
 * from :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float truncf(float x);
 *     double trunc(double x);
 *     long double truncl(long double x);
 *
 * Description
 * ===========
 *
 * ``trunc`` computes the nearest integer value towards zero from :math:`x`.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    trunc(x) = \left\{\begin{array}{ll} \lfloor x \rfloor, & x \in \mathbb{F}^{+} \\ \lceil x \rceil, & otherwise \end{array}\right.
 *
 * Returns
 * =======
 *
 * ``trunc`` returns the nearest integer value towards zero from :math:`x`.
 *
 * Exceptions
 * ==========
 *
 * Does not raise exceptions.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+---------------------------+--------------+--------------+---------------------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<0`                | :math:`-0`   | :math:`+0`   | :math:`>0`                | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+===========================+==============+==============+===========================+==============+==============+
 * | **trunc(x)**        | :math:`-Inf` | :math:`\lceil x \rceil`   | :math:`x`                   | :math:`\lfloor x \rfloor` | :math:`+Inf` | :math:`qNaN` |
 * +---------------------+--------------+---------------------------+--------------+--------------+---------------------------+--------------+--------------+
 *
 */
//

pub fn trunc(x: f64) -> f64 {
    let sb: u32;

    /* Most significant word, least significant word. */

    let msw: u32;

    let lsw: u32;

    let exponent_less_1023: i32;

    loop {
        let mut ew_u: ieee_double_shape_type = Default::default();

        ew_u.value = (x);

        (msw) = ew_u.parts.msw;

        (lsw) = ew_u.parts.lsw;

        if (0 == 0) == false {
            break;
        }
    }

    /* Extract sign bit. */

    sb = msw & 0x80000000;

    /* Extract exponent field. */

    exponent_less_1023 = ((msw & 0x7ff00000) >> 20) - 1023;

    if exponent_less_1023 < 20 {
        /* All significant digits are in msw. */

        if exponent_less_1023 < 0 {
            /* -1 < x < 1, so result is +0 or -0. */

            loop {
                let mut iw_u: ieee_double_shape_type = Default::default();

                iw_u.parts.msw = (sb);

                iw_u.parts.lsw = (0);

                (x) = iw_u.value;

                if (0 == 0) == false {
                    break;
                }
            }
        } else {
            /* All relevant fraction bits are in msw, so lsw of the result is 0. */

            loop {
                let mut iw_u: ieee_double_shape_type = Default::default();

                iw_u.parts.msw = (sb | (msw & !(0x000fffff >> exponent_less_1023)));

                iw_u.parts.lsw = (0);

                (x) = iw_u.value;

                if (0 == 0) == false {
                    break;
                }
            }
        }
    } else if exponent_less_1023 > 51 {
        if exponent_less_1023 == 1024 {
            /* x is infinite, or not a number, so trigger an exception. */

            return x + x;
        }

    /* All bits in the fraction fields of the msw and lsw are needed in the result. */
    } else {
        /* All fraction bits in msw are relevant.  Truncate irrelevant bits from lsw. */

        loop {
            let mut iw_u: ieee_double_shape_type = Default::default();

            iw_u.parts.msw = (msw);

            iw_u.parts.lsw = (lsw & !(0xffffffff >> (exponent_less_1023 - 20)));

            (x) = iw_u.value;

            if (0 == 0) == false {
                break;
            }
        }
    }

    return x;
}
