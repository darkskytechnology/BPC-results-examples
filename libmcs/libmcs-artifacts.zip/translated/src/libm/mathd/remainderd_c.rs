#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_invalid;
use crate::libm::include::math_h::fabs;
use crate::libm::include::math_h::fmod;
use crate::libm::mathd::atan2d_c::zero;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the floating-point remainder :math:`x\ REM\ y`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float remainderf(float x, float y);
 *     double remainder(double x, double y);
 *     long double remainderl(long double x, long double y);
 *
 * Description
 * ===========
 *
 * ``remainder`` computes the floating-point remainder :math:`r = x\ REM\ y = x
 * - n \cdot y` of their arguments :math:`x` and :math:`y`, where :math:`n` is
 *   the integral value nearest to :math:`\frac{x}{y}`.
 *
 * The ``fmod`` and ``remainder`` procedures are rather similar, but not the
 * same, see examples:
 *
 * +----------------+----------------+----------------+----------------+
 * | x              | y              | fmod           | remainder      |
 * +================+================+================+================+
 * | :math:`+2.456` | :math:`+2.0`   | :math:`+0.456` | :math:`+0.456` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`+3.456` | :math:`+2.0`   | :math:`+1.456` | :math:`-0.544` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`-2.456` | :math:`+2.0`   | :math:`-0.456` | :math:`-0.456` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`-3.456` | :math:`+2.0`   | :math:`-1.456` | :math:`+0.544` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`+2.456` | :math:`-2.0`   | :math:`+0.456` | :math:`+0.456` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`+3.456` | :math:`-2.0`   | :math:`+1.456` | :math:`-0.544` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`-2.456` | :math:`-2.0`   | :math:`-0.456` | :math:`-0.456` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`-3.456` | :math:`-2.0`   | :math:`-1.456` | :math:`+0.544` |
 * +----------------+----------------+----------------+----------------+
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    remainder(x, y) = x - n \cdot y \wedge n \in \mathbb{Z} \wedge remainder(x, y) \in \left [-\left | \frac{y}{2} \right |,\left | \frac{y}{2} \right | \right ]
 *
 * Returns
 * =======
 *
 * ``remainder`` returns the floating-point remainder :math:`x\ REM\ y`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when :math:`x` is infinite or
 * :math:`y` is zero.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | remainder(x,y)           | x                                                                                                                                                                                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | y                        | :math:`-Inf`             | :math:`<0`               | :math:`-0`               | :math:`+0`               | :math:`>0`               | :math:`+Inf`             | :math:`NaN`              |
 * +==========================+==========================+==========================+==========================+==========================+==========================+==========================+==========================+
 * | :math:`-Inf`             | :math:`qNaN`             | :math:`x`                                                                                                 | :math:`qNaN`             | :math:`qNaN`             |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`<0`               |                          | :math:`x\ REM\ y`        | :math:`x`                                           | :math:`x\ REM\ y`        |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`-0`               |                          | :math:`qNaN`                                                                                              |                          |                          |
 * +--------------------------+                          +                                                                                                           +                          +                          +
 * | :math:`+0`               |                          |                                                                                                           |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`>0`               |                          | :math:`x\ REM\ y`        | :math:`x`                                           | :math:`x\ REM\ y`        |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`+Inf`             |                          | :math:`x`                                                                                                 |                          |                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+                          +
 * | :math:`NaN`              | :math:`qNaN`                                                                                                                                                    |                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 *
 */
//

const zero : f64 = 0.0 ;


pub fn remainder ( 
x : f64 , 

y : f64 
) -> f64 { 
let hx : int32_t = Default :: default ( ) ;
let hy : int32_t = Default :: default ( ) ;


let sx : uint32_t = Default :: default ( ) ;
let lx : uint32_t = Default :: default ( ) ;
let ly : uint32_t = Default :: default ( ) ;


let y_half : f64 = Default :: default ( ) ;


loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

ew_u . parts 
. msw 
;



( 
lx 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
y 
) 
;



( 
hy 
) 
= 

ew_u . parts 
. msw 
;



( 
ly 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




sx 
= 

hx 
& 
0x80000000 

;


hy &= 
0x7fffffff 
;


hx &= 
0x7fffffff 
;

/* purge off exception values */

if 

( 
hx 
>= 
0x7ff00000 
) 
|| 
( 
hy 
>= 
0x7ff00000 
) 

{ /* x or y not finite */

if 

__builtin_isnan ( x ) 
|| 
__builtin_isnan ( y ) 

{ /* x or y is NaN */

return x + y ;

}



else if 
hx == 0x7ff00000 
{ /* x is infinite */


__raise_invalid ( ) 

}



else { /* No action required */

// }
} 
}


}



else if 

( 
hy | ly 
) 
== 
0 

{ /* y = 0 */


__raise_invalid ( ) 

}



else { /* No action required */

// }
} 

if 
hy 
<= 
0x7fdfffff 
{ 
x = fmod ( 
x , 

2 * y 
) ;

/* now x < 2y */
}



if 

( 

( 
hx - hy 
) 
| 
( 
lx - ly 
) 

) 
== 
0 

{ /* x equals y */

return zero * x ;

}



x = x . abs ( ) ;


y = y . abs ( ) ;


if 
hy < 0x00200000 
{ 
if 

x + x 
> 
y 

{ 
x -= y ;


if 

x + x 
>= 
y 

{ 
x -= y ;

}


}


}



else { 
y_half = 0.5 * y ;


if 
x 
> 
y_half 
{ 
x -= y ;


if 
x 
>= 
y_half 
{ 
x -= y ;

}


}


}



loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut sh_u : ieee_double_shape_type = Default :: default ( ) ;


sh_u . value = 
( 
x 
) 
;




sh_u . parts 
. msw 
= 
( 
hx ^ sx 
) 
;



( 
x 
) 
= 
sh_u . value 
;

if ( 
0 
== 
0 
) == false { break ;






return x ;







