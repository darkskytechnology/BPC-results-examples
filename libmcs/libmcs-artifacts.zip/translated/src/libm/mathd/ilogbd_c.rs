#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_invalid;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions computes the binary exponent of the input value as
 * a signed integer.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     int ilogbf(float x);
 *     int ilogb(double x);
 *     int ilogbl(long double x);
 *
 * Description
 * ===========
 *
 * ``ilogb`` computes the binary exponent of the input value as a signed integer.
 *
 * ``ilogb`` and :ref:`logb` have the same functionality, but ``ilogb`` returns
 * the binary exponent as a signed integer while :ref:`logb` returns a
 * floating-point value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    ilogb(x) \approx \lfloor {\log_2 |x|} \rfloor
 *
 * Returns
 * =======
 *
 * ``ilogb`` returns the binary exponent of the input value, in the range
 * :math:`\mathbb{I}`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when the correct result is not
 * representable as an integer. This is the case when the input value is zero,
 * infinite or :math:`NaN`, or the magnitude of the result is too large to be
 * represented as an integer.
 *
 * Output map
 * ==========
 *
 * +---------------------+------------------------+----------------------------------------------------------------------------------------------------------+------------------------------------------------------------------+----------------------------------------------------------------------------------------------------------+--------------+--------------+
 * | **x**               | :math:`-Inf`           | :math:`<0 \wedge \lfloor {\log_2 |x|} \rfloor \notin \mathbb{I} \wedge \lfloor {\log_2 |x|} \rfloor > 0` | :math:`<0 \wedge \lfloor {\log_2 |x|} \rfloor \in \mathbb{I}`    | :math:`<0 \wedge \lfloor {\log_2 |x|} \rfloor \notin \mathbb{I} \wedge \lfloor {\log_2 |x|} \rfloor < 0` | :math:`-0`   | :math:`+0`   |
 * +=====================+========================+==========================================================================================================+==================================================================+==========================================================================================================+==============+==============+
 * | **ilogb(x)**        | max :math:`\mathbb{I}` | max :math:`\mathbb{I}`                                                                                   | :math:`\lfloor {\log_2 |x|} \rfloor`                             | min :math:`\mathbb{I}`                                                                                   | min :math:`\mathbb{I}`      |
 * +---------------------+------------------------+----------------------------------------------------------------------------------------------------------+------------------------------------------------------------------+----------------------------------------------------------------------------------------------------------+--------------+--------------+
 *
 * +---------------------+----------------------------------------------------------------------------------------------------------+------------------------------------------------------------------+----------------------------------------------------------------------------------------------------------+--------------+--------------+
 * | **x**               | :math:`>0 \wedge \lfloor {\log_2 |x|} \rfloor \notin \mathbb{I} \wedge \lfloor {\log_2 |x|} \rfloor < 0` | :math:`<0 \wedge \lfloor {\log_2 |x|} \rfloor \in \mathbb{I}`    | :math:`>0 \wedge \lfloor {\log_2 |x|} \rfloor \notin \mathbb{I} \wedge \lfloor {\log_2 |x|} \rfloor > 0` | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==========================================================================================================+==================================================================+==========================================================================================================+==============+==============+
 * | **ilogb(x)**        | min :math:`\mathbb{I}`                                                                                   | :math:`\lfloor {\log_2 |x|} \rfloor`                             | max :math:`\mathbb{I}`                                                                                   | max :math:`\mathbb{I}`      |
 * +---------------------+----------------------------------------------------------------------------------------------------------+------------------------------------------------------------------+----------------------------------------------------------------------------------------------------------+--------------+--------------+
 *
 * .. raw:: html
 *
 *    <!--
 *    TODO: Check usefulness of this output map as well as the exception, as I
 *    think the magnitude of the result can only exceed the integer range if
 *    the size of ``int`` is smaller than [-1074,1023]. So the POSIX/C/etc.
 *    issues may not apply to our use-cases.
 *    -->
 *
 */
//

pub fn ilogb(x: f64) -> i32 {
    let hx: int32_t = Default::default();
    let lx: int32_t = Default::default();
    let ix: int32_t = Default::default();

    loop {
        let mut ew_u: ieee_double_shape_type = Default::default();

        ew_u.value = (x);

        (hx) = ew_u.parts.msw;

        (lx) = ew_u.parts.lsw;

        if (0 == 0) == false {
            break;
        }
    }

    hx &= 0x7fffffff;

    if hx < 0x00100000 {
        if (hx | lx) == 0 {
            let _ = __raise_invalid();

            -2147483647 - -2147483647

            /* ilogb(0) = special case error */
        } else {
            /* subnormal x */

            if hx == 0 {
                ix = -1043;
                while lx > 0 {
                    ix -= 1;

                    // lx <<= 1
                    lx <<= 1;
                }
            } else {
                {
                    ix = -1022;

                    // hx <<= 11
                    hx <<= 11;
                };
                while hx > 0 {
                    ix -= 1;

                    // hx <<= 1
                    hx <<= 1;
                }
            }
        }

        return ix;
    } else if hx < 0x7ff00000 {
        (hx >> 20) - 1023
    } else if hx > 0x7ff00000 {
        let _ = __raise_invalid();

        -2147483647 - -2147483647

        /* NAN */
    } else {
        let _ = __raise_invalid();

        return 0x7fffffff;

        /* infinite */
    }
}
