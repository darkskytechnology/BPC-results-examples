#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::include::math_h::pow;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions implements :math:`2` powered by :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float exp2f(float x);
 *     double exp2(double x);
 *     long double exp2l(long double x);
 *
 * Description
 * ===========
 *
 * ``exp2`` computes :math:`2` powered by the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    exp2(x) \approx 2^x
 *
 * Returns
 * =======
 *
 * ``exp2`` returns :math:`2` powered by :math:`x`, in the range
 * :math:`\mathbb{F}^{+}_0`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``overflow`` exception when the magnitude of the input value is too
 * large.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<0`   | :math:`-0`   | :math:`+0`   | :math:`>0`   | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+==============+==============+==============+==============+==============+==============+
 * | **exp2(x)**         | :math:`+0`   | :math:`2^x`  | :math:`+1`                  | :math:`2^x`  | :math:`+Inf` | :math:`qNaN` |
 * +---------------------+--------------+--------------+--------------+--------------+--------------+--------------+--------------+
 *
 */
//

pub fn exp2(x: f64) -> f64 {
    return 2.0.powf(x);
}
