#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_invalid;
use crate::translate_bpc_vmm;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the floating-point remainder of
 * :math:`x` divided by :math:`y`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float fmodf(float x, float y);
 *     double fmod(double x, double y);
 *     long double fmodl(long double x, long double y);
 *
 * Description
 * ===========
 *
 * ``fmod`` computes the floating-point remainder of :math:`x` divided by
 * :math:`y`.
 *
 * The ``fmod`` and ``remainder`` procedures are rather similar, but not the
 * same, see examples:
 *
 * +----------------+----------------+----------------+----------------+
 * | x              | y              | fmod           | remainder      |
 * +================+================+================+================+
 * | :math:`+2.456` | :math:`+2.0`   | :math:`+0.456` | :math:`+0.456` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`+3.456` | :math:`+2.0`   | :math:`+1.456` | :math:`-0.544` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`-2.456` | :math:`+2.0`   | :math:`-0.456` | :math:`-0.456` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`-3.456` | :math:`+2.0`   | :math:`-1.456` | :math:`+0.544` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`+2.456` | :math:`-2.0`   | :math:`+0.456` | :math:`+0.456` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`+3.456` | :math:`-2.0`   | :math:`+1.456` | :math:`-0.544` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`-2.456` | :math:`-2.0`   | :math:`-0.456` | :math:`-0.456` |
 * +----------------+----------------+----------------+----------------+
 * | :math:`-3.456` | :math:`-2.0`   | :math:`-1.456` | :math:`+0.544` |
 * +----------------+----------------+----------------+----------------+
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    fmod(x, y) = x - n \cdot y \wedge n \in \mathbb{Z} \wedge |fmod(x, y)| < |y| \wedge \frac{f(x, y)}{|f(x, y)|} = \frac{x}{|x|}
 *
 * Returns
 * =======
 *
 * ``fmod`` returns the floating-point remainder of :math:`x` divided by :math:`y`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when :math:`x` is infinite or
 * :math:`y` is zero.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | fmod(x,y)                | x                                                                                                                                                                                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | y                        | :math:`-Inf`             | :math:`<0`               | :math:`-0`               | :math:`+0`               | :math:`>0`               | :math:`+Inf`             | :math:`NaN`              |
 * +==========================+==========================+==========================+==========================+==========================+==========================+==========================+==========================+
 * | :math:`-Inf`             | :math:`qNaN`             | :math:`x`                                                                                                 | :math:`qNaN`             | :math:`qNaN`             |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`<0`               |                          | :math:`fmod(x, y)`       | :math:`x`                                           | :math:`fmod(x, y)`       |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`-0`               |                          | :math:`qNaN`                                                                                              |                          |                          |
 * +--------------------------+                          +                                                                                                           +                          +                          +
 * | :math:`+0`               |                          |                                                                                                           |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`>0`               |                          | :math:`fmod(x, y)`       | :math:`x`                                           | :math:`fmod(x, y)`       |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+                          +                          +
 * | :math:`+Inf`             |                          | :math:`x`                                                                                                 |                          |                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+                          +
 * | :math:`NaN`              | :math:`qNaN`                                                                                                                                                    |                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 *
 */
//

// static const double Zero[] = {0.0, -0.0,};
static Zero: [f64; 2] = [0.0, -0.0]; 

pub fn fmod ( 
x : f64 , 

y : f64 
) -> f64 { 
// int32_t n, hx, hy, hz, ix, iy, sx, i;
let mut n: i32;
let mut hx: i32;
let mut hy: i32;
let mut hz: i32;
let mut ix: i32;
let mut iy: i32;
let mut sx: i32;
let mut i: i32; 

let lx : uint32_t = Default :: default ( ) ;
let ly : uint32_t = Default :: default ( ) ;
let lz : uint32_t = Default :: default ( ) ;


loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

ew_u . parts 
. msw 
;



( 
lx 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



loop { 
let mut ew_u : ieee_double_shape_type = Default :: default ( ) ;


ew_u . value = 
( 
y 
) 
;



( 
hy 
) 
= 

ew_u . parts 
. msw 
;



( 
ly 
) 
= 

ew_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




sx 
= 

{'rust_function': 'hx ^= sx;'}
;

/* sign of x */

// hx ^= sx;
break 
/* |x| */

hy &= 
0x7fffffff 
;

/* |y| */
/* purge off exception values */

if 

hx 
>= 
0x7ff00000 
|| 
hy 
>= 
0x7ff00000 

{ /* x or y is +-Inf/NaN */

if 

hx == 0x7ff00000 
&& 
lx == 0 

{ /* x is +-Inf */


__raise_invalid ( ) 

}



else if 

__builtin_isnan ( x ) 
|| 
__builtin_isnan ( y ) 

{ /* x or y is NaN */

return x + y ;

}
fn main() {
    // The original C code seems to be incomplete or malformed.
    // Please provide the complete C code for accurate translation.
}else { /* No action required */

// }
break 
}


}



else if 

( 
hy | ly 
) 
== 
0 

{ /* y is +-0 */


__raise_invalid ( ) 

}
fn main() {
    // The original C code seems to be incomplete or malformed.
    // Please provide the complete C code for accurate translation.
}else { /* No action required */

// }
break 

if 
hx 
<= 
hy 
{ 
if 

( 
hx 
< 
hy 
) 
|| 
( 
lx 
< 
ly 
) 

{ 
return x ;

/* |x|<|y| return x */
}



if 
lx == ly 
{ 

Zero [ 


sx 
as uint32_t 
>> 
31 

] 

/* |x|=|y| return x*0*/
}


}


/* determine ix = ilogb(x) */

if 
hx < 0x00100000 
{ /* subnormal x */

if 
hx == 0 
{ 

{ 
ix = -1043 
;

i = lx 
}


;
while 
i 
> 
i <<= 1;

// i <<= 1
break 
;
}


}



else { 

{ 
ix = -1022 
;


i 
= 
( 

hx 
<< 
11 

) 

}


;
while 
i 
> 
0 
{ 
ix -= 1 ;
i <<= 1;break 
;
}


}


}



else { 

ix 
= 

( 

hx 
>> 
20 

) 
- 
1023 

;

}


/* determine iy = ilogb(y) */

if 
hy < 0x00100000 
{ /* subnormal y */

if 
hy == 0 
{ 

{ 
iy = -1043 
;

i = ly 
}


;
while 
i 
> 
0 
{ 
iy -= 1 ;


// i <<= 1
i <<= 1; 
;
}


}



else { 

{ 
iy = -1022 
;


i 
= 
( 

hy 
<< 
11 

) 

}


;
while 
i 
> 
0 
{ 
iy -= 1 ;


// i <<= 1
i <<= 1; 
;
}


}


}



else { 

iy 
= 

( 

hy 
>> 
20 

) 
- 
1023 

;

}


/* set up {hx,lx}, {hy,ly} and align y to x */

if 
ix 
>= 
-1022 
{ 

hx 
= 

0x00100000 
| 
( 

0x000fffff 
& 
hx 

) 

;

}



else { /* subnormal x, shift x to normal */

n = -1022 - ix ;


if 
n 
<= 
31 
{ 

hx 
= 

( 
hx << n 
) 
| 
( 

lx 
>> 
( 
32 - n 
) 

) 

;


lx <<= 
n 
;

}



else { 

hx 
= 

lx 
<< 
( 
n - 32 
) 

;


lx = 0 ;

}


}



if 
iy 
>= 
-1022 
{ 

hy 
= 

0x00100000 
| 
( 

0x000fffff 
& 
hy 

) 

;

}



else { /* subnormal y, shift y to normal */

n = -1022 - iy ;


if 
n 
<= 
31 
{ 

hy 
= 

( 
hy << n 
) 
| 
( 

ly 
>> 
( 
32 - n 
) 

) 

;


ly <<= 
n 
;

}



else { 

hy 
= 

ly 
<< 
( 
n - 32 
) 

;


ly = 0 ;

}


}


/* fix point fmod */

n = ix - iy ;


while 
( 

translate_bpc_vmm ! ( n ) 
> 
0 

) 
{ 
hz = hx - hy ;


lz = lx - ly ;


if 
lx 
< 
ly 
{ 
hz -= 1 ;

}



if 
hz < 0 
{ 

hx 
= 

hx + hx 
+ 
( 

lx 
>> 
31 

) 

;


lx = lx + lx ;

}



else { 
if 

( 
hz | lz 
) 
== 
0 

{ /* return sign(x)*0 */


Zero [ 


sx 
as uint32_t 
>> 
31 

] 

}




hx 
= 

hz + hz 
+ 
( 

lz 
>> 
31 

) 

;


lx = lz + lz ;

}


}



hz = hx - hy ;


lz = lx - ly ;


if 
lx 
< 
ly 
{ 
hz -= 1 ;

}



if 
hz 
>= 
0 
{ 
hx = hz ;


lx = lz ;

}


/* convert back to floating value and restore the sign */

if 

( 
hx | lx 
) 
== 
0 

{ /* return sign(x)*0 */


Zero [ 


sx 
as uint32_t 
>> 
31 

] 

}



while hx < 0x00100000 { /* normalize x */


hx 
= 

hx + hx 
+ 
( 

lx 
>> 
31 

) 

;


lx = lx + lx ;


iy -= 1 ;

}



if 
iy 
>= 
-1022 
{ /* normalize output */


hx 
= 
( 

( 
hx - 0x00100000 
) 
| 
( 

( 
iy + 1023 
) 
<< 
20 

) 

) 
;


loop { 
let mut iw_u : ieee_double_shape_type = Default :: default ( ) ;




iw_u . parts 
. msw 
= 
( 
hx | sx 
) 
;




iw_u . parts 
. lsw 
= 
( 
lx 
) 
;



( 
x 
) 
= 
iw_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


}



else { /* subnormal output */

n = -1022 - iy ;


if 
n 
<= 
20 
{ 

lx 
= 

( 
lx >> n 
) 
| 
( 


hx 
as uint32_t 
<< 
( 
32 - n 
) 

) 

;


hx >>= 
n 
;

}



else if 
n 
<= 
31 
{ 

lx 
= 

( 

hx 
<< 
( 
32 - n 
) 

) 
| 
( 
lx >> n 
) 

;


hx = sx ;

}



else { 

lx 
= 

hx 
>> 
( 
n - 32 
) 

;


hx = sx ;

}



loop { 
let mut iw_u : ieee_double_shape_type = Default :: default ( ) ;




iw_u . parts 
. msw 
= 
( 
hx | sx 
) 
;




iw_u . parts 
. lsw 
= 
( 
lx 
) 
;



( 
x 
) 
= 
iw_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}






return x ;

/* exact output */






