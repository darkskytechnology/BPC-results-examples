#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexact;
use crate::libm::common::tools_h::__raise_invalid;
use crate::libm::include::math_h::sqrt;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the arc cosine of :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float acosf(float x);
 *     double acos(double x);
 *     long double acosl(long double x);
 *
 * Description
 * ===========
 *
 * ``acos`` computes the inverse cosine (*arc cosine*) of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    acos(x) \approx cos^{-1}(x)
 *
 * Returns
 * =======
 *
 * ``acos`` returns value in radians, in the range :math:`[0, \pi]`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when the input value is not in the
 * interval :math:`[-1, 1]`.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+--------------+---------------------+--------------+--------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<-1`  | :math:`\in [-1,+1[` | :math:`+1`   | :math:`>+1`  | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+==============+=====================+==============+==============+==============+==============+
 * | **acos(x)**         | :math:`qNaN` | :math:`qNaN` | :math:`cos^{-1} x`  | :math:`+0`   | :math:`qNaN` | :math:`qNaN` | :math:`qNaN` |
 * +---------------------+--------------+--------------+---------------------+--------------+--------------+--------------+--------------+
 *
 */
//

// static const double
// one = 1.00000000000000000000e+00, /* 0x3FF00000, 0x00000000 */
// pi = 3.14159265358979311600e+00, /* 0x400921FB, 0x54442D18 */
// pio2_hi = 1.57079632679489655800e+00, /* 0x3FF921FB, 0x54442D18 */
// pio2_lo = 6.12323399573676603587e-17, /* 0x3C91A626, 0x33145C07 */
// pS0 = 1.66666666666666657415e-01, /* 0x3FC55555, 0x55555555 */
// pS1 = -3.25565818622400915405e-01, /* 0xBFD4D612, 0x03EB6F7D */
// pS2 = 2.01212532134862925881e-01, /* 0x3FC9C155, 0x0E884455 */
// pS3 = -4.00555345006794114027e-02, /* 0xBFA48228, 0xB5688F3B */
// pS4 = 7.91534994289814532176e-04, /* 0x3F49EFE0, 0x7501B288 */
// pS5 = 3.47933107596021167570e-05, /* 0x3F023DE1, 0x0DFDF709 */
// qS1 = -2.40339491173441421878e+00, /* 0xC0033A27, 0x1C8A2D4B */
// qS2 = 2.02094576023350569471e+00, /* 0x40002AE5, 0x9C598AC8 */
// qS3 = -6.88283971605453293030e-01, /* 0xBFE6066C, 0x1B8D0159 */
// qS4 = 7.70381505559019352791e-02;
static ONE: f64 = 1.00000000000000000000e+00; // 0x3FF00000, 0x00000000
static PI: f64 = 3.14159265358979311600e+00; // 0x400921FB, 0x54442D18
static PIO2_HI: f64 = 1.57079632679489655800e+00; // 0x3FF921FB, 0x54442D18
static PIO2_LO: f64 = 6.12323399573676603587e-17; // 0x3C91A626, 0x33145C07
static PS0: f64 = 1.66666666666666657415e-01; // 0x3FC55555, 0x55555555
let mut z: f64;
let mut p: f64;
let mut q: f64;
let mut r: f64;
let mut w: f64;
let mut s: f64;
let mut c: f64;
let mut df: f64;static PS4: f64 = 7.91534994289814532176e-04; // 0x3F49EFE0, 0x7501B288
static PS5: f64 = 3.47933107596021167570e-05; // 0x3F023DE1, 0x0DFDF709
static QS1: f64 = -2.40339491173441421878e+00; // 0xC0033A27, 0x1C8A2D4B
static QS2: f64 = 2.02094576023350569471e+00; // 0x40002AE5, 0x9C598AC8
static QS3: f64 = -6.88283971605453293030e-01; // 0xBFE6066C, 0x1B8D0159
// Note: The original code is incomplete, and the last constant is not fully defined. 
/* 0x3FB3B8C5, 0xB12E9282 */

pub fn acos ( 
x : f64 
) -> f64 { 
// double z, p, q, r, w, s, c, df;
break 

let hx : int32_t = Default :: default ( ) ;
let ix : int32_t = Default :: default ( ) ;


loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
x 
) 
;



( 
hx 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




ix 
= 

hx 
& 
0x7fffffff 

;


if 
ix 
>= 
0x3ff00000 
{ /* |x| >= 1 */

let lx : u32 ;


loop { 
let mut gl_u : ieee_double_shape_type = Default :: default ( ) ;


gl_u . value = 
( 
x 
) 
;



( 
lx 
) 
= 

gl_u . parts 
. lsw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}



if 

( 

( 
ix - 0x3ff00000 
) 
| 
lx 

) 
== 
0 

{ /* |x|==1 */

if 
hx 
> 
0 
{ 
return 0.0 ;

/* acos(1) = 0  */
}



else { 

__raise_inexact ( pi ) 

/* acos(-1)= pi */
}


}



if 
__builtin_isnan ( x ) 
{ 
return x + x ;

}




__raise_invalid ( ) 

/* acos(|x|>1) is NaN */
}



if 
ix < 0x3fe00000 
{ /* |x| < 0.5 */

if 
ix 
<= 
0x3c600000 
{ 

__raise_inexact ( pio2_hi ) 

/*if|x|<2**-57*/
}



z = x * x ;



p 
= 

z 
* 
( 

pS0 
+ 

z 
* 
( 

pS1 
+ 

z 
* 
( 

pS2 
+ 

z 
* 
( 

pS3 
+ 

z 
* 
( 

pS4 
+ 
z * pS5 

) 


) 


) 


) 


) 

;



q 
= 

one 
+ 

z 
* 
( 

qS1 
+ 

z 
* 
( 

qS2 
+ 

z 
* 
( 

qS3 
+ 
z * qS4 

) 


) 


) 


;


r = p / q ;




pio2_hi 
- 
( 

x 
- 
( 

pio2_lo 
- 
x * r 

) 

) 


}



else if 
hx < 0 
{ /* x < -0.5 */


z 
= 

( 
one + x 
) 
* 
0.5 

;



p 
= 

z 
* 
( 

pS0 
+ 

z 
* 
( 

pS1 
+ 

z 
* 
( 

pS2 
+ 

z 
* 
( 

pS3 
+ 

z 
* 
( 

pS4 
+ 
z * pS5 

) 


) 


) 


) 


) 

;



q 
= 

one 
+ 

z 
* 
( 

qS1 
+ 

z 
* 
( 

qS2 
+ 

z 
* 
( 

qS3 
+ 
z * qS4 

) 


) 


) 


;


s = z . sqrt ( ) ;


r = p / q ;



w 
= 

r * s 
- 
pio2_lo 

;




pi 
- 

2.0 
* 
( 
s + w 
) 



}



else { /* x > 0.5 */


z 
= 

( 
one - x 
) 
* 
0.5 

;


s = z . sqrt ( ) ;


df = s ;


loop { 
let mut sl_u : ieee_double_shape_type = Default :: default ( ) ;


sl_u . value = 
( 
df 
) 
;




sl_u . parts 
. lsw 
= 
( 
0 
) 
;



( 
df 
) 
= 
sl_u . value 
;

if ( 
0 
== 
0 
) == false { break ;
}

}




c 
= 

( 

z 
- 
df * df 

) 
/ 
( 
s + df 
) 

;



p 
= 

z 
* 
( 

pS0 
+ 

z 
* 
( 

pS1 
+ 

z 
* 
( 

pS2 
+ 

z 
* 
( 

pS3 
+ 

z 
* 
( 

pS4 
+ 
z * pS5 

) 


) 


) 


) 


) 

;



q 
= 

one 
+ 

z 
* 
( 

qS1 
+ 

z 
* 
( 

qS2 
+ 

z 
* 
( 

qS3 
+ 
z * qS4 

) 


) 


) 


;


r = p / q ;



w 
= 

r * s 
+ 
c 

;




2.0 
* 
( 
df + w 
) 


}


}


