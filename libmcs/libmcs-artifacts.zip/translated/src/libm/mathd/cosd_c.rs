#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexactf;
use crate::libm::common::tools_h::__raise_invalid;
use crate::libm::mathd::internal::trigd_c::__cos;
use crate::libm::mathd::internal::trigd_c::__rem_pio2;
use crate::libm::mathd::internal::trigd_c::__sin;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/* 
 *
 * This family of functions implements the cosine of :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float cosf(float x);
 *     double cos(double x);
 *     long double cosl(long double x);
 *
 * Description
 * ===========
 *
 * ``cos`` computes the cosine of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    cos(x) \approx cos(x)
 *
 * Returns
 * =======
 *
 * ``cos`` returns the cosine of the input value, in the range :math:`[-1, 1]`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``invalid operation`` exception when the input value is infinite.
 *
 * Output map
 * ==========
 *
 * +---------------------+----------------+----------------+----------------+----------------+----------------+----------------+----------------+
 * | **x**               | :math:`-Inf`   | :math:`<0`     | :math:`-0`     | :math:`+0`     | :math:`>0`     | :math:`+Inf`   | :math:`NaN`    |
 * +=====================+================+================+================+================+================+================+================+
 * | **cos(x)**          | :math:`qNaN`   | :math:`cos(x)` | :math:`1`                       | :math:`cos(x)` | :math:`qNaN`   | :math:`qNaN`   |
 * +---------------------+----------------+----------------+----------------+----------------+----------------+----------------+----------------+
 *
 */
//

pub fn cos ( 
x : f64 
) -> f64 { 
// double y[2], z = 0.0;
let mut y: [f64; 2] = [0.0, 0.0];
let mut z: f64 = 0.0; 

let n : int32_t = Default :: default ( ) ;
let ix : int32_t = Default :: default ( ) ;

/* High word of x. */

loop { 
let mut gh_u : ieee_double_shape_type = Default :: default ( ) ;


gh_u . value = 
( 
x 
) 
;



( 
ix 
) 
= 

gh_u . parts 
. msw 
;

if ( 
0 
== 
0 
) == false { break ;
}

}


/* |x| ~< pi/4 */

ix &= 
0x7fffffff 
;


if 
ix 
<= 
0x3fe921fb 
{ 
if 
ix < 0x3e46a09e 
{ /* if x < 2**-27 * sqrt(2) */

if 
x == 0.0 
{ /* return 1 inexact except 0 */

return 1.0 ;

}



else { 

__raise_inexactf ( 1.0 ) 

}


}




__cos ( 
x , 

z 
) 

}


/* cos(Inf or NaN) is NaN */

else if 
ix 
>= 
0x7ff00000 
{ 
if 
__builtin_isnan ( x ) 
{ 
return x + x ;

}



else { 

__raise_invalid ( ) 

}


}


/* argument reduction needed */

else { 
n = __rem_pio2 ( 
x , 

y 
) ;


match 

n 
& 
3 

{ 
0 => { 

__cos ( 
y [ 0 ] 

, 

y [ 1 ] 
) 

}



-__sin(y[0], y[1], 1)break 

}



2 => { 

// -__cos(y[0], y[1])
-__cos(y[0], y[1]) 

}


_ => { 

__sin ( 
y [ 0 ] 

, 

y [ 1 ] 

, 

1 
) 

}

}


}





