#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: RedHat */
/* Copyright (C) 2002 by  Red Hat, Incorporated. All rights reserved. */
/*
 *
 * This family of functions implements the positive difference value of
 * :math:`x` subtracted by :math:`y`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float fdimf(float x, float y);
 *     double fdim(double x, double y);
 *     long double fdiml(long double x, long double y);
 *
 * Description
 * ===========
 *
 * ``fdim`` computes the positive difference value of :math:`x` subtracted by
 * :math:`y`.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    fdim(x, y) \approx \left\{\begin{array}{ll} x - y, & x > y \\ 0, & otherwise \end{array}\right.
 *
 * Returns
 * =======
 *
 * ``fdim`` returns the positive difference value of :math:`x` subtracted by
 * :math:`y`.
 *
 * Exceptions
 * ==========
 *
 * Raise ``overflow`` exception when the result overflows.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | fdim(x,y)                | x                                                                                                                                                                                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | y                        | :math:`-Inf`             | :math:`<0`               | :math:`-0`               | :math:`+0`               | :math:`>0`               | :math:`+Inf`             | :math:`NaN`              |
 * +==========================+==========================+==========================+==========================+==========================+==========================+==========================+==========================+
 * | :math:`-Inf`             | :math:`+0`               | :math:`+Inf`                                                                                                                         | :math:`qNaN`             |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 * | :math:`<0`               |                          | :math:`fdim(x, y)`       | :math:`x - y`                                       | :math:`x - y`            | :math:`+Inf`             |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+                          +                          +                          +
 * | :math:`-0`               |                          | :math:`+0`               | :math:`+0`                                          |                          |                          |                          |
 * +--------------------------+                          +                          +                                                     +                          +                          +                          +
 * | :math:`+0`               |                          |                          |                                                     |                          |                          |                          |
 * +--------------------------+                          +                          +                                                     +--------------------------+                          +                          +
 * | :math:`>0`               |                          |                          |                                                     | :math:`fdim(x, y)`       |                          |                          |
 * +--------------------------+                          +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+                          +
 * | :math:`+Inf`             |                          | :math:`+0`                                                                                                                           |                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+                          +
 * | :math:`NaN`              | :math:`qNaN`                                                                                                                                                    |                          |
 * +--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+--------------------------+
 *
 */
//

pub fn fdim(x: f64, y: f64) -> f64 {
    if __builtin_isnan(x) || __builtin_isnan(y) {
        return x * y;
    }

    if x > y {
        x - y
    } else {
        0.0
    }
}
