#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::common::tools_h::__raise_inexact;
use crate::libm::common::tools_h::__raise_overflow;
use crate::libm::include::math_h::exp;
use crate::libm::include::math_h::expm1;
use crate::libm::include::math_h::fabs;
use crate::libm::mathd::acosd_c::one;
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
 *
 * This family of functions implements the hyperbolic sine of :math:`x`.
 *
 * Synopsis
 * ========
 *
 * .. code-block:: c
 *
 *     #include <math.h>
 *     float sinhf(float x);
 *     double sinh(double x);
 *     long double sinhl(long double x);
 *
 * Description
 * ===========
 *
 * ``sinh`` computes the hyperbolic sine of the input value.
 *
 * Mathematical Function
 * =====================
 *
 * .. math::
 *
 *    sinh(x) \approx sinh(x) = \frac{e^x-e^{-x}}{2}
 *
 * Returns
 * =======
 *
 * ``sinh`` returns the hyperbolic sine.
 *
 * Exceptions
 * ==========
 *
 * Raise ``overflow`` exception when the magnitude of the input value is too
 * large.
 *
 * .. May raise ``underflow`` exception.
 *
 * Output map
 * ==========
 *
 * +---------------------+--------------+-----------------+--------------+--------------+-----------------+--------------+--------------+
 * | **x**               | :math:`-Inf` | :math:`<0`      | :math:`-0`   | :math:`+0`   | :math:`>0`      | :math:`+Inf` | :math:`NaN`  |
 * +=====================+==============+=================+==============+==============+=================+==============+==============+
 * | **sinh(x)**         | :math:`-Inf` | :math:`sinh(x)` | :math:`x`                   | :math:`sinh(x)` | :math:`+Inf` | :math:`qNaN` |
 * +---------------------+--------------+-----------------+--------------+--------------+-----------------+--------------+--------------+
 *
 */
//

const one: f64 = 1.0;

pub fn sinh(x: f64) -> f64 {
    let t: f64 = Default::default();
    let w: f64 = Default::default();
    let h: f64 = Default::default();

    let ix: int32_t = Default::default();
    let jx: int32_t = Default::default();

    let lx: u32;

    /* High word of |x|. */

    loop {
        let mut gh_u: ieee_double_shape_type = Default::default();

        gh_u.value = (x);

        (jx) = gh_u.parts.msw;

        if (0 == 0) == false {
            break;
        }
    }

    ix = jx & 0x7fffffff;

    /* x is INF or NaN */

    if ix >= 0x7ff00000 {
        return x + x;
    }

    h = 0.5;

    if jx < 0 {
        h = -h;
    }

    /* |x| in [0,22], return sign(x)*0.5*(E+E/(E+1))) */

    if ix < 0x40360000 {
        /* |x|<22 */

        if ix < 0x3e300000 {
            /* |x|<2**-28 */

            if x == 0.0 {
                /* return x inexact except 0 */

                return x;
            } else {
                __raise_inexact(x)
            }
        }

        t = expm1(x.abs());

        if ix < 0x3ff00000 {
            h * (2.0 * t - t * t / (t + one))
        }

        h * (t + t / (t + one))
    }

    /* |x| in [22, log(maxdouble)] return 0.5*exp(|x|) */

    if ix < 0x40862E42 {
        h * exp(x.abs())
    }

    /* |x| in [log(maxdouble), overflowthresold] */

    loop {
        let mut gl_u: ieee_double_shape_type = Default::default();

        gl_u.value = (x);

        (lx) = gl_u.parts.lsw;

        if (0 == 0) == false {
            break;
        }
    }

    if ix < 0x408633CE || (ix == 0x408633ce && lx <= 0x8fb9f87d as uint32_t) {
        w = exp(0.5 * x.abs());

        t = h * w;

        return t * w;
    }

    /* |x| > overflowthresold, sinh(x) overflow */

    __raise_overflow(x)
}
