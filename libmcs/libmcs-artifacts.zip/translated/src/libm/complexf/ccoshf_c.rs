#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
use crate::libm::mathf::cosf_c::cosf;
use crate::libm::mathf::coshf_c::coshf;
use crate::libm::mathf::sinf_c::sinf;
use crate::libm::mathf::sinhf_c::sinhf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex ccoshf(float _Complex z)
// {
//
//
//
//
//     float _Complex w;
//     float x, y;
//
//     x = crealf(z);
//     y = cimagf(z);
//     /* w = coshf(x) * cosf(y) + (sinhf(x) * sinf(y)) * I; */
//     w = __builtin_complex ((float) (coshf(x) * cosf(y)), (float) (sinhf(x) * sinf(y)));
//     return w;
// }
fn ccoshf(z: num_complex::Complex32) -> num_complex::Complex32 {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= 1.0; // __volatile_onef is assumed to be 1.0 in Rust
    }

    let x = z.re;
    let y = z.im;
    // w = coshf(x) * cosf(y) + (sinhf(x) * sinf(y)) * I;
    let w = num_complex::Complex32::new(x.cosh() * y.cos(), x.sinh() * y.sin());
    w
}
