#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::casinf_c::casinf;
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex casinhf(float _Complex z)
// {
//
//
//
//
//     float _Complex w;
//     float _Complex tmp;
//
//     /* w = -1.0f * I * casinf(z * I); */
//     tmp = __builtin_complex ((float) (-cimagf(z)), (float) (crealf(z)));
//     tmp = casinf(tmp);
//     w = __builtin_complex ((float) (cimagf(tmp)), (float) (-crealf(tmp)));
//     return w;
// }
fn casinhf(z: num_complex::Complex32) -> num_complex::Complex32 {
    #[cfg(__LIBMCS_FPU_DAZ)]
    let z = z * num_complex::Complex32::new(1.0, 0.0);

    let mut w: num_complex::Complex32;
    let mut tmp: num_complex::Complex32;

    // w = -1.0f * I * casinf(z * I);
    tmp = num_complex::Complex32::new(-z.im, z.re);
    tmp = tmp.asin();
    w = num_complex::Complex32::new(tmp.im, -tmp.re);
    w
}
