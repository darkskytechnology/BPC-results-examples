#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: PublicDomain */
/* Written by Matthias Drochner <drochner@NetBSD.org>. */

pub fn crealf ( 
_Complex : f32 

z 
) -> f32 { 
let w : float_complex = 
// { .z = z }
{ z } 
;



( 
REAL_PART ( w ) 
) 

}


