#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cabsf_c::cabsf;
use crate::libm::complexf::cargf_c::cargf;
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
use crate::libm::mathf::cosf_c::cosf;
use crate::libm::mathf::expf_c::expf;
use crate::libm::mathf::logf_c::logf;
use crate::libm::mathf::powf_c::powf;
use crate::libm::mathf::sinf_c::sinf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex cpowf(float _Complex x, float _Complex y)
// {
//
//
//
//
//
//     float _Complex w;
//     float realz, imagz, result, theta, absx, argx;
//
//     realz = crealf(y);
//     imagz = cimagf(y);
//     absx = cabsf(x);
//
//     if (absx == 0.0f) {
//         return __builtin_complex ((double) (0.0f), (double) (0.0f));
//     }
//
//     argx = cargf(x);
//     result = powf(absx, realz);
//     theta = realz * argx;
//
//     if (imagz != 0.0f) {
//         result = result * expf(-imagz * argx);
//         theta = theta + imagz * logf(absx);
//     }
//
//     /*w = result * cosf(theta) + (result * sinf(theta)) * I; */
//     w = __builtin_complex ((float) (result * cosf(theta)), (float) (result * sinf(theta)));
//     return w;
// }
fn cpowf(x: num_complex::Complex32, y: num_complex::Complex32) -> num_complex::Complex32 {
    #[cfg(__LIBMCS_FPU_DAZ)]
    {
        x *= __volatile_onef;
        y *= __volatile_onef;
    }

    let mut w;
    let realz = y.re;
    let imagz = y.im;
    let absx = x.norm();

    if absx == 0.0 {
        return num_complex::Complex32::new(0.0, 0.0);
    }

    let argx = x.arg();
    let mut result = absx.powf(realz);
    let mut theta = realz * argx;

    if imagz != 0.0 {
        result *= (-imagz * argx).exp();
        theta += imagz * absx.ln();
    }

    w = num_complex::Complex32::new(result * theta.cos(), result * theta.sin());
    w
}
