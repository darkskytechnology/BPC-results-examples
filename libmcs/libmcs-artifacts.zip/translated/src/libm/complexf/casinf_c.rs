#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::clogf_c::clogf;
use crate::libm::complexf::crealf_c::crealf;
use crate::libm::complexf::csqrtf_c::csqrtf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex casinf(float _Complex z)
// {
//
//
//
//
//     float _Complex w;
//     float _Complex ct, zz, z2;
//     float x, y;
//
//     x = crealf(z);
//     y = cimagf(z);
//
//     ct = __builtin_complex ((float) (-y), (float) (x));
//     /* zz = (x - y) * (x + y) + (2.0f * x * y) * I; */
//     zz = __builtin_complex ((float) ((x - y) * (x + y)), (float) (2.0f * x * y));
//
//     /* zz = 1.0f - crealf(zz) - cimagf(zz) * I; */
//     zz = __builtin_complex ((float) (1.0f - crealf(zz)), (float) (-cimagf(zz)));
//     z2 = csqrtf(zz);
//
//     zz = ct + z2;
//     zz = clogf(zz);
//     /* w = zz * (-1.0f * I); */
//     w = __builtin_complex ((float) (cimagf(zz)), (float) (-crealf(zz)));
//     return w;
// }
fn casinf(z: num_complex::Complex32) -> num_complex::Complex32 {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= num_complex::Complex32::new(1.0, 0.0);
    }

    let mut w: num_complex::Complex32;
    let mut ct: num_complex::Complex32;
    let mut zz: num_complex::Complex32;
    let mut z2: num_complex::Complex32;
    let x: f32 = z.re;
    let y: f32 = z.im;

    ct = num_complex::Complex32::new(-y, x);
    zz = num_complex::Complex32::new((x - y) * (x + y), 2.0 * x * y);

    zz = num_complex::Complex32::new(1.0 - zz.re, -zz.im);
    z2 = zz.sqrt();

    zz = ct + z2;
    zz = zz.ln();
    w = num_complex::Complex32::new(zz.im, -zz.re);
    w
}
