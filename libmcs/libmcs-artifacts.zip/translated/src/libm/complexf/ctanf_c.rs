#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
use crate::libm::complexf::internal::ctrigf_c::__redupif;
use crate::libm::mathf::cosf_c::cosf;
use crate::libm::mathf::coshf_c::coshf;
use crate::libm::mathf::fabsf_c::fabsf;
use crate::libm::mathf::sinf_c::sinf;
use crate::libm::mathf::sinhf_c::sinhf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/* Taylor series expansion for cosh(2y) - cos(2x) */

// static inline float __ctansf(float _Complex z)
// {
//     float f, x, x2, y, y2, rn, t, d;
// 
//     x = fabsf(2.0f * crealf(z));
//     y = fabsf(2.0f * cimagf(z));
// 
//     x = __redupif(x);
// 
//     x = x * x;
//     y = y * y;
//     x2 = 1.0f;
//     y2 = 1.0f;
//     f = 1.0f;
//     rn = 0.0f;
//     d = 0.0f;
// 
//     do {
//         rn += 1.0f;
//         f *= rn;
//         rn += 1.0f;
//         f *= rn;
//         x2 *= x;
//         y2 *= y;
//         t = y2 + x2;
//         t /= f;
//         d += t;
// 
//         rn += 1.0f;
//         f *= rn;
//         rn += 1.0f;
//         f *= rn;
//         x2 *= x;
//         y2 *= y;
//         t = y2 - x2;
//         t /= f;
//         d += t;
//     } while (fabsf(t / d) > 3.0e-8);
// 
//     return d;
// }
fn __ctansf(z: std::num::Complex<f32>) -> f32 {
fn ctanf(z: std::num::Complex<f32>) -> std::num::Complex<f32> {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= __volatile_onef;
    }

    let mut w: std::num::Complex<f32>;
    let mut d: f32;

    d = (2.0 * z.re).cos() + (2.0 * z.im).cosh();

    if d.abs() < 0.25 {
        d = __ctansf(z);
    }

    if d == 0.0 {
        w = std::num::Complex::new(f32::INFINITY, f32::INFINITY);
        return w;
    }

    w = std::num::Complex::new((2.0 * z.re).sin() / d, (2.0 * z.im).sinh() / d);
    return w;
}        f *= rn;
        x2 *= x;
        y2 *= y;
        t = y2 + x2;
        t /= f;
        d += t;

        rn += 1.0;
        f *= rn;
        rn += 1.0;
        f *= rn;
        x2 *= x;
        y2 *= y;
        t = y2 - x2;
        t /= f;
        d += t;

        if (t / d).abs() <= MACHEPF {
            break;
        }
    }

    d
} 

// float _Complex ctanf(float _Complex z)
// {
// 
// 
// 
// 
//     float _Complex w;
//     float d;
// 
//     d = cosf(2.0f * crealf(z)) + coshf(2.0f * cimagf(z));
// 
//     if (fabsf(d) < 0.25f) {
//         d = __ctansf(z);
//     }
// 
//     if (d == 0.0f) {
//         w = __builtin_complex ((float) ((__builtin_huge_valf ())), (float) ((__builtin_huge_valf ())));
//         return w;
//     }
// 
//     /* w = sinf(2.0f * crealf(z)) / d + (sinhf(2.0f * cimagf(z)) / d) * I; */
//     w = __builtin_complex ((float) (sinf(2.0f * crealf(z)) / d), (float) (sinhf(2.0f * cimagf(z)) / d));
//     return w;
// 
break 
