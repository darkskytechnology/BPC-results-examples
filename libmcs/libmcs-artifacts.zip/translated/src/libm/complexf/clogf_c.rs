#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cabsf_c::cabsf;
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
use crate::libm::mathf::atan2f_c::atan2f;
use crate::libm::mathf::logf_c::logf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex clogf(float _Complex z)
// {
//
//
//
//
//     float _Complex w;
//     float p, rr;
//
//     rr = cabsf(z);
//     p = logf(rr);
//     rr = atan2f(cimagf(z), crealf(z));
//     /* w = p + rr * I; */
//     w = __builtin_complex ((float) (p), (float) (rr));
//     return w;
// }
fn clogf(z: std::num::Complex32) -> std::num::Complex32 {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= __volatile_onef;
    }

    let mut w: std::num::Complex32;
    let p: f32;
    let rr: f32;

    rr = z.norm();
    p = rr.ln();
    rr = z.im.atan2(z.re);
    // w = p + rr * I;
    w = std::num::Complex32::new(p, rr);
    w
}
