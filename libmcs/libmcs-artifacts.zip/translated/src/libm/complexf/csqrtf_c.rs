#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cabsf_c::cabsf;
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
use crate::libm::machine::sparc_v8::mathf::sqrtf_c::sqrtf;
use crate::libm::mathf::fabsf_c::fabsf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex csqrtf(float _Complex z)
// {
//
//
//
//
//     float _Complex w;
//     float x, y, r, t, scale;
//
//     x = crealf(z);
//     y = cimagf(z);
//
//     if (y == 0.0f) {
//         if (x < 0.0f) {
//             w = __builtin_complex ((float) (0.0f), (float) (sqrtf(-x)));
//         } else if (x == 0.0f) {
//             w = __builtin_complex ((float) (0.0f), (float) (y));
//         } else {
//             w = __builtin_complex ((float) (sqrtf(x)), (float) (y));
//         }
//
//         return w;
//     }
//
//     if (x == 0.0f) {
//         r = fabsf(y);
//         r = sqrtf(0.5f * r);
//
//         if (y > 0) {
//             w = __builtin_complex ((float) (r), (float) (r));
//         } else {
//             w = __builtin_complex ((float) (r), (float) (-r));
//         }
//
//         return w;
//     }
//
//     /* Rescale to avoid internal overflow or underflow.  */
//     if ((fabsf(x) > 4.0f) || (fabsf(y) > 4.0f)) {
//         x *= 0.25f;
//         y *= 0.25f;
//         scale = 2.0f;
//     } else {
//         x *= 6.7108864e7f; /* 2^26 */
//         y *= 6.7108864e7f;
//         scale = 1.220703125e-4f; /* 2^-13 */
//     }
//
//     w = __builtin_complex ((float) (x), (float) (y));
//     r = cabsf(w);
//
//     if (x > 0) {
//         t = sqrtf(0.5f * r + 0.5f * x);
//         r = scale * fabsf((0.5f * y) / t);
//         t *= scale;
//     } else {
//         r = sqrtf(0.5f * r - 0.5f * x);
//         t = scale * fabsf((0.5f * y) / r);
//         r *= scale;
//     }
//
//     if (y < 0) {
//         w = __builtin_complex ((float) (t), (float) (-r));
//     } else {
//         w = __builtin_complex ((float) (t), (float) (r));
//     }
//
//     return w;
// }
fn csqrtf(z: std::num::Complex<f32>) -> std::num::Complex<f32> {
    let mut z = z;
    #[cfg(__LIBMCS_FPU_DAZ)]
    {
        z *= std::num::Complex::new(1.0, 0.0);
    }

    let mut w;
    let x = z.re;
    let y = z.im;

    if y == 0.0 {
        if x < 0.0 {
            w = std::num::Complex::new(0.0, (-x).sqrt());
        } else if x == 0.0 {
            w = std::num::Complex::new(0.0, y);
        } else {
            w = std::num::Complex::new(x.sqrt(), y);
        }

        return w;
    }

    if x == 0.0 {
        let mut r = y.abs();
        r = (0.5 * r).sqrt();

        if y > 0.0 {
            w = std::num::Complex::new(r, r);
        } else {
            w = std::num::Complex::new(r, -r);
        }

        return w;
    }

    let (x, y, scale) = if x.abs() > 4.0 || y.abs() > 4.0 {
        (x * 0.25, y * 0.25, 2.0)
    } else {
        (x * 6.7108864e7, y * 6.7108864e7, 1.220703125e-4)
    };

    w = std::num::Complex::new(x, y);
    let mut r = w.norm();

    let (t, r) = if x > 0.0 {
        let t = (0.5 * r + 0.5 * x).sqrt();
        let r = scale * (0.5 * y / t).abs();
        (t * scale, r)
    } else {
        let r = (0.5 * r - 0.5 * x).sqrt();
        let t = scale * (0.5 * y / r).abs();
        (t, r * scale)
    };

    if y < 0.0 {
        w = std::num::Complex::new(t, -r);
    } else {
        w = std::num::Complex::new(t, r);
    }

    w
}
