#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
use crate::libm::mathf::cosf_c::cosf;
use crate::libm::mathf::coshf_c::coshf;
use crate::libm::mathf::sinf_c::sinf;
use crate::libm::mathf::sinhf_c::sinhf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex ctanhf(float _Complex z)
// {
//
//
//
//
//     float _Complex w;
//     float x, y, d;
//
//     x = crealf(z);
//     y = cimagf(z);
//     d = coshf(2.0f * x) + cosf(2.0f * y);
//     /* w = sinhf(2.0f * x) / d  + (sinf(2.0f * y) / d) * I; */
//     w = __builtin_complex ((float) (sinhf(2.0f * x) / d), (float) (sinf(2.0f * y) / d));
//
//     return w;
// }
fn ctanhf(z: std::num::Complex<f32>) -> std::num::Complex<f32> {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= __volatile_onef;
    }

    let x = z.re;
    let y = z.im;
    let d = (2.0 * x).cosh() + (2.0 * y).cos();
    let w = std::num::Complex::new((2.0 * x).sinh() / d, (2.0 * y).sin() / d);

    w
}
