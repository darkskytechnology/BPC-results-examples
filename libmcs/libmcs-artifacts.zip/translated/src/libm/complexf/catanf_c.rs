#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
use crate::libm::complexf::internal::ctrigf_c::__redupif;
use crate::libm::mathf::atan2f_c::atan2f;
use crate::libm::mathf::logf_c::logf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex catanf(float _Complex z)
// {
//
//
//
//
//     float _Complex w;
//     float a, t, x, x2, y, tmp;
//
//     x = crealf(z);
//     y = cimagf(z);
//
//     if ((x == 0.0f) && (y > 1.0f)) {
//         goto ovrf;
//     }
//
//     x2 = x * x;
//     a = 1.0f - x2 - (y * y);
//
//     if (a == 0.0f) {
//         goto ovrf;
//     }
//
//     t = 0.5f * atan2f(2.0f * x, a);
//     tmp = __redupif(t);
//
//     t = y - 1.0f;
//     a = x2 + (t * t);
//
//     t = y + 1.0f;
//     a = (x2 + (t * t)) / a;
//     /* w = tmp + (0.25f * logf(a)) * I; */
//     w = __builtin_complex ((float) (tmp), (float) (0.25f * logf(a)));
//     return w;
//
// ovrf:
//     w = __builtin_complex ((float) ((__builtin_huge_valf ())), (float) ((__builtin_huge_valf ())));
//     return w;
// }
fn catanf(z: std::num::Complex<f32>) -> std::num::Complex<f32> {
    #[cfg(__LIBMCS_FPU_DAZ)]
    {
        z *= __volatile_onef;
    }

    let mut w;
    let a;
    let t;
    let x;
    let x2;
    let y;
    let tmp;

    x = z.re;
    y = z.im;

    if (x == 0.0f32) && (y > 1.0f32) {
        return std::num::Complex::new(f32::INFINITY, f32::INFINITY);
    }

    x2 = x * x;
    a = 1.0f32 - x2 - (y * y);

    if a == 0.0f32 {
        return std::num::Complex::new(f32::INFINITY, f32::INFINITY);
    }

    t = 0.5f32 * (2.0f32 * x).atan2(a);
    tmp = __redupif(t);

    t = y - 1.0f32;
    a = x2 + (t * t);

    t = y + 1.0f32;
    a = (x2 + (t * t)) / a;
    w = std::num::Complex::new(tmp, 0.25f32 * a.ln());
    return w;
}
