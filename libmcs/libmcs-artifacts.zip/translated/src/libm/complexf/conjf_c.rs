#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: PublicDomain */
/* Written by Matthias Drochner <drochner@NetBSD.org>. */

// float _Complex conjf(float _Complex z)
// {
//     float_complex w = { .z = z };
//
//     IMAG_PART(w) = -IMAG_PART(w);
//
//     return (w.z);
// }
fn conjf(z: num_complex::Complex32) -> num_complex::Complex32 {
    let mut w = z;
    w.im = -w.im;
    w
}
