#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexd::internal::ctrigd_c::DP1;
use crate::libm::complexd::internal::ctrigd_c::DP2;
use crate::libm::complexd::internal::ctrigd_c::DP3;
use crate::libm::mathf::coshf_c::coshf;
use crate::libm::mathf::expf_c::expf;
use crate::libm::mathf::fabsf_c::fabsf;
use crate::libm::mathf::internal::fpclassifyf_c::__fpclassifyf;
use crate::libm::mathf::sinhf_c::sinhf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */
/* calculate cosh and sinh */

pub fn __ccoshsinhf ( 
x : f32 , 

// float *c
let c: *mut f32; 

, 

// float *s
let s: *mut f32; 
) { 
let e : f32 = Default :: default ( ) ;
let ei : f32 = Default :: default ( ) ;


if 

x . abs ( ) 
<= 
0.5 

{ 


c 

= 
coshf ( x ) 
;




s 

= 
sinhf ( x ) 
;

}



else { 
e = expf ( x ) ;


if 

__fpclassifyf ( e ) 
!= 
2 

{ 
ei = 0.5 / e ;

}



else { 

ei 
= 
( 
__builtin_huge_valf ( ) 
) 
;

}



e = 0.5 * e ;




s 

= 
e - ei 
;




c 

= 
e + ei 
;

}


}


/* Program to subtract nearest integer multiple of PI */
/* extended precision value of PI: */

const DP1 : f32 = 3.140625 ;


const DP2 : f32 = 9.67502593994140625E-4 ;


const DP3 : f32 = 1.509957990978376432E-7 ;


pub fn __redupif ( 
x : f32 
) -> f32 { 
let t : f32 = Default :: default ( ) ;


let i : i64 = Default :: default ( ) ;



t 
= 

x 
/ 

3.14159265358979323846 
as f32 

;


if 
t 
>= 
0.0 
{ 
t += 0.5 ;

}



else { 
t -= 0.5 ;

}



i = t ;

/* the multiple */

t = i ;



t 
= 

( 

( 

x 
- 
t * DP1 

) 
- 
t * DP2 

) 
- 
t * DP3 

;


return t ;

}


