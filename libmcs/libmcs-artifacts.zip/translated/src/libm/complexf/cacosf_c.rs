#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::casinf_c::casinf;
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex cacosf(float _Complex z)
// {
//
//
//
//
//     float _Complex w;
//     float _Complex tmp0;
//     float tmp1;
//
//     tmp0 = casinf(z);
//     tmp1 = (float)1.57079632679489661923 - crealf(tmp0);
//     w = __builtin_complex ((float) (tmp1), (float) (-cimagf(tmp0)));
//
//     return w;
// }
fn cacosf(z: std::num::Complex<f32>) -> std::num::Complex<f32> {
    #[cfg(feature = "libmcs_fpu_daz")]
    {
        z *= __volatile_onef;
    }

    let tmp0 = casinf(z);
    let tmp1 = std::f32::consts::FRAC_PI_2 - tmp0.re;
    let w = std::num::Complex::new(tmp1, -tmp0.im);

    w
}
