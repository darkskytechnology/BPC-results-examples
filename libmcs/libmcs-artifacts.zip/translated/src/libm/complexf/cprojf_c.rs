#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::mathf::copysignf_c::copysignf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex cprojf(float _Complex z)
// {
//     float_complex w = { .z = z };
//
//     if (__builtin_isinf_sign (REAL_PART(w)) || __builtin_isinf_sign (IMAG_PART(w))) {
//         REAL_PART(w) = (__builtin_inff ());
//         IMAG_PART(w) = copysignf(0.0, cimagf(z));
//     }
//
//     return (w.z);
// }
fn cprojf(z: num_complex::Complex32) -> num_complex::Complex32 {
    let mut w = z;

    if w.re.is_infinite() || w.im.is_infinite() {
        w.re = f32::INFINITY;
        w.im = z.im.signum() * 0.0;
    }

    w
}
