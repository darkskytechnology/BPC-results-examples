#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
use crate::libm::mathf::cosf_c::cosf;
use crate::libm::mathf::expf_c::expf;
use crate::libm::mathf::sinf_c::sinf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex cexpf(float _Complex z)
// {
//
//
//
//
//     float _Complex w;
//     float r, x, y;
//
//     x = crealf(z);
//     y = cimagf(z);
//     r = expf(x);
//     /* w = r * cosf(y) + r * sinf(y) * I; */
//     w = __builtin_complex ((float) (r * cosf(y)), (float) (r * sinf(y)));
//     return w;
// }
fn cexpf(z: std::num::Complex<f32>) -> std::num::Complex<f32> {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= __volatile_onef;
    }

    let mut w: std::num::Complex<f32>;
    let r: f32;
    let x: f32 = z.re;
    let y: f32 = z.im;

    r = x.exp();
    // w = r * cosf(y) + r * sinf(y) * I;
    w = std::num::Complex::new(r * y.cos(), r * y.sin());
    w
}
