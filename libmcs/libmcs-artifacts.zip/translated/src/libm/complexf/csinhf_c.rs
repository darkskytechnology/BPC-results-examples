#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
use crate::libm::mathf::cosf_c::cosf;
use crate::libm::mathf::coshf_c::coshf;
use crate::libm::mathf::sinf_c::sinf;
use crate::libm::mathf::sinhf_c::sinhf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex csinhf(float _Complex z)
// {
//
//
//
//
//     float _Complex w;
//     float x, y;
//
//     x = crealf(z);
//     y = cimagf(z);
//     /* w = sinhf(x) * cosf(y) + (coshf(x) * sinf(y)) * I; */
//     w = __builtin_complex ((float) (sinhf(x) * cosf(y)), (float) (coshf(x) * sinf(y)));
//     return w;
// }
fn csinhf(z: std::num::Complex<f32>) -> std::num::Complex<f32> {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= 1.0;
    }

    let x = z.re;
    let y = z.im;
    let w = std::num::Complex::new(x.sinh() * y.cos(), x.cosh() * y.sin());
    w
}
