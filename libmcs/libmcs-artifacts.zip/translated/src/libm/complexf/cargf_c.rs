#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
use crate::libm::mathf::atan2f_c::atan2f;
// USE STATEMENTS END
/* SPDX-License-Identifier: PublicDomain */
/* Written by Matthias Drochner <drochner@NetBSD.org>. */

pub fn cargf ( 
_Complex : f32 

z 
) -> f32 { 

atan2f ( 
cimagf ( z ) 

, 

crealf ( z ) 
) 

}


