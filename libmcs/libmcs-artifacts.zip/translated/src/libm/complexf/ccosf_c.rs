#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::libm::complexf::cimagf_c::cimagf;
use crate::libm::complexf::crealf_c::crealf;
use crate::libm::complexf::internal::ctrigf_c::__ccoshsinhf;
use crate::libm::mathf::cosf_c::cosf;
use crate::libm::mathf::sinf_c::sinf;
// USE STATEMENTS END
/* SPDX-License-Identifier: NetBSD */

// float _Complex ccosf(float _Complex z)
// {
//
//
//
//
//     float _Complex w;
//     float ch, sh;
//
//     __ccoshsinhf(cimagf(z), &ch, &sh);
//     /* w = cosf(crealf(z)) * ch - (sinf(crealf(z)) * sh) * I; */
//     w = __builtin_complex ((float) (cosf(crealf(z)) * ch), (float) (-(sinf(crealf(z)) * sh)));
//     return w;
// }
fn ccosf(z: std::num::Complex<f32>) -> std::num::Complex<f32> {
    #[cfg(feature = "__LIBMCS_FPU_DAZ")]
    {
        z *= __volatile_onef;
    }

    let mut w: std::num::Complex<f32>;
    let (ch, sh): (f32, f32);

    __ccoshsinhf(z.im, &mut ch, &mut sh);
    // w = cosf(crealf(z)) * ch - (sinf(crealf(z)) * sh) * I;
    w = std::num::Complex::new(z.re.cos() * ch, -(z.re.sin() * sh));
    w
}
