#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: GTDGmbH */
/* Copyright 2020-2021 by GTD GmbH. */

pub fn feclearexcept(excepts: i32) -> i32 {
    return -1;
}

pub fn feraiseexcept(excepts: i32) -> i32 {
    return -1;
}

pub fn fegetexceptflag(
    flagp: Option<std::rc::Rc<std::cell::RefCell<fexcept_t>>>,

    excepts: i32,
) -> i32 {
    return -1;
}

pub fn fesetexceptflag(
    flagp: Option<std::rc::Rc<std::cell::RefCell<fexcept_t>>>,

    excepts: i32,
) -> i32 {
    return -1;
}

fn fegetround() -> impl std::process::Termination {
    let argv = std::env::args().collect::<Vec<_>>();
    let argc = argv.len();
    let retcode = move || -> u8 {
        return -1;

        return 0;
    }();
    return std::process::ExitCode::from(retcode);
}

pub fn fesetround(rdir: i32) -> i32 {
    return -1;
}

pub fn fegetenv(envp: Option<std::rc::Rc<std::cell::RefCell<fenv_t>>>) -> i32 {
    return -1;
}

pub fn fesetenv(envp: Option<std::rc::Rc<std::cell::RefCell<fenv_t>>>) -> i32 {
    return -1;
}

pub fn feholdexcept(envp: Option<std::rc::Rc<std::cell::RefCell<fenv_t>>>) -> i32 {
    return -1;
}

pub fn feupdateenv(envp: Option<std::rc::Rc<std::cell::RefCell<fenv_t>>>) -> i32 {
    return -1;
}

pub fn fetestexcept(excepts: i32) -> i32 {
    return -1;
}
