#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: GTDGmbH */
/* Copyright 2020-2021 by GTD GmbH. */

// const float __inff = 1.0f/0.0f;
const __inff: f32 = 1.0f32 / 0.0f32;

// const double __infd = 1.0/0.0;
const __infd: f64 = 1.0 / 0.0;
