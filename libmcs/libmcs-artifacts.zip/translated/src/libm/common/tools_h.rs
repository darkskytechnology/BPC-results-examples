#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* SPDX-License-Identifier: SunMicrosystems */
/* Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
/*
*
* This file contains a set of functions used by multiple procedures as
* internal functions. These procedures should not be accessed directly by a
* user. Note that all procedures are either macors or inline procedures.
*
* Synopsis
* ========
*
* .. code-block:: c
*
*     #include "tools.h"
*     EXTRACT_WORDS(ix0,ix1,d);                // this macro has no return value, the inputs are expected to be (int, int, double)
*     GET_HIGH_WORD(i,d);                      // this macro has no return value, the inputs are expected to be (int, double)
*     GET_LOW_WORD(i,d);                       // this macro has no return value, the inputs are expected to be (int, double)
*     INSERT_WORDS(d,ix0,ix1);                 // this macro has no return value, the inputs are expected to be (double, int, int)
*     SET_HIGH_WORD(d,v);                      // this macro has no return value, the inputs are expected to be (double, int)
*     SET_LOW_WORD(d,v);                       // this macro has no return value, the inputs are expected to be (double, int)
*     GET_FLOAT_WORD(i,d);                     // this macro has no return value, the inputs are expected to be (int, float)
*     SET_FLOAT_WORD(d,i);                     // this macro has no return value, the inputs are expected to be (float, int)
*     SAFE_RIGHT_SHIFT(op,amt);                // this macros return value has the same type as input `op`, the inputs are expected to be integer types
*     double __forced_calculation(double x);
*     float __forced_calculationf(float x);
*     double __raise_invalid();
*     float __raise_invalidf();
*     double __raise_div_by_zero(double x);
*     float __raise_div_by_zerof(float x);
*     double __raise_overflow(double x);
*     float __raise_overflowf(float x);
*     double __raise_underflow(double x);
*     float __raise_underflowf(float x);
*     double __raise_inexact(double x);
*     float __raise_inexactf(float x);
*     int __issignaling(double x);
*     int __issignalingf(float x);
*     REAL_PART(z);                            // this macros return value has the non-complex type of input `z`, the input is expected to be a complex floating-point datum
*     IMAG_PART(z);                            // this macros return value has the non-complex type of input `z`, the input is expected to be a complex floating-point datum
*
* Description
* ===========
*
* ``EXTRACT_WORDS`` is a macro to extract two integer words from a double
* floating-point datum.
*
* ``GET_HIGH_WORD`` is a macro to extract only the highword of the two integer
* words from a double floating-point datum.
*
* ``GET_LOW_WORD`` is a macro to extract only the lowword of the two integer
* words from a double floating-point datum.
*
* ``INSERT_WORDS`` is a macro to insert two integer words into a double
* floating-point datum.
*
* ``SET_HIGH_WORD`` is a macro to insert only the highword of the two integer
* words into a double floating-point datum.
*
* ``SET_LOW_WORD`` is a macro to insert only the lowword of the two integer
* words into a double floating-point datum.
*
* ``GET_FLOAT_WORD`` is a macro to extract the integer representation from a
* single floating-point datum.
*
* ``SET_FLOAT_WORD`` is a macro to insert the integer representation into a
* single floating-point datum.
*
* ``SAFE_RIGHT_SHIFT`` is a macro to avoid undefined behaviour that can arise
* if the amount of a right shift is exactly equal to the size of the shifted
* operand. If the amount is equal to the size the macro returns 0.
*
* ``__forced_calculation`` is a function to force the execution of the input
* to go throught the :ref:`FPU <ABBR>`. The input for this function is usually
* an arithmetic operation and not a single value. At the moment the function
* is only used by others within this file and not expected to be called from
* outside.
*
* ``__raise_invalid`` is a function to force the :ref:`FPU <ABBR>` to generate
* an ``invalid operation`` exception.
*
* ``__raise_div_by_zero`` is a function to force the :ref:`FPU <ABBR>` to
* generate an ``divide by zero`` exception.
*
* ``__raise_overflow`` is a function to force the :ref:`FPU <ABBR>` to
* generate an ``overflow`` exception.
*
* ``__raise_underflow`` is a function to force the :ref:`FPU <ABBR>` to
* generate an ``underflow`` exception. Even though the library usually does
* not care about this exception for qualification purposes, the library still
* tries to conform to the standards (mainly POSIX) in regards to where the
* exception shall be raised intentionally. In those places this function is
* used.
*
* ``__raise_inexact`` is a function to force the :ref:`FPU <ABBR>` to generate
* an ``inexact`` exception. Even though the library usually does not care
* about this exception for qualification purposes, the library still tries to
* conform to the standards (mainly POSIX) in regards to where the exception
* shall be raised intentionally. In those places this function is used.
*
* ``__issignaling`` is a function to check if a value is a signaling NaN.
*
* ``REAL_PART`` is a macro to extract only the real part of a complex
* floating-point datum.
*
* ``IMAG_PART`` is a macro to extract only the imaginary part of a complex
* floating-point datum.
*
* Mathematical Function
* =====================
*
* .. math::
*
*    EXTRACT\_WORDS_{ix0}(d) &= \text{highword of } d  \ *    EXTRACT\_WORDS_{ix1}(d) &= \text{lowword of } d  \ *    GET\_HIGH\_WORD_{i}(d) &= \text{highword of } d  \ *    GET\_LOW\_WORD_{i}(d) &= \text{lowword of } d  \ *    SET\_HIGH\_WORD_{\text{highword of } d}(d, v) &= d \text{ with highword } v  \ *    SET\_LOW\_WORD_{\text{lowword of } d}(d, v) &= d \text{ with lowword } v  \ *    GET\_FLOAT\_WORD_{i}(d) &= \text{integer representation of } d  \ *    SET\_FLOAT\_WORD_{d}(i) &= \text{floating-point representation of } i  \ *    SAFE\_RIGHT\_SHIFT(op, amt) &= \left\{\begin{array}{ll} op \gg amt, & amt < \text{size of } op \\ 0, & otherwise \end{array}\right.  \ *    \_\_forced\_calculation(x) &= x  \ *    \_\_raise\_invalid() &= NaN  \ *    \_\_raise\_div\_by\_zero(x) &= \left\{\begin{array}{ll} -Inf, & x \in \mathbb{F}^{-} \\ +Inf, & otherwise \end{array}\right.  \ *    \_\_raise\_overflow(x) &= \left\{\begin{array}{ll} -Inf, & x \in \mathbb{F}^{-} \\ +Inf, & otherwise \end{array}\right.  \ *    \_\_raise\_underflow(x) &= \left\{\begin{array}{ll} -0.0, & x \in \mathbb{F}^{-} \\ +0.0, & otherwise \end{array}\right.  \ *    \_\_raise\_inexact(x) &= x  \ *    \_\_issignaling(x) &= \left\{\begin{array}{ll} 1, & x = sNaN \\ 0, & otherwise \end{array}\right.  \ *    REAL\_PART(z) &= \Re(z)  \ *    IMAG\_PART(z) &= \Im(z)
\\
*    IMAG\_PART(z) &= \Im(z)
*
* Returns
* =======
*
* ``EXTRACT_WORDS`` has no return value. It places the two extracted integer
* words into the parameters ``ix0`` and ``ix1``.
*
* ``GET_HIGH_WORD`` has no return value. It places the extracted integer word
* into the parameter ``i``.
*
* ``GET_LOW_WORD`` has no return value. It places the extracted integer word
* into the parameter ``i``.
*
* ``INSERT_WORDS`` has no return value. It places the created double
* floating-point datum into the parameter ``d``.
*
* ``SET_HIGH_WORD`` has no return value. It places the created double
* floating-point datum into the parameter ``d``.
*
* ``SET_LOW_WORD`` has no return value. It places the created double
* floating-point datum into the parameter ``d``.
*
* ``GET_FLOAT_WORD`` has no return value. It places the extracted integer word
* into the parameter ``i``.
*
* ``SET_FLOAT_WORD`` has no return value. It places the created single
* floating-point datum into the parameter ``d``.
*
* ``SAFE_RIGHT_SHIFT`` returns the value ``op`` right shifted by ``amt`` if
* ``amt`` is smaller than the size of ``op``, otherwise it returns zero.
*
* ``__forced_calculation`` returns the input value, or rather the result of
* the arithmetic calculation used as an input.
*
* ``__raise_invalid`` returns ``NaN``.
*
* ``__raise_div_by_zero`` returns ``-Inf`` for negative inputs and ``+Inf``
* for positive inputs.
*
* ``__raise_overflow`` returns ``-Inf`` for negative inputs and ``+Inf`` for
* positive inputs.
*
* ``__raise_underflow`` returns ``-0.0`` for negative inputs and ``+0.0`` for
* positive inputs.
*
* ``__raise_inexact`` returns the input value.
*
* ``__issignaling`` returns ``1`` if the input value is a signaling ``NaN``,
* else ``0``.
*
* ``REAL_PART`` returns the real part of the input as a floating-point datum
* of the adequate size.
*
* ``IMAG_PART`` returns the imaginary part of the input as a floating-point
* datum of the adequate size.
*
* Exceptions
* ==========
*
* The macros do not raise exceptions.
*
* The functions raise the exceptions they are named after, it is their sole
* purpose. Additionally the procedures ``__raise_overflow`` and
* ``__raise_underflow`` may raise ``inexact``.
*
*/
//
/* A union which permits us to convert between a double and two 32 bit
ints.  */
/* Get two 32 bit ints from a double.  */
/* Get the more significant 32 bit int from a double.  */
/* Get the less significant 32 bit int from a double.  */
/* Set a double from two 32 bit ints.  */
/* Set the more significant 32 bits of a double from an int.  */
/* Set the less significant 32 bits of a double from an int.  */
/* A union which permits us to convert between a float and a 32 bit
int.  */

pub union ieee_float_shape_type {
    pub value: std::mem::ManuallyDrop<f32>,

    pub word: std::mem::ManuallyDrop<uint32_t>,
}

/* Get a 32 bit int from a float.  */
/* Set a float from a 32 bit int.  */
/* Macros to avoid undefined behaviour that can arise if the amount
of a shift is exactly equal to the size of the shifted operand.  */

// static inline double __forced_calculation(double x) {
//     volatile double r = x;
//     return r;
// }
fn __forced_calculation(x: f64) -> f64 {
    x * 2.0
}
fn __forced_calculationf(x: f32) -> f32 {
    let r = x;
    r
}
fn __raise_invalid() -> f64 {
    let r = __forced_calculationf(0.0 / 0.0);
    r
}
fn __raise_div_by_zero(x: f64) -> f64 {
    if x.is_sign_negative() {
        __forced_calculation(-1.0 / 0.0)
    } else {
        __forced_calculation(1.0 / 0.0)
    }
} //     return (__builtin_signbit (x) != 0) ? __forced_calculation(-1.0 / 0.0) : __forced_calculation(1.0 / 0.0);
  // }
fn __raise_overflow(x: f64) -> f64 {
    let huge: f64 = 1.0e300;
    if x.is_sign_negative() {
        -huge
    } else {
        huge
    }
}
fn __raise_underflow(x: f64) -> f64 {
    let tiny: f64 = 1.0e-300;
    if x.is_sign_negative() {
        -__forced_calculation(tiny * tiny)
    } else {
        __forced_calculation(tiny * tiny)
    }
} // static inline double __raise_overflow(double x) {
  //     volatile double huge = 1.0e300;
  //     return (__builtin_signbit (x) != 0) ? -__forced_calculation(huge * huge) : __forced_calculation(huge * huge);
  // }
fn __raise_inexact(x: f64) -> f64 {
    fn __raise_invalidf() -> f32 {
        let r = __forced_calculationf(0.0f32 / 0.0f32);
        r
    }
}
fn __raise_div_by_zerof(x: f32) -> f32 {
    if x.is_sign_negative() {
        panic!("Division by zero");
    }
    x
}
fn __raise_overflowf(x: f32) -> f32 {
    let huge: f32 = 1.0e30f32;
    if x.is_sign_negative() {
        -__forced_calculationf(huge * huge)
    } else {
        __forced_calculationf(huge * huge)
    }
} // static inline double __raise_inexact(double x) {
  //     volatile double huge = 1.0e300;
  //     return (__forced_calculation(huge - 1.0e-300) != 0.0) ? x : 0.0;
  // }
fn __raise_underflowf(x: f32) -> f32 {
    fn __raise_inexactf(x: f32) -> f32 {
        let huge: f32 = 1.0e30;
        if __forced_calculationf(huge - 1.0e-30) != 0.0 {
            x
        } else {
            0.0
        }
    }
}

// static inline float __raise_invalidf() {
//     double r = __forced_calculationf(0.0f / 0.0f);
//     return r;
// }
fn __issignaling(x: f64) -> i32 {
    let hx: u32 = x.to_bits() as u32 >> 32;
    if x.is_nan() && (hx & 0x00080000) == 0 {
        1
    } else {
        0
    }
}

// static inline float __raise_div_by_zerof(float x) {
//     return (__builtin_signbit (x) != 0) ? __forced_calculationf(-1.0f / 0.0f) : __forced_calculationf(1.0f / 0.0f);
// }
fn __issignalingf(x: f32) -> i32 {
    let ix: u32 = x.to_bits();
    if (ix & 0x7fffffff) > 0x7f800000 && (ix & 0x00400000) == 0 {
        1
    } else {
        0
    }
}
