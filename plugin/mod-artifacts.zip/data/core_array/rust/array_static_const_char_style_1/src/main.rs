/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/


// lilac:A:start:declare static constant char * array using HOLE
static foo: &[&str] = &[
    // lilac:B+:start:strings
    // lilac:BA:start:string
    "zero", 
    // lilac:BA:stop
    // lilac:BB:start:string
    "one"
     // lilac:BB:stop
     // lilac:B+:stop
 ];
 // lilac:A:stop

//lilac:F:start:function to return const char * value based on integer index of array
pub fn int_to_char(index: usize) -> &'static str 
{
    foo[index]
}
//lilac:F:stop

pub fn return_example(index: usize) -> &'static str 
{
    //lilac:R:start:index value
    foo[index]
    //lilac:R:stop
}

 fn main() {

    print!("Result: {}", 
        //lilac:P:start:index value
        foo[0]
        //lilac:P:stop
        );

    print!("Result: {}", 
        //lilac:PA:start:function results
        int_to_char(1)
        //lilac:PA:stop
    );

    print!("Result: {}", 
        //lilac:PB:start:function results
        return_example(0)
        //lilac:PB:stop
    );

}
    
