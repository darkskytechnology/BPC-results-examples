/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>

// lilac:A:start:declare static constant char * array using HOLE
static const char *foo[] = {
    // lilac:B+:start:strings
    // lilac:BA:start:string
    "zero", 
    // lilac:BA:stop
    // lilac:BB:start:string
    "one"
     // lilac:BB:stop
     // lilac:B+:stop
};
// lilac:A:stop


//lilac:F:start:function to return const char * value based on integer index of array
const char *int_to_char(int index) 
{
    return foo[index];
}
//lilac:F:stop


const char *return_example(int index) 
{
    return 
    //lilac:R:start:index value
    foo[index]
    //lilac:R:stop
    ;
}

int main(int argc, char* argv[]) {

    printf("Result: %s", 
        //lilac:P:start:index value
        foo[0]
        //lilac:P:stop
        );

    printf("Result: %s", 
        //lilac:PA:start:function results
        int_to_char(1)
        //lilac:PA:stop
    );

    printf("Result: %s", 
        //lilac:PB:start:function results
        return_example(0)
        //lilac:PB:stop
    );

    return 0;
}
