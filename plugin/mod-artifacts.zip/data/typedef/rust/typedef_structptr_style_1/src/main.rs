/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/
#![allow(non_camel_case_types)]

#[derive(Clone, Default)]
pub struct sample {
    pub elem: char,
}

//lilac:A:start:declare typedef for a struct pointer
pub type structptr_t = Option<std::rc::Rc<std::cell::RefCell<sample>>>;
//lilac:A:stop

fn main() {
    let mut example_structptr: structptr_t;

    // lilac:B:start:allocate an instance of a struct on the heap
    let example: Option<std::rc::Rc<std::cell::RefCell<sample>>> =
        Some(std::rc::Rc::new(std::cell::RefCell::new(sample::default())));
    // lilac:B:stop

    example_structptr = example;

    // lilac:C:start:assign to a pointer field
    example_structptr.as_mut().unwrap().borrow_mut().elem =
        // lilac:D:start:(value)
        'a'
        // lilac:D:stop^
        ;
    // lilac:C:stop

    print!(
        "char: {}\n",
        // lilac:E:start:dereference a pointer field
        // lilac:EA:start_:identifier
        example_structptr
            .as_ref()
            .unwrap()
            .borrow()
            // lilac:EA:stop
            .elem // lilac:E:stop
    );

    if //lilac:Z:start:check for null
        //lilac:ZA:start_2:(lhs)
        example_structptr
        //lilac:ZA:stop
        .is_none()
        //lilac:Z:stop
        {
        return;
    }

    if
    //lilac:N:start:check for not-null
    //lilac:NA:start_2:(lhs)
    example_structptr
        //lilac:NA:stop
        .is_some()
    //lilac:N:stop
    {
        // lilac:S:start:set to null
        //  lilac:SA:start_2:(lhs)
        example_structptr
            // lilac:SA:stop
            = None;
        // lilac:S:stop
    }
}
