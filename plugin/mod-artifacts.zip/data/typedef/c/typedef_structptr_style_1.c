/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>
#include <stdlib.h>

struct sample
{
    char elem;
};

// lilac:A:start:declare typedef for a struct pointer
typedef struct sample *structptr_t;
// lilac:A:stop

int main(int argc, char *argv[])
{
    structptr_t example_structptr;

    // lilac:B:start:allocate an instance of a struct on the heap
    struct sample *example = malloc(sizeof(struct sample));
    // lilac:B:stop

    example_structptr = example;

    // lilac:C:start:assign to a pointer field
    example_structptr->elem =
        // lilac:D:start:(value)
        'a'
        // lilac:D:stop^
        ;
    // lilac:C:stop

    printf("char: %c\n",
           // lilac:E:start:dereference a pointer field
           // lilac:EA:start_:identifier
           example_structptr
               // lilac:EA:stop
               ->elem
           // lilac:E:stop
    );

    if (//lilac:Z:start:check for null
        //lilac:ZA:start_:(lhs)
        example_structptr
        //lilac:ZA:stop
        == NULL
        //lilac:Z:stop
       ) {
        return 0;
    }

    if ( // lilac:N:start:check for not-null
         // lilac:NA:start_:(lhs)
        example_structptr
        // lilac:NA:stop
        != NULL
        // lilac:N:stop
    )
    {
        free(example_structptr);
        // lilac:S:start:set to null
        //  lilac:SA:start_2:(lhs)
        example_structptr
            // lilac:SA:stop
            = NULL;
        // lilac:S:stop
    }
    return 0;
}
