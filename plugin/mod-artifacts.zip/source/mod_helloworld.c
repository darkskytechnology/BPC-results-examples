#include "httpd.h"
#include "http_config.h"
#include "http_protocol.h"
#include "ap_config.h"
#include "apr_tables.h"

// Request handler example
static int helloworld_handler(request_rec *req) {
    if (strcmp(req->handler, "helloworld")) {
        return DECLINED;
    }
    if (!req->header_only) {
        ap_rputs("{\"message\": \"Hello world!\"}\n", req);
    }
    req->content_type = "application/json;charset=UTF-8";
    apr_table_set(req->headers_out, "X-Content-Type-Options", "nosniff");

    return OK;
}

// Register hooks
static void helloworld_register_hooks(apr_pool_t *p) {
    ap_hook_handler(helloworld_handler, NULL, NULL, APR_HOOK_MIDDLE);
}

// Dispatch list for API hooks
module AP_MODULE_DECLARE_DATA helloworld_module = {
    STANDARD20_MODULE_STUFF,
    NULL, /* create per-dir config structures */
    NULL, /* merge per-dir config structures */
    NULL, /* create per-server config structures */
    NULL, /* merge per-server config structures */
    NULL, /* table of config file commands */
    helloworld_register_hooks  /* register hooks */
};

