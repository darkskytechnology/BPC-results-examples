#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
// Request handler example

struct ReqStruct {
    handler: String,
    header_only: bool,
    content_type: String,
    headers_out: std::collections::HashMap<String, String>,
}
fn ap_rputs(message: &str, req: &mut ReqStruct) {
    println!("{}", message);
}
fn apr_table_set(headers: &mut std::collections::HashMap<String, String>, key: &str, value: &str) {
    headers.insert(key.to_string(), value.to_string());
}
fn helloworld_handler(req: Option<std::rc::Rc<std::cell::RefCell<ReqStruct>>>) -> i32 {
    if let Some(req_rc) = req {
        let mut req = req_rc.borrow_mut();
        if req.handler != "helloworld" {
            return -1;
        }
        if !req.header_only {
            ap_rputs("{\"message\": \"Hello world!\"}\n", &mut req);
        }
        req.content_type = "application/json;charset=UTF-8".to_string();
        apr_table_set(&mut req.headers_out, "X-Content-Type-Options", "nosniff");
        return 0;
    }
    -1
}
fn helloworld_register_hooks() {
    ap_hook_handler(helloworld_handler_simple, None, None, apr_hook_middle());
}
fn apr_hook_middle() -> i32 {
    0
}
fn ap_hook_handler(handler: fn(), _a: Option<fn()>, _b: Option<fn()>, _c: i32) {
    handler();
}
fn helloworld_handler_simple() {
    println!("Hello, world!");
}
struct Module {
    standard20_module_stuff: u32,
    create_per_dir_config_structures: Option<fn()>,
    merge_per_dir_config_structures: Option<fn()>,
    create_per_server_config_structures: Option<fn()>,
    merge_per_server_config_structures: Option<fn()>,
    table_of_config_file_commands: Option<fn()>,
    register_hooks: fn(),
}
static helloworld_module: Module = Module {
    standard20_module_stuff: 0,
    create_per_dir_config_structures: None,
    merge_per_dir_config_structures: None,
    create_per_server_config_structures: None,
    merge_per_server_config_structures: None,
    table_of_config_file_commands: None,
    register_hooks: helloworld_register_hooks,
};
