#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use math::translate_bpc_vpp;
// USE STATEMENTS END

pub fn add(a: f64, b: f64) -> f64 {
    return a + b;
}

pub fn subtract(a: f64, b: f64) -> f64 {
    return a - b;
}

pub fn multiply(a: f64, b: f64) -> f64 {
    return a * b;
}

pub fn divide(a: f64, b: f64) -> f64 {
    if b != 0.0 {
        return a / b;
    } else {
        print!("Error: Division by zero.\n");

        return 0.0;
    }
}

pub fn power(base: f64, exponent: f64) -> f64 {
    return base.powf(exponent);
}

pub fn square_root(number: f64) -> f64 {
    if number >= 0.0 {
        return number.sqrt();
    } else {
        print!("Error: Square root of a negative number.\n");

        return 0.0;
    }
}

pub fn factorial(number: i32) -> f64 {
    if number < 0 {
        println!("Error: Factorial of a negative number is not defined.\n");
        return 0.0;
    }

    let mut result: f64 = 1.0;
    for i in 1..=number {
        result *= i as f64;
    }

    result
}
pub fn sine_function(angle: f64) -> f64 {
    return angle.sin();
}

pub fn cosine_function(angle: f64) -> f64 {
    return angle.cos();
}

pub fn tangent_function(angle: f64) -> f64 {
    return angle.tan();
}

fn main() -> impl std::process::Termination {
    let x: f64 = 5.0;
    let y: f64 = 3.0;

    println!("Addition of {:.2} and {:.2}: {:.2}", x, y, add(x, y));
    println!(
        "Subtraction of {:.2} and {:.2}: {:.2}",
        x,
        y,
        subtract(x, y)
    );
    println!(
        "Multiplication of {:.2} and {:.2}: {:.2}",
        x,
        y,
        multiply(x, y)
    );
    println!("Division of {:.2} and {:.2}: {:.2}", x, y, divide(x, y));
    println!("Power of {:.2} to {:.2}: {:.2}", x, y, power(x, y));
    println!("Square root of {:.2}: {:.2}", x, square_root(x));
    println!("Factorial of {}: {:.2}", y as i32, factorial(y as i32));
    println!("Sine of {:.2} radians: {:.2}", x, sine_function(x));
    println!("Cosine of {:.2} radians: {:.2}", x, cosine_function(x));
    println!("Tangent of {:.2} radians: {:.2}", x, tangent_function(x));

    std::process::ExitCode::SUCCESS
}
