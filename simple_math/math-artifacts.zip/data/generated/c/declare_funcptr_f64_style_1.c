/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

struct other
{
    double val;
};

typedef struct other user_t;

//lilac:A:start:declare typedef for a function pointer
typedef double (*func_name)
(
 //lilac:B*:start:(arguments)
 //lilac:BA:start:(arg)
 double a,
 //lilac:BA:stop
 //lilac:BB:start:(arg)
 double b
 //lilac:BB:stop
 //lilac:B*:stop
);
//lilac:A:stop

//lilac:V:start:declare typedef for a void function pointer
typedef void (*void_func_name)
(
 //lilac:VB*:start:(arguments)
 //lilac:VBA:start:(arg)
 double a,
 //lilac:VBA:stop
 //lilac:VBB:start:(arg)
 double b
 //lilac:VBB:stop
 //lilac:VB*:stop
);
//lilac:V:stop

struct foo {
  //lilac:F:start:declare function pointer field
  double (*func_name)(
 //lilac:FB*:start:(arguments)
 //lilac:FBA:start:(arg)
 double a,
 //lilac:FBA:stop
 //lilac:FBB:start:(arg)
 double b
 //lilac:FBB:stop
 //lilac:FB*:stop
  );
  //lilac:F:stop

  //lilac:VF:start:declare void function pointer field
  void (*void_func_name)(
 //lilac:VFB*:start:(arguments)
 //lilac:VFBA:start:(arg)
 double a,
 //lilac:VFBA:stop
 //lilac:VFBB:start:(arg)
 double b
 //lilac:VFBB:stop
 //lilac:VFB*:stop
  );
  //lilac:VF:stop
};

double function(double a, double b) {
    return a;
}

int main(int argc, char *argv[])
{
    double aval;
    double bval;
    double cval;

    struct foo structure;
    structure.func_name = function;

    cval = //lilac:FCA:start:call a function through a structure function pointer   
    //lilac:FEXP:start_2:variable
    structure
    //lilac:FEXP:stop
    .func_name(
      //lilac:FCB*:start:(arguments)
      //lilac:FCBA:start:(argument)
      aval,
      //lilac:FCBA:stop
      //lilac:FCBB:start:(argument)
      bval
      //lilac:FCBB:stop
      //lilac:FCB*:stop
    )
    // lilac:FCA:stop^
    ;

    //lilac:SCA:start:call a function through a structure function pointer   
    //lilac:SEXP:start_3:variable
    structure
    //lilac:SEXP:stop
    .func_name(
      //lilac:SCB*:start:(arguments)
      //lilac:SCBA:start:(argument)
      aval,
      //lilac:SCBA:stop
      //lilac:SCBB:start:(argument)
      bval
      //lilac:SCBB:stop
      //lilac:SCB*:stop
    );
    // lilac:SCA:stop

    return 0;
}