/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <assert.h>


int main(int argc, char *argv[]) {
    int value_a = 10;
    int value_b = 20;

    //lilac:C:start:assert condition
    assert(
    //lilac:CC:start:evaluate expression variable is HOLE variable
    value_a
    //lilac:CCA:start:equal to
    ==
    //lilac:CCA:stop
    value_b
    //lilac:CC:stop
    );
    //lilac:C:stop

    return 0;
}
