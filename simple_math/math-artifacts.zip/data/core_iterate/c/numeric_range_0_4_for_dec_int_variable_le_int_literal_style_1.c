/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>

int main(int argc, char *argv[]) {

    //lilac:A:start:loop
    for
    (
    int i = 0
    ;
    //lilac:CCE:start:evaluate if a variable is HOLE to an integer
    i
    //lilac:CCEA:start:less than or equal to
    <=
    //lilac:CCEA:stop
    4
    //lilac:CCE:stop
    ;
    //lilac:CCU+:start:increment a variable
    i = i + 1
    //lilac:CCU+:stop
    )
    {
        //lilac:AA+:start:print a string containing a variable
        printf("%d", i);
        //lilac:AA+:stop
    }

    //lilac:A:stop

    return 0;
}
