/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[macro_export]
macro_rules! as_bool {
    ($i:expr) => {
        $i != 0
    };
}

#[macro_export]
macro_rules! from_bool {
    ($ty:ty, $i:expr) => {
        $i as $ty
    };
}

#[macro_export]
macro_rules! translate_bpc_mmv {
    ($i:expr) => {{
        $i -= 1;
        $i
    }};
}

#[macro_export]
macro_rules! translate_bpc_ppv {
    ($i:expr) => {{
        $i += 1;
        $i
    }};
}

#[macro_export]
macro_rules! translate_bpc_vmm {
    ($i:expr) => {{
        let _v = $i;
        $i -= 1;
        _v
    }};
}

#[macro_export]
macro_rules! translate_bpc_vpp {
    ($i:expr) => {{
        let _v = $i;
        $i += 1;
        _v
    }};
}

#[macro_export]
macro_rules! review_required {
    ($msg:literal) => {
        #[cfg(feature = "review")]
        compile_error!($msg);
    };
}

#[macro_export]
macro_rules! goto {
    ($msg:ident) => {
        #[cfg(feature = "review")]
        compile_error!(concat!("cannot compile `goto ", stringify!($msg), ";`"));
    };
}
