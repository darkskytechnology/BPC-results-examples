#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
// Function to swap the values of two integers

pub fn swap(a: &mut i32, b: &mut i32) {
    let temp = *a;
    *a = *b;
    *b = temp;
}
pub fn print_values(a: i32, b: i32) {
    print!("a = {}, b = {}\n", a, b);
}

fn main() {
    let mut x: i32 = 5;
    let mut y: i32 = 10;

    println!("Before swapping:");
    print_values(x, y);

    // Call the swap function
    swap(&mut x, &mut y);

    println!("After swapping:");
    print_values(x, y);
}
