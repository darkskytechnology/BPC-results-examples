/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>

//lilac:F:start:declare function
void function_example(
    //lilac:FP+:start:(function arguments)
    //lilac:FA:start:declare integer variable
    int argument_example
    //lilac:FA:stop
    //lilac:FP+:stop
    ) {
    //lilac:FM*:start:(function content)
    printf("Basic function example: %d",
    argument_example
    );
    //lilac:FM*:stop
}
//lilac:F:stop


int main(int argc, char *argv[]) {
    //lilac:B:start:call function
    function_example(
    //lilac:BP+:start:(function arguments)
    //lilac:BB:start:(integer)
    8
    //lilac:BB:stop
    //lilac:BP+:stop
    );
    //lilac:B:stop
    //lilac:C:start:return integer
    return
    0;
    //lilac:C:stop
}
