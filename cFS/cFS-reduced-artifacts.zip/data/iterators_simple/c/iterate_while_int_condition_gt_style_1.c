/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>

int main(int argc, char *argv[]) {

    int i = 3;

    //lilac:B:start:loop while a variable is greater than an integer
    while (i > 1) {
        //lilac:BA+:start:print a string containing a variable and then decrement the variable
        printf("Condition satisfied: %d\n", i);
        i = i - 1;
        //lilac:BA+:stop
    }
    //lilac:B:stop

    return 0;
}