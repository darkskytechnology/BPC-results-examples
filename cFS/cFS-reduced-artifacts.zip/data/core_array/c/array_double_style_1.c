/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>

int main(int argc, char* argv[]) {

    // lilac:A:start:declare double array initialized using HOLE
    double foo[] = {
        // lilac:B+:start:floating-point literals
        // lilac:BA:start:floating-point literal
        1.0, 
        // lilac:BA:stop
        // lilac:BB:start:floating-point literal
        2.0
        // lilac:BB:stop
        // lilac:B+:stop
    };
    // lilac:A:stop

    double result;

    result = 
        // lilac:D:start:element in an array indexed by HOLE
        foo[
        // lilac:E:start:integer
        0
        // lilac:E:stop
        ]
        // lilac:D:stop^
        ;

    printf("Result: %.1f", result);

    return 0;
}
