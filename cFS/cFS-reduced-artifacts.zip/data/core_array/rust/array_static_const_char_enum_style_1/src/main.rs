/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

type enum_Index = i32;
const ZERO: enum_Index = 0;
const ONE: enum_Index = ZERO + 1;


// lilac:A:start:declare static constant char * array using HOLE
static foo: &[&str] = &[
    // lilac:B+:start:strings
    // lilac:BA:start:string
    "zero", 
    // lilac:BA:stop
    // lilac:BB:start:string
    "one"
     // lilac:BB:stop
     // lilac:B+:stop
 ];
 // lilac:A:stop

//lilac:F:start:function to return const char * value based on integer index of array
pub fn int_to_char(index: enum_Index) -> &'static str 
{
    foo[index as usize]
}
//lilac:F:stop

pub fn return_example(index: enum_Index) -> &'static str 
{
    //lilac:R:start:index value
    foo[index as usize]
    //lilac:R:stop
}

 fn main() {

    print!("Result: {}", 
        //lilac:P:start:index value
        foo[ZERO as usize]
        //lilac:P:stop
        );

    print!("Result: {}", 
        //lilac:PA:start:function results
        int_to_char(ONE)
        //lilac:PA:stop
    );

    print!("Result: {}", 
        //lilac:PB:start:function results
        return_example(ZERO)
        //lilac:PB:stop
    );

}
    
