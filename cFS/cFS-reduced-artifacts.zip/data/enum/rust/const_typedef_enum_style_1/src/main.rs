/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

//lilac:A:start:declare typedef
pub type enum_Foo = i32;
//lilac:A:stop

//lilac:B:start:declare constant
const VARIANT_A: enum_Foo = 0;
//lilac:B:stop

//lilac:C:start:declare constant
const VARIANT_B: enum_Foo = 
//lilac:CA:start:assignment value
VARIANT_A + 1
//lilac:CA:stop
;
//lilac:C:stop

//lilac:D:start:typedef to enum
pub type Foo = enum_Foo;
//lilac:D:stop

fn main() {
    //lilac:E:start:declare variable
    let mut foo: enum_Foo = Default::default();
    //lilac:E:stop
    //lilac:F:start:declare variable
    let mut foobar: Foo = Default::default();
    //lilac:F:stop

    foo = VARIANT_A;
    foobar = VARIANT_B;

    print!("{}", foobar);
}
