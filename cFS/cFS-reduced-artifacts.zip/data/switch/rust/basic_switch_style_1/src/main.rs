/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

fn main() {
    let argv = std::env::args().collect::<Vec<_>>();
    let data = argv[1].parse::<i32>().unwrap();

    //lilac:A:start:switch statement
    match 
    //lilac:AA:start:switch expression
    data 
    //lilac:AA:stop
    {
        //lilac:B*:start:case statement with literal expression
        1 => {
            //lilac:BA*:start:print string
            print!("case 1");
            //lilac:BA*:stop
        }
        //lilac:B*:stop
        _ => {
            //lilac:C*:start:print string
            print!("default");
            //lilac:C*:stop
        }
    }
    //lilac:A:stop
}
