/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>

//lilac:F:start:declare function
int function_example() {
    //lilac:FM+:start:(function content)
    //lilac:FB:start:return integer
    return
    10
    ;
    //lilac:FB:stop
    //lilac:FM+:stop
}
//lilac:F:stop


int main(int argc, char *argv[]) {
    //lilac:A:start:declare integer variable
    int results;
    //lilac:A:stop
    //lilac:B:start:assign variable function results
    results = function_example();
    //lilac:B:stop
    //lilac:C:start:print string
    printf("Results: %d",
    //lilac:BP+:start:(function arguments)
    //lilac:BBA:start:(variable)
    results
    //lilac:BBA:stop
    //lilac:BP+:stop
    );
    //lilac:C:stop
    //lilac:D:start:return integer
    return
    0;
    //lilac:D:stop
}
