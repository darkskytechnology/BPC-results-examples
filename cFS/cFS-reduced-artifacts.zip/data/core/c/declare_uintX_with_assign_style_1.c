/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>
#include <stdint.h>

int main(int argc, char *argv[]) {
    //lilac:A:start:declare unsigned integer variable and assign value
    uint8_t u8var = 8;
    //lilac:A:stop

    //lilac:B:start:declare unsigned integer variable and assign value
    uint16_t u16var = 16;
    //lilac:B:stop

    //lilac:C:start:declare unsigned integer variable and assign value
    uint32_t u32var = 32;
    //lilac:C:stop

    //lilac:D:start:declare unsigned integer variable and assign value
    uint64_t u64var = 64;
    //lilac:D:stop

    printf("u8var is %u\n", u8var);
    printf("u16var is %lu\n", (unsigned long) u16var);
    printf("u32var is %lu\n", (unsigned long) u32var);
    printf("u64var is %lu\n", (unsigned long) u64var);

}
