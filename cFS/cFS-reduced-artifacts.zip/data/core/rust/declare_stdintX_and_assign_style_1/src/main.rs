/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[allow(unused_variables)]
#[allow(non_snake_case)]

fn main() -> impl std::process::Termination {
    let argv = std::env::args().collect::<Vec<_>>();
    let argc = argv.len();

    let retcode = move || -> u8 {
        // lilac:A:start:declare integer variable
        let i8var: i8;
         // lilac:A:stop

        // lilac:B:start:declare integer variable
        let i16var: i16;
        // lilac:B:stop

        // lilac:C:start:declare integer variable
        let i32var: i32;
        // lilac:C:stop

        // lilac:D:start:declare integer variable
        let i64var: i64;
        // lilac:D:stop

        // lilac:AA:start:assign variable integer value
        i8var = 8;
        // lilac:AA:stop

        // lilac:BA:start:assign variable integer value
        i16var = 16;
        // lilac:BA:stop

        // lilac:CA:start:assign variable integer value
        i32var = 32;
        // lilac:CA:stop

        // lilac:DA:start:assign variable integer value
        i64var = 64;
        // lilac:DA:stop

        println!("i8var is {}", i8var);
        println!("i16var is {}", i16var);
        println!("i32var is {}", i32var);
        println!("i64var is {}", i64var);
        return 0;
    }();

    return std::process::ExitCode::from(retcode);
}
