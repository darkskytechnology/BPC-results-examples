/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[allow(unused_variables)]
#[allow(non_snake_case)]

//lilac:F:start:(function with character return value)
pub fn function_example(
    //lilac:FP+:start:(function arguments)
    //lilac:FPA:start:declare character variable
    incoming_a: char,
    //lilac:FPA:stop
    //lilac:FPB:start:declare character variable
    incoming_b: char
    //lilac:FPB:stop
    //lilac:FP+:stop
    ) -> char {
    //lilac:FA+:start:(function contents)
    //lilac:FAA:start:return character value
    return 'a';
    //lilac:FAA:stop
    //lilac:FA+:stop
}
//lilac:F:stop


fn main() -> impl std::process::Termination {
    let argv = std::env::args().collect::<Vec<_>>();
    let argc = argv.len();

    let retcode = move || -> u8 {
        let initial: char = 'a';
        
        //lilac:C:start:print string
        print!("Results: {}",
        //lilac:BP+:start:(function arguments)
        //lilac:BBA:start:(function call)
        function_example(
            //lilac:BBP+:start:(function arguments)
            //lilac:BBPA:start:(variable)
            initial,
            //lilac:BBPA:stop
            //lilac:BBPB:start:(character)
            'a'
            //lilac:BBPB:stop
            //lilac:BBP+:stop
            )
        //lilac:BBA:stop
        //lilac:BP+:stop
        );
        //lilac:C:stop
        return
        0;
    }();

    return std::process::ExitCode::from(retcode);
}
