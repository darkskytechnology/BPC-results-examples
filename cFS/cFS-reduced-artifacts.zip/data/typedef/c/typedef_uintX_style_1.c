/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>
#include <stdint.h>

//lilac:A:start:declare typedef for unsigned integer
typedef uint8_t u8_t;
//lilac:A:stop

//lilac:B:start:declare typedef for unsigned integer
typedef uint16_t u16_t;
//lilac:B:stop

//lilac:C:start:declare typedef for unsigned integer
typedef uint32_t u32_t;
//lilac:C:stop

//lilac:D:start:declare typedef for unsigned integer
typedef uint64_t u64_t;
//lilac:D:stop

//lilac:U:start:declare typedef for unsigned integer
typedef unsigned int other_u32_t;
//lilac:U:stop

int main(int argc, char *argv[]) {
    //lilac:EA:start:declare variable and assign value
    u8_t u8var_a = 8;
    //lilac:EA:stop
    //lilac:EB:start:declare variable
    u8_t u8var_b;
    //lilac:EB:stop
    //lilac:EC:start:assign value
    u8var_b = 8;
    //lilac:EC:stop
    
    //lilac:FA:start:declare variable and assign value
    u16_t u16var_a = 16;
    //lilac:FA:stop
    //lilac:FB:start:declare variable
    u16_t u16var_b;
    //lilac:FB:stop
    //lilac:FC:start:assign value
    u16var_b = 16;
    //lilac:FC:stop

    //lilac:GA:start:declare variable and assign value
    u32_t u32var_a = 32;
    //lilac:GA:stop
    //lilac:GB:start:declare variable
    u32_t u32var_b;
    //lilac:GB:stop
    //lilac:GC:start:assign value
    u32var_b = 32;
    //lilac:GC:stop

    //lilac:HA:start:declare variable and assign value
    u64_t u64var_a = 64;
    //lilac:HA:stop
    //lilac:HB:start:declare variable
    u64_t u64var_b;
    //lilac:HB:stop
    //lilac:HC:start:assign value
    u64var_b = 64;
    //lilac:HC:stop

    //lilac:UA:start:declare variable and assign value
    other_u32_t other_u32var_a = 32;
    //lilac:UA:stop
    //lilac:UB:start:declare variable
    other_u32_t other_u32var_b;
    //lilac:UB:stop
    //lilac:UC:start:assign value
    other_u32var_b = 32;
    //lilac:UC:stop

    printf("u8: %u %u\n", u8var_a, u8var_b);
    printf("u16: %lu %lu\n", (unsigned long) u16var_a, (unsigned long) u16var_b);
    printf("u32: %lu %lu\n", (unsigned long) u32var_a, (unsigned long) u32var_b);
    printf("otheru32: %lu %lu\n", (unsigned long) other_u32var_a, (unsigned long) other_u32var_b);
    printf("u64: %lu %lu\n", (unsigned long) u64var_a, (unsigned long) u64var_b);

    return 0;
}
