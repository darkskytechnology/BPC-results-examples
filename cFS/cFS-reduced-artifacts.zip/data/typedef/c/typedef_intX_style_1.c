/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>
#include <stdint.h>

//lilac:A:start:declare typedef for integer
typedef int8_t s8_t;
//lilac:A:stop

//lilac:B:start:declare typedef for integer
typedef int16_t s16_t;
//lilac:B:stop

//lilac:C:start:declare typedef for integer
typedef int32_t s32_t;
//lilac:C:stop

//lilac:D:start:declare typedef for integer
typedef int64_t s64_t;
//lilac:D:stop


int main(int argc, char *argv[]) {
    //lilac:EA:start:declare variable and assign value
    s8_t s8var_a = 8;
    //lilac:EA:stop
    //lilac:EB:start:declare variable
    s8_t s8var_b;
    //lilac:EB:stop
    //lilac:EC:start:assign value
    s8var_b = 8;
    //lilac:EC:stop
    
    //lilac:FA:start:declare variable and assign value
    s16_t s16var_a = 16;
    //lilac:FA:stop
    //lilac:FB:start:declare variable
    s16_t s16var_b;
    //lilac:FB:stop
    //lilac:FC:start:assign value
    s16var_b = 16;
    //lilac:FC:stop

    //lilac:GA:start:declare variable and assign value
    s32_t s32var_a = 32;
    //lilac:GA:stop
    //lilac:GB:start:declare variable
    s32_t s32var_b;
    //lilac:GB:stop
    //lilac:GC:start:assign value
    s32var_b = 32;
    //lilac:GC:stop

    //lilac:HA:start:declare variable and assign value
    s64_t s64var_a = 64;
    //lilac:HA:stop
    //lilac:HB:start:declare variable
    s64_t s64var_b;
    //lilac:HB:stop
    //lilac:HC:start:assign value
    s64var_b = 64;
    //lilac:HC:stop

    printf("s8: %d %d\n", s8var_a, s8var_b);
    printf("s16: %d %d\n", s16var_a, s16var_b);
    printf("s32: %d %d\n", s32var_a, s32var_b);
    printf("s64: %ld %ld\n", (long int) s64var_a, (long int) s64var_b);

    return 0;
}
