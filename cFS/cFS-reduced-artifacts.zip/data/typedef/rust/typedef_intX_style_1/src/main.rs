/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/
#![allow(non_camel_case_types)]
//lilac:A:start:declare typedef for integer
pub type s8_t = u8;
//lilac:A:stop

//lilac:B:start:declare typedef for integer
pub type s16_t = u16;
//lilac:B:stop

//lilac:C:start:declare typedef for integer
pub type s32_t = u32;
//lilac:C:stop

//lilac:D:start:declare typedef for integer
pub type s64_t = u64;
//lilac:D:stop

fn main() {
    //lilac:EA:start:declare variable and assign value
    let s8var_a: s8_t = 8;
    //lilac:EA:stop
    //lilac:EB:start:declare variable
    let s8var_b: s8_t;
    //lilac:EB:stop
    //lilac:EC:start:assign value
    s8var_b = 8;
    //lilac:EC:stop
        
    //lilac:FA:start:declare variable and assign value
    let s16var_a: s16_t = 16;
    //lilac:FA:stop
    //lilac:FB:start:declare variable
    let s16var_b: s16_t;
    //lilac:FB:stop
    //lilac:FC:start:assign value
    s16var_b = 16;
    //lilac:FC:stop
        
    //lilac:GA:start:declare variable and assign value
    let s32var_a: s32_t = 32;
    //lilac:GA:stop
    //lilac:GB:start:declare variable
    let s32var_b: s32_t;
    //lilac:GB:stop
    //lilac:GC:start:assign value
    s32var_b = 32;
    //lilac:GC:stop

    //lilac:HA:start:declare variable and assign value
    let s64var_a: s64_t = 64;
    //lilac:HA:stop
    //lilac:HB:start:declare variable
    let s64var_b: s64_t;
    //lilac:HB:stop
    //lilac:HC:start:assign value
    s64var_b = 64;
    //lilac:HC:stop

    print!("s8: {} {}\n", s8var_a, s8var_b);
    print!("s16: {} {}\n", s16var_a, s16var_b);
    print!("s32: {} {}\n", s32var_a, s32var_b);
    print!("s64: {} {}\n", s64var_a, s64var_b);
}
