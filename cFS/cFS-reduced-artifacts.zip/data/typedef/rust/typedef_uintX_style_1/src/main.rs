/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/
#![allow(non_camel_case_types)]

//lilac:A:start:declare typedef for unsigned integer
pub type u8_t = u8;
//lilac:A:stop

//lilac:B:start:declare typedef for unsigned integer
pub type u16_t = u16;
//lilac:B:stop

//lilac:C:start:declare typedef for unsigned integer
pub type u32_t = u32;
//lilac:C:stop

//lilac:D:start:declare typedef for unsigned integer
pub type u64_t = u64;
//lilac:D:stop

//lilac:U:start:declare typedef for unsigned integer
pub type other_u32_t = u32;
//lilac:U:stop

fn main() {
    //lilac:EA:start:declare variable and assign value
    let u8var_a: u8_t = 8;
    //lilac:EA:stop
    //lilac:EB:start:declare variable
    let u8var_b: u8_t;
    //lilac:EB:stop
    //lilac:EC:start:assign value
    u8var_b = 8;
    //lilac:EC:stop
        
    //lilac:FA:start:declare variable and assign value
    let u16var_a: u16_t = 16;
    //lilac:FA:stop
    //lilac:FB:start:declare variable
    let u16var_b: u16_t;
    //lilac:FB:stop
    //lilac:FC:start:assign value
    u16var_b = 16;
    //lilac:FC:stop
        
    //lilac:GA:start:declare variable and assign value
    let u32var_a: u32_t = 32;
    //lilac:GA:stop
    //lilac:GB:start:declare variable
    let u32var_b: u32_t;
    //lilac:GB:stop
    //lilac:GC:start:assign value
    u32var_b = 32;
    //lilac:GC:stop

    //lilac:HA:start:declare variable and assign value
    let u64var_a: u64_t = 64;
    //lilac:HA:stop
    //lilac:HB:start:declare variable
    let u64var_b: u64_t;
    //lilac:HB:stop
    //lilac:HC:start:assign value
    u64var_b = 64;
    //lilac:HC:stop

    //lilac:UA:start:declare variable and assign value
    let other_u32var_a: other_u32_t = 32;
    //lilac:UA:stop
    //lilac:UB:start:declare variable
    let other_u32var_b: other_u32_t;
    //lilac:UB:stop
    //lilac:UC:start:assign value
    other_u32var_b = 32;
    //lilac:UC:stop

    print!("u8: {} {}\n", u8var_a, u8var_b);
    print!("u16: {} {}\n", u16var_a, u16var_b);
    print!("u32: {} {}\n", u32var_a, u32var_b);
    print!("otheru32: {} {}\n", other_u32var_a, other_u32var_b);
    print!("u64: {} {}\n", u64var_a, u64var_b);
}
