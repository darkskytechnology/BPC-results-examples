/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[allow(unused_variables)]
#[allow(non_snake_case)]

fn main() -> impl std::process::Termination {
    let argv = std::env::args().collect::<Vec<_>>();
    let argc = argv.len();

    let retcode = move || -> u8 {
        let var: i32 = 4;
        if var == 4 {
            print!("Performed consequence 1");
        }
        //lilac:E:start:else if statement
        else if
        //lilac:I:start:evaluate expression variable is equal to integer
        var == 5
        //lilac:I:stop
        {
            //lilac:S+:start:print string
            print!("Performed consequence 1");
            //lilac:S+:stop
        }
        // lilac:E:stop^2
        return 0;
    }();

    return std::process::ExitCode::from(retcode);
}
