/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>

int main(int argc, char *argv[])
{
    int var = 4;
    if (var == 4)
    {
        printf("Performed consequence 1");
    }
    // lilac:E:start:else if statement
    else if (// lilac:I:start:evaluate expression variable is equal to integer
        var == 5
    // lilac:I:stop
        )
    {
        // lilac:S+:start:print string
        printf("Performed consequence 2");
        // lilac:S+:stop
    }
    // lilac:L:start:else statement
    else
    {
        // lilac:S+:start:print string
        printf("Performed consequence 2");
        // lilac:S+:stop
    }
    // lilac:L:stop^3
    // lilac:E:stop^
    return 0;
}
