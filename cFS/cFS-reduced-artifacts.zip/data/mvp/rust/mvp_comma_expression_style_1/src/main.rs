/*
Copyright (C) 2022-2024 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

fn main() {
    let mut i: i32 = 0;
    //lilac:A:start:(comma expression)
        {
  //lilac:B:start_:assign literal to variable
    i = 1
  //lilac:B:stop
    ; 
  //lilac:C:start:assign literal to variable
  i = 2
  //lilac:C:stop
        }
//lilac:A:stop
;

}
