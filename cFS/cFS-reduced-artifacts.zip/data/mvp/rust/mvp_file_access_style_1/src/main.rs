/*
Copyright (C) 2022-2024 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

use std::io::Write;

// lilac:A:start:(file pointer)
static fp: std::sync::Mutex<Option<std::fs::File>> = std::sync::Mutex::new(None);
// lilac:A:stop

fn init(
    // lilac:CP:start:(string)
    filename: &str, // lilac:CP:stop
) {
    // lilac:B:start:open a file for writing
    *fp.lock().unwrap() = std::fs::File::create(filename).ok();
    // lilac:B:stop
}

fn main() {
    let filename = "filename";

    init(filename);

    // lilac:C:start:fprintf followed by flush all:L{1}
    write!(
        fp.lock().unwrap().as_mut().unwrap(),
        "{}\n",   // lilac:CA+:start:(variable)
        filename  // lilac:CA+:stop
    )
    .unwrap();
    fp.lock().unwrap().as_mut().unwrap().flush().unwrap();
    // lilac:C:stop
}
