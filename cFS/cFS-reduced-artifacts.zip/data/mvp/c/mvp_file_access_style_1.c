/*
Copyright (C) 2022-2024 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#include <stdio.h>

// lilac:A:start:(file pointer)
static FILE *fp;
// lilac:A:stop

void init(
    // lilac:CP:start:(string)
    char *filename
    // lilac:CP:stop
)
{
    // lilac:B:start:open a file for writing:L
    fp = fopen(filename, "w");
    // lilac:B:stop
}

int main(int argc, char *argv[])
{
    char *filename = "filename";

    init(filename);

    // lilac:C:start:fprintf followed by flush all:L{1}
    fprintf(
        fp,
        "%s\n",
        // lilac:CA+:start:(variable)
        filename
        // lilac:CA+:stop
    );
    fflush(NULL);
    // lilac:C:stop
}