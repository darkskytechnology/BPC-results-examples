/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[derive(Clone, Default)]
pub struct data {
    pub var: i32,
}

fn main() {
    let reference: i32 = 20;
    let mut var = 10;
    let mut data = data { var: 10 };
    let mut dataptr = Some(std::rc::Rc::new(std::cell::RefCell::new(data.clone())));
    
    // lilac:U:start:update plus expression
    var +=
        //lilac:L:start:(variable)
        reference
        //lilac:L:stop^
    ;
    // lilac:U:stop
}