/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[derive(Clone, Default)]
pub struct other {
    pub val: f64,
}

// lilac:A:start:(define struct)
#[derive(Clone, Default)]
pub struct user_defined {
    // lilac:B+:start:(define field)
    pub field: f32,
    // lilac:B+:stop
}
// lilac:A:stop

// lilac:U:start:(define union)
pub union union_user_defined {
    // lilac:UB+:start:(define field)
    pub field: std::mem::ManuallyDrop<f32>,
    // lilac:UB+:stop
}
// lilac:U:stop

fn main()
{
    // lilac:C:start:declare variable
    let mut var: user_defined = user_defined::default();
    // lilac:C:stop

    let access =
    // lilac:D:start:(field)
    var.field
    // lilac:D:stop
    ;

    // lilac:E:start:(assign field)
    var.field = 
    // lilac:F:start:(value)
    access
    // lilac:F:stop^
    ;
    // lilac:E:stop

}