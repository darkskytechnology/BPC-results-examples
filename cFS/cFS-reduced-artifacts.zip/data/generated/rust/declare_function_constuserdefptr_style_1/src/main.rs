/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[derive(Clone, Default)]
pub struct other {
    pub val: f64,
}

pub type user_t = other;

//lilac:A:start:declare function
pub fn func_name(
//lilac:B+:start:(arguments)
//lilac:BA:start:(arg)
a: Option<std::rc::Rc<std::cell::RefCell<user_t>>>,
//lilac:BA:stop
//lilac:BB:start:(arg)
b: Option<std::rc::Rc<std::cell::RefCell<user_t>>>
//lilac:BB:stop
//lilac:B+:stop
) -> Option<std::rc::Rc<std::cell::RefCell<user_t>>> {
  //lilac:C+:start:(return)
  return a;
  //lilac:C+:stop
}
//lilac:A:stop

//lilac:V:start:declare function
pub fn no_arg_function() -> Option<std::rc::Rc<std::cell::RefCell<user_t>>> {
  //lilac:VA+:start:(body)
  //lilac:VAA:start:declare variable
  let a: Option<std::rc::Rc<std::cell::RefCell<user_t>>> = Default::default();
  //lilac:VAA:stop
  //lilac:VAB:start:(return)
  return a;
  //lilac:VAB:stop
  //lilac:VA+:stop
}
//lilac:V:stop

//lilac:W:start:declare function
pub fn no_arg_function_void() -> Option<std::rc::Rc<std::cell::RefCell<user_t>>> {
  //lilac:WA+:start:(body)
  //lilac:WAA:start:declare variable
  let a: Option<std::rc::Rc<std::cell::RefCell<user_t>>> = Default::default();
  //lilac:WAA:stop
  //lilac:WAB:start:(return)
  return a;
  //lilac:WAB:stop
  //lilac:WA+:stop
}
//lilac:W:stop

fn main()
{
}