/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[derive(Clone, Default)]
pub struct other {
    pub val: f64,
}


#[derive(Copy, Clone)]
pub union other_union {
    pub val: f64,
}

impl Default for other_union {
    fn default() -> other_union {
        unsafe { std::mem::MaybeUninit::<other_union>::zeroed().assume_init() }
    }
}

pub type user_t = other;

// lilac:A:start:(define struct)
#[derive(Clone, Default)]
pub struct user_defined {
    // lilac:B+:start:(define field)
    pub field: i8,
    // lilac:B+:stop
}
// lilac:A:stop

// lilac:P:start:(define packed struct)
#[derive(Default)]
#[repr(packed)]
pub struct user_defined_packed {
    // lilac:PB+:start:(define field)
    pub field: i8,
    // lilac:PB+:stop
}
// lilac:P:stop

pub struct user_defined_with_array {
    // lilac:WA:start:(define array field)
    pub array: [i8; 
    //lilac:WAE:start:(expression)
    10
    //lilac:WAE:stop
    ],
    // lilac:WA:stop
}

// lilac:U:start:(define union)
pub union union_user_defined {
    // lilac:UB+:start:(define fields)
    // lilac:UBA:start:(define field)
    pub field: std::mem::ManuallyDrop<i8>,
    // lilac:UBA:stop
    // lilac:UBB:start:(define array field)
    pub array: [std::mem::ManuallyDrop<i8>; 
    //lilac:UBBE:start:(expression)
    10
    //lilac:UBBE:stop
    ],
    // lilac:UBB:stop
    // lilac:UB+:stop
}

impl Default for union_user_defined {
    fn default() -> union_user_defined {
        unsafe { std::mem::MaybeUninit::<union_user_defined>::zeroed().assume_init() }
    }
}
// lilac:U:stop


fn main()
{
    // lilac:C:start:(declare struct)
    let mut var: user_defined = user_defined::default();
    // lilac:C:stop

    let access =
    // lilac:D:start:field expression
    // lilac:DA:start_:identifier
    var
    // lilac:DA:stop
    .field
    // lilac:D:stop
    ;

    // lilac:E:start:(assign field)
    var.field = 
    // lilac:F:start:(value)
    access
    // lilac:F:stop^
    ;
    // lilac:E:stop

}