/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[derive(Clone, Default)]
pub struct other {
    pub val: f64,
}

pub type user_t = other;

#[derive(Clone, Default)]
pub struct user_defined {
    // lilac:A:start:(define field)
    pub field1: user_t,
    // lilac:A:stop
    // lilac:B:start:(define two fields)
    pub field2: user_t,
    pub field3: user_t,
    // lilac:B:stop
    // lilac:C:start:(define three fields)
    pub field4: user_t,
    pub field5: user_t,
    pub field6: user_t,
    // lilac:C:stop
}

fn main()
{
    // lilac:D:start:(define field)
    let field1: user_t = Default::default();
    // lilac:D:stop
    // lilac:E:start:(define two fields)
    let field2: user_t = Default::default();
    let field3: user_t = Default::default();
    // lilac:E:stop
    // lilac:F:start:(define three fields)
    let field4: user_t = Default::default();
    let field5: user_t = Default::default();
    let field6: user_t = Default::default();
    // lilac:F:stop
}