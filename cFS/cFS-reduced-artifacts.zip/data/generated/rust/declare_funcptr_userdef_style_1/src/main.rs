/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

#[derive(Clone, Default)]
pub struct other {
    pub val: f64,
}

pub type user_t = other;

//lilac:A:start:declare typedef for a function pointer
pub type func_name = fn(
//lilac:B*:start:(arguments)
//lilac:BA:start:(arg)
a: user_t,
//lilac:BA:stop
//lilac:BB:start:(arg)
b: user_t
//lilac:BB:stop
//lilac:B*:stop
) -> user_t ;
//lilac:A:stop

//lilac:V:start:declare typedef for a void function pointer
pub type void_func_name = fn(
//lilac:VB*:start:(arguments)
//lilac:VBA:start:(arg)
a: user_t,
//lilac:VBA:stop
//lilac:VBB:start:(arg)
b: user_t
//lilac:VBB:stop
//lilac:VB*:stop
);
//lilac:V:stop

#[derive(Clone, Default)]
pub struct foo {
  //lilac:F:start:declare function pointer field
  pub func_name: Option<fn(
 //lilac:FB*:start:(arguments)
 //lilac:FBA:start:(arg)
 a: user_t,
 //lilac:FBA:stop
 //lilac:FBB:start:(arg)
 b: user_t
 //lilac:FBB:stop
 //lilac:FB*:stop
  ) -> user_t>,
  //lilac:F:stop

  //lilac:VF:start:declare void function pointer field
  pub void_func_name: Option<fn(
 //lilac:VFB*:start:(arguments)
 //lilac:VFBA:start:(arg)
 a: user_t,
 //lilac:VFBA:stop
 //lilac:VFBB:start:(arg)
 b: user_t
 //lilac:VFBB:stop
 //lilac:VFB*:stop
  )>,
  //lilac:VF:stop
}

fn function(a: user_t, b: user_t) -> user_t {
    a
}

fn main() {
    let aval: user_t = Default::default();
    let bval: user_t = Default::default();
    let cval: user_t;

    let structure: foo = foo { func_name: Some(function), void_func_name: None };

    {
      let aval = aval.clone();
      let bval = bval.clone();
      cval = //lilac:FCA:start:call a function through a structure function pointer   
      //lilac:FEXP:start_4:variable
      structure
      //lilac:FEXP:stop
      .func_name.unwrap()(
      //lilac:FCB*:start:(arguments)
      //lilac:FCBA:start:(argument)
      aval,
      //lilac:FCBA:stop
      //lilac:FCBB:start:(argument)
      bval
      //lilac:FCBB:stop
      //lilac:FCB*:stop
      )
      // lilac:FCA:stop^
      ;
    }

    //lilac:SCA:start:call a function through a structure function pointer   
    //lilac:SEXP:start_5:variable
    structure
    //lilac:SEXP:stop
    .func_name.unwrap()(
      //lilac:SCB*:start:(arguments)
      //lilac:SCBA:start:(argument)
      aval,
      //lilac:SCBA:stop
      //lilac:SCBB:start:(argument)
      bval
      //lilac:SCBB:stop
      //lilac:SCB*:stop
    );
    // lilac:SCA:stop
}