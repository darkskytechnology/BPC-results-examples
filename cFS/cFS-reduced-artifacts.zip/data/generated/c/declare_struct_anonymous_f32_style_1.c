/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

struct other
{
    double val;
};

// lilac:A:start:(define struct)
typedef struct 
{
    // lilac:B+:start:(define field)
    float field;
    // lilac:B+:stop
} user_defined;
// lilac:A:stop

// lilac:U:start:(define union)
typedef union 
{
    // lilac:UB+:start:(define field)
    float field;
    // lilac:UB+:stop
} union_user_defined;
// lilac:U:stop

int main(int argc, char *argv[])
{
    // lilac:C:start:declare variable
    user_defined var;
    // lilac:C:stop

    float access =
    // lilac:D:start:(field)
    var.field
    // lilac:D:stop^
    ;

    // lilac:E:start:(assign field)
    var.field = 
    // lilac:F:start:(value)
    access
    // lilac:F:stop^
    ;
    // lilac:E:stop


    return 0;
}