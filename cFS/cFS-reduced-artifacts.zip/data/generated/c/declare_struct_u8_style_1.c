/*
Copyright (C) 2022-2023 Dark Sky Technology, Inc. - All Rights Reserved

This file is part of Bulletproof Code. Unauthorized copying of this file, via any
medium is strictly prohibited. Proprietary and confidential.

Acknowledgment of Support and Disclaimer:
This material is based upon work supported by the Defense Advanced Research
Projects Agency (DARPA) under Small Business Innovative Research (SBIR) Contract
Number HR001123C0078. Any opinions, findings and conclusions or recommendations
expressed in this material are those of the author(s) and do not necessarily
reflect the views of DARPA.
*/

struct other
{
    double val;
};

union other_union {
    double val;
};

typedef struct other user_t;

// lilac:A:start:(define struct)
struct user_defined
{
    // lilac:B+:start:(define field)
    unsigned char field;
    // lilac:B+:stop
};
// lilac:A:stop

// lilac:P:start:(define packed struct)
struct user_defined_packed
{
    // lilac:PB+:start:(define field)
    unsigned char field;
    // lilac:PB+:stop
} __attribute__((packed));
// lilac:P:stop

struct user_defined_with_array
{
    // lilac:WA:start:(define array field)
    unsigned char array[
      //lilac:WAE:start:(expression)
      10
      //lilac:WAE:stop
      ];
    // lilac:WA:stop
};

// lilac:U:start:(define union)
union union_user_defined
{
    // lilac:UB+:start:(define fields)
    // lilac:UBA:start:(define field)
    unsigned char field;
    // lilac:UBA:stop
    // lilac:UBB:start:(define array field)
    unsigned char array[
      //lilac:UBBE:start:(expression)
      10
      //lilac:UBBE:stop
    ];
    // lilac:UBB:stop
    // lilac:UB+:stop
};
// lilac:U:stop

int main(int argc, char *argv[])
{
    // lilac:C:start:(declare struct)
    struct user_defined var;
    // lilac:C:stop

    unsigned char access =
    // lilac:D:start:field expression
    // lilac:DA:start_:identifier
    var
    // lilac:DA:stop
    .field
    // lilac:D:stop^
    ;

    // lilac:E:start:(assign field)
    var.field = 
    // lilac:F:start:(value)
    access
    // lilac:F:stop^
    ;
    // lilac:E:stop


    return 0;
}