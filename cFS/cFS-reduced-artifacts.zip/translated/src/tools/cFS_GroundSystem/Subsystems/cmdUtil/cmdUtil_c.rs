#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use cFS_reduced::tools::cFS_GroundSystem::Subsystems::cmdUtil::SendUdp_c::SendUdp;
use cFS_reduced::translate_bpc_vpp;
// USE STATEMENTS END
/* **********************************************************************
 * NASA Docket No. GSC-18,719-1, and identified as “core Flight System: Bootes”
 *
 * Copyright (c) 2020 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/
/*
 * Command utility. This program will build a Command packet
 * with variable parameters and send it on a UDP network socket.
 * this program is primarily used to command a cFS flight software system.
 */
/* System define for endian functions */
/*
 * System includes
 */
/*
 * Defines
 */
/* Max sizes */
/* Protocol names - for interpreting protocol argument */
/* Endian strings - related to MAX_ENDIAN_SIZE, don't exceed */
/* Destination default values */
/*
 * Packet default values
 * NOTE: Defaulting for backwards compatibility, make sure values match protocol or override in cmd line
 */
/*
 * Parameter datatype structure
 */

# [ derive ( Clone , Default ) ] pub struct CommandData_t { 
pub HostName : [ i8 ;

32 
] , 
/* Host name like "localhost" or "192.168.0.121" */

pub PortNum : [ i8 ;

16 
] , 
/* Port number */

pub CCSDS_Pri : [ uint16_t ;

3 
] , 
/* CCSDS Primary Header (always big endian)
                                            * index  mask    ------------ description ----------------
                                            *   0   0xE000 : Packet Version number: CCSDS Version 1 = b000
                                            *   0   0x1000 : Packet Type:           0 = TLM, 1 = CMD
                                            *   0   0x0800 : Sec Hdr Flag:          0 = absent, 1 = present
                                            *   0   0x07FF : Application Process Identifier
                                            *   1   0xC000 : Sequence Flags:        b00 = continuation
                                            *                                       b01 = first segment
                                            *                                       b10 = last segment
                                            *                                       b11 = unsegmented
                                            *   1   0x3FFF : Packet Sequence Count or Packet Name
                                            *   2   0xFFFF : Packet Data Length: (total packet length) - 7
                                            */

pub CCSDS_Ext : [ uint16_t ;

2 
] , 
/* CCSDS Extended Header (always big endian)
                                            * index  mask    ------------ description ----------------
                                            *   0   0xF800 : EDS Version for packet definition used
                                            *   0   0x0400 : Endian:        Big = 0, Little (Intel) = 1
                                            *   0   0x0200 : Playback flag: 0 = original, 1 = playback
                                            *   0   0x01FF : APID Qualifier (Subsystem Identifier)
                                            *   1   0xFFFF : APID Qualifier (System Identifier)
                                            */

pub CFS_CmdSecHdr : uint16_t , 
/* cFS standard secondary command header (always big endian)
                                            * index  mask    ------------ description ----------------
                                            *   0   0x8000 : Reserved
                                            *   0   0x7F00 : Command Function Code
                                            *   1   0x00FF : Command Checksum
                                            */

pub BigEndian : _Bool , 
/* Endian default, false means little endian */

pub Verbose : _Bool , 
/* Verbose option */

pub IncludeCCSDSPri : _Bool , 
/* Include CCSDS Primary Header */

pub IncludeCCSDSExt : _Bool , 
/* Include CCSDS Secondary Header */

pub IncludeCFSSec : _Bool , 
/* Include cFS Command Secondary Header */

pub OverridePktType : _Bool , 
/* Override packet type field */

pub OverridePktSec : _Bool , 
/* Override packet secondary header exists field */

pub OverridePktSeqFlg : _Bool , 
/* Override packet sequence flags */

pub OverridePktLen : _Bool , 
/* Override packet length field */

pub OverridePktEndian : _Bool , 
/* Override packet endian field */

pub OverridePktCksum : _Bool , 
/* Override packet checksum */

pub Packet : [ u8 ;

1024 
] , 
/* Data packet to send */
}


/*
 * getopts parameter passing options string
 */

// static const char *optString = "A:B:C:D:E:F:G:H:I:J:L:P:Q:R:S:T:U:V:Y:b:d:f:h:i:j:k:l:m:n:o:p:q:s:vw:x:y:?";
const OPT_STRING: &str = "A:B:C:D:E:F:G:H:I:J:L:P:Q:R:S:T:U:V:Y:b:d:f:h:i:j:k:l:m:n:o:p:q:s:vw:x:y:?"; 
/*
 * getopts_long long form argument table
 */

// static struct option longOpts[] = {{"pktapid", 1, ((void *)0), 'A'},
//                                    {"pktpb", 1, ((void *)0), 'B'},
//                                    {"cmdcode", 1, ((void *)0), 'C'},
//                                    {"pktfc", 1, ((void *)0), 'C'},
//                                    {"pktedsver", 1, ((void *)0), 'D'},
//                                    {"endian", 1, ((void *)0), 'E'},
//                                    {"pktseqflg", 1, ((void *)0), 'F'},
//                                    {"pktname", 1, ((void *)0), 'G'},
//                                    {"pktseqcnt", 1, ((void *)0), 'G'},
//                                    {"host", 1, ((void *)0), 'H'},
//                                    {"pktid", 1, ((void *)0), 'I'},
//                                    {"pktendian", 1, ((void *)0), 'J'},
//                                    {"pktlen", 1, ((void *)0), 'L'},
//                                    {"port", 1, ((void *)0), 'P'},
//                                    {"protocol", 1, ((void *)0), 'Q'},
//                                    {"pktcksum", 1, ((void *)0), 'R'},
//                                    {"pktsec", 1, ((void *)0), 'S'},
//                                    {"pkttype", 1, ((void *)0), 'T'},
//                                    {"pktsubsys", 1, ((void *)0), 'U'},
//                                    {"pktver", 1, ((void *)0), 'V'},
//                                    {"pktsys", 1, ((void *)0), 'Y'},
//                                    {"byte", 1, ((void *)0), 'b'},
//                                    {"int8", 1, ((void *)0), 'b'},
//                                    {"double", 1, ((void *)0), 'd'},
//                                    {"float", 1, ((void *)0), 'f'},
//                                    {"half", 1, ((void *)0), 'h'},
//                                    {"int16", 1, ((void *)0), 'h'},
//                                    {"int16b", 1, ((void *)0), 'i'},
//                                    {"int32b", 1, ((void *)0), 'j'},
//                                    {"int64b", 1, ((void *)0), 'k'},
//                                    {"long", 1, ((void *)0), 'l'},
//                                    {"word", 1, ((void *)0), 'l'},
//                                    {"int32", 1, ((void *)0), 'l'},
//                                    {"uint8", 1, ((void *)0), 'm'},
//                                    {"uint16", 1, ((void *)0), 'n'},
//                                    {"uint32", 1, ((void *)0), 'o'},
//                                    {"uint64", 1, ((void *)0), 'p'},
//                                    {"int64", 1, ((void *)0), 'q'},
//                                    {"string", 1, ((void *)0), 's'},
//                                    {"verbose", 0, ((void *)0), 'v'},
//                                    {"uint16b", 1, ((void *)0), 'w'},
//                                    {"uint32b", 1, ((void *)0), 'x'},
//                                    {"uint64b", 1, ((void *)0), 'y'},
//                                    {"help", 0, ((void *)0), '?'},
//                                    {0, 0, 0, 0}};
static longOpts: [Option; 44] = [
    Option { name: "pktapid", has_arg: RequiredArgument, flag: None, val: 'A' as i32 },
    Option { name: "pktpb", has_arg: RequiredArgument, flag: None, val: 'B' as i32 },
    Option { name: "cmdcode", has_arg: RequiredArgument, flag: None, val: 'C' as i32 },
    Option { name: "pktfc", has_arg: RequiredArgument, flag: None, val: 'C' as i32 },
    Option { name: "pktedsver", has_arg: RequiredArgument, flag: None, val: 'D' as i32 },
    Option { name: "endian", has_arg: RequiredArgument, flag: None, val: 'E' as i32 },
    Option { name: "pktseqflg", has_arg: RequiredArgument, flag: None, val: 'F' as i32 },
    Option { name: "pktname", has_arg: RequiredArgument, flag: None, val: 'G' as i32 },
    Option { name: "pktseqcnt", has_arg: RequiredArgument, flag: None, val: 'G' as i32 },
    Option { name: "host", has_arg: RequiredArgument, flag: None, val: 'H' as i32 },
    Option { name: "pktid", has_arg: RequiredArgument, flag: None, val: 'I' as i32 },
    Option { name: "pktendian", has_arg: RequiredArgument, flag: None, val: 'J' as i32 },
    Option { name: "pktlen", has_arg: RequiredArgument, flag: None, val: 'L' as i32 },
    Option { name: "port", has_arg: RequiredArgument, flag: None, val: 'P' as i32 },
    Option { name: "protocol", has_arg: RequiredArgument, flag: None, val: 'Q' as i32 },
    Option { name: "pktcksum", has_arg: RequiredArgument, flag: None, val: 'R' as i32 },
    Option { name: "pktsec", has_arg: RequiredArgument, flag: None, val: 'S' as i32 },
    Option { name: "pkttype", has_arg: RequiredArgument, flag: None, val: 'T' as i32 },
    Option { name: "pktsubsys", has_arg: RequiredArgument, flag: None, val: 'U' as i32 },
    Option { name: "pktver", has_arg: RequiredArgument, flag: None, val: 'V' as i32 },
    Option { name: "pktsys", has_arg: RequiredArgument, flag: None, val: 'Y' as i32 },
    Option { name: "byte", has_arg: RequiredArgument, flag: None, val: 'b' as i32 },
    Option { name: "int8", has_arg: RequiredArgument, flag: None, val: 'b' as i32 },
    Option { name: "double", has_arg: RequiredArgument, flag: None, val: 'd' as i32 },
    Option { name: "float", has_arg: RequiredArgument, flag: None, val: 'f' as i32 },
    Option { name: "half", has_arg: RequiredArgument, flag: None, val: 'h' as i32 },
    Option { name: "int16", has_arg: RequiredArgument, flag: None, val: 'h' as i32 },
    Option { name: "int16b", has_arg: RequiredArgument, flag: None, val: 'i' as i32 },
    Option { name: "int32b", has_arg: RequiredArgument, flag: None, val: 'j' as i32 },
    Option { name: "int64b", has_arg: RequiredArgument, flag: None, val: 'k' as i32 },
    Option { name: "long", has_arg: RequiredArgument, flag: None, val: 'l' as i32 },
    Option { name: "word", has_arg: RequiredArgument, flag: None, val: 'l' as i32 },
    Option { name: "int32", has_arg: RequiredArgument, flag: None, val: 'l' as i32 },
    Option { name: "uint8", has_arg: RequiredArgument, flag: None, val: 'm' as i32 },
    Option { name: "uint16", has_arg: RequiredArgument, flag: None, val: 'n' as i32 },
    Option { name: "uint32", has_arg: RequiredArgument, flag: None, val: 'o' as i32 },
    Option { name: "uint64", has_arg: RequiredArgument, flag: None, val: 'p' as i32 },
    Option { name: "int64", has_arg: RequiredArgument, flag: None, val: 'q' as i32 },
    Option { name: "string", has_arg: RequiredArgument, flag: None, val: 's' as i32 },
    Option { name: "verbose", has_arg: NoArgument, flag: None, val: 'v' as i32 },
    Option { name: "uint16b", has_arg: RequiredArgument, flag: None, val: 'w' as i32 },
    Option { name: "uint32b", has_arg: RequiredArgument, flag: None, val: 'x' as i32 },
    Option { name: "uint64b", has_arg: RequiredArgument, flag: None, val: 'y' as i32 },
    Option { name: "help", has_arg: NoArgument, flag: None, val: '?' as i32 },
    Option { name: "", has_arg: 0, flag: None, val: 0 },
]; 
/* *****************************************************************************
 * Display program usage, and exit.
 */

pub fn DisplayUsage ( 
Name : & str , 
) { 
let endian = "LE" ;


if 
1 
{ 
strcpy ( 
endian , 

"BE" 
) ;

}



print ! ( "{} -- Command Client.\n" , Name ) ;


print ! ( "  - General options:\n" ) ;


print ! ( "    -v, --verbose: Extra output\n" ) ;


print ! ( "    -?, --help: print options and exit\n" ) ;


print ! ( "  - Destination options:\n" ) ;


print ! ( "    -H, --host: Destination hostname or IP address (Default = {})\n" , 
"127.0.0.1" 
) ;


print ! ( "    -P, --port: Destination port (default = {})\n" , 
"1234" 
) ;


print ! ( "  - Packet format options:\n" ) ;


print ! ( "    -E, --endian: Default endian for unnamed fields/payload: [{}|{}] (default = {})\n" , 
"BE" , 

"LE" , 

endian 
) ;


print ! ( "    -Q, --protocol: Sets allowed named fields and header layout (default = {})\n" , 
"cfsv1" 
) ;


print ! ( "        {:>8} = no predefined fields/layout\n" , 
"raw" 
) ;


print ! ( "        {:>8} = CCSDS Pri header only\n" , 
"ccsdspri" 
) ;


print ! ( "        {:>8} = CCSDS Pri and Ext headers\n" , 
"ccsdsext" 
) ;


print ! ( "        {:>8} = CCSDS Pri and cFS Cmd Sec headers\n" , 
"cfsv1" 
) ;


print ! ( "        {:>8} = CCSDS Pri, Ext, and cFS Cmd Sec headers\n" , 
"cfsv2" 
) ;


print ! ( "  - CCSDS Primary Header named fields (protocol=[{}|{}|{}|{}])\n" , 
"ccsdspri" , 

"ccsdsext" , 

"cfsv1" , 

"cfsv2" 
) ;


print ! ( "    -I, --pktid: macro for setting first 16 bits of CCSDS Primary header\n" ) ;


print ! ( "    -V, --pktver: Packet version number (range=0-0x7)\n" ) ;


print ! ( "    -T, --pkttype: !OVERRIDE! Packet type (default is cmd, 0=tlm, 1=cmd)\n" ) ;


print ! ( "    -S, --pktsec: !OVERRIDE! Secondary header flag (default set from protocol, 0=absent, 1=present)\n" ) ;


print ! ( "    -A, --pktapid: Application Process Identifier (range=0-0x7FF)\n" ) ;


print ! ( "    -F, --pktseqflg: !OVERRIDE! Sequence Flags (default unsegmented, 0=continuation, 1=first, 2=last, 3=unsegmented)\n" ) ;


print ! ( "    -G, --pktseqcnt, --pktname: Packet sequence count or Packet name (range=0-0x3FFF)\n" ) ;


print ! ( "    -L, --pktlen: !OVERRIDE! Packet data length (default will calculate value, range=0-0xFFFF)\n" ) ;


print ! ( "  - CCSDS Extended Header named fields (protocol=[{}|{}])\n" , 
"ccsdsext" , 

"cfsv2" 
) ;


print ! ( "    -D, --pktedsver: EDS version (range=0-0x1F)\n" ) ;


print ! ( "    -J, --pktendian: !OVERRIDE! Endian (default uses endian, 0=big, 1=little(INTEL))\n" ) ;


print ! ( "    -B, --pktpb: Playback field (0=original, 1=playback)\n" ) ;


print ! ( "    -U, --pktsubsys: APID Qualifier Subsystem (range=0-0x1FF)\n" ) ;


print ! ( "    -Y, --pktsys: APID Qualifier System (range=0-0xFFFF)\n" ) ;


print ! ( "  - cFS Command Secondary Header named fields (protocol=[{}|{}])\n" , 
"cfsv1" , 

"cfsv2" 
) ;


print ! ( "    -C, --pktfc, --cmdcode: Command function code (range=0-0x7F)\n" ) ;


print ! ( "    -R, --pktcksum: !OVERRIDE! Packet checksum (default will calculate value, range=0-0xFF)\n" ) ;


print ! ( "  - Raw values converted to selected endian where applicable\n" ) ;


print ! ( "    -b, --int8, --byte: Signed 8 bit int (range=-127-127)\n" ) ;


print ! ( "    -m, --uint8: Unsigned 8 bit int (range=0-0xFF)\n" ) ;


print ! ( "    -h, --int16, --half: Signed 16 bit int (range=-32767-32767)\n" ) ;


print ! ( "    -n, --uint16: Unsigned 16 bit int (range=0-0xFFFF)\n" ) ;


print ! ( "    -l, --int32, --long, --word: Signed 32 bit int (range=-2147483647-2147483647)\n" ) ;


print ! ( "    -o, --uint32: Unsigned 32 bit int (range=0-0xFFFFFFFF)\n" ) ;


print ! ( "    -q, --int64: Signed 64 bit int (range=-9223372036854775807-9223372036854775807)\n" ) ;


print ! ( "    -p, --uint64: Unsigned 64 bit int (range=0-0xFFFFFFFFFFFFFFFF)\n" ) ;


print ! ( "    -d, --double: Double format (caution - host format w/ converted endian, may not match target)\n" ) ;


print ! ( "    -f, --float: Float format (caution - host format w/ converted endian, may not match target)\n" ) ;


print ! ( "    -s, --string: Fixed length string, NNN:String where NNN is fixed length (0 padded)\n" ) ;


print ! ( "  - Raw values always big endian (even if endian={})\n" , 
"LE" 
) ;


print ! ( "    -i, --int16b: Big endian signed 16 bit int (range=-32767-32767)\n" ) ;


print ! ( "    -j, --int32b: Big endian signed 32 bit int (range=-2147483647-2147483647)\n" ) ;


print ! ( "    -k, --int64b: Big endian signed 64 bit int (range=-9223372036854775807-9223372036854775807)\n" ) ;


print ! ( "    -w, --uint16b: Big endian unsigned 16 bit int (range=0-0xFFFF)\n" ) ;


print ! ( "    -x, --uint32b: Big endian unsigned 32 bit int (range=0-0xFFFFFFFF)\n" ) ;


print ! ( "    -y, --uint64b: Big endian unsigned 64 bit int (range=0-0xFFFFFFFFFFFFFFFF)\n" ) ;


print ! ( " \n" ) ;


print ! ( "Examples:\n" ) ;


print ! ( "  ./cmdUtil --host=localhost --port=1234 --pktid=0x1803 --pktfc=3 --int16=100 --string=16:ES_APP\n" ) ;


print ! ( "  ./cmdUtil -ELE -C2 -A6 -n2 # Processor reset on little endian, using defaults\n" ) ;


print ! ( "  ./cmdUtil --endian=LE --protocol=raw --uint64b=0x1806C000000302DD --uint16=2\n" ) ;


print ! ( "  ./cmdUtil --pktver=1 --pkttype=0 --pktsec=0 --pktseqflg=2 --pktlen=0xABC --pktcksum=0\n" ) ;


print ! ( "  ./cmdUtil -Qcfsv2 --pktedsver=0xA --pktendian=1 --pktpb=1 --pktsubsys=0x123 --pktsys=0x4321 --pktfc=0xB\n" ) ;


print ! ( " \n" ) ;


std :: process :: exit ( 0 ) ;

}


/* *****************************************************************************
 * Set the header booleans based on protocol selection
 */

pub fn SetProtocol ( 
cmd : Option < std :: rc :: Rc < std :: cell :: RefCell < CommandData_t > > > , 

protocol : & 'static str 
) { 
if 


protocol 
. is_none ( ) 
|| 

cmd 
. is_none ( ) 

{ 
fprintf ( 
stderr , 

"ERROR: %s:%u - null input, exiting\n" , 

__func__ , 

267 
) ;


std :: process :: exit ( 
1 
) ;

}


/* Clear any default setting */

cmd . as_mut ( ) . unwrap ( ) . borrow_mut ( ) . IncludeCCSDSPri = 
0 
;


cmd . as_mut ( ) . unwrap ( ) . borrow_mut ( ) . IncludeCCSDSExt = 
0 
;


cmd . as_mut ( ) . unwrap ( ) . borrow_mut ( ) . IncludeCFSSec = 
0 
;


if 

match protocol . cmp ( "ccsdspri" ) { std :: cmp :: Ordering :: Less => - 1 , std :: cmp :: Ordering :: Equal => 0 , std :: cmp :: Ordering :: Greater => 1 , }


== 
0 

{ 
cmd . as_mut ( ) . unwrap ( ) . borrow_mut ( ) . IncludeCCSDSPri = 
1 
;

}



else if 

match protocol . cmp ( "ccsdsext" ) { std :: cmp :: Ordering :: Less => - 1 , std :: cmp :: Ordering :: Equal => 0 , std :: cmp :: Ordering :: Greater => 1 , }


== 
0 

{ 
cmd . as_mut ( ) . unwrap ( ) . borrow_mut ( ) . IncludeCCSDSPri = 
1 
;


cmd . as_mut ( ) . unwrap ( ) . borrow_mut ( ) . IncludeCCSDSExt = 
1 
;

}



else if 

match protocol . cmp ( "cfsv1" ) { std :: cmp :: Ordering :: Less => - 1 , std :: cmp :: Ordering :: Equal => 0 , std :: cmp :: Ordering :: Greater => 1 , }


== 
0 

{ 
cmd . as_mut ( ) . unwrap ( ) . borrow_mut ( ) . IncludeCCSDSPri = 
1 
;


cmd . as_mut ( ) . unwrap ( ) . borrow_mut ( ) . IncludeCFSSec = 
1 
;

}



else if 

match protocol . cmp ( "cfsv2" ) { std :: cmp :: Ordering :: Less => - 1 , std :: cmp :: Ordering :: Equal => 0 , std :: cmp :: Ordering :: Greater => 1 , }


== 
0 

{ 
cmd . as_mut ( ) . unwrap ( ) . borrow_mut ( ) . IncludeCCSDSPri = 
1 
;


cmd . as_mut ( ) . unwrap ( ) . borrow_mut ( ) . IncludeCCSDSExt = 
1 
;


cmd . as_mut ( ) . unwrap ( ) . borrow_mut ( ) . IncludeCFSSec = 
1 
;

}



else if 

match protocol . cmp ( "raw" ) { std :: cmp :: Ordering :: Less => - 1 , std :: cmp :: Ordering :: Equal => 0 , std :: cmp :: Ordering :: Greater => 1 , }


!= 
0 

{ 
fprintf ( 
stderr , 

"ERROR: %s:%u - Invalid protocol: %s\n" , 

__func__ , 
const MASK: u16;protocol 
) ;


std :: process :: exit ( 
1 
) ;

}

let shift: u32 = 0;
cmd 
. Verbose 
let mut tail: Option<&mut str> = None;
303 , 

protocol 
) ;

}


}


/* *****************************************************************************
 * Process string protocol field
 *  - updates orig masked bits with big endian in masked/shifted
 *  - in = input string(unshifted)
 *  - mask = value mask, also used to calculate shift
 *  - fieldexists = process helper, returns if false
 */

pub fn ProcessField ( 
orig : Option < std :: rc :: Rc < std :: cell :: RefCell < uint16_t > > > , 

r#in : & 'static str , 

// const uint16_t mask
break 

, 

fieldexists : _Bool 
) { 
let templong : i64 ;


// unsigned int shift = 0;
break 

// char * tail = ((void *)0);
break 
/* Check for null pointer */

if 

r#in 
. is_none ( ) 
{ 
fprintf ( 
stderr , 

"ERROR: %s:%u - Null string input\n" , 

__func__ , 

322 
) ;


std :: process :: exit ( 
1 
) ;

}


/* Check for bad mask */

if 
mask == 0 
{ 
fprintf ( 
stderr , 

"ERROR: %s:%u - Zero mask returns 0\n" , 

__func__ , 

329 
) ;


std :: process :: exit ( 
1 
) ;

}


/* Check if protocol includes field */

if 
! 
fieldexists 

{ 
fprintf ( 
stderr , 

"ERROR: %s:%u - Field does not exist for selected protocol: %s\n" , 

__func__ , 

336 , 

r#in 
) ;


std :: process :: exit ( 
1 
) ;

}


/* Find shift from mask (already checked for non-zero) */

while 
( 

( 

( 
mask >> shift 
) 
& 
0x1 

) 
== 
0 

) 
{ 
translate_bpc_vpp ! ( 
shift 
) ;

}




( 

__errno_location ( ) 

) 
= 
0 
;


templong = strtoul ( 
r#in , 

& 
tail , 


, 

0 
) ;


if 

( 

__errno_location ( ) 

) 
!= 
0 

{ 
fprintf ( 
stderr , 

"ERROR: %s:%u - String conversion (%s): %s\n" , 

__func__ , 

350 , 

r#in , 

strerror ( 
( 

__errno_location ( ) 

) 
) 
) ;


std :: process :: exit ( 
1 
) ;

}



if 
tail . len ( ) 
{ 
fprintf ( 
stderr , 

"ERROR: %s:%u - Trailing characters (%s) in parameter %s\n" , 

__func__ , 

356 , 

tail , 

r#in 
) ;


std :: process :: exit ( 
1 
) ;

}



templong <<= 
shift 
;


if 

( 

templong 
& 
! mask 

) 
!= 
0 

{ 
fprintf ( 
stderr , 

"ERROR: %s:%u - Parameter 0x%lX (%s<<%u) exceeds mask 0x%X\n" , 

__func__ , 

363 , 

templong , 

r#in , 

shift , 

mask 
) ;


std :: process :: exit ( 
1 
) ;

let pkt: *mut u8;


orig 

let mut startbyte: *mut u32;( 

__bswap_16 ( 

orig 

) 
& 
! mask 

) 
| 
( 
templong & mask 
) 

) 
;

}


/* ****************************************************************************
 * Copy data into packet buffer
 */

pub fn CopyData ( 
// unsigned char *pkt
break 

, 

// unsigned int *startbyte
break 

, 

r#in : & str , 

, 

nbytes : u32 
) { /* Ensure space */

if 

( 


startbyte 

+ 
nbytes 

) 
> 
1024 

{ 
fprintf ( 
stderr , 

"ERROR %s:%u - Exceeded packet size, startbyte = %u, nbytes = %u, max = %u\n" , 

__func__ , 

381 , 


startbyte , 


, 

*startbyte += nbytes;) ;


std :: process :: exit ( 
1 
) ;

}


/* Copy data into packet buffer and move start byte */
let bbuf: *mut u8;pkt [ 

startbyte 

] 


let checksum: u8 = 0xFF;
nbytes 
) ;


// *startbyte += nbytes;
for i in 0..nbytes {
    checksum ^= bbuf[i];
} 
}


/* ****************************************************************************
 * Calculate cFS Secondary Header Checksum
 * Note - this matches cFS checksum calc in framework
 */

pub fn CalcChecksum ( 
// unsigned char *bbuf
break 

, 

nbytes : u32 
) -> u8 { 
// unsigned char checksum = 0xFF;
let star: u32; 

// for (unsigned int i = 0; i < nbytes; i++)
//         checksum ^= bbuf[i];
let pktn: u32; 

return checksum ;

char/* ****************************************************************************
 * Constructs packets given inputs and sends over UDP
 */
let tai: *mut i8;let retcode = move | | -> u8 { 
let opt : i32 = 0 ;


let longIndex : i32 = 0 ;


// unsigned int startbyte = 0;
let mut tempull: u64; 

// unsigned int pktnbytes = 0;
break 

let i : u32 = Default :: default ( ) ;


// char sbuf[1024];
break 

// char * tail = ((void *)0);
break 

let templl : i64 ;


// long long unsigned int tempull;
break 

let tempint8 : i8 ;


let tempuint8 : u8 ;


let tempint16 : i16 ;


let tempuint16 : u16 ;


let tempint32 : i32 ;


let tempuint32 : u32 ;


let tempint64 : i64 ;


let tempuint64 : u64 ;


let tempd : f64 = Default :: default ( ) ;


let tempf : f32 = Default :: default ( ) ;


let mut forcebigendian : _Bool = Default :: default ( ) ;


let mut cmd : CommandData_t = Default :: default ( ) ;


let status : i32 = Default :: default ( ) ;

/*
     * Initialize the cmd struct
     */

memset ( 
& 
( 
cmd 
) 


, 

0 , 

std :: mem :: size_of_val ( & cmd ) 
) ;

/* Set defaults */

strncpy ( 
cmd . HostName 

, 

"127.0.0.1" , 

32 - 1 
) ;


strncpy ( 
cmd . PortNum 

, 

"1234" , 

16 - 1 
) ;


cmd . BigEndian = 
1 
;


cmd . Verbose = 
0 
;


SetProtocol ( 
& 
cmd , 


, 

"cfsv1" 
) ;

/* Process general options first, protocol is critical for checking */

while 
( 

( 

opt 
= 
getopt_long ( 
argc , 

argv , 
match 'H' {
    'H' => { // host
        cmd.HostName[..MAX_HOSTNAME_SIZE - 1].copy_from_slice(&optarg.as_bytes()[..MAX_HOSTNAME_SIZE - 1.min(optarg.len())]);
        if cmd.HostName != optarg {
            eprintln!("ERROR: {}:{} - Truncating host name: {} -> {}", __func__, line!(), optarg, String::from_utf8_lossy(&cmd.HostName));
            std::process::exit(libc::EXIT_FAILURE);
        }
    },
    _ => {}
}!= 
-1 
case 'P': /* port */
    {
        let optarg_bytes = optarg.as_bytes();
        let max_len = MAX_PORT_SIZE - 1;
        if optarg_bytes.len() > max_len {
            eprintln!("ERROR: {}:{} - Truncating port number: {} -> {}", __func__, __LINE__, optarg, cmd.HostName);
            std::process::exit(EXIT_FAILURE);
        }
        cmd.PortNum[..optarg_bytes.len()].copy_from_slice(&optarg_bytes[..]);
        cmd.PortNum[optarg_bytes.len()] = 0; // Null-terminate
    }
    match 'v' {
    'v' => {
        cmd.Verbose = true;
    },
    _ => {},
};//                             cmd.HostName);
//                     exit(1);
//                 }
//                 ;
 

// case 'P': /* port */
//                 strncpy(cmd.PortNum, optarg, 16 - 1);
//                 if (strcmp(cmd.PortNum, optarg) != 0)
//                 {
//                     fprintf(stderr, "ERROR: %s:%u - Trucating port number: %s -> %s\n", __func__, 463, optarg,
//                             cmd.HostName);
//                     exit(1);
//                 }
//                 match optarg {
    ENDIAN_LITTLE => {
        cmd.BigEndian = false;
match 'Q' {
    'Q' => {
        SetProtocol(&mut cmd, optarg);
    },
    _ => {},
match '?' {
    '?' => { // help
        DisplayUsage(argv[0]);
    },
    _ => (),
}
// case 'v': /* verbose */
//                 cmd.Verbose = 1;
//                 break;
break 

// case 'E': /* endian */
//                 if (strcmp(optarg, "LE") == 0)
//                 {
//                     cmd.BigEndian = 0;
//                 }
//                 else if (strcmp(optarg, "BE") == 0)
//                 {
//                     cmd.BigEndian = 1;
//                 }
//                 else
//                 {
//                     fprintf(stderr, "ERROR: %s:%u - Unrecognized endian selection: %s\n", __func__, 484, optarg);
//                     exit(1);
//                 }
//                 break;
break 

// case 'Q': /* protocol */
//                 SetProtocol(&cmd, optarg);
//                 break;
break 

// case '?': /* help */
//                 DisplayUsage(argv[0]);
//                 break;
break 
_ => { }

}


}


/* Reset op list for protocol field processing */

optind = 1 ;

match 'I' {
    'I' => { // pktid
        ProcessField(&mut cmd.CCSDS_Pri[0], optarg, 0xFFFF, cmd.IncludeCCSDSPri);
    },
    _ => {},
match 'V' {
    'V' => { // pktver
        ProcessField(&mut cmd.CCSDS_Pri[0], optarg, 0xE000, cmd.IncludeCCSDSPri);
    },
    _ => {},
match 'T' { /* pkttype */
    'T' => {
        ProcessField(&mut cmd.CCSDS_Pri[0], optarg, 0x1000, cmd.IncludeCCSDSPri);
        cmd.OverridePktType = true;
    },
    _ => (),
match 'S' {
    'S' => { // pktsec
        ProcessField(&mut cmd.CCSDS_Pri[0], optarg, 0x0800, cmd.IncludeCCSDSPri);
        cmd.OverridePktSec = true;
    },
    _ => {},
match 'A' {
    /* pktapid */
    'A' => {
        ProcessField(&mut cmd.CCSDS_Pri[0], optarg, 0x07FF, cmd.IncludeCCSDSPri);
    },
match 'F' { /* pktseqflg */
    'F' => {
        ProcessField(&mut cmd.CCSDS_Pri[1], optarg, 0xC000, cmd.IncludeCCSDSPri);
        cmd.OverridePktSeqFlg = true;
    },
    _ => (),
}
// case 'I': /* pktid */
//                 ProcessField(&cmd.CCSDS_Pri[0], optarg, 0xFFFF, cmd.IncludeCCSDSPri);
//                 match 'G' {
    'G' => { // pktseqcnt
match 'L' {
    'L' => { // pktlen
        ProcessField(&mut cmd.CCSDS_Pri[2..], optarg, 0xFFFF, cmd.IncludeCCSDSPri);
        cmd.OverridePktLen = true;
    },
    _ => {},
}// case 'V': /* pktver */
//                 ProcessField(&cmd.CCSDS_Pri[0], optarg, 0xE000, cmd.IncludeCCSDSPri);
//                 match 'D' {
    'D' => { // pktedsver
        ProcessField(&mut cmd.CCSDS_Ext[0], optarg, 0xF800, cmd.IncludeCCSDSExt);
    },
match 'J' { /* pktendian */
    'J' => {
        ProcessField(&mut cmd.CCSDS_Ext[0], optarg, 0x0400, cmd.IncludeCCSDSExt);
        cmd.OverridePktEndian = true;
    },
    _ => (),
}//                 cmd.OverridePktType = 1;
//                 match 'B' {
    'B' => {
        ProcessField(&mut cmd.CCSDS_Ext[0], optarg, 0x0200, cmd.IncludeCCSDSExt);
    },
match 'U' {
    'U' => { // pktsubsys
        ProcessField(&mut cmd.CCSDS_Ext[0], optarg, 0x01FF, cmd.IncludeCCSDSExt);
    },
    _ => (),
}//                 ProcessField(&cmd.CCSDS_Pri[0], optarg, 0x0800, cmd.IncludeCCSDSPri);
//                 cmd.OverridePktSec = 1;
//                 match 'Y' {
    // pktsys
    'Y' => {
        ProcessField(&mut cmd.CCSDS_Ext[1], optarg, 0xFFFF, cmd.IncludeCCSDSExt);
match 'C' {
    'C' => {
        ProcessField(&mut cmd.CFS_CmdSecHdr, optarg, 0x7F00, cmd.IncludeCFSSec);
    },
    _ => {},
}// case 'A': /* pktapid */
//                 ProcessField(&cmd.CCSDS_Pri[0], optarg, 0x07FF, cmd.IncludeCCSDSPri);
//                 match 'R' { /* pktcksum */
    'R' => {
        ProcessField(&mut cmd.CFS_CmdSecHdr, optarg, 0x00FF, cmd.IncludeCFSSec);
        cmd.OverridePktCksum = true;
    },
    _ => (),
};
 

// case 'F': /* pktseqflg */
//                 ProcessField(&cmd.CCSDS_Pri[1], optarg, 0xC000, cmd.IncludeCCSDSPri);
//                 cmd.OverridePktSeqFlg = 1;
//                 break;
break 

// case 'G': /* pktseqcnt */
//                 ProcessField(&cmd.CCSDS_Pri[1], optarg, 0x3FFF, cmd.IncludeCCSDSPri);
//                 break;
break 

// case 'L': /* pktlen */
//                 ProcessField(&cmd.CCSDS_Pri[2], optarg, 0xFFFF, cmd.IncludeCCSDSPri);
//                 cmd.OverridePktLen = 1;
//                 break;
break 
/* CCSDS Extended fields */

// case 'D': /* pktedsver */
//                 ProcessField(&cmd.CCSDS_Ext[0], optarg, 0xF800, cmd.IncludeCCSDSExt);
//                 break;
break 

// case 'J': /* pktendian */
//                 ProcessField(&cmd.CCSDS_Ext[0], optarg, 0x0400, cmd.IncludeCCSDSExt);
//                 cmd.OverridePktEndian = 1;
//                 break;
break 

// case 'B': /* pktpb */
//                 ProcessField(&cmd.CCSDS_Ext[0], optarg, 0x0200, cmd.IncludeCCSDSExt);
//                 break;
break 

// case 'U': /* pktsubsys */
//                 ProcessField(&cmd.CCSDS_Ext[0], optarg, 0x01FF, cmd.IncludeCCSDSExt);
//                 break;
std::mem::size_of_val(&cmd.CCSDS_Pri) 

// case 'Y': /* pktsys */
//                 ProcessField(&cmd.CCSDS_Ext[1], optarg, 0xFFFF, cmd.IncludeCCSDSExt);
//                 break;
break 
/* CFS Secondary fields */

// case 'C': /* pktfc */
//                 ProcessField(&cmd.CFS_CmdSecHdr, optarg, 0x7F00, cmd.IncludeCFSSec);
//                 break;
break 
std::mem::size_of_val(&cmd.CCSDS_Ext)//                 cmd.OverridePktCksum = 1;
//                 break;
break 
_ => { }

}


}


/* Print arguments (useful when debugging internal call) */
std::mem::size_of_val(&cmd.CFS_CmdSecHdr){ 
print ! ( "Call echo:\n" ) ;


i = 0 ;
while 
i 
< 
argc 
{ 
print ! ( " {}" , 
argv [ i ] 
) ;


translate_bpc_vpp ! ( i ) 
}



print ! ( "\n" ) ;

}


/* Calculate data start byte, these get copied over later */

if 
cmd . IncludeCCSDSPri 
{ 
startbyte += 
// sizeof(cmd.CCSDS_Pri)
break 
;

}



if 
cmd . IncludeCCSDSExt 
{ 
startbyte += 
// sizeof(cmd.CCSDS_Ext)
break 
;

}



if 
cmd . IncludeCFSSec 
{ 
startbyte += 
// sizeof(cmd.CFS_CmdSecHdr)
break 
;

}


/* Round up to account for padding */

startbyte += 
startbyte % 8 
;


if 
cmd . Verbose 
{ 
print ! ( "Payload start byte = {}\n" , startbyte ) ;
match 'b' {
    'b' => { // int8
        let templl = optarg.parse::<i64>().unwrap();
        let tempint8 = templl as i8;
        if tempint8 as i64 != templl {
            eprintln!("ERROR {}:{} - Parameter not int8 {} -> {}", __func__, line!(), templl, tempint8);
            std::process::exit(libc::EXIT_FAILURE);
        }
        CopyData(cmd.Packet, &mut startbyte, &tempint8.to_ne_bytes(), std::mem::size_of::<i8>());
    },
    _ => {}
}( 

match 'm' {
    'm' => { // uint8
        let tempull = optarg.parse::<u64>().unwrap();
        let tempuint8 = tempull as u8;
        if tempuint8 as u64 != tempull {
            eprintln!("ERROR {}:{} - Parameter not uint8 {} -> {}", 
                      std::module_path!(), line!(), tempull, tempuint8);
            std::process::exit(libc::EXIT_FAILURE);
        }
        CopyData(cmd.Packet, &mut startbyte, &tempuint8.to_ne_bytes(), std::mem::size_of::<u8>());
    },
    _ => {}
}
case 'i': /* int16b */
                forcebigendian = tr-1 

) 
match 'h' {
    'h' => { // int16
        let templl = optarg.parse::<i64>().unwrap_or_else(|_| {
            eprintln!("ERROR {}:{} - Parameter not int16", __func__, __LINE__);
            std::process::exit(libc::EXIT_FAILURE);
        });
        let tempint16 = templl as i16;
        if tempint16 as i64 != templl {
            eprintln!("ERROR {}:{} - Parameter not int16 {} -> {}", __func__, __LINE__, templl, tempint16);
            std::process::exit(libc::EXIT_FAILURE);
        }

        // Endian conversion
        let tempint16 = if cmd.BigEndian || forcebigendian {
            tempint16.to_be()
        } else {
            tempint16.to_le()
        };

        CopyData(cmd.Packet, &mut startbyte, &tempint16.to_ne_bytes(), std::mem::size_of::<i16>());
case 'w': /* uint16b */
                forcebigendian = tr//                 if (tempint8 != templl)
//                 {
//                     fprintf(stderr, "ERROR %s:%u - Parameter not int8 %lld -> %d\n", __func__, 627, templl,
//                             tempint8);
//                     exit(1);
//                 }
//                 CopyData(cmd.Packet, &startbyte, (char *)&tempint8, sizeof(tempint8));
//                 match 'n' {
    'n' => {
        let tempull = optarg.parse::<u64>().unwrap_or_else(|_| {
            eprintln!("ERROR {}:{} - Parameter not uint16", __func__, __LINE__);
            std::process::exit(libc::EXIT_FAILURE);
        });
        let tempuint16 = tempull as u16;
        if tempuint16 as u64 != tempull {
            eprintln!("ERROR {}:{} - Parameter not uint16 {} -> {}", __func__, __LINE__, tempull, tempuint16);
            std::process::exit(libc::EXIT_FAILURE);
        }

        // Endian conversion
        let tempuint16 = if cmd.BigEndian || forcebigendian {
            tempuint16.to_be()
        } else {
case 'j': /* int32b */
                forcebigendian = tr    },
    _ => {}
};
 

// case 'm': /* uint8 */
//                 tempull = strtoull(optarg, &tail, 0);
//                 tempuint8 = tempull;
//                 if (tempuint8 != tempull)
//                 {
//                     fprintf(stderr, "ERROR %s:%u - Parameter not uint8 %llu -> %u\n", __func__, 639, tempull,
//                             tempuint8);
//                     exit(1);
//                 }
//                 CopyData(cmd.Packet, &startbyte, (char *)&tempuint8, sizeof(tempuint8));
//                 ;
 

// case 'i': /* int16b */
//                 forcebigendian = 1;
match 'l' { /* int32 */
    'l' => {
        let templl = optarg.parse::<i64>().unwrap_or_else(|_| {
case 'x': // uint32b
    forcebigendian = tr        if tempint32 as i64 != templl {
            eprintln!("ERROR {}:{} - Parameter not int32 {} -> {}", __func__, __LINE__, templl, tempint32);
            std::process::exit(libc::EXIT_FAILURE);
match 'o' {
    'o' => { /* uint32 */
        let tempull = optarg.parse::<u64>().unwrap();
        let tempuint32 = tempull as u32;
        if tempuint32 as u64 != tempull {
            eprintln!("ERROR {}:{} - Parameter not uint32 {} -> {}", __func__, line!(), tempull, tempuint32);
            std::process::exit(libc::EXIT_FAILURE);
        }

        /* Endian conversion */
        let tempuint32 = if cmd.BigEndian || forcebigendian {
            tempuint32.to_be()
        } else {
            tempuint32.to_le()
        };

        CopyData(cmd.Packet, &mut startbyte, &tempuint32.to_ne_bytes(), std::mem::size_of::<u32>());
    },
    _ => {}
}//                             tempint16);
case 'k': /* int64b */
                forcebigendian = tr//                 if (cmd.BigEndian || forcebigendian)
//                     tempint16 = __bswap_16 (tempint16);
//                 else
//                     tempint16 = __uint16_identity (tempint16);
// 
//                 CopyData(cmd.Packet, &startbyte, (char *)&tempint16, sizeof(tempint16));
//                 match 'q' {
    'q' => {
        let templl = optarg.parse::<i64>().unwrap_or_else(|_| {
            eprintln!("ERROR {}:{} - Parameter not int64", __func__, __LINE__);
            std::process::exit(libc::EXIT_FAILURE);
        });
        let mut tempint64 = templl;
        if tempint64 != templl {
            eprintln!("ERROR {}:{} - Parameter not int64 {} -> {}", __func__, __LINE__, templl, tempint64);
            std::process::exit(libc::EXIT_FAILURE);
        }

        // Endian conversion
        if cmd.BigEndian || forcebigendian {
            tempint64 = tempint64.to_be();
        } else {
            tempint64 = tempint64.to_le();
case 'y': /* uint64b */
                forcebigendian = tr    _ => {}
};
 
match 'p' {
    'p' => { /* uint64 */
        let tempull = optarg.parse::<u64>().unwrap_or_else(|_| {
            eprintln!("ERROR {}:{} - Parameter not uint64", __func__, line!());
            std::process::exit(libc::EXIT_FAILURE);
        });
        let tempuint64 = tempull;

        /* Endian conversion */
        let tempuint64 = if cmd.BigEndian || forcebigendian {
            tempuint64.to_be()
        } else {
            tempuint64.to_le()
        };

        CopyData(cmd.Packet, &mut startbyte, &tempuint64.to_ne_bytes(), std::mem::size_of::<u64>());
    },
    _ => {}
}// 
//                 CopyData(cmd.Packet, &startbyte, (char *)&tempuint16, sizeof(tempuint16));
//                 match 'f' {
    'f' => { // float
        let tempf: f32 = optarg.parse().unwrap_or(0.0);
        let mut tempint32: u32 = unsafe { std::mem::transmute(tempf) };

        // Endian conversion
        if cmd.BigEndian {
            tempint32 = tempint32.to_be();
        } else {
            tempint32 = tempint32.to_le();
        }

        CopyData(cmd.Packet, &mut startbyte, &tempint32.to_ne_bytes(), std::mem::size_of::<u32>());
    },
match 'd' {
    'd' => { /* double */
        let tempd = optarg.parse::<f64>().unwrap();
        let tempint64: i64 = unsafe { std::mem::transmute(tempd) };

        /* Endian conversion */
        let tempint64 = if cmd.BigEndian {
            tempint64.to_be()
        } else {
            tempint64.to_le()
        };

        CopyData(cmd.Packet, &mut startbyte, &tempint64.to_ne_bytes(), std::mem::size_of::<i64>());
    },
    _ => {}
}//                             tempint32);
//                     exit(1);
//                 }
// 
//                 /* Endian conversion */
//                 if (cmd.BigEndian || forcebigendian)
//                     tempint32 = __bswap_32 (tempint32);
//                 else
//                     tempint32 = __uint32_identity (tempint32);
// 
//                 CopyData(cmd.Packet, &startbyte, (char *)&tempint32, sizeof(tempint32));
//                 match 's' {
    's' => { /* string */
        let tempull = optarg.parse::<u64>().unwrap_or(0);
        let tail = optarg.find(':');

        if tail.is_none() || tempull == 0 {
            eprintln!("ERROR: {}:{} - String format is NNN:string, not {}", __func__, line!(), optarg);
            std::process::exit(libc::EXIT_FAILURE);
        }

        /* Copy the data over (zero fills) */
        let tail_index = tail.unwrap() + 1;
        let sbuf = &optarg[tail_index..];
        let sbuf = &sbuf[..std::cmp::min(sbuf.len(), sbuf.capacity() - 1)];
        CopyData(cmd.Packet, &mut startbyte, sbuf, tempull);

        /* Reset tail so it doesn't trigger error */
        // In Rust, tail is not used after this point, so no need to reset
    },
    _ => {}
};
 

// case 'x': /* uint32b */
//                 forcebigendian = 1;
 

// case 'o': /* uint32 */
//                 tempull = strtoull(optarg, &tail, 0);
//                 tempuint32 = tempull;
//                 if (tempuint32 != tempull)
//                 {
//                     fprintf(stderr, "ERROR %s:%u - Parameter not uint32 %llu -> %u\n", __func__, 720, tempull,
//                             tempuint32);
//                     exit(1);
//                 }
// 
//                 /* Endian conversion */
//                 if (cmd.BigEndian || forcebigendian)
//                     tempuint32 = __bswap_32 (tempuint32);
//                 else
//                     tempuint32 = __uint32_identity (tempuint32);
// 
//                 CopyData(cmd.Packet, &startbyte, (char *)&tempuint32, sizeof(tempuint32));
//                 break;
break 

// case 'k': /* int64b */
//                 forcebigendian = 1;
break 

// case 'q': /* int64 */
//                 templl = strtoll(optarg, &tail, 0);
//                 tempint64 = templl;
//                 if (tempint64 != templl)
//                 {
//                     fprintf(stderr, "ERROR %s:%u - Parameter not int64 %lld -> %lld\n", __func__, 742, templl,
//                             (long long int)tempint64);
//                     exit(1);
//                 }
// 
//                 /* Endian conversion */
//                 if (cmd.BigEndian || forcebigendian)
//                     tempint64 = __bswap_64 (tempint64);
//                 else
//                     tempint64 = __uint64_identity (tempint64);
// 
//                 CopyData(cmd.Packet, &startbyte, (char *)&tempint64, sizeof(tempint64));
//                 break;
break 

// case 'y': /* uint64b */
//                 forcebigendian = 1;
break 

// case 'p': /* uint64 */
//                 tempull = strtoull(optarg, &tail, 0);
//                 tempuint64 = tempull;
//                 if (tempuint64 != tempull)
//                 {
//                     fprintf(stderr, "ERROR %s:%u - Parameter not uint64 %llu -> %llu\n", __func__, 764, tempull,
//                             (unsigned long long int)tempuint64);
//                     exit(1);
//                 }
// 
//                 /* Endian conversion */
//                 if (cmd.BigEndian || forcebigendian)
//                     tempuint64 = __bswap_64 (tempuint64);
//                 else
//                     tempuint64 = __uint64_identity (tempuint64);
// 
//                 CopyData(cmd.Packet, &startbyte, (char *)&tempuint64, sizeof(tempuint64));
//                 break;
break 

// case 'f': /* float */
//                 tempf = strtof(optarg, &tail);
//                 memcpy(&tempint32, &tempf, sizeof(tempint32));
// 
//                 /* Endian conversion */
//                 if (cmd.BigEndian)
//                     tempint32 = __bswap_32 (tempint32);
//                 else
//                     tempint32 = __uint32_identity (tempint32);
// 
//                 CopyData(cmd.Packet, &startbyte, (char *)&tempint32, sizeof(tempint32));
//                 break;
break 

// case 'd': /* double */
//                 tempd = strtod(optarg, &tail);
//                 memcpy(&tempint64, &tempd, sizeof(tempint64));
// 
//                 /* Endian conversion */
//                 if (cmd.BigEndian)
//                     tempint64 = __bswap_64 (tempint64);
//                 else
//                     tempint64 = __uint64_identity (tempint64);
// 
//                 CopyData(cmd.Packet, &startbyte, (char *)&tempint64, sizeof(tempint64));
//                 break;
break 

// case 's': /* string */
// 
//                 tempull = strtoull(optarg, &tail, 0);
// 
//                 if ((tail[0] != ':') || (tempull == 0))
//                 {
//                     fprintf(stderr, "ERROR: %s:%u - String format is NNN:string, not %s\n", __func__, 810, optarg);
//                     exit(1);
//                 }
// 
//                 /* Copy the data over (zero fills) */
//                 strncpy(sbuf, &tail[1], sizeof(sbuf) - 1);
//                 CopyData(cmd.Packet, &startbyte, sbuf, tempull);
// 
//                 /* Reset tail so it doesn't trigger error */
//                 tail = ((void *)0);
//                 break;
break 
_ => { }

}



if 

( 

__errno_location ( ) 

) 
!= 
0 

{ 
fprintf ( 
stderr , 

"ERROR: %s:%u - String conversion (%s): %s\n" , 

__func__ , 

828 , 

optarg , 

strerror ( 
( 

__errno_location ( ) 

) 
) 
) ;


std :: process :: exit ( 
1 
) ;

}



if 

( 

tail 
. is_some ( ) 
) 
&& 
tail . len ( ) 

{ 
fprintf ( 
stderr , 

"ERROR: %s:%u - Trailing characters (%s) in argument %s\n" , 

__func__ , 

834 , 

tail , 

optarg 
) ;


std :: process :: exit ( 
1 
) ;

}


}


/* Save packet length */

pktnbytes = startbyte ;

/* Set non-overridden fields - PktType, PktSec, PktSeqFlg, PktLen, PktEndian */

if 
! 
cmd . OverridePktType 

{ 
ProcessField ( 
& 

cmd . CCSDS_Pri 
[ 
0 
] 


, 

"1" , 

0x1000 , 

1 
) ;

}



if 

! 
cmd . OverridePktSec 

&& 
cmd . IncludeCFSSec 

{ 
ProcessField ( 
& 

cmd . CCSDS_Pri 
[ 
cmd.CCSDS_Pri as *const _ as *mut i8
, 

"1" , 

std::mem::size_of_val(&cmd.CCSDS_Pri)) ;

}



if 
! 
cmd . OverridePktSeqFlg 

{ 
ProcessField ( 
& 

cmd . CCSDS_Pri 
[ 
1 
] 


, 

cmd.CCSDS_Ext as *const i8 as *mut i8
1 
) ;

}
std::mem::size_of_val(&cmd.CCSDS_Ext)if 
! 
cmd . OverridePktLen 

{ 
sprintf ( 
sbuf , 

"%u" , 


( 
pktnbytes - 7 
) 
as uint16_t 
) ;


ProcessField ( 
& 

cmd . CCSDS_Pri 
cmd.CFS_CmdSecHdr as *const _ as *mut i8

, 

sbuf , 
std::mem::size_of_val(&cmd.CFS_CmdSecHdr)1 
) ;

}



if 

! 
cmd . OverridePktEndian 

&& 
! 
cmd . BigEndian 


{ 
ProcessField ( 
& 

cmd . CCSDS_Ext 
[ 
0 
] 


, 

"1" , 

0x0400 , 

1 
) ;

}


/* Copy selected header data (pre-checksum) */

startbyte = 0 ;


if 
cmd . IncludeCCSDSPri 
{ 
CopyData ( 
cmd . Packet 

, 

& 
startbyte , 


std::mem::size_of_val(&cmd.CCSDS_Pri)break 

, 

// sizeof(cmd.CCSDS_Pri)
break 
) ;

}



std::mem::size_of_val(&cmd.CCSDS_Ext)CopyData ( 
cmd . Packet 

, 

& 
startbyte , 


, 

// (char *)cmd.CCSDS_Ext
break 

, 

// sizeof(cmd.CCSDS_Ext)
break 
) ;
cmd.CFS_CmdSecHdr as *const _ as *mut i8

if 
cmd . IncludeCFSSec 
{ 
std::mem::size_of_val(&cmd.CFS_CmdSecHdr), 

& 
startbyte , 


, 

// (char *)&cmd.CFS_CmdSecHdr
break 

, 

// sizeof(cmd.CFS_CmdSecHdr)
break 
) ;

}


/* Calculate checksum and insert into cFS Secondary header buffer if exists and not overridden */

if 

! 
cmd . OverridePktCksum 

&& 
cmd . IncludeCFSSec 

{ 
sprintf ( 
sbuf , 

"%u" , 

CalcChecksum ( 
cmd . Packet 

, 

pktnbytes 
) 
) ;


ProcessField ( 
& 
cmd . CFS_CmdSecHdr 


, 

sbuf , 

0x00FF , 

1 
) ;

/* Copy secondary header buffer into packet buffer with checksum */

startbyte = 0 ;


if 
cmd . IncludeCCSDSPri 
{ 
startbyte += 
// sizeof(cmd.CCSDS_Pri)
break 
;

}



if 
cmd . IncludeCCSDSExt 
{ 
startbyte += 
// sizeof(cmd.CCSDS_Ext)
break 
;

}



CopyData ( 
cmd . Packet 

, 

& 
startbyte , 


, 

// (char *)&cmd.CFS_CmdSecHdr
break 

, 

// sizeof(cmd.CFS_CmdSecHdr)
break 
) ;

}



if 
cmd . Verbose 
{ 
print ! ( "Command checksum (cFS version): 0x{:02X}\n" , 
CalcChecksum ( 
cmd . Packet 

, 

pktnbytes 
) 
) ;

}


/* Echo command buffer */

if 
cmd . Verbose 
{ 
print ! ( "Command Data:\n" ) ;


i = 0 ;
while 

i 
< 
pktnbytes / 2 

{ 
print ! ( " {:02X}{:02X}" , 

cmd . Packet 
[ 
i * 2 
] 

, 


cmd . Packet 
[ 

( 
i * 2 
) 
+ 
1 

] 
) ;


if 

( 
i 
> 
0 
) 
&& 
( 

i % 16 
== 
0 

) 

{ 
print ! ( "\n" ) ;

}



translate_bpc_vpp ! ( i ) 
}



if 

pktnbytes % 2 
!= 
0 

{ 
print ! ( " {:02X}" , 

cmd . Packet 
[ 
pktnbytes 
] 
) ;

}



print ! ( "\n" ) ;

}


/* Send the packet */

status = SendUdp ( 
cmd . HostName 

, 

cmd . PortNum 

, 

cmd . Packet 

, 

pktnbytes 
) ;


if 
status < 0 
{ 
fprintf ( 
stderr , 

"Problem sending UDP packet: %d\n" , 

status 
) ;


std :: process :: exit ( 
1 
) ;

}



return 0 ;

return 0 ;
}

( ) ;
return std :: process :: ExitCode :: from ( retcode ) ;
}


}}}}}}
