#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::translate_bpc_ppv;
// USE STATEMENTS END
/* **********************************************************************
 * NASA Docket No. GSC-18,719-1, and identified as “core Flight System: Bootes”
 *
 * Copyright (c) 2020 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/
/*
 * Udp packet send routine
 */
/*
** SendUdp
*/

pub fn SendUdp ( 
hostname : & str , 

, 

portNum : & str , 

, 

// unsigned char *packetData
let packetData: *mut u8; 

, 

packetSize : i32 
) -> i32 { 
let sd : i32 = Default :: default ( ) ;


let rc : i32 = Default :: default ( ) ;


let port : i32 = Default :: default ( ) ;


let i : u32 = Default :: default ( ) ;


let hints : addrinfo = Default :: default ( ) ;


let result : Option < std :: rc :: Rc < std :: cell :: RefCell < addrinfo > > > = Default :: default ( ) ;


let rp : Option < std :: rc :: Rc < std :: cell :: RefCell < addrinfo > > > = Default :: default ( ) ;


let mut hbuf = String :: from ( "UNKNOWN" ) ;


if 

hostname 
. is_none ( ) 
{ 
return -1 ;

}


/*
    ** Check port
    */

port = atoi ( portNum ) ;


if 
port == -1 
{ 
return -2 ;

}


/*
    **Criteria for selecting socket address
    */

memset ( 
& 
hints , 


, 

0 , 

std :: mem :: size_of_val ( & hints ) 
) ;


hints . ai_family = 
2 
;

/*IPv4*/

hints . ai_socktype = 
SOCK_DGRAM 
;

/*Datagram socket*/

hints . ai_flags = 
0x0002 
;


hints . ai_protocol = 
0 
;

/*Any Protocol*/

rc = getaddrinfo ( 
hostname , 

portNum , 

& 
hints , 


, 

& 
result 

) ;


if 
rc 
!= 
0 
{ 
return -3 ;

}


/* Loop through potential addresses until successful socket/connect */


rp = result 
;
while 

rp 
. is_some ( ) 
{ 
sd = socket ( 

rp 
. ai_family 

, 


rp 
. ai_socktype 

, 


rp 
. ai_protocol 
) ;


// if (sd == -1)
//             continue;
if sd == -1 {
if connect(sd, rp.ai_addr, rp.ai_addrlen) != -1 {
    break;
}//             break;
break 
/* Success */

close ( 
sd 
) ;



rp 
= 

rp 
. ai_next 

;
}



if 

rp 
. is_none ( ) 
{ 
freeaddrinfo ( 
result 
) ;


return -4 ;

}



getnameinfo ( 

rp 
. ai_addr 

, 


rp 
. ai_addrlen 

, 

hbuf , 

std :: mem :: size_of_val ( & hbuf ) 

, 

None 

, 

0 , 

1 
) ;


print ! ( "sending data to '{}' (IP : {}); port {}\n" , 

rp 
. ai_canonname 

, 

hbuf , 

port 
) ;


freeaddrinfo ( 
result 
) ;


print ! ( "Data to send:\n" ) ;


i = 0 ;


while 
( 
i 
< 
packetSize 
) 
{ 
print ! ( "0x{:02X} " , 

packetData [ i ] 
& 
0xFF 

) ;


if 


translate_bpc_ppv ! ( i ) 
% 
8 

== 
0 

{ 
puts ( 
"" 
) ;

}


}



puts ( 
"" 
) ;

/*
    ** send the event
    */

rc = send ( 
sd , 

// (char *)packetData
packetData as *const i8 as *mut i8 

, 

packetSize , 

0 
) ;


close ( 
sd 
) ;


if 
rc 
!= 
packetSize 
{ 
return -6 ;

}



return 0 ;

}


}
