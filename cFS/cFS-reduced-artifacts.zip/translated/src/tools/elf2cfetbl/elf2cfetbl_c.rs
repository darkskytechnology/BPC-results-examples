#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use cFS_reduced::cfe::modules::core_api::fsw::inc::cfe_tbl_filedef_h::CFE_TBL_FileDef_t;
use cFS_reduced::cfe::modules::fs::config::default_cfe_fs_filedef_h::CFE_FS_Header_t;
use cFS_reduced::cfe::modules::tbl::config::default_cfe_tbl_extern_typedefs_h::CFE_TBL_File_Hdr_t;
use cFS_reduced::osal::src::os::inc::common_types_h::int32;
use cFS_reduced::osal::src::os::inc::common_types_h::int64;
use cFS_reduced::osal::src::os::inc::common_types_h::uint16;
use cFS_reduced::osal::src::os::inc::common_types_h::uint32;
use cFS_reduced::osal::src::os::inc::common_types_h::uint64;
use cFS_reduced::osal::src::os::inc::common_types_h::uint8;
use cFS_reduced::tools::elf2cfetbl::ELF_Structures_h::Elf_Ehdr;
use cFS_reduced::tools::elf2cfetbl::ELF_Structures_h::Elf_Shdr;
use cFS_reduced::tools::elf2cfetbl::ELF_Structures_h::Elf_Sym;
use cFS_reduced::translate_bpc_vpp;
// USE STATEMENTS END
/* **********************************************************************
 * NASA Docket No. GSC-18,719-1, and identified as “core Flight System: Bootes”
 *
 * Copyright (c) 2020 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/
/* 
 * \file
 *    This file implements the ELF file to Standard cFE Table file format tool
 */
/*
** Required header files.
*/
/* macro to construct 32 bit value from 4 chars */

# [ derive ( Clone , Default ) ] pub struct ElfStrMap { 
pub Value : int32 , 

pub String : [ i8 ;

50 
] , 
}


/* 
 *    Function Prototypes
 */
/* int32 ProcessCmdLineOptions(int argc, char *argv[]); */
/* int32 GetSrcFilename(void); */
/* int32 GetDstFilename(void); */
/* int32 OpenSrcFile(void); */
/* int32 OpenDstFile(void); */
/* int32 checkELFFileMagicNumber(void); */
/* int32 GetElfHeader(void); */
/* void SwapElfHeader(void); */
/* int32 GetSectionHeader(int32 SectionIndex, union Elf_Shdr *SectionHeader); */
/* void SwapSectionHeader(union Elf_Shdr *SectionHeader); */
/* int32 GetSymbol(int32 SymbolIndex, union Elf_Sym *Symbol); */
/* void SwapSymbol(union Elf_Sym *Symbol); */
/* int32 GetStringFromMap(char *Result, ElfStrMap *Map, int32 Key); */
/* void SwapUInt16(uint16 *ValueToSwap); */
/* void SwapUInt32(uint32 *ValueToSwap); */
/* void SwapUInt64(uint64 *ValueToSwap); */
/* int32 AllocateSectionHeaders(void); */
/* void DeallocateSectionHeaders(void); */
/* int32 AllocateSymbols(void); */
/* void DeallocateSymbols(void); */
/* void FreeMemoryAllocations(void); */
/* int32 GetTblDefInfo(void); */
/* int32 OutputDataToTargetFile(void); */
/* void OutputVersionInfo(void); */
/* void OutputHelpInfo(void); */
/* int32 LocateAndReadUserObject(void); */
/* void PrintSymbol32(union Elf_Sym *Symbol); */
/* void PrintSymbol64(union Elf_Sym *Symbol); */
/* void PrintSectionHeader32(union Elf_Shdr *SectionHeader); */
/* void PrintSectionHeader64(union Elf_Shdr *SectionHeader); */
/* void PrintElfHeader32(union Elf_Ehdr ElfHeaderLcl); */
/* void PrintElfHeader64(union Elf_Ehdr ElfHeaderLcl); */
/* 
 *    Global Variables
 */

// char SrcFilename[4096] = {""};
let mut SrcFilename: [u8; PATH_MAX] = [0; PATH_MAX]; 

// char DstFilename[4096] = {""};
let mut DstFilename: [u8; PATH_MAX] = [0; PATH_MAX]; 

// char TableName[38] = {""};
let mut TableName: [char; 38] = ['\0'; 38]; 

// char Description[32] = {""};
let mut Description: [u8; 32] = [0; 32]; 

// char LineOfText[300] = {""};
let mut LineOfText: [char; 300] = ['\\0'; 300]; 

let Verbose : _Bool = 0 ;


let ReportVersion : _Bool = 0 ;


let OutputHelp : _Bool = 0 ;


let ByteSwapRequired : _Bool = 0 ;


let ScIDSpecified : _Bool = 0 ;


let ProcIDSpecified : _Bool = 0 ;


let AppIDSpecified : _Bool = 0 ;


let ScEpochSpecified : _Bool = 0 ;


let FileEpochSpecified : _Bool = 0 ;


let TableNameOverride : _Bool = 0 ;


let DescriptionOverride : _Bool = 0 ;


let ThisMachineIsLittleEndian : _Bool = 1 ;


let TargetMachineIsLittleEndian : _Bool = 1 ;


let EnableTimeTagInHeader : _Bool = 0 ;


let TargetWordsizeIs32Bit : _Bool = 1 ;


let TableDataIsAllZeros : _Bool = 0 ;


// FILE *SrcFileDesc = ((void *)0);
let mut src_file_desc: Option<std::fs::File> = None;
let mut DstFileDesc: Option<std::fs::File> = None;

CFE_Fbreak 

let mut FileHeader : CFE_FS_Header_t = Default :: default ( ) ;


let mut TableHeader : CFE_TBL_File_Hdr_t = Default :: default ( ) ;


// union Elf_Ehdr ElfHeader;
union Elf_Ehdr { ElfHeade: u32 } 

// union Elf_Shdr **SectionHeaderPtrs = ((void *)0);
let mut section_header_ptrs: Vec<*mut Elf_Shdr> = Vec::new(); 

// union Elf_Shdr SectionHeaderStringTable = {{0, 0, 0, 0, 0, 0, 0, 0, 0, 0}};
union Elf_Shdr   SectionHeaderStringTable           = {{0, 0, 0, 0, 0, 0, 0 

let SectionHeaderStringTableDataOffset : int64 = 0 ;


// char ** SectionNamePtrs = ((void *)0);
let mut SectionNamePtrs: Vec<*mut i8>; 

let SrcFileStats : stat = Default :: default ( ) ;


let StringTableDataOffset : u64 = 0 ;


let SymbolTableDataOffset : int32 = 0 ;


let NumSymbols : u64 = 0 ;


let SymbolTableEntrySize : u64 = 0 ;


// union Elf_Sym ** SymbolPtrs = ((void *)0);
let mut SymbolPtrs: *mut *mut Elf_Sym = std::ptr::null_mut(); 

// char ** SymbolNames;
let Sy: *mut *mut i8; 

let TblDefSymbolIndex : int32 = -1 ;


let mut TblFileDef : CFE_TBL_FileDef_t = Default :: default ( ) ;


let UserObjSymbolIndex : int32 = -1 ;


let SpacecraftID : uint32 = 0 ;


let ProcessorID : uint32 = 0 ;


let ApplicationID : uint32 = 0 ;


let EpochTime : time_t = 0 ;


# [ derive ( Clone , Default ) ] pub struct SpecifiedEpoch_t { 
pub Year : uint32 , 

pub Month : uint32 , 

pub Day : uint32 , 

pub Hour : uint32 , 

pub Minute : uint32 , 

pub Second : uint32 , 
}



let ScEpoch : SpecifiedEpoch_t = 
// {1970, 1, 1, 0, 0, 0}
= (1970, 1, 1, 0, 0,  
;


let FileEpoch : SpecifiedEpoch_t = 
// {1970, 1, 1, 0, 0, 0}
{1970, 1, 1, 0, 0, 0} 
;


let mut EpochDelta : time_t = Default :: default ( ) ;


let mut SrcFileTimeInScEpoch : time_t = Default :: default ( ) ;

/* 
 *    ELF Characteristic Maps
 */

// ElfStrMap e_type_Map[] = {
//     {0, "ET_NONE (0)"}, {1, "ET_REL (1)"}, {2, "ET_EXEC (2)"},
//     {3, "ET_DYN (3)"}, {4, "ET_CORE (4)"}, {0, "* Unknown Elf File Type (%d) *"},
// };
let e_type_Map = [
ElfStrMap e_machine_Map[] = {
    {EM_NONE, "EM_NONE         ( 0)"},
    {EM_M32, "EM_M32          ( 1)"},
    {EM_SPARC, "EM_SPARC        ( 2)"},
    {EM_386, "EM_386          ( 3)"},
    {EM_68K, "EM_68K          ( 4)"},
    {EM_88K, "EM_88K          ( 5)"},
    {EM_860, "EM_860          ( 7)"},
    {EM_MIPS, "EM_MIPS         ( 8)"},
    {EM_S370, "EM_S370         ( 9)"},
    {EM_MIPS_RS3_LE, "EM_MIPS_RS3_LE  (10)"},
    {EM_PARISC, "EM_PARISC       (15)"},
    {EM_VPP500, "EM_VPP500       (17)"},
    {EM_SPARC32PLUS, "EM_SPARC32PLUS  (18)"},
    {EM_960, "EM_960          (19)"},
    {EM_PPC, "EM_PPC          (20)"},
    {EM_PPC64, "EM_PPC64        (21)"},
    {EM_S390, "EM_S390         (22)"},
    {EM_SPU, "EM_SPU          (23)"},
    {EM_V800, "EM_V800         (36)"},
    {EM_FR20, "EM_FR20         (37)"},
    {EM_RH32, "EM_RH32         (38)"},
    {EM_RCE, "EM_RCE          (39)"},
    {EM_ARM, "EM_ARM          (40)"},
    {EM_ALPHA, "EM_ALPHA        (41)"},
    {EM_SH, "EM_SH           (42)"},
    {EM_SPARCV9, "EM_SPARCV9      (43)"},
    {EM_TRICORE, "EM_TRICORE      (44)"},
    {EM_ARC, "EM_ARC          (45)"},
    {EM_H8_300, "EM_H8_300       (46)"},
    {EM_H8_300H, "EM_H8_300H      (47)"},
    {EM_H8S, "EM_H8S          (48)"},
    {EM_H8_500, "EM_H8_500       (49)"},
    {EM_IA_64, "EM_IA_64        (50)"},
    {EM_MIPS_X, "EM_MIPS_X       (51)"},
    {EM_COLDFIRE, "EM_COLDFIRE     (52)"},
    {EM_68HC12, "EM_68HC12       (53)"},
    {EM_MMA, "EM_MMA          (54)"},
    {EM_PCP, "EM_PCP          (55)"},
    {EM_NCPU, "EM_NCPU         (56)"},
    {EM_NDR1, "EM_NDR1         (57)"},
    {EM_STARCORE, "EM_STARCORE     (58)"},
    {EM_ME16, "EM_ME16         (59)"},
    {EM_ST100, "EM_ST100        (60)"},
    {EM_TINYJ, "EM_TINYJ        (61)"},
    {EM_X86_64, "EM_X86_64       (62)"},
    {EM_PDSP, "EM_PDSP         (63)"},
    {EM_PDP10, "EM_PDP10        (64)"},
    {EM_PDP11, "EM_PDP11        (65)"},
    {EM_FX66, "EM_FX66         (66)"},
    {EM_ST9PLUS, "EM_ST9PLUS      (67)"},
    {EM_ST7, "EM_ST7          (68)"},
    {EM_68HC16, "EM_68HC16       (69)"},
    {EM_68HC11, "EM_68HC11       (70)"},
    {EM_68HC08, "EM_68HC08       (71)"},
    {EM_68HC05, "EM_68HC05       (72)"},
    {EM_SVX, "EM_SVX          (73)"},
    {EM_ST19, "EM_ST19         (74)"},
    {EM_VAX, "EM_VAX          (75)"},
    {EM_CRIS, "EM_CRIS         (76)"},
    {EM_JAVELIN, "EM_JAVELIN      (77)"},
    {EM_FIREPATH, "EM_FIREPATH     (78)"},
    {EM_ZSP, "EM_ZSP          (79)"},
    {EM_MMIX, "EM_MMIX         (80)"},
    {EM_HUANY, "EM_HUANY        (81)"},
    {EM_PRISM, "EM_PRISM        (82)"},
    {EM_AVR, "EM_AVR          (83)"},
    {EM_FR30, "EM_FR30         (84)"},
    {EM_D10V, "EM_D10V         (85)"},
    {EM_D30V, "EM_D30V         (86)"},
    {EM_V850, "EM_V850         (87)"},
    {EM_M32R, "EM_M32R         (88)"},
    {EM_MN10300, "EM_MN10300      (89)"},
    {EM_MN10200, "EM_MN10200      (90)"},
    {EM_PJ, "EM_PJ           (91)"},
    {EM_OPENRISC, "EM_OPENRISC     (92)"},
    {EM_ARC_COMPACT, "EM_ARC_COMPACT  (93)"},
    {EM_XTENSA, "EM_XTENSA       (94)"},
    {EM_VIDEOCORE, "EM_VIDEOCORE    (95)"},
    {EM_TMM_GPP, "EM_TMM_GPP      (96)"},
    {EM_NS32K, "EM_NS32K        (97)"},
    {EM_TPC, "EM_TPC          (98)"},
    {EM_SNP1K, "EM_SNP1K        (99)"},
    {EM_ST200, "EM_ST200       (100)"},
    {EM_IP2K, "EM_IP2K        (101)"},
    {EM_MAX, "EM_MAX         (102)"},
    {EM_CR, "EM_CR          (103)"},
    {EM_F2MC16, "EM_F2MC16      (104)"},
    {EM_MSP430, "EM_MSP430      (105)"},
    {EM_BLACKFIN, "EM_BLACKFIN    (106)"},
    {EM_SE_C33, "EM_SE_C33      (107)"},
    {EM_SEP, "EM_SEP         (108)"},
    {EM_ARCA, "EM_ARCA        (109)"},
    {EM_UNICORE, "EM_UNICORE     (110)"},
    {EM_EXCESS, "EM_EXCESS      (111)"},
    {EM_DXP, "EM_DXP         (112)"},
    {EM_ALTERA_NIOS2, "EM_ALTERA_NIOS2 (113)"},
    {EM_CRX, "EM_CRX         (114)"},
    {EM_XGATE, "EM_XGATE       (115)"},
    {EM_C166, "EM_C166        (116)"},
    {EM_M16C, "EM_M16C        (117)"},
    {EM_DSPIC30F, "EM_DSPIC30F    (118)"},
    {EM_CE, "EM_CE          (119)"},
    {EM_M32C, "EM_M32C        (120)"},
    {EM_TSK3000, "EM_TSK3000     (131)"},
    {EM_RS08, "EM_RS08        (132)"},
    {EM_SHARC, "EM_SHARC       (133)"},
    {EM_ECOG2, "EM_ECOG2       (134)"},
    {EM_SCORE7, "EM_SCORE7      (135)"},
    {EM_DSP24, "EM_DSP24       (136)"},
    {EM_VIDEOCORE3, "EM_VIDEOCORE3  (137)"},
    {EM_LATTICEMICO32, "EM_LATTICEMICO32(138)"},
    {EM_SE_C17, "EM_SE_C17      (139)"},
    {EM_TI_C6000, "EM_TI_C6000    (140)"},
    {EM_TI_C2000, "EM_TI_C2000    (141)"},
    {EM_TI_C5500, "EM_TI_C5500    (142)"},
    {EM_TI_ARP32, "EM_TI_ARP32    (143)"},
    {EM_TI_PRU, "EM_TI_PRU      (144)"},
    {EM_MMDSP_PLUS, "EM_MMDSP_PLUS  (160)"},
    {EM_CYPRESS_M8C, "EM_CYPRESS_M8C (161)"},
    {EM_R32C, "EM_R32C        (162)"},
    {EM_TRIMEDIA, "EM_TRIMEDIA    (163)"},
    {EM_QDSP6, "EM_QDSP6       (164)"},
    {EM_8051, "EM_8051        (165)"},
    {EM_STXP7X, "EM_STXP7X      (166)"},
    {EM_NDS32, "EM_NDS32       (167)"},
    {EM_ECOG1, "EM_ECOG1       (168)"},
    {EM_ECOG1X, "EM_ECOG1X      (168)"},
    {EM_MAXQ30, "EM_MAXQ30      (169)"},
    {EM_XIMO16, "EM_XIMO16      (170)"},
    {EM_MANIK, "EM_MANIK       (171)"},
    {EM_RX, "EM_RX          (173)"},
    {EM_METAG, "EM_METAG       (174)"},
    {EM_MCST_ELBRUS, "EM_MCST_ELBRUS (175)"},
    {EM_ECOG16, "EM_ECOG16      (176)"},
    {EM_CR16, "EM_CR16        (177)"},
    {EM_ETPU, "EM_ETPU        (178)"},
    {EM_SLE9X, "EM_SLE9X       (179)"},
    {EM_L10M, "EM_L10M        (180)"},
    {EM_K10M, "EM_K10M        (181)"},
    {EM_AARCH64, "EM_AARCH64     (183)"},
    {EM_AVR32, "EM_AVR32       (185)"},
    {EM_STM8, "EM_STM8        (186)"},
    {EM_TILE64, "EM_TILE64      (187)"},
    {EM_TILEPRO, "EM_TILEPRO     (188)"},
    {EM_MICROBLAZE, "EM_MICROBLAZE  (189)"},
    {EM_CUDA, "EM_CUDA        (190)"},
    {EM_TILEGX, "EM_TILEGX      (191)"},
    {EM_CLOUDSHIELD, "EM_CLOUDSHIELD (192)"},
    {EM_COREA_1ST, "EM_COREA_1ST   (193)"},
    {EM_COREA_2ND, "EM_COREA_2ND   (194)"},
    {EM_ARC_COMPACT2, "EM_ARC_COMPACT2 (195)"},
    {EM_OPEN8, "EM_OPEN8       (196)"},
    {EM_RL78, "EM_RL78        (197)"},
    {EM_VIDEOCORE5, "EM_VIDEOCORE5  (198)"},
    {EM_78KOR, "EM_78KOR       (199)"},
    {EM_56800EX, "EM_56800EX     (200)"},
    {EM_BA1, "EM_BA1         (201)"},
    {EM_BA2, "EM_BA2         (202)"},
    {EM_XCORE, "EM_XCORE       (203)"},
    {EM_MCHP_PIC, "EM_MCHP_PIC    (204)"},
    {EM_INTEL205, "EM_INTEL205    (205)"},
    {EM_INTEL206, "EM_INTEL206    (206)"},
    {EM_INTEL207, "EM_INTEL207    (207)"},
    {EM_INTEL208, "EM_INTEL208    (208)"},
    {EM_INTEL209, "EM_INTEL209    (209)"},
    {EM_KM32, "EM_KM32        (210)"},
    {EM_KMX32, "EM_KMX32       (211)"},
    {EM_KMX16, "EM_KMX16       (212)"},
    {EM_KMX8, "EM_KMX8        (213)"},
    {EM_KVARC, "EM_KVARC       (214)"},
    {EM_CDP, "EM_CDP         (215)"},
    {EM_COGE, "EM_COGE        (216)"},
    {EM_COOL, "EM_COOL        (217)"},
    {EM_NORC, "EM_NORC        (218)"},
    {EM_CSR_KALIMBA, "EM_CSR_KALIMBA (219)"},
    {EM_Z80, "EM_Z80         (220)"},
    {EM_VISIUM, "EM_VISIUM      (221)"},
    {EM_FT32, "EM_FT32        (222)"},
    {EM_MOXIE, "EM_MOXIE       (223)"},
    {EM_AMDGPU, "EM_AMDGPU      (224)"},
    {EM_RISCV, "EM_RISCV       (243)"},
    {0, "* Unknown Machine Type (%d) *"},
};//     {221, "EM_VISIUM      (221)"},
//     {222, "EM_FT32        (222)"},
//     {223, "EM_MOXIE       (223)"},
//     {224, "EM_AMDGPU      (224)"},
//     {243, "EM_RISCV       (243)"},
//     {0, "* Unknown Machine Type (%d) *"},
// };
const ElfHeaderLcl: &Elf_Ehdr 
/* Elf Header helper functions */

pub fn get_e_ident ( 
// const union Elf_Ehdr *ElfHeaderLcl
break 

, 

index : i32 
) -> uint8_t { 
if 
TargetWordsizeIs32Bit 
{ 




ElfHeaderLcl 
. Ehdr32 
. e_ident 
[ 
index 
] 

}



else { 




ElfHeaderLcl 
. Ehdr64 
. e_ident 
[ 
index 
] 

}

const ElfHeaderLcl: *const Elf_Ehdr

pub fn get_e_type ( 
// const union Elf_Ehdr *ElfHeaderLcl
break 
) -> uint16_t { 
if 
TargetWordsizeIs32Bit 
{ 



ElfHeaderLcl 
. Ehdr32 
. e_type 

}



else { 



ElfHeaderLcl 
. Ehdr64 
. e_type 

}


}

const ElfHeaderLcl: *const Elf_Ehdr// const union Elf_Ehdr *ElfHeaderLcl
break 
) -> uint16_t { 
if 
TargetWordsizeIs32Bit 
{ 



ElfHeaderLcl 
. Ehdr32 
. e_machine 

}



else { 



ElfHeaderLcl 
. Ehdr64 
. e_machine 

}


}



pub fn get_e_version ( 
// const union Elf_Ehdr *ElfHeaderLcl
const ElfHeaderLcl: *const Elf_Ehdr 
) -> uint32_t { 
if 
TargetWordsizeIs32Bit 
{ 



ElfHeaderLcl 
. Ehdr32 
. e_version 

}



else { 



ElfHeaderLcl 
. Ehdr64 
. e_version 

}


}



pub fn get_e_shstrndx ( 
// const union Elf_Ehdr *ElfHeaderLcl
const ElfHeaderLcl: *const Elf_Ehdr 
) -> uint16_t { 
if 
TargetWordsizeIs32Bit 
{ 



ElfHeaderLcl 
. Ehdr32 
. e_shstrndx 

}



else { 



ElfHeaderLcl 
. Ehdr64 
. e_shstrndx 

}


}



pub fn get_e_shnum ( 
// const union Elf_Ehdr *ElfHeaderLcl
const ElfHeaderLcl: *const Elf_Ehdr 
) -> uint16_t { 
if 
TargetWordsizeIs32Bit 
{ 



ElfHeaderLcl 
. Ehdr32 
. e_shnum 

}



else { 



ElfHeaderLcl 
. Ehdr64 
. e_shnum 

}


}


/* Elf Section Header helper functions */

pub fn get_sh_name ( 
// const union Elf_Shdr *SectionHeader
const SectionHeader: &Elf_Shdr 
) -> uint32_t { 
if 
TargetWordsizeIs32Bit 
{ 



SectionHeader 
. Shdr32 
. sh_name 

}



else { 



SectionHeader 
. Shdr64 
. sh_name 

}


}



pub fn get_sh_type ( 
// const union Elf_Shdr *SectionHeader
const SectionHeader: &Elf_Shdr 
) -> uint32_t { 
if 
TargetWordsizeIs32Bit 
{ 



SectionHeader 
. Shdr32 
. sh_type 

}



else { 



SectionHeader 
. Shdr64 
. sh_type 

}


}



pub fn print_sh_flags ( 
// const union Elf_Shdr *SectionHeader
const SectionHeader: &Elf_Shdr 
) { 
// char VerboseStr[60];
let mut VerboseStr: [char; 60] = ['\0'; 60]; 

sprintf ( 
VerboseStr , 

"/" 
) ;


if 
TargetWordsizeIs32Bit 
{ 
if 

( 



SectionHeader 
. Shdr32 
. sh_flags 
& 
0x1 

) 
== 
0x1 

{ 
sprintf ( 
VerboseStr , 

"SHF_WRITE/" 
) ;

}



if 

( 



SectionHeader 
. Shdr32 
. sh_flags 
& 
0x2 

) 
== 
0x2 

{ 
VerboseStr . push_str ( "SHF_ALLOC/" ) ;

}



if 

( 



SectionHeader 
. Shdr32 
. sh_flags 
& 
0x4 

) 
== 
0x4 

{ 
VerboseStr . push_str ( "SHF_EXECINSTR/" ) ;

}



print ! ( "   sh_flags      = {}\n" , VerboseStr ) ;

}



else { 
if 

( 



SectionHeader 
. Shdr64 
. sh_flags 
& 
0x1 

) 
== 
0x1 

{ 
sprintf ( 
VerboseStr , 

"SHF_WRITE/" 
) ;

}



if 

( 



SectionHeader 
. Shdr64 
. sh_flags 
& 
0x2 

) 
== 
0x2 

{ 
VerboseStr . push_str ( "SHF_ALLOC/" ) ;

}



if 

( 



SectionHeader 
. Shdr64 
. sh_flags 
& 
0x4 

) 
== 
0x4 

{ 
VerboseStr . push_str ( "SHF_EXECINSTR/" ) ;

}



print ! ( "   sh_flags      = {}\n" , VerboseStr ) ;

}


}



pub fn get_sh_offset ( 
// const union Elf_Shdr *SectionHeader
const SectionHeader: &Elf_Shdr 
) -> uint64_t { 
if 
TargetWordsizeIs32Bit 
{ 



SectionHeader 
. Shdr32 
. sh_offset 

}



else { 



SectionHeader 
. Shdr64 
. sh_offset 

}


}



pub fn get_sh_size ( 
// const union Elf_Shdr *SectionHeader
const SectionHeader: &Elf_Shdr 
) -> uint64_t { 
if 
TargetWordsizeIs32Bit 
{ 



SectionHeader 
. Shdr32 
. sh_size 

}



else { 



SectionHeader 
. Shdr64 
. sh_size 

}


}



pub fn get_sh_entsize ( 
// const union Elf_Shdr *SectionHeader
const SectionHeader: &Elf_Shdr 
) -> uint64_t { 
if 
TargetWordsizeIs32Bit 
{ 



SectionHeader 
. Shdr32 
. sh_entsize 

}



else { 



SectionHeader 
. Shdr64 
. sh_entsize 

}


}


/* Elf_Sym helper functions */

pub fn get_st_name ( 
// const union Elf_Sym *Symbol
const Symbol: &Elf_Sym 
) -> uint32_t { 
if 
TargetWordsizeIs32Bit 
{ 



Symbol 
. Sym32 
. st_name 

}



else { 



Symbol 
. Sym64 
. st_name 

}


}



pub fn get_st_value ( 
// const union Elf_Sym *Symbol
const Symbol: &Elf_Sym 
) -> uint64_t { 
if 
TargetWordsizeIs32Bit 
{ 



Symbol 
. Sym32 
. st_value 

}



else { 



Symbol 
. Sym64 
. st_value 

}


}



pub fn get_st_size ( 
// const union Elf_Sym *Symbol
const Symbol: &Elf_Sym 
) -> uint64_t { 
if 
TargetWordsizeIs32Bit 
{ 



Symbol 
. Sym32 
. st_size 

}



else { 



Symbol 
. Sym64 
. st_size 

}


}



pub fn set_st_size ( 
// union Elf_Sym *Symbol
let symbol: *mut Elf_Sym; 

, 

new_value : uint64_t 
) { 
if 
TargetWordsizeIs32Bit 
{ 



Symbol 
. Sym32 
. st_size 
= 

new_value 
as uint32_t 
;


if 



Symbol 
. Sym32 
. st_size 
!= 
new_value 

{ 
print ! ( "ERROR: Sym32.st_size can not hold {}\n" , 
// (long unsigned int)new_value
new_value as u64 
) ;

}


}



else { 



Symbol 
. Sym64 
. st_size 
= 
new_value 
;

}


}



pub fn get_st_shndx ( 
// const union Elf_Sym *Symbol
const Symbol: &Elf_Sym 
) -> uint16_t { 
if 
TargetWordsizeIs32Bit 
{ 



Symbol 
. Sym32 
. st_shndx 

}



else { 



Symbol 
. Sym64 
. st_shndx 

}


}


/* Check status helper functions */

pub fn CheckStatusAndExit ( 
status : int32 
) { 
if 

status 
!= 
( 
0 
) 

{ 
std :: process :: exit ( 
status 
) ;

}


}



pub fn CheckStatusCleanupAndExit ( 
status : int32 
) { 
if 

status 
!= 
( 
0 
) 

{ 
FreeMemoryAllocations ( ) ;


std :: process :: exit ( 
status 
) ;

}


}


/* 
 *
 */

fn main ( ) -> impl std :: process :: Termination { let argv = std :: env :: args ( ) . collect :: < Vec < _ > > ( ) ;
let argc = argv . len ( ) ;
let retcode = move | | -> u8 { 
let Status : int32 = 
( 
0 
) 
;


let i : int32 = 0 ;


Status = ProcessCmdLineOptions ( 
argc , 

argv 
) ;


CheckStatusAndExit ( 
Status 
) ;


if 
ReportVersion 
{ 
OutputVersionInfo ( ) ;

}



if 
OutputHelp 
{ 
OutputHelpInfo ( ) ;

}



Status = GetSrcFilename ( ) ;


CheckStatusAndExit ( 
Status 
) ;


Status = OpenSrcFile ( ) ;


CheckStatusAndExit ( 
Status 
) ;


Status = GetElfHeader ( ) ;


CheckStatusAndExit ( 
Status 
) ;

/* Get the string section header first */

Status = GetSectionHeader ( 
get_e_shstrndx ( 
& 
ElfHeader 

) 

, 

& 
SectionHeaderStringTable 

) ;


CheckStatusCleanupAndExit ( 
Status 
) ;


if 
TargetWordsizeIs32Bit 
{ 

SectionHeaderStringTableDataOffset 
= 

SectionHeaderStringTable . Shdr32 
. sh_offset 
;

}



else { 

SectionHeaderStringTableDataOffset 
= 

SectionHeaderStringTable . Shdr64 
. sh_offset 
;

}


/* Allocate memory for all of the ELF object file section headers */

Status = AllocateSectionHeaders ( ) ;


CheckStatusCleanupAndExit ( 
Status 
) ;

/* Read in each section header from input file */

i = 0 ;
while 

i 
< 
get_e_shnum ( 
& 
ElfHeader 

) 

{ 
Status = GetSectionHeader ( 
i , 

SectionHeaderPtrs [ i ] 
) ;


CheckStatusCleanupAndExit ( 
Status 
) ;


translate_bpc_vpp ! ( i ) 
}



if 
StringTableDataOffset == 0 
{ 
print ! ( "Error! Unable to locate ELF string table for symbol names\n" ) ;


return 1 ;

}


/* Allocate memory for all of the symbol table entries */

Status = AllocateSymbols ( ) ;


CheckStatusCleanupAndExit ( 
Status 
) ;

/* Read in each symbol table entry */

i = 0 ;
while 
i 
< 
NumSymbols 
{ 
Status = GetSymbol ( 
i , 

SymbolPtrs [ i ] 
) ;


CheckStatusCleanupAndExit ( 
Status 
) ;


translate_bpc_vpp ! ( i ) 
}



if 
TblDefSymbolIndex == -1 
{ 
print ! ( "Error! Unable to locate '{}' object in '{}'.\n" , 
"CFE_TBL_FileDef" , 

SrcFilename 
) ;


FreeMemoryAllocations ( ) ;


return 1 ;

}


/* Read in the definition of the table file */

Status = GetTblDefInfo ( ) ;


CheckStatusCleanupAndExit ( 
Status 
) ;


Status = GetDstFilename ( ) ;


CheckStatusAndExit ( 
Status 
) ;


Status = OpenDstFile ( ) ;


CheckStatusAndExit ( 
Status 
) ;


Status = LocateAndReadUserObject ( ) ;


CheckStatusCleanupAndExit ( 
Status 
) ;


Status = OutputDataToTargetFile ( ) ;


FreeMemoryAllocations ( ) ;



( 
0 
) 

return 0 ;
}

( ) ;
return std :: process :: ExitCode :: from ( retcode ) ;
}


/* 
 *
 */

pub fn AllocateSectionHeaders ( ) -> int32 { 
let Status : int32 = 
( 
0 
) 
;


let i : int32 = 0 ;


if 

get_e_shnum ( 
& 
ElfHeader 

) 
== 
0 

{ 
print ! ( "Error! Failed to locate any Section Headers in '{}'!\n" , SrcFilename ) ;



Status 
= 
( 
1 
) 
;

}



else { 

SectionHeaderPtrs 
= 
// (union Elf_Shdr **)malloc(sizeof(union Elf_Shdr *) * get_e_shnum(&ElfHeader))
vec![std::ptr::null_mut(); get_e_shnum(&ElfHeader) as usize].into_boxed_slice() 
;


if 

SectionHeaderPtrs 
. is_none ( ) 
{ 
print ! ( "Error! Insufficient memory for number of Sections in '{}'!\n" , SrcFilename ) ;



Status 
= 
( 
1 
) 
;

}




SectionNamePtrs 
= 
// (char **)malloc(sizeof(char *) * get_e_shnum(&ElfHeader))
vec![std::ptr::null_mut::<*mut i8>(); get_e_shnum(&ElfHeader) as usize].as_mut_ptr() 
;


if 

SectionNamePtrs 
. is_none ( ) 
{ 
print ! ( "Error! Insufficient memory for number of Sections in '{}'!\n" , SrcFilename ) ;



Status 
= 
( 
1 
) 
;

}



if 

Status 
== 
( 
0 
) 

{ /* Initialize all of the pointers to NULL */

i = 0 ;
while 

i 
< 
get_e_shnum ( 
& 
ElfHeader 

) 

{ 

SectionHeaderPtrs [ i ] 
= None ;



SectionNamePtrs [ i ] 
= None ;


translate_bpc_vpp ! ( i ) 
}


/* Allocate memory for each header */

i = 0 ;
while 

i 
< 
get_e_shnum ( 
& 
ElfHeader 

) 

{ 
SectionHeaderPtrs [ 
i 
] = 
// (union Elf_Shdr *)malloc(sizeof(union Elf_Shdr))
Box::new(mem::zeroed::<Elf_Shdr>()) 
;


if 

SectionHeaderPtrs [ i ] 
. is_none ( ) 
{ 
print ! ( "Error! Insufficient memory to store Section Headers\n" ) ;



Status 
= 
( 
1 
) 
;

}



SectionNamePtrs [ 
i 
] = 
// (char *)malloc((128))
vec![0u8; MAX_SE].as_mut_ptr() as *mut i8 
;


if 

SectionNamePtrs [ i ] 
. is_none ( ) 
{ 
print ! ( "Error! Insufficient memory to store Section Names\n" ) ;



Status 
= 
( 
1 
) 
;

}



translate_bpc_vpp ! ( i ) 
}


}


}



return Status ;

}


/* 
 *
 */

pub fn DeallocateSectionHeaders ( ) { 
let i : int32 = 0 ;


if 

SectionHeaderPtrs 
. is_some ( ) 
{ 
while 
( 

( 

i 
< 
get_e_shnum ( 
& 
ElfHeader 

) 

) 
&& 
( 

SectionHeaderPtrs [ i ] 
. is_some ( ) 
) 

) 
{ 
free ( 
SectionHeaderPtrs [ i ] 
) ;


translate_bpc_vpp ! ( 
i 
) ;

}



free ( 
SectionHeaderPtrs 
) ;

}



i = 0 ;


if 

SectionNamePtrs 
. is_some ( ) 
{ 
while 
( 

( 

i 
< 
get_e_shnum ( 
& 
ElfHeader 

) 

) 
&& 
( 

SectionNamePtrs [ i ] 
. is_some ( ) 
) 

) 
{ 
free ( 
SectionNamePtrs [ i ] 
) ;


translate_bpc_vpp ! ( 
i 
) ;

}



free ( 
SectionNamePtrs 
) ;

}


}


/* 
 *
 */

pub fn AllocateSymbols ( ) -> int32 { 
let Status : int32 = 
( 
0 
) 
;


let i : int32 = 0 ;


if 
NumSymbols == 0 
{ 
print ! ( "Error! Failed to locate any Symbols in '{}'!\n" , SrcFilename ) ;



Status 
= 
( 
1 
) 
;

}



else { 
SymbolPtrs = malloc ( 

// sizeof(union Elf_Sym *)
std::mem::size_of::<*const Elf_Sym>() 
* 
NumSymbols 

) ;


if 

SymbolPtrs 
. is_none ( ) 
{ 
print ! ( "Error! Insufficient memory for number of Symbols in '{}'!\n" , SrcFilename ) ;



Status 
= 
( 
1 
) 
;

}



SymbolNames = malloc ( 

// sizeof(char *)
std::mem::size_of::<*const char>() 
* 
NumSymbols 

) ;


if 

SymbolNames 
. is_none ( ) 
{ 
print ! ( "Error! Insufficient memory for number of Symbols in '{}'!\n" , SrcFilename ) ;



Status 
= 
( 
1 
) 
;

}



i = 0 ;
while 
i 
< 
NumSymbols 
{ 

SymbolPtrs [ i ] 
= None ;



SymbolNames [ i ] 
= None ;


translate_bpc_vpp ! ( i ) 
}



if 

Status 
== 
( 
0 
) 

{ /* Allocate memory for each symbol */

i = 0 ;
while 
i 
< 
NumSymbols 
{ 
SymbolPtrs [ 
i 
] = 
// (union Elf_Sym *)malloc(sizeof(union Elf_Sym))
Box::into_raw(Box::new(std::mem::zeroed::<Elf_Sym>())) as *mut Elf_Sym 
;


if 

SymbolPtrs [ i ] 
. is_none ( ) 
{ 
print ! ( "Error! Insufficient memory to store Symbol Headers\n" ) ;



Status 
= 
( 
1 
) 
;

}



translate_bpc_vpp ! ( i ) 
}


}


}



return Status ;

}


/* 
 *
 */

pub fn DeallocateSymbols ( ) { 
let i : int32 = 0 ;


if 

SymbolPtrs 
. is_some ( ) 
{ 
while 
( 

( 
i 
< 
NumSymbols 
) 
&& 
( 

SymbolPtrs [ i ] 
. is_some ( ) 
) 

) 
{ 
free ( 
SymbolPtrs [ i ] 
) ;


if 

SymbolNames [ i ] 
. is_some ( ) 
{ 
free ( 
SymbolNames [ i ] 
) ;

}



translate_bpc_vpp ! ( 
i 
) ;

}



free ( 
SymbolPtrs 
) ;

}


}


/* 
 *
 */

pub fn FreeMemoryAllocations ( ) { 
DeallocateSymbols ( ) ;


DeallocateSectionHeaders ( ) ;


if 

SrcFileDesc 
. is_some ( ) 
{ 
fclose ( 
SrcFileDesc 
) ;

}



if 

DstFileDesc 
. is_some ( ) 
{ 
fclose ( 
DstFileDesc 
) ;

}


}


/* 
 *
 */

pub fn ProcessCmdLineOptions ( 
ArgumentCount : i32 , 

// char *Arguments[]
let mut Arguments: [*mut i8; N] = [std::ptr::null_mut(); N]; // N should be defined as per the required size 
) -> int32 { 
let Status : int32 = 
( 
0 
) 
;


let InputFileSpecified : _Bool = 0 ;


let OutputFileSpecified : _Bool = 0 ;


let i : i32 = 1 ;


// char * EndPtr;
let mut EndP: *mut i8; 

let mut MaxDay : uint32 = Default :: default ( ) ;


let FileEpochTm : tm = Default :: default ( ) ;


let ScEpochTm : tm = Default :: default ( ) ;


let mut FileEpochInSecs : time_t = Default :: default ( ) ;


let mut ScEpochInSecs : time_t = Default :: default ( ) ;


while 
( 

( 
i 
< 
ArgumentCount 
) 
&& 
( 

Status 
== 
( 
0 
) 

) 

) 
{ 
if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
't' 

) 

{ /* Extract the Table Name Override */

strncpy ( 
TableName , 

& 

Arguments [ i ] 
[ 
2 
] 


, 


std :: mem :: size_of_val ( & TableName ) 
- 
1 

) ;


TableName [ 

std :: mem :: size_of_val ( & TableName ) 
- 
1 

] = 
0 
;


TableNameOverride = 1 ;

}



else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
'd' 

) 

{ /* Extract the Description Override */

strncpy ( 
Description , 

& 

Arguments [ i ] 
[ 
2 
] 


, 


std :: mem :: size_of_val ( & Description ) 
- 
1 

) ;


Description [ 

std :: mem :: size_of_val ( & Description ) 
- 
1 

] = 
0 
;


DescriptionOverride = 1 ;

}



else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
's' 

) 

{ 
SpacecraftID = strtoul ( 
& 

Arguments [ i ] 
[ 
2 
] 


, 

& 
EndPtr , 


, 

0 
) ;


if 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
2 
] 


{ 
ScIDSpecified = 1 ;

}



else { 
print ! ( "Error!, Spacecraft ID of '{}' cannot be interpreted as an integer.\n" , 
& 

Arguments [ i ] 
[ 
2 
] 

) ;


Status = 0 ;

}


}



else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
'S' 

) 

{ 
if 

strlen ( 
& 

Arguments [ i ] 
[ 
2 
] 

) 
== 
4 

{ 

SpacecraftID 
= 
( 




( 

Arguments [ i ] 
[ 
2 
] 
) as uint32 
<< 
24 

| 

( 

Arguments [ i ] 
[ 
3 
] 
) as uint32 
<< 
16 


| 

( 

Arguments [ i ] 
[ 
4 
] 
) as uint32 
<< 
8 


| 
( 

Arguments [ i ] 
[ 
5 
] 
) as uint32 

) 
;


ScIDSpecified = 1 ;

}



else { 
print ! ( "Error!, Spacecraft ID of '{}' does not have exactly 4 characters.\n" , 
& 

Arguments [ i ] 
[ 
2 
] 

) ;


Status = 0 ;

}


}



else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
'a' 

) 

{ 
ApplicationID = strtoul ( 
& 

Arguments [ i ] 
[ 
2 
] 


, 

& 
EndPtr , 


, 

0 
) ;


if 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
2 
] 


{ 
AppIDSpecified = 1 ;

}



else { 
print ! ( "Error!, Application ID of '{}' cannot be interpreted as an integer.\n" , 
& 

Arguments [ i ] 
[ 
2 
] 

) ;


Status = 0 ;

}


}



else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
'p' 

) 

{ 
ProcIDSpecified = 1 ;


ProcessorID = strtoul ( 
& 

Arguments [ i ] 
[ 
2 
] 


, 

& 
EndPtr , 


, 

0 
) ;


if 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
2 
] 


{ 
ProcIDSpecified = 1 ;

}



else { 
print ! ( "Error!, Processor ID of '{}' cannot be interpreted as an integer.\n" , 
& 

Arguments [ i ] 
[ 
2 
] 

) ;


Status = 0 ;

}


}



else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
'P' 

) 

{ 
if 

strlen ( 
& 

Arguments [ i ] 
[ 
2 
] 

) 
== 
4 

{ 

ProcessorID 
= 
( 




( 

Arguments [ i ] 
[ 
2 
] 
) as uint32 
<< 
24 

| 

( 

Arguments [ i ] 
[ 
3 
] 
) as uint32 
<< 
16 


| 

( 

Arguments [ i ] 
[ 
4 
] 
) as uint32 
<< 
8 


| 
( 

Arguments [ i ] 
[ 
5 
] 
) as uint32 

) 
;


ProcIDSpecified = 1 ;

}



else { 
print ! ( "Error!, Processor ID of '{}' does not have exactly 4 characters.\n" , 
& 

Arguments [ i ] 
[ 
2 
] 

) ;


Status = 0 ;

}


}



else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
'h' 

) 

{ 
OutputHelp = 1 ;

}



else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
'v' 

) 

{ 
Verbose = 1 ;

}



else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
'V' 

) 

{ 
ReportVersion = 1 ;

}



else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
'n' 

) 

{ /* This option is ignored for compatibility */

// }
} 

else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
'T' 

) 

{ 
EnableTimeTagInHeader = 1 ;

}



else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
'e' 

) 

{ 
ScEpoch . Year = 
strtoul ( 
& 

Arguments [ i ] 
[ 
2 
] 


, 

& 
EndPtr , 


, 

0 
) 
;


if 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
6 
] 


{ 
fprintf ( 
stderr , 

"Error! Spacecraft Epoch Year is not of the form 'YYYY:'\n" 
) ;


Status = 0 ;

}



else { 
ScEpoch . Month = 
strtoul ( 
& 

Arguments [ i ] 
[ 
7 
] 


, 

& 
EndPtr , 


, 

0 
) 
;


if 


( 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
9 
] 


) 
|| 
( 

ScEpoch . Month 
== 
0 

) 

|| 
( 

ScEpoch . Month 
> 
12 

) 

{ 
fprintf ( 
stderr , 

"Error! Spacecraft Epoch Month is not of the form 'MM:' where MM is in the range of 1-12\n" 
) ;


Status = 0 ;

}



else { 
MaxDay = 31 ;


if 



( 

ScEpoch . Month 
== 
4 

) 
|| 
( 

ScEpoch . Month 
== 
6 

) 

|| 
( 

ScEpoch . Month 
== 
9 

) 

|| 
( 

ScEpoch . Month 
== 
11 

) 

{ 
MaxDay = 30 ;

}



else if 

ScEpoch . Month 
== 
2 

{ 
if 

( 

ScEpoch . Year 
% 
4 

) 
== 
0 

{ 
if 

( 

ScEpoch . Year 
% 
100 

) 
== 
0 

{ 
if 

( 

ScEpoch . Year 
% 
400 

) 
== 
0 

{ 
MaxDay = 29 ;

}



else { 
MaxDay = 28 ;

}


}



else { 
MaxDay = 29 ;

}


}



else { 
MaxDay = 28 ;

}


}



ScEpoch . Day = 
strtoul ( 
& 

Arguments [ i ] 
[ 
10 
] 


, 

& 
EndPtr , 


, 

0 
) 
;


if 


( 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
12 
] 


) 
|| 
( 

ScEpoch . Day 
== 
0 

) 

|| 
( 

ScEpoch . Day 
> 
MaxDay 

) 

{ 
fprintf ( 
stderr , 

"Error! Spacecraft Epoch Day is not of the form 'DD:' where DD is in the range of 1-%d\n" , 

MaxDay 
) ;


Status = 0 ;

}



else { 
ScEpoch . Hour = 
strtoul ( 
& 

Arguments [ i ] 
[ 
13 
] 


, 

& 
EndPtr , 


, 

0 
) 
;


if 

( 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
15 
] 


) 
|| 
( 

ScEpoch . Hour 
> 
23 

) 

{ 
fprintf ( 
stderr , 

"Error! Spacecraft Epoch Hour is not of the form 'hh:' where hh is in the range of 0-23\n" 
) ;


Status = 0 ;

}



else { 
ScEpoch . Minute = 
strtoul ( 
& 

Arguments [ i ] 
[ 
16 
] 


, 

& 
EndPtr , 


, 

0 
) 
;


if 

( 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
18 
] 


) 
|| 
( 

ScEpoch . Minute 
> 
59 

) 

{ 
fprintf ( 
stderr , 

"Error! Spacecraft Epoch Minute is not of the form 'mm:' where mm is in the range of 0-59\n" 
) ;


Status = 0 ;

}



else { 
ScEpoch . Second = 
strtoul ( 
& 

Arguments [ i ] 
[ 
19 
] 


, 

& 
EndPtr , 


, 

0 
) 
;


if 

( 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
21 
] 


) 
|| 
( 

ScEpoch . Second 
> 
59 

) 

{ 
fprintf ( 
stderr , 

"Error! Spacecraft Epoch Second is not of the form 'ss' where ss is in the range of 0-59\n" 
) ;


Status = 0 ;

}



else { 
ScEpochSpecified = 1 ;

}


}


}


}


}


}


}



else if 

( 


Arguments [ i ] 
[ 
0 
] 
== 
'-' 

) 
&& 
( 


Arguments [ i ] 
[ 
1 
] 
== 
'f' 

) 

{ 
FileEpoch . Year = 
strtoul ( 
& 

Arguments [ i ] 
[ 
2 
] 


, 

& 
EndPtr , 


, 

0 
) 
;


if 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
6 
] 


{ 
fprintf ( 
stderr , 

"Error! File Epoch Year is not of the form 'YYYY:'\n" 
) ;


Status = 0 ;

}



else { 
FileEpoch . Month = 
strtoul ( 
& 

Arguments [ i ] 
[ 
7 
] 


, 

& 
EndPtr , 


, 

0 
) 
;


if 


( 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
9 
] 


) 
|| 
( 

FileEpoch . Month 
== 
0 

) 

|| 
( 

FileEpoch . Month 
> 
12 

) 

{ 
fprintf ( 
stderr , 

"Error! File Epoch Month is not of the form 'MM:' where MM is in the range of 1-12\n" 
) ;


Status = 0 ;

}



else { 
MaxDay = 31 ;


if 



( 

FileEpoch . Month 
== 
4 

) 
|| 
( 

FileEpoch . Month 
== 
6 

) 

|| 
( 

FileEpoch . Month 
== 
9 

) 

|| 
( 

FileEpoch . Month 
== 
11 

) 

{ 
MaxDay = 30 ;

}



else if 

FileEpoch . Month 
== 
2 

{ 
if 

( 

FileEpoch . Year 
% 
4 

) 
== 
0 

{ 
if 

( 

FileEpoch . Year 
% 
100 

) 
== 
0 

{ 
if 

( 

FileEpoch . Year 
% 
400 

) 
== 
0 

{ 
MaxDay = 29 ;

}



else { 
MaxDay = 28 ;

}


}



else { 
MaxDay = 29 ;

}


}



else { 
MaxDay = 28 ;

}


}



FileEpoch . Day = 
strtoul ( 
& 

Arguments [ i ] 
[ 
10 
] 


, 

& 
EndPtr , 


, 

0 
) 
;


if 


( 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
12 
] 


) 
|| 
( 

FileEpoch . Day 
== 
0 

) 

|| 
( 

FileEpoch . Day 
> 
MaxDay 

) 

{ 
fprintf ( 
stderr , 

"Error! File Epoch Day is not of the form 'DD:' where DD is in the range of 1-%d\n" , 

MaxDay 
) ;


Status = 0 ;

}



else { 
FileEpoch . Hour = 
strtoul ( 
& 

Arguments [ i ] 
[ 
13 
] 


, 

& 
EndPtr , 


, 

0 
) 
;


if 

( 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
15 
] 


) 
|| 
( 

FileEpoch . Hour 
> 
23 

) 

{ 
fprintf ( 
stderr , 

"Error! File Epoch Hour is not of the form 'hh:' where hh is in the range of 0-23\n" 
) ;


Status = 0 ;

}



else { 
FileEpoch . Minute = 
strtoul ( 
& 

Arguments [ i ] 
[ 
16 
] 


, 

& 
EndPtr , 


, 

0 
) 
;


if 

( 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
18 
] 


) 
|| 
( 

FileEpoch . Minute 
> 
59 

) 

{ 
fprintf ( 
stderr , 

"Error! File Epoch Minute is not of the form 'mm:' where mm is in the range of 0-59\n" 
) ;


Status = 0 ;

}



else { 
FileEpoch . Second = 
strtoul ( 
& 

Arguments [ i ] 
[ 
19 
] 


, 

& 
EndPtr , 


, 

0 
) 
;


if 

( 

EndPtr 
!= 
& 

Arguments [ i ] 
[ 
21 
] 


) 
|| 
( 

FileEpoch . Second 
> 
59 

) 

{ 
fprintf ( 
stderr , 

"Error! File Epoch Second is not of the form 'ss' where ss is in the range of 0-59\n" 
) ;


Status = 0 ;

}



else { 
FileEpochSpecified = 1 ;

}


}


}


}


}


}


}



else if 
! 
InputFileSpecified 

{ 
strncpy ( 
SrcFilename , 

Arguments [ i ] 

, 

4096 - 1 
) ;


SrcFilename [ 
4096 - 1 
] = 
// '\0'
translated Rust code here 
;


InputFileSpecified = 1 ;

}



else if 
! 
OutputFileSpecified 

{ 
strncpy ( 
DstFilename , 

Arguments [ i ] 

, 

4096 - 1 
) ;


DstFilename [ 
4096 - 1 
] = 
// '\0'
translated Rust code here 
;


OutputFileSpecified = 1 ;

}



else { 
print ! ( "\nError! Unknown Command Line Option '{}'\n" , 
Arguments [ i ] 
) ;



Status 
= 
( 
1 
) 
;

}



translate_bpc_vpp ! ( 
i 
) ;

}


}



FileEpochTm . tm_sec = 
FileEpoch . Second 
;


FileEpochTm . tm_min = 
FileEpoch . Minute 
;


FileEpochTm . tm_hour = 
FileEpoch . Hour 
;


FileEpochTm . tm_mday = 
FileEpoch . Day 
;


FileEpochTm . tm_mon = 

FileEpoch . Month 
- 
1 

;


FileEpochTm . tm_year = 

FileEpoch . Year 
- 
1900 

;


FileEpochTm . tm_isdst = 
-1 
;


FileEpochInSecs = mktime ( 
& 
FileEpochTm 

) ;


ScEpochTm . tm_sec = 
ScEpoch . Second 
;


ScEpochTm . tm_min = 
ScEpoch . Minute 
;


ScEpochTm . tm_hour = 
ScEpoch . Hour 
;


ScEpochTm . tm_mday = 
ScEpoch . Day 
;


ScEpochTm . tm_mon = 

ScEpoch . Month 
- 
1 

;


ScEpochTm . tm_year = 

ScEpoch . Year 
- 
1900 

;


ScEpochTm . tm_isdst = 
-1 
;


ScEpochInSecs = mktime ( 
& 
ScEpochTm 

) ;


EpochDelta = FileEpochInSecs - ScEpochInSecs ;


return Status ;

}


/* 
 *
 */

pub fn OutputVersionInfo ( ) { 
// char VersionString[256];
const VersionString: [u8; ELF2C] 

snprintf ( 
VersionString , 

256 , 

"%s %s %s (Codename %s), Last Official Release: %s %s)" , 

"elf2cfetbl" , 

if 
0 
== 
0 
{ 
"Development Build" 
}

else { 
"Release" , 
}



, 

"equuleues-rc122" , 

"Equuleus" , 

"elf2cfetbl" , 

"v3.1.0" 
) ;


print ! ( "\n{}\n" , VersionString ) ;

}


/* 
 *
 */

pub fn OutputHelpInfo ( ) { 
print ! ( "\nElf Object File to cFE Table Image File Conversion Tool (elf2cfetbl)\n\n" ) ;


print ! ( "elf2cfetbl [-tTblName] [-d\"Description\"] [-h] [-v] [-V] [-s#] [-p#] [-n] \n" ) ;


print ! ( "           [-T] [-eYYYY:MM:DD:hh:mm:ss] [-fYYYY:MM:DD:hh:mm:ss] SrcFilename [DestDirectory]\n" ) ;


print ! ( "   where:\n" ) ;


print ! ( "   -tTblName             replaces the table name specified in the object file with 'TblName'\n" ) ;


print ! ( "   -d\"Description\"       replaces the description specified in the object file with 'Description'\n" ) ;


print ! ( "   -h                    produces this output\n" ) ;


print ! ( "   -v                    produces verbose output showing the breakdown of the object file in detail\n" ) ;


print ! ( "   -V                    shows the version of this utility\n" ) ;


print ! ( "   -s#                   specifies a Spacecraft ID to be put into file header.\n" ) ;


print ! ( "                         # can be specified as decimal, octal (starting with a zero), or hex (starting with '0x')\n" ) ;


print ! ( "   -Scccc                specifies a Spacecraft ID as a 4 byte string to be put into the table file file header.\n" ) ;


print ! ( "                         cccc represents the 4 ASCII characters that will be encoded into the 32 bit Spacecraft ID field.\n" ) ;


print ! ( "                              examples: -SMMS1 or -SQQ#2\n" ) ;


print ! ( "   -p#                   specifies a Processor ID to be put into file header.\n" ) ;


print ! ( "                         # can be specified as decimal, octal (starting with a zero), or hex (starting with '0x')\n" ) ;


print ! ( "   -Pcccc                specifies a Processor ID as a 4 byte string to be put into the table file header.\n" ) ;


print ! ( "                         cccc represents the 4 ASCII characters that will be encoded into the 32 bit Processor ID field.\n" ) ;


print ! ( "                              examples: -PMMS1 or -PQQ#2\n" ) ;


print ! ( "   -a#                   specifies an Application ID to be put into file header.\n" ) ;


print ! ( "                         # can be specified as decimal, octal (starting with a zero), or hex (starting with '0x')\n" ) ;


print ! ( "   -T                    enables insertion of the SrcFilename's file creation time into the standard cFE File Header.\n" ) ;


print ! ( "                         This option must be specified for either the '-e' and/or '-f' options below to have any effect.\n" ) ;


print ! ( "                         By default, the time tag fields are set to zero.\n" ) ;


print ! ( "   -eYYYY:MM:DD:hh:mm:ss specifies the spacecraft epoch time.  The SrcFilename's file creation time will be converted to\n" ) ;


print ! ( "                         seconds since the specified epoch time and stored in the standard cFE File Header.\n" ) ;


print ! ( "                         where:   YYYY=year, MM=month (01-12), DD=day (01-31), \n" ) ;


print ! ( "                                  hh=hour (00-23), mm=minute (00-59), ss=seconds (00-59)\n" ) ;


print ! ( "                         If no epoch is specified, the default epoch is either 1970:01:01:00:00:00 or the epoch specified\n" ) ;


print ! ( "                         by the user using the '-f' option described below\n" ) ;


print ! ( "                         This option requires the '-T' option, defined above, to be specified to have any effect\n" ) ;


print ! ( "   -fYYYY:MM:DD:hh:mm:ss specifies the file system epoch time.  The SrcFilename's file creation time is obtained from the\n" ) ;


print ! ( "                         file system as seconds since an epoch.  On most systems the file system epoch is defined as\n" ) ;


print ! ( "                         1970:01:01:00:00:00.  If the user is running this application on a machine with a different epoch,\n" ) ;


print ! ( "                         then the file system epoch should be defined with this option.\n" ) ;


print ! ( "                         where:   YYYY=year, MM=month (01-12), DD=day (01-31), \n" ) ;


print ! ( "                                  hh=hour (00-23), mm=minute (00-59), ss=seconds (00-59)\n" ) ;


print ! ( "                         If no epoch is specified, the default epoch is 1970:01:01:00:00:00\n" ) ;


print ! ( "                         This option requires the '-T' option, defined above, to be specified to have any effect\n" ) ;


print ! ( "   SrcFilename           specifies the object file to be converted\n" ) ;


print ! ( "   DestDirectory         specifies the directory in which the cFE Table Image file is to be created.\n" ) ;


print ! ( "                         If a directory is not specified './' is assumed.\n" ) ;


print ! ( "\n" ) ;


print ! ( "EXAMPLES:\n" ) ;


print ! ( "   elf2cfetbl MyObjectFile ../../TblDefaultImgDir/\n" ) ;


print ! ( "   elf2cfetbl -s12 -p0x0D -a016 -e2000:01:01:00:00:00 MyObjectFile ../../TblDefaultImgDir/\n" ) ;


print ! ( "\n" ) ;


print ! ( "NOTE: The name of the target file is specified within the source file as part of the CFE_TBL_FILEDEF macro.\n" ) ;


print ! ( "      If the macro has not been included in the source file, the utility will fail to convert the object file.\n" ) ;

}


/* 
 *
 */

pub fn GetSrcFilename ( ) -> int32 { 
let Status : int32 = 
( 
0 
) 
;


if 

SrcFilename . len ( ) 
== 
0 

{ 
OutputHelp = 1 ;



Status 
= 
( 
1 
) 
;

}



return Status ;

}


/* 
 *
 */

pub fn GetDstFilename ( ) -> int32 { 
let Status : int32 = 
( 
0 
) 
;


if 

DstFilename . len ( ) 
== 
0 

{ 
strcpy ( 
DstFilename , 

"./" 
) ;

}



strcat ( 
DstFilename , 

TblFileDef . TgtFilename 
) ;


if 
Verbose 
{ 
print ! ( "Target Filename: {}\n" , DstFilename ) ;

}



return Status ;

}


/* 
 *
 */

pub fn OpenSrcFile ( ) -> int32 { 
let RtnCode : i32 = Default :: default ( ) ;


// char TimeBuff[50];
let mut TimeBuff: [u8; 50] = [0; 50]; 
/* Check to see if input file can be found and opened */

SrcFileDesc = fopen ( 
SrcFilename , 

"r" 
) ;


if 

SrcFileDesc 
. is_none ( ) 
{ 
print ! ( "'{}' was not opened\n" , SrcFilename ) ;



( 
1 
) 

}


/* Obtain time of object file's last modification */

RtnCode = stat ( 
SrcFilename , 

& 
SrcFileStats 

) ;


if 
RtnCode == 0 
{ 

SrcFileTimeInScEpoch 
= 

SrcFileStats . st_mtime 
+ 
EpochDelta 

;


if 
Verbose 
{ 
print ! ( "Original Source File Modification Time: {}\n" , 
ctime_r ( 
& 
SrcFileStats . st_mtime 


, 

TimeBuff 
) 
) ;


print ! ( "Source File Modification Time in Seconds since S/C Epoch: {} (0x{:08X})\n" , SrcFileTimeInScEpoch , SrcFileTimeInScEpoch ) ;

}


}



else { 
if 
Verbose 
{ 
print ! ( "Unable to get modification time from {}" , SrcFilename ) ;

}



SrcFileTimeInScEpoch = 0 ;

}




( 
0 
) 

}



pub fn OpenDstFile ( ) -> int32 { 
let dststat : stat = Default :: default ( ) ;


let Status : int32 = 
( 
0 
) 
;

/* Check to see if output file can be opened and written */

* DstFileDesc . lock ( ) . unwrap ( ) = std :: fs :: File :: create ( DstFilename ) . ok ( ) ;


if 

DstFileDesc 
. is_none ( ) 
{ 
print ! ( "'{}' was not opened\n" , DstFilename ) ;



( 
1 
) 

}


/* Fix file if too permissive (CWE-732) */

if 

stat ( 
DstFilename , 

& 
dststat 

) 
== 
0 

{ 
if 
Verbose 
{ 
print ! ( "{}: Destination file permissions after open = 0x{:X}\n" , 
DstFilename , 

dststat . st_mode 
) ;

}



Status = chmod ( 
DstFilename , 


dststat . st_mode 
& 
! 
( 





( 

0400 
>> 
3 

) 
| 
( 

0200 
>> 
3 

) 

| 
( 

0100 
>> 
3 

) 

| 
( 

( 

0400 
>> 
3 

) 
>> 
3 

) 

| 
( 

( 

0200 
>> 
3 

) 
>> 
3 

) 

| 
( 

( 

0100 
>> 
3 

) 
>> 
3 

) 

) 


) ;


if 
Status 
!= 
0 
{ 
print ! ( "{}: Error while attempting to modify file permissions\n" , DstFilename ) ;



( 
1 
) 

}



if 

stat ( 
DstFilename , 

& 
dststat 

) 
!= 
0 

{ 
print ! ( "{}: Error retrieving file status after chmod\n" , DstFilename ) ;

}



if 
Verbose 
{ 
print ! ( "{}: Destination file permissions after chmod = 0x{:X}\n" , 
DstFilename , 

dststat . st_mode 
) ;

}


}




( 
0 
) 

}


/* 
 *
 */

pub fn checkELFFileMagicNumber ( ) -> int32 { 
if 




get_e_ident ( 
& 
ElfHeader , 


, 

0 
) 
!= 
0x7f 

|| 

get_e_ident ( 
& 
ElfHeader , 


, 

1 
) 
!= 
'E' 


|| 

get_e_ident ( 
& 
ElfHeader , 


, 

2 
) 
!= 
'L' 


|| 

get_e_ident ( 
& 
ElfHeader , 


, 

3 
) 
!= 
'F' 


{ 

( 
1 
) 

}




( 
0 
) 

}


/* 
 *
 */

pub fn GetElfHeader ( ) -> int32 { 
let Status : int32 = 
( 
0 
) 
;


let NumHdrsRead : size_t = 0 ;


// char VerboseStr[60];
let mut VerboseStr: [char; 60] = ['\\0'; 60]; 

let EndiannessCheck : int32 = 0x01020304 ;


if 


( 
// (char *)&EndiannessCheck
EndiannessCheck as *const _ as *const u8 
) 
[ 
0 
] 
== 
0x01 

{ 
ThisMachineIsLittleEndian = 0 ;

}



else if 


( 
// (char *)&EndiannessCheck
unsafe { &EndiannessCheck as *const _ as *const u8 } 
) 
[ 
0 
] 
!= 
0x04 

{ 
print ! ( "Unable to determine endianness of this machine! (0x{:02x}, 0x{:02x}, 0x{:02x}, 0x{:02x})\n" , 

( 
// (char *)&EndiannessCheck
unsafe { &EndiannessCheck as *const _ as *const u8 } 
) 
[ 
0 
] 

, 


( 
// (char *)&EndiannessCheck
EndiannessCheck as *const _ as *const u8 
) 
[ 
1 
] 

, 


( 
// (char *)&EndiannessCheck
(&EndiannessCheck as *const _ as *const u8) 
) 
[ 
2 
] 

, 


( 
// (char *)&EndiannessCheck
(EndiannessCheck as *const _ as *const u8) 
) 
[ 
3 
] 
) ;



( 
1 
) 

}


/* Begin by reading e_ident characters */

NumHdrsRead = fread ( 
& 
ElfHeader , 


, 

16 , 

1 , 

SrcFileDesc 
) ;


if 
NumHdrsRead 
!= 
1 
{ 
print ! ( "Experienced error attempting to read e_ident of ELF Header from file '{}'\n" , SrcFilename ) ;



( 
1 
) 

}



if 
Verbose 
{ 
print ! ( "ELF Header:\n   e_ident[EI_MAG0..3] = 0x{:02x},{}{}{}\n" , 
get_e_ident ( 
& 
ElfHeader , 


, 

0 
) 

, 

get_e_ident ( 
& 
ElfHeader , 


, 

1 
) 

, 

get_e_ident ( 
& 
ElfHeader , 


, 

2 
) 

, 

get_e_ident ( 
& 
ElfHeader , 


, 

3 
) 
) ;

}


/* Verify the ELF file magic number */

Status = checkELFFileMagicNumber ( ) ;


if 

Status 
== 
( 
1 
) 

{ 
print ! ( "Source File '{}' does not have an ELF Magic Number\n" , SrcFilename ) ;


print ! ( "If this object file was compiled on a PC under cygwin, then it is probably in COFF format.\n" ) ;


print ! ( "To convert it to an elf file, use the following command:\n" ) ;


print ! ( "./objcopy -O elf32-little {} {}.elf\n" , SrcFilename , SrcFilename ) ;


print ! ( "then try running this utility again on the {}.elf file\n" , SrcFilename ) ;


return Status ;

}


/* Verify the processor class type */

match 
get_e_ident ( 
& 
ElfHeader , 


, 

4 
) 
{ 
0 => { 
sprintf ( 
VerboseStr , 

"ELFCLASSNONE (0)" 
) ;



Status 
= 
( 
1 
) 
;

}



1 => { 
sprintf ( 
VerboseStr , 

"ELFCLASS32 (1)" 
) ;


if 
Verbose 
{ 
print ! ( "Target table is 32 bit\n" ) ;

}



TargetWordsizeIs32Bit = 1 ;

}



2 => { 
sprintf ( 
VerboseStr , 

"ELFCLASS64 (2)" 
) ;


if 
Verbose 
{ 
print ! ( "Target table is 64 bit\n" ) ;

}



TargetWordsizeIs32Bit = 0 ;

}


_ => { 
sprintf ( 
VerboseStr , 

"Invalid Class (%d)" , 

get_e_ident ( 
& 
ElfHeader , 


, 

4 
) 
) ;



Status 
= 
( 
1 
) 
;

}

}



if 

Status 
== 
( 
1 
) 

{ 
print ! ( "Source file '{}' contains objects of class type '{}' which is unsupported by this utility\n" , SrcFilename , VerboseStr ) ;


return Status ;

}



if 
Verbose 
{ 
print ! ( "   e_ident[EI_CLASS] = {}\n" , VerboseStr ) ;

}


/* Verify Data Encoding type */

match 
get_e_ident ( 
& 
ElfHeader , 


, 

5 
) 
{ 
0 => { 
sprintf ( 
VerboseStr , 

"ELFDATANONE" 
) ;



Status 
= 
( 
1 
) 
;

}



1 => { 
sprintf ( 
VerboseStr , 

"ELFDATA2LSB (Little-Endian)" 
) ;


TargetMachineIsLittleEndian = 1 ;


if 
ThisMachineIsLittleEndian == 0 
{ 
ByteSwapRequired = 1 ;

}


}



2 => { 
sprintf ( 
VerboseStr , 

"ELFDATA2MSB (Big-Endian)" 
) ;


TargetMachineIsLittleEndian = 0 ;


if 
ThisMachineIsLittleEndian == 1 
{ 
ByteSwapRequired = 1 ;

}


}


_ => { 
sprintf ( 
VerboseStr , 

"Unknown Data Encoding Type (%d)" , 

get_e_ident ( 
& 
ElfHeader , 


, 

5 
) 
) ;



Status 
= 
( 
1 
) 
;

}

}



if 

Status 
== 
( 
1 
) 

{ 
print ! ( "Source file '{}' contains data encoded with '{}'\n" , SrcFilename , VerboseStr ) ;


return Status ;

}



if 
Verbose 
{ 
print ! ( "   e_ident[EI_DATA] = {}\n" , VerboseStr ) ;

}


/* Verify ELF Header Version */

if 

get_e_ident ( 
& 
ElfHeader , 


, 

6 
) 
!= 
1 

{ 
print ! ( "Source file '{}' is improper ELF header version ({})\n" , 
SrcFilename , 

get_e_ident ( 
& 
ElfHeader , 


, 

6 
) 
) ;



( 
1 
) 

}



if 
Verbose 
{ 
print ! ( "   e_ident[EI_VERSION] = {}\n" , 
get_e_ident ( 
& 
ElfHeader , 


, 

6 
) 
) ;

}


/* Now that e_ident is processed (with word size), read rest of the header */

if 
TargetWordsizeIs32Bit 
{ 
NumHdrsRead = fread ( 
& 
( 

ElfHeader . Ehdr32 
. e_type 
) 


, 


std :: mem :: size_of_val ( & Elf32_Ehdr ) 
- 
16 , 


, 

1 , 

SrcFileDesc 
) ;

}



else { 
NumHdrsRead = fread ( 
& 
( 

ElfHeader . Ehdr64 
. e_type 
) 


, 


std :: mem :: size_of_val ( & Elf64_Ehdr ) 
- 
16 , 


, 

1 , 

SrcFileDesc 
) ;

}



if 
NumHdrsRead 
!= 
1 
{ 
print ! ( "Experienced error attempting to read remaining ELF Header from file '{}'\n" , SrcFilename ) ;



( 
1 
) 

}



if 
ByteSwapRequired == 1 
{ 
SwapElfHeader ( ) ;

}


/* Verify ELF Type */

Status = GetStringFromMap ( 
& 
VerboseStr [ 0 ] 


, 

e_type_Map , 


get_e_type ( 
& 
ElfHeader 

) 
as int32 
) ;


if 

Status 
== 
( 
1 
) 

{ 
print ! ( "Error in source file '{}' - {}\n" , SrcFilename , VerboseStr ) ;



( 
1 
) 

}



if 
Verbose 
{ 
print ! ( "   e_type = {}\n" , VerboseStr ) ;

}


/* Verify machine type */

Status = GetStringFromMap ( 
& 
VerboseStr [ 0 ] 


, 

e_machine_Map , 


get_e_machine ( 
& 
ElfHeader 

) 
as int32 
) ;


if 

Status 
== 
( 
1 
) 

{ 
print ! ( "Error in source file '{}' - {}\n" , SrcFilename , VerboseStr ) ;



( 
1 
) 

}



if 
Verbose 
{ 
print ! ( "   e_machine = {}\n" , VerboseStr ) ;

}


/* Verify ELF Object File Version */

if 

get_e_version ( 
& 
ElfHeader 

) 
!= 
1 

{ 
print ! ( "Error in source file '{}' - Improper ELF object version ({})\n" , 
SrcFilename , 

get_e_version ( 
& 
ElfHeader 

) 
) ;



( 
1 
) 

}



if 
TargetWordsizeIs32Bit 
{ 
PrintElfHeader32 ( 
ElfHeader 
) ;

}



else { 
PrintElfHeader64 ( 
ElfHeader 
) ;

}



return Status ;

}


/* 
 *
 */

pub fn GetSectionHeader ( 
SectionIndex : int32 , 

// union Elf_Shdr *SectionHeader
let section_header: *mut Elf_Shdr; 
) -> int32 { 
let Status : int32 = 
( 
0 
) 
;


let NumHdrsRead : size_t = 0 ;


// char VerboseStr[60];
let mut VerboseStr: [char; 60] = ['\\0'; 60]; 

let mut SeekOffset : int64 = Default :: default ( ) ;


let mut Shentsize : int32 = Default :: default ( ) ;


let i : int32 = 0 ;


if 
TargetWordsizeIs32Bit 
{ 

SeekOffset 
= 

ElfHeader . Ehdr32 
. e_shoff 
;



Shentsize 
= 

ElfHeader . Ehdr32 
. e_shentsize 
;

}



else { 

SeekOffset 
= 

ElfHeader . Ehdr64 
. e_shoff 
;



Shentsize 
= 

ElfHeader . Ehdr64 
. e_shentsize 
;

}



if 
SectionIndex 
> 
0 
{ 

SeekOffset 
= 

SeekOffset 
+ 
( 
SectionIndex * Shentsize 
) 

;

}



Status = fseek ( 
SrcFileDesc , 

SeekOffset , 

0 
) ;


if 
Status 
!= 
0 
{ 
print ! ( "Error locating Section Header #{} in file '{}'\n" , SectionIndex , SrcFilename ) ;



( 
1 
) 

}



if 
TargetWordsizeIs32Bit 
{ 
NumHdrsRead = fread ( 
SectionHeader , 

std :: mem :: size_of_val ( & Elf32_Shdr ) 

, 

1 , 

SrcFileDesc 
) ;

}



else { 
NumHdrsRead = fread ( 
SectionHeader , 

std :: mem :: size_of_val ( & Elf64_Shdr ) 

, 

1 , 

SrcFileDesc 
) ;

}



if 
NumHdrsRead 
!= 
1 
{ 
print ! ( "Experienced error attempting to read Section Header #{} from file '{}'\n" , SectionIndex , SrcFilename ) ;



( 
1 
) 

}



if 
ByteSwapRequired == 1 
{ 
SwapSectionHeader ( 
SectionHeader 
) ;

}



if 

( 
SectionHeaderStringTableDataOffset 
!= 
0 
) 
&& 
( 

get_sh_name ( SectionHeader ) 
!= 
0 

) 

{ 
if 
Verbose 
{ 
print ! ( "Section Header #{}:\n" , SectionIndex ) ;

}




SeekOffset 
= 

SectionHeaderStringTableDataOffset 
+ 
get_sh_name ( SectionHeader ) 

;


if 
Verbose 
{ 
print ! ( "   sh_name       = 0x{:08x} - " , 
get_sh_name ( SectionHeader ) 
) ;

}



fseek ( 
SrcFileDesc , 

SeekOffset , 

0 
) ;


while 
( 

( 

VerboseStr [ i ] 
= 
fgetc ( SrcFileDesc ) 

) 
!= 
// '\0'
'\\0' 

) 
{ 
translate_bpc_vpp ! ( 
i 
) ;

}



if 
Verbose 
{ 
print ! ( "{}\n" , VerboseStr ) ;

}


/* Save the name for later reference */

strncpy ( 
SectionNamePtrs [ SectionIndex ] 

, 

VerboseStr , 

( 

( 
128 
) 
- 
1 

) 
) ;




SectionNamePtrs [ SectionIndex ] 
[ 
( 

( 
128 
) 
- 
1 

) 
] 
= 
// '\0'
R_NA 
;


match 
get_sh_type ( SectionHeader ) 
{ 
0 => { 
sprintf ( 
VerboseStr , 

"SHT_NULL (0)" 
) ;

}



1 => { 
sprintf ( 
VerboseStr , 

"SHT_PROGBITS (1)" 
) ;

}



2 => { 
if 
TargetWordsizeIs32Bit 
{ 

SymbolTableDataOffset 
= 



SectionHeader 
. Shdr32 
. sh_offset 
+ 
std :: mem :: size_of_val ( & Elf32_Sym ) 

;

}



else { 

SymbolTableDataOffset 
= 



SectionHeader 
. Shdr64 
. sh_offset 
+ 
std :: mem :: size_of_val ( & Elf64_Sym ) 

;

}



SymbolTableEntrySize = get_sh_entsize ( SectionHeader ) ;


if 
SymbolTableEntrySize == 0 
{ 
NumSymbols = 0 ;

}



else { 

NumSymbols 
= 

( 

get_sh_size ( SectionHeader ) 
/ 
SymbolTableEntrySize 

) 
- 
1 

;

}



sprintf ( 
VerboseStr , 

"SHT_SYMTAB (2) - # Symbols = %lu" , 

// (long unsigned int)NumSymbols
NumSymbols as u64 
) ;

}



3 => { 
sprintf ( 
VerboseStr , 

"SHT_STRTAB (3)" 
) ;

/*
                 * If the section name is ".strtab" then preferentially use this section for symbol name data
                 * Otherwise use the first section which is NOT the section header string table (.shstrtab)
                 *
                 * Not all compilers generate a separate strtab for section header names; some put everything
                 * into one string table.
                 */

if 


strcmp ( 
SectionNamePtrs [ SectionIndex ] 

, 

".strtab" 
) 
== 
0 

|| 
( 

StringTableDataOffset == 0 
&& 

SectionIndex 
!= 
get_e_shstrndx ( 
& 
ElfHeader 

) 


) 

{ 
StringTableDataOffset = get_sh_offset ( SectionHeader ) ;

}


}



4 => { 
sprintf ( 
VerboseStr , 

"SHT_RELA (4)" 
) ;

}



5 => { 
sprintf ( 
VerboseStr , 

"SHT_HASH (5)" 
) ;

}



6 => { 
sprintf ( 
VerboseStr , 

"SHT_DYNAMIC (6)" 
) ;

}



7 => { 
sprintf ( 
VerboseStr , 

"SHT_NOTE (7)" 
) ;

}



8 => { 
sprintf ( 
VerboseStr , 

"SHT_NOBITS (8)" 
) ;

}



9 => { 
sprintf ( 
VerboseStr , 

"SHT_REL (9)" 
) ;

}



10 => { 
sprintf ( 
VerboseStr , 

"SHT_SHLIB (10)" 
) ;

}



11 => { 
sprintf ( 
VerboseStr , 

"SHT_DYNSYM (11)" 
) ;

}



14 => { 
sprintf ( 
VerboseStr , 

"SHT_INIT_ARRAY (14)" 
) ;

}



15 => { 
sprintf ( 
VerboseStr , 

"SHT_FINI_ARRAY (15)" 
) ;

}



16 => { 
sprintf ( 
VerboseStr , 

"SHT_PREINIT_ARRAY (16)" 
) ;

}



17 => { 
sprintf ( 
VerboseStr , 

"SHT_GROUP (17)" 
) ;

}



18 => { 
sprintf ( 
VerboseStr , 

"SHT_SYMTAB_SHNDX (18)" 
) ;

}


_ => { 
sprintf ( 
VerboseStr , 

"Unknown (%d)" , 

get_sh_type ( SectionHeader ) 
) ;

}

}



if 
Verbose 
{ 
print ! ( "   sh_type       = {}\n" , VerboseStr ) ;

}



if 
Verbose 
{ 
print_sh_flags ( 
SectionHeader 
) ;

}



if 
TargetWordsizeIs32Bit 
{ 
PrintSectionHeader32 ( 
SectionHeader 
) ;

}



else { 
PrintSectionHeader64 ( 
SectionHeader 
) ;

}


}



return Status ;

}


/* 
 *
 */

pub fn GetSymbol ( 
SymbolIndex : int32 , 

// union Elf_Sym *Symbol
let symbol: *mut Elf_Sym; 
) -> int32 { 
let Status : int32 = 
( 
0 
) 
;


let NumSymRead : int32 = 0 ;


let calculated_offset : uint64_t = 

SymbolTableDataOffset 
+ 
( 
SymbolIndex * SymbolTableEntrySize 
) 

;


let SeekOffset : int32_t = 

calculated_offset 
as int32_t 
;


// char VerboseStr[60];
let mut VerboseStr: [char; /* size */] = [ 

let i : int32 = 0 ;


memset ( 
VerboseStr , 

0 , 

std :: mem :: size_of_val ( & VerboseStr ) 
) ;


if 
SeekOffset 
!= 
calculated_offset 
{ 
print ! ( "Error: SeekOffset may not be {}\n" , 
// (long unsigned int)calculated_offset
calculated_offset as u64 
) ;



Status 
= 
( 
1 
) 
;

}



else { 
Status = fseek ( 
SrcFileDesc , 

SeekOffset , 

0 
) ;

}



if 
Status 
!= 
0 
{ 
print ! ( "Error locating Symbol #{} in file '{}'\n" , SymbolIndex , SrcFilename ) ;



( 
1 
) 

}



if 
TargetWordsizeIs32Bit 
{ 
NumSymRead = fread ( 
Symbol , 

std :: mem :: size_of_val ( & Elf32_Sym ) 

, 

1 , 

SrcFileDesc 
) ;

}



else { 
NumSymRead = fread ( 
Symbol , 

std :: mem :: size_of_val ( & Elf64_Sym ) 

, 

1 , 

SrcFileDesc 
) ;

}



if 
NumSymRead 
!= 
1 
{ 
print ! ( "Experienced error attempting to read Symbol #{} from file '{}'\n" , SymbolIndex , SrcFilename ) ;



( 
1 
) 

}



if 
ByteSwapRequired 
{ 
SwapSymbol ( 
Symbol 
) ;

}



if 
Verbose 
{ 
print ! ( "Symbol #{}:\n" , 
( 
SymbolIndex + 1 
) 
) ;

}




SeekOffset 
= 

StringTableDataOffset 
+ 
get_st_name ( Symbol ) 

;


if 
Verbose 
{ 
print ! ( "   st_name  = 0x{:08x} - " , 
get_st_name ( Symbol ) 
) ;

}



fseek ( 
SrcFileDesc , 

SeekOffset , 

0 
) ;


while 
( 

( 

i 
< 
std :: mem :: size_of_val ( & VerboseStr ) 

) 
&& 
( 

( 

VerboseStr [ i ] 
= 
fgetc ( SrcFileDesc ) 

) 
!= 
// '\0'
'\\0' 

) 

) 
{ 
translate_bpc_vpp ! ( 
i 
) ;

}



VerboseStr [ 
i 
] = 
// '\0'
'\\0' 
;

/* Just in case i=sizeof(VerboseStr) */

SymbolNames [ 
SymbolIndex 
] = 
malloc ( 
i + 1 
) 
;


strcpy ( 
SymbolNames [ SymbolIndex ] 

, 

VerboseStr 
) ;


if 

VerboseStr == "CFE_TBL_FileDef" 
|| 
( 

strcmp ( 
& 
VerboseStr [ 1 ] 


, 

"CFE_TBL_FileDef" 
) 
== 
0 

) 

{ 
if 
Verbose 
{ 
print ! ( "*** {} ***\n" , 
SymbolNames [ SymbolIndex ] 
) ;

}



TblDefSymbolIndex = SymbolIndex ;

}



else { 
if 
Verbose 
{ 
print ! ( "{}\n" , 
SymbolNames [ SymbolIndex ] 
) ;

}


}



if 
TargetWordsizeIs32Bit 
{ 
PrintSymbol32 ( 
Symbol 
) ;

}



else { 
PrintSymbol64 ( 
Symbol 
) ;

}



return Status ;

}



pub fn PrintSymbol32 ( 
// union Elf_Sym *Symbol
let symbol: *mut Elf_Sym; 
) { 
if 
Verbose 
{ 
print ! ( "   st_value = 0x{:x}\n" , 


Symbol 
. Sym32 
. st_value 
) ;

}



if 
Verbose 
{ 
print ! ( "   st_size  = 0x{:08x}\n" , 


Symbol 
. Sym32 
. st_size 
) ;

}



if 
Verbose 
{ 
print ! ( "   st_info  = 0x{:02x}\n" , 


Symbol 
. Sym32 
. st_info 
) ;

}



if 
Verbose 
{ 
print ! ( "   st_other = 0x{:02x}\n" , 


Symbol 
. Sym32 
. st_other 
) ;

}



if 
Verbose 
{ 
print ! ( "   st_shndx = 0x{:04x}\n" , 


Symbol 
. Sym32 
. st_shndx 
) ;

}


}



pub fn PrintSymbol64 ( 
// union Elf_Sym *Symbol
let Symbol: *mut Elf_Sym; 
) { 
if 
Verbose 
{ 
print ! ( "   st_value = 0x{:x}\n" , 
// (long unsigned int)Symbol->Sym64.st_value
(Symbol.Sym64.st_value) as u64 
) ;

}



if 
Verbose 
{ 
print ! ( "   st_size  = 0x{:08x}\n" , 
// (long unsigned int)Symbol->Sym64.st_size
(Symbol.Sym64.st_size) as u64 
) ;

}



if 
Verbose 
{ 
print ! ( "   st_info  = 0x{:02x}\n" , 


Symbol 
. Sym64 
. st_info 
) ;

}



if 
Verbose 
{ 
print ! ( "   st_other = 0x{:02x}\n" , 


Symbol 
. Sym64 
. st_other 
) ;

}



if 
Verbose 
{ 
print ! ( "   st_shndx = 0x{:04x}\n" , 


Symbol 
. Sym64 
. st_shndx 
) ;

}


}



pub fn PrintSectionHeader32 ( 
// union Elf_Shdr *SectionHeader
let section_header: *mut Elf_Shdr; 
) { 
if 
Verbose 
{ 
print ! ( "   sh_addr       = 0x{:x}\n" , 


SectionHeader 
. Shdr32 
. sh_addr 
) ;

}



if 
Verbose 
{ 
print ! ( "   sh_offset     = 0x{:08x}\n" , 


SectionHeader 
. Shdr32 
. sh_offset 
) ;

}



if 
Verbose 
{ 
print ! ( "   sh_size       = 0x{:08x}\n" , 


SectionHeader 
. Shdr32 
. sh_size 
) ;

}



if 
Verbose 
{ 
print ! ( "   sh_link       = 0x{:08x}\n" , 


SectionHeader 
. Shdr32 
. sh_link 
) ;

}



if 
Verbose 
{ 
print ! ( "   sh_info       = 0x{:08x}\n" , 


SectionHeader 
. Shdr32 
. sh_info 
) ;

}



if 
Verbose 
{ 
print ! ( "   sh_addralign  = 0x{:08x}\n" , 


SectionHeader 
. Shdr32 
. sh_addralign 
) ;

}



if 
Verbose 
{ 
print ! ( "   sh_entsize    = 0x{:08x}\n" , 


SectionHeader 
. Shdr32 
. sh_entsize 
) ;

}


}



pub fn PrintSectionHeader64 ( 
// union Elf_Shdr *SectionHeader
let section_header: *mut Elf_Shdr; 
) { 
if 
Verbose 
{ 
print ! ( "   sh_addr       = 0x{:x}\n" , 
// (long unsigned int)SectionHeader->Shdr64.sh_addr
SectionHeader.Shdr64.sh_addr as u64 
) ;

}



if 
Verbose 
{ 
print ! ( "   sh_offset     = 0x{:08x}\n" , 
// (long unsigned int)SectionHeader->Shdr64.sh_offset
(SectionHeader.Shdr64.sh_offset) as u64 
) ;

}



if 
Verbose 
{ 
print ! ( "   sh_size       = 0x{:08x}\n" , 
// (long unsigned int)SectionHeader->Shdr64.sh_size
SectionHeader.Shdr64.sh_size as u64 
) ;

}



if 
Verbose 
{ 
print ! ( "   sh_link       = 0x{:08x}\n" , 


SectionHeader 
. Shdr64 
. sh_link 
) ;

}



if 
Verbose 
{ 
print ! ( "   sh_info       = 0x{:08x}\n" , 


SectionHeader 
. Shdr64 
. sh_info 
) ;

}



if 
Verbose 
{ 
print ! ( "   sh_addralign  = 0x{:08x}\n" , 
// (long unsigned int)SectionHeader->Shdr64.sh_addralign
SectionHeader.Shdr64.sh_addralign as u64 
) ;

}



if 
Verbose 
{ 
print ! ( "   sh_entsize    = 0x{:08x}\n" , 
// (long unsigned int)SectionHeader->Shdr64.sh_entsize
SectionHeader.Shdr64.sh_entsize as u64 
) ;

}


}



pub fn PrintElfHeader32 ( 
// union Elf_Ehdr ElfHeaderLcl
union Elf_Ehdr ElfHeaderLcl 
) { 
if 
Verbose 
{ 
print ! ( "   e_version = {}\n" , 
get_e_version ( 
& 
ElfHeaderLcl 

) 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_entry = 0x{:x}\n" , 

ElfHeaderLcl . Ehdr32 
. e_entry 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_phoff = 0x{:08x} ({})\n" , 

ElfHeaderLcl . Ehdr32 
. e_phoff 

, 


ElfHeaderLcl . Ehdr32 
. e_phoff 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_shoff = 0x{:08x} ({})\n" , 

ElfHeaderLcl . Ehdr32 
. e_shoff 

, 


ElfHeaderLcl . Ehdr32 
. e_shoff 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_flags = 0x{:08x}\n" , 

ElfHeaderLcl . Ehdr32 
. e_flags 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_ehsize = {}\n" , 

ElfHeaderLcl . Ehdr32 
. e_ehsize 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_phentsize = {}\n" , 

ElfHeaderLcl . Ehdr32 
. e_phentsize 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_phnum = {}\n" , 

ElfHeaderLcl . Ehdr32 
. e_phnum 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_shentsize = {}\n" , 

ElfHeaderLcl . Ehdr32 
. e_shentsize 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_shnum = {}\n" , 
get_e_shnum ( 
& 
ElfHeaderLcl 

) 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_shstrndx = {}\n" , 
get_e_shstrndx ( 
& 
ElfHeaderLcl 

) 
) ;

}


}



pub fn PrintElfHeader64 ( 
// union Elf_Ehdr ElfHeaderLcl
union Elf_Ehdr ElfHeaderLcl 
) { 
if 
Verbose 
{ 
print ! ( "   e_version = {}\n" , 
get_e_version ( 
& 
ElfHeaderLcl 

) 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_entry = 0x{:x}\n" , 
// (long unsigned int)ElfHeaderLcl.Ehdr64.e_entry
ElfHeaderLcl.Ehdr64.e_entry as u64 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_phoff = 0x{:08x} ({})\n" , 
// (long unsigned int)ElfHeaderLcl.Ehdr64.e_phoff
ElfHeaderLcl.Ehdr64.e_phoff as u64 

, 

// (long unsigned int)ElfHeaderLcl.Ehdr64.e_phoff
ElfHeaderLcl.Ehdr64.e_phoff as u64 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_shoff = 0x{:08x} ({})\n" , 
// (long unsigned int)ElfHeaderLcl.Ehdr64.e_shoff
ElfHeaderLcl.Ehdr64.e_shoff as u64 

, 

// (long unsigned int)ElfHeaderLcl.Ehdr64.e_shoff
ElfHeaderLcl.Ehdr64.e_shoff as u64 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_flags = 0x{:08x}\n" , 

ElfHeaderLcl . Ehdr64 
. e_flags 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_ehsize = {}\n" , 

ElfHeaderLcl . Ehdr64 
. e_ehsize 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_phentsize = {}\n" , 

ElfHeaderLcl . Ehdr64 
. e_phentsize 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_phnum = {}\n" , 

ElfHeaderLcl . Ehdr64 
. e_phnum 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_shentsize = {}\n" , 

ElfHeaderLcl . Ehdr64 
. e_shentsize 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_shnum = {}\n" , 
get_e_shnum ( 
& 
ElfHeaderLcl 

) 
) ;

}



if 
Verbose 
{ 
print ! ( "   e_shstrndx = {}\n" , 
get_e_shstrndx ( 
& 
ElfHeaderLcl 

) 
) ;

}


}



pub fn SwapElfHeader ( ) { 
if 
TargetWordsizeIs32Bit 
{ 
SwapUInt16 ( 
& 

ElfHeader . Ehdr32 
. e_type 

) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr32 
. e_machine 

) ;


SwapUInt32 ( 
Some ( 
& 

ElfHeader . Ehdr32 
. e_version 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 

ElfHeader . Ehdr32 
. e_entry 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 

ElfHeader . Ehdr32 
. e_phoff 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 

ElfHeader . Ehdr32 
. e_shoff 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 

ElfHeader . Ehdr32 
. e_flags 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr32 
. e_ehsize 

) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr32 
. e_phentsize 

) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr32 
. e_phnum 

) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr32 
. e_shentsize 

) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr32 
. e_shnum 

) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr32 
. e_shstrndx 

) ;

}



else { 
SwapUInt16 ( 
& 

ElfHeader . Ehdr64 
. e_type 

) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr64 
. e_machine 

) ;


SwapUInt32 ( 
Some ( 
& 

ElfHeader . Ehdr64 
. e_version 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt64 ( 
Some ( 
& 

ElfHeader . Ehdr64 
. e_entry 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint64 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt64 ( 
& 

ElfHeader . Ehdr64 
. e_phoff 

) ;


SwapUInt64 ( 
& 

ElfHeader . Ehdr64 
. e_shoff 

) ;


SwapUInt32 ( 
Some ( 
& 

ElfHeader . Ehdr64 
. e_flags 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr64 
. e_ehsize 

) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr64 
. e_phentsize 

) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr64 
. e_phnum 

) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr64 
. e_shentsize 

) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr64 
. e_shnum 

) ;


SwapUInt16 ( 
& 

ElfHeader . Ehdr64 
. e_shstrndx 

) ;

}


}


/* 
 *
 */

pub fn SwapSectionHeader ( 
// union Elf_Shdr *SectionHeader
let section_header: *mut Elf_Shdr; 
) { 
if 
TargetWordsizeIs32Bit 
{ 
SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr32 
. sh_name 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr32 
. sh_type 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr32 
. sh_flags 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr32 
. sh_addr 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr32 
. sh_offset 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr32 
. sh_size 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr32 
. sh_addralign 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr32 
. sh_entsize 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr32 
. sh_link 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr32 
. sh_info 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;

}



else { 
SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr64 
. sh_name 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr64 
. sh_type 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt64 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr64 
. sh_flags 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint64 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt64 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr64 
. sh_addr 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint64 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt64 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr64 
. sh_offset 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint64 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt64 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr64 
. sh_size 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint64 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt64 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr64 
. sh_addralign 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint64 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt64 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr64 
. sh_entsize 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint64 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr64 
. sh_link 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


SectionHeader 
. Shdr64 
. sh_info 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;

}


}


/* 
 *
 */

pub fn SwapSymbol ( 
// union Elf_Sym *Symbol
let symbol: *mut Elf_Sym; 
) { 
if 
TargetWordsizeIs32Bit 
{ 
SwapUInt32 ( 
Some ( 
& 
( 


Symbol 
. Sym32 
. st_name 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


Symbol 
. Sym32 
. st_value 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt32 ( 
Some ( 
& 
( 


Symbol 
. Sym32 
. st_size 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt16 ( 
Some ( 
& 
( 


Symbol 
. Sym32 
. st_shndx 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint16 > > ( ) . unwrap ( ) ) 
) ;

}



else { 
SwapUInt32 ( 
Some ( 
& 
( 


Symbol 
. Sym64 
. st_name 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint32 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt64 ( 
Some ( 
& 
( 


Symbol 
. Sym64 
. st_value 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint64 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt64 ( 
Some ( 
& 
( 


Symbol 
. Sym64 
. st_size 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint64 > > ( ) . unwrap ( ) ) 
) ;


SwapUInt16 ( 
Some ( 
& 
( 


Symbol 
. Sym64 
. st_shndx 
) 

. unwrap ( ) . downcast :: < std :: cell :: RefCell < uint16 > > ( ) . unwrap ( ) ) 
) ;

}


}


/* 
 *
 */

pub fn SwapUInt16 ( 
ValueToSwap : Option < std :: rc :: Rc < std :: cell :: RefCell < uint16 > > > 
) { 
// uint8 *BytePtr = (uint8 *)ValueToSwap;
let byte_ptr: *mut u8 = value_to_swap as *mut u8; 

let TempByte : uint8 = 
BytePtr [ 1 ] 
;


BytePtr [ 
1 
] = 
BytePtr [ 0 ] 
;


BytePtr [ 
0 
] = 
TempByte 
;

}


/* 
 *
 */

pub fn SwapUInt32 ( 
ValueToSwap : Option < std :: rc :: Rc < std :: cell :: RefCell < uint32 > > > 
) { 
// uint8 *BytePtr = (uint8 *)ValueToSwap;
let byte_ptr: *mut u8 = value_to_swap as *mut u8; 

let TempByte : uint8 = 
BytePtr [ 3 ] 
;


BytePtr [ 
3 
] = 
BytePtr [ 0 ] 
;


BytePtr [ 
0 
] = 
TempByte 
;



TempByte 
= 
BytePtr [ 2 ] 
;


BytePtr [ 
2 
] = 
BytePtr [ 1 ] 
;


BytePtr [ 
1 
] = 
TempByte 
;

}



pub fn SwapUInt64 ( 
ValueToSwap : Option < std :: rc :: Rc < std :: cell :: RefCell < uint64 > > > 
) { 
// uint8 *BytePtr = (uint8 *)ValueToSwap;
let byte_ptr: *mut u8 = ValueToSwap as *mut u8; 

let mut TempByte : uint8 = Default :: default ( ) ;



TempByte 
= 
BytePtr [ 7 ] 
;


BytePtr [ 
7 
] = 
BytePtr [ 0 ] 
;


BytePtr [ 
0 
] = 
TempByte 
;



TempByte 
= 
BytePtr [ 6 ] 
;


BytePtr [ 
6 
] = 
BytePtr [ 1 ] 
;


BytePtr [ 
1 
] = 
TempByte 
;



TempByte 
= 
BytePtr [ 5 ] 
;


BytePtr [ 
5 
] = 
BytePtr [ 2 ] 
;


BytePtr [ 
2 
] = 
TempByte 
;



TempByte 
= 
BytePtr [ 4 ] 
;


BytePtr [ 
4 
] = 
BytePtr [ 3 ] 
;


BytePtr [ 
3 
] = 
TempByte 
;

}


/* 
 *
 */

pub fn GetStringFromMap ( 
Result : & str , 

, 

Map : Option < std :: rc :: Rc < std :: cell :: RefCell < ElfStrMap > > > , 

Key : int32 
) -> int32 { 
let Status : int32 = 
( 
1 
) 
;


while 
( 

( 



Map 
. String 
[ 
0 
] 
!= 
'*' 

) 
&& 
( 

Status 
== 
( 
1 
) 

) 

) 
{ 
if 


Map 
. Value 
== 
Key 

{ 

Status 
= 
( 
0 
) 
;


strcpy ( 
Result , 


Map 
. String 
) ;

}



else { 
translate_bpc_vpp ! ( 
Map 
) ;

}


}



if 

Status 
== 
( 
1 
) 

{ 
sprintf ( 
Result , 


Map 
. String 

, 

Key 
) ;

}



return Status ;

}


/* 
 *
 */

pub fn GetTblDefInfo ( ) -> int32 { 
let Status : int32 = 
( 
0 
) 
;


let SeekOffset : uint32 = 0 ;


let NumDefsRead : int32 = 0 ;


let calculated_offset : u64 ;

/* Read the data to be used to format the CFE File and Table Headers */

if 

( 

get_st_size ( 
SymbolPtrs [ TblDefSymbolIndex ] 
) 
!= 
std :: mem :: size_of_val ( & CFE_TBL_FileDef_t ) 

) 
&& 
( 

get_st_size ( 
SymbolPtrs [ TblDefSymbolIndex ] 
) 
!= 
0 

) 

{ 
print ! ( "Error! '{}' is not properly defined in '{}'.  Size of object is incorrect ({}).\n" , 
"CFE_TBL_FileDef" , 

SrcFilename , 

// (long unsigned int)get_st_size(SymbolPtrs[TblDefSymbolIndex])
(SymbolPtrs[TblDefSymbolIndex] as *const _ as usize) as u64 
) ;



Status 
= 
( 
1 
) 
;

}



else { /* fseek expects a long int, sh_offset and st_value are uint64 for elf64 */


calculated_offset 
= 

get_sh_offset ( 
SectionHeaderPtrs [ 
get_st_shndx ( 
SymbolPtrs [ TblDefSymbolIndex ] 
) 
] 
) 
+ 
get_st_value ( 
SymbolPtrs [ TblDefSymbolIndex ] 
) 

;



SeekOffset 
= 

( 
calculated_offset 
) 
as uint32_t 
;


if 
SeekOffset 
!= 
calculated_offset 
{ 
print ! ( "Error: SeekOffset may not be {}\n" , 
// (long unsigned int)calculated_offset
(calculated_offset as u64) 
) ;



Status 
= 
( 
1 
) 
;

}



fseek ( 
SrcFileDesc , 

SeekOffset , 

0 
) ;


NumDefsRead = fread ( 
& 
TblFileDef , 


, 

std :: mem :: size_of_val ( & CFE_TBL_FileDef_t ) 

, 

1 , 

SrcFileDesc 
) ;

/* ensuring all are strings are null-terminated */



TblFileDef . ObjectName 
[ 

// sizeof(TblFileDef.ObjectName)
std::mem::size_of_val(&TblFileDef.ObjectName) 
- 
1 

] 
= 
// '\0'
= '\ 
;




TblFileDef . TableName 
[ 

// sizeof(TblFileDef.TableName)
std::mem::size_of_val(&TblFileDef.TableName) 
- 
1 

] 
= 
// '\0'
translated Rust code here 
;




TblFileDef . Description 
[ 

// sizeof(TblFileDef.Description)
std::mem::size_of_val(&TblFileDef.Description) 
- 
1 

] 
= 
// '\0'
'\\0' 
;




TblFileDef . TgtFilename 
[ 

// sizeof(TblFileDef.TgtFilename)
std::mem::size_of_val(&TblFileDef.TgtFilename) 
- 
1 

] 
= 
// '\0'
'\0' 
;


if 
NumDefsRead 
!= 
1 
{ 
print ! ( "Error! Unable to read data content of '{}' from '{}'.\n" , 
"CFE_TBL_FileDef" , 

SrcFilename 
) ;



Status 
= 
( 
1 
) 
;

}



if 
ByteSwapRequired 
{ 
SwapUInt32 ( 
& 
TblFileDef . ObjectSize 

) ;

}



if 
Verbose 
{ 
print ! ( "Table Defined as follows:\n" ) ;


print ! ( "   Data Object: {}\n" , 
TblFileDef . ObjectName 
) ;


print ! ( "   Table Name : '{}'" , 
TblFileDef . TableName 
) ;


if 
TableNameOverride == 1 
{ 
print ! ( " overridden with : '{}'" , TableName ) ;

}



print ! ( "\n" ) ;


print ! ( "   Description: '{}'" , 
TblFileDef . Description 
) ;


if 
DescriptionOverride == 1 
{ 
print ! ( " overridden with : '{}'" , Description ) ;

}



print ! ( "\n" ) ;


print ! ( "   Output File: {}\n" , 
TblFileDef . TgtFilename 
) ;


print ! ( "   Object Size: {} (0x{:08x})\n" , 
TblFileDef . ObjectSize 

, 

TblFileDef . ObjectSize 
) ;

}


}



return Status ;

}


/* 
 *
 */

pub fn LocateAndReadUserObject ( ) -> int32 { 
let Status : int32 = 
( 
0 
) 
;


let i : int32 = 0 ;


let j : int32 = 0 ;


let SeekOffset : uint32 = 0 ;


let mut AByte : uint8 = Default :: default ( ) ;


let calculated_offset : u64 ;

/* Search the symbol table for the user defined object */

if 
Verbose 
{ 
print ! ( "\nTrying to match ObjectName '{}'... (length {})" , 
TblFileDef . ObjectName 

, 

// (long unsigned int)strlen(TblFileDef.ObjectName)
(TblFileDef.ObjectName.len()) as u64 
) ;

}



while 
( 
i 
< 
NumSymbols 
) 
{ 
if 
Verbose 
{ 
print ! ( "\nSymbol Search loop {}: SymbolName ='{}' " , 
i , 

SymbolNames [ i ] 
) ;

}


/* Check to see if the symbol names match as far as the ObjectName is defined */

if 

strncmp ( 
SymbolNames [ i ] 

, 

TblFileDef . ObjectName 

, 

strlen ( 
TblFileDef . ObjectName 
) 
) 
== 
0 

{ 
if 
Verbose 
{ 
print ! ( "Found ObjectName '{}' inside SymbolName '{}'\n" , 
TblFileDef . ObjectName 

, 

SymbolNames [ i ] 
) ;

}


/* Check to see if the Symbol Name happens to have one extra character */

if 

( 

strlen ( 
SymbolNames [ i ] 
) 
- 
strlen ( 
TblFileDef . ObjectName 
) 

) 
== 
1 

{ 
if 
Verbose 
{ 
print ! ( "Found an extra character...\n" ) ;

}


/* If the character is non-printable, then we have a match */

if 

( 


( 

__ctype_b_loc ( ) 

) 
[ 

( 
( 

SymbolNames [ i ] 
[ 
strlen ( 
SymbolNames [ i ] 
) 
] 
) 
) 
as i32 
] 
& 

_ISprint 
as u16 

) 
== 
0 

{ 
if 
Verbose 
{ 
print ! ( "...and it's unprintable!" ) ;

}



break ;

}


}


/* Check to see if the Symbol Name is an exact match */

else if 

( 

strlen ( 
SymbolNames [ i ] 
) 
- 
strlen ( 
TblFileDef . ObjectName 
) 

) 
== 
0 

{ 
if 
Verbose 
{ 
print ! ( "\nFound an exact match! Symbol='{}' Object='{}'\n" , 
SymbolNames [ i ] 

, 

TblFileDef . ObjectName 
) ;

}



break ;

}


}



if 
Verbose 
{ 
print ! ( "strstr[{}] = {}; strlenSN = {}; strlenON = {}\n" , 
i , 

strstr ( 
SymbolNames [ i ] 

, 

TblFileDef . ObjectName 
) 

, 

// (long unsigned int)strlen(SymbolNames[i])
(SymbolNames[i].len()) as u64 

, 

// (long unsigned int)strlen(TblFileDef.ObjectName)
(TblFileDef.ObjectName.len()) as u64 
) ;

}



translate_bpc_vpp ! ( 
i 
) ;

}



if 
Verbose 
{ 
print ! ( "\ni = {}, NumSymbols = {}\n" , 
i , 

// (long unsigned int)NumSymbols
NumSymbols as u64 
) ;


if 
i 
< 
NumSymbols 
{ 
print ! ( "\nSymbolName = '{}', ObjectName = '{}'\n" , 
SymbolNames [ i ] 

, 

TblFileDef . ObjectName 
) ;


print ! ( "\nSymbolName length = {}, ObjectName length = {}\n" , 
// (long unsigned int)strlen(SymbolNames[i])
(SymbolNames[i].len()) as u64 

, 

// (long unsigned int)strlen(TblFileDef.ObjectName)
(TblFileDef.ObjectName.len()) as u64 
) ;

}


}



if 
i == NumSymbols 
{ 
print ! ( "Error! Unable to find '{}' object in '{}'\n" , 
TblFileDef . ObjectName 

, 

SrcFilename 
) ;



Status 
= 
( 
1 
) 
;

}



else { 
if 
Verbose 
{ 
print ! ( "Found '{}' object as Symbol #{}\n" , 
TblFileDef . ObjectName 

, 

( 
i + 1 
) 
) ;

}



UserObjSymbolIndex = i ;


if 

strcmp ( 
SectionNamePtrs [ 
get_st_shndx ( 
SymbolPtrs [ UserObjSymbolIndex ] 
) 
] 

, 

".bss" 
) 
== 
0 

{ 
if 
Verbose 
{ 
print ! ( "Table contents are in '.bss' section and are assumed to be all zeros.\n" ) ;

}



TableDataIsAllZeros = 1 ;


if 
Verbose 
{ 
print ! ( "Object Data:\n" ) ;


i = 0 ;
while 

i 
< 
get_st_size ( 
SymbolPtrs [ UserObjSymbolIndex ] 
) 

{ 
print ! ( " 0x{:02x}" , 
0 
) ;


translate_bpc_vpp ! ( 
j 
) ;


if 
j == 16 
{ 
print ! ( "\n" ) ;


j = 0 ;

}



translate_bpc_vpp ! ( i ) 
}


}


}



else { /* Locate data associated with symbol */


calculated_offset 
= 

get_sh_offset ( 
SectionHeaderPtrs [ 
get_st_shndx ( 
SymbolPtrs [ UserObjSymbolIndex ] 
) 
] 
) 
+ 
get_st_value ( 
SymbolPtrs [ UserObjSymbolIndex ] 
) 

;



SeekOffset 
= 

( 
calculated_offset 
) 
as uint32_t 
;


if 
SeekOffset 
!= 
calculated_offset 
{ 
print ! ( "Error: SeekOffset may not be {}\n" , 
// (long unsigned int)calculated_offset
(calculated_offset as u64) 
) ;



Status 
= 
( 
1 
) 
;

}



fseek ( 
SrcFileDesc , 

SeekOffset , 

0 
) ;

/* Determine if the elf file contained the size of the object */

if 

get_st_size ( 
SymbolPtrs [ UserObjSymbolIndex ] 
) 
!= 
0 

{ /* Check to see if the size in the elf file agrees with the size specified in our table def structure */

if 

get_st_size ( 
SymbolPtrs [ UserObjSymbolIndex ] 
) 
!= 
TblFileDef . ObjectSize 

{ 
print ! ( "ELF file indicates object '{}' is of size {} but table definition structure indicates size {}" , 
TblFileDef . ObjectName 

, 

// (long unsigned int)get_st_size(SymbolPtrs[UserObjSymbolIndex])
(get_st_size(SymbolPtrs[UserObjSymbolIndex]) as u64) 

, 

TblFileDef . ObjectSize 
) ;


if 

TblFileDef . ObjectSize 
< 
get_st_size ( 
SymbolPtrs [ UserObjSymbolIndex ] 
) 

{ 
set_st_size ( 
SymbolPtrs [ UserObjSymbolIndex ] 

, 

TblFileDef . ObjectSize 
) ;

}



print ! ( "Size of {} is assumed.\n" , 
// (long unsigned int)get_st_size(SymbolPtrs[UserObjSymbolIndex])
(SymbolPtrs[UserObjSymbolIndex] as &YourType).get_st_size() as u64 
) ;

}


}



else { /* Since the size is not available from the elf file, assume the value in the table def structure is
                 * right */

set_st_size ( 
SymbolPtrs [ UserObjSymbolIndex ] 

, 

TblFileDef . ObjectSize 
) ;

}



if 
Verbose 
{ 
print ! ( "Object Data:\n" ) ;


i = 0 ;
while 

i 
< 
get_st_size ( 
SymbolPtrs [ UserObjSymbolIndex ] 
) 

{ 
AByte = fgetc ( SrcFileDesc ) ;


print ! ( " 0x{:02x}" , AByte ) ;


translate_bpc_vpp ! ( 
j 
) ;


if 
j == 16 
{ 
print ! ( "\n" ) ;


j = 0 ;

}



translate_bpc_vpp ! ( i ) 
}


/* Reset the file pointer */

fseek ( 
SrcFileDesc , 

SeekOffset , 

0 
) ;

}


}


}



return Status ;

}


/* 
 *
 */

pub fn OutputDataToTargetFile ( ) -> int32 { 
let Status : int32 = 
( 
0 
) 
;


let AByte : uint8 = 0 ;


let i : int32 = 0 ;

/* Create the standard header */

FileHeader . ContentType = 
0x63464531 
;


FileHeader . SubType = 
CFE_FS_SubType_TBL_IMG 
;


FileHeader . Length = 
std :: mem :: size_of_val ( & CFE_FS_Header_t ) 
;


if 
ScIDSpecified == 1 
{ 
FileHeader . SpacecraftID = 
SpacecraftID 
;

}



else { 
FileHeader . SpacecraftID = 
0 
;

}



if 
ProcIDSpecified == 1 
{ 
FileHeader . ProcessorID = 
ProcessorID 
;

}



else { 
FileHeader . ProcessorID = 
0 
;

}



if 
AppIDSpecified == 1 
{ 
FileHeader . ApplicationID = 
ApplicationID 
;

}



else { 
FileHeader . ApplicationID = 
0 
;

}



if 
EnableTimeTagInHeader 
{ 
FileHeader . TimeSeconds = 
SrcFileTimeInScEpoch 
;


FileHeader . TimeSubSeconds = 
0 
;

}



else { 
FileHeader . TimeSeconds = 
0 
;


FileHeader . TimeSubSeconds = 
0 
;

}



memset ( 
FileHeader . Description 

, 

0 , 

32 
) ;


if 
DescriptionOverride == 1 
{ 
strcpy ( 
FileHeader . Description 

, 

Description 
) ;

}



else { 
strcpy ( 
FileHeader . Description 

, 

TblFileDef . Description 
) ;

}


/* If this machine is little endian, the CFE header must be swapped */

if 
ThisMachineIsLittleEndian == 1 
{ 
if 
Verbose 
{ 
print ! ( "\ncFE Headers are being byte-swapped because this machine is 'Little Endian'\n" ) ;

}



SwapUInt32 ( 
& 
FileHeader . ContentType 

) ;


SwapUInt32 ( 
& 
FileHeader . SubType 

) ;


SwapUInt32 ( 
& 
FileHeader . Length 

) ;


SwapUInt32 ( 
& 
FileHeader . SpacecraftID 

) ;


SwapUInt32 ( 
& 
FileHeader . ProcessorID 

) ;


SwapUInt32 ( 
& 
FileHeader . ApplicationID 

) ;


SwapUInt32 ( 
& 
FileHeader . TimeSeconds 

) ;


SwapUInt32 ( 
& 
FileHeader . TimeSubSeconds 

) ;

}


/* Create the standard cFE Table Header */

memset ( 
& 
TableHeader , 


, 

0 , 

std :: mem :: size_of_val ( & TableHeader ) 
) ;


TableHeader . NumBytes = 

( 
get_st_size ( 
SymbolPtrs [ UserObjSymbolIndex ] 
) 
) 
as uint32_t 
;


if 

TableHeader . NumBytes 
!= 
get_st_size ( 
SymbolPtrs [ UserObjSymbolIndex ] 
) 

{ 
print ! ( "ERROR: TableHeader.NumBytes is too small for Sym64.st_size\n" ) ;



Status 
= 
( 
1 
) 
;

}



if 
TableNameOverride == 1 
{ 
strcpy ( 
TableHeader . TableName 

, 

TableName 
) ;

}



else { 
strcpy ( 
TableHeader . TableName 

, 

TblFileDef . TableName 
) ;

}


/* If this machine is little endian, the TBL header must be swapped */

if 
ThisMachineIsLittleEndian == 1 
{ 
SwapUInt32 ( 
& 
TableHeader . Reserved 

) ;


SwapUInt32 ( 
& 
TableHeader . Offset 

) ;


SwapUInt32 ( 
& 
TableHeader . NumBytes 

) ;

}


/* Output the two headers to the target file */

fwrite ( 
& 
FileHeader . ContentType 


, 

std :: mem :: size_of_val ( & uint32 ) 

, 

1 , 

DstFileDesc 
) ;


fwrite ( 
& 
FileHeader . SubType 


, 

std :: mem :: size_of_val ( & uint32 ) 

, 

1 , 

DstFileDesc 
) ;


fwrite ( 
& 
FileHeader . Length 


, 

std :: mem :: size_of_val ( & uint32 ) 

, 

1 , 

DstFileDesc 
) ;


fwrite ( 
& 
FileHeader . SpacecraftID 


, 

std :: mem :: size_of_val ( & uint32 ) 

, 

1 , 

DstFileDesc 
) ;


fwrite ( 
& 
FileHeader . ProcessorID 


, 

std :: mem :: size_of_val ( & uint32 ) 

, 

1 , 

DstFileDesc 
) ;


fwrite ( 
& 
FileHeader . ApplicationID 


, 

std :: mem :: size_of_val ( & uint32 ) 

, 

1 , 

DstFileDesc 
) ;


fwrite ( 
& 
FileHeader . TimeSeconds 


, 

std :: mem :: size_of_val ( & uint32 ) 

, 

1 , 

DstFileDesc 
) ;


fwrite ( 
& 
FileHeader . TimeSubSeconds 


, 

std :: mem :: size_of_val ( & uint32 ) 

, 

1 , 

DstFileDesc 
) ;


fwrite ( 
& 

FileHeader . Description 
[ 
0 
] 


, 

// sizeof(FileHeader.Description)
std::mem::size_of_val(&FileHeader.Description) 

, 

1 , 

DstFileDesc 
) ;


fwrite ( 
& 
TableHeader . Reserved 


, 

std :: mem :: size_of_val ( & uint32 ) 

, 

1 , 

DstFileDesc 
) ;


fwrite ( 
& 
TableHeader . Offset 


, 

std :: mem :: size_of_val ( & uint32 ) 

, 

1 , 

DstFileDesc 
) ;


fwrite ( 
& 
TableHeader . NumBytes 


, 

std :: mem :: size_of_val ( & uint32 ) 

, 

1 , 

DstFileDesc 
) ;


fwrite ( 
& 

TableHeader . TableName 
[ 
0 
] 


, 

// sizeof(TableHeader.TableName)
std::mem::size_of_val(&TableHeader.TableName) 

, 

1 , 

DstFileDesc 
) ;

/* Output the data from the object file */

if 
TableDataIsAllZeros 
{ 
AByte = 0 ;


i = 0 ;
while 

i 
< 
get_st_size ( 
SymbolPtrs [ UserObjSymbolIndex ] 
) 

{ 
fwrite ( 
& 
AByte , 


, 

1 , 

1 , 

DstFileDesc 
) ;


translate_bpc_vpp ! ( i ) 
}


}



else { 
i = 0 ;
while 

i 
< 
get_st_size ( 
SymbolPtrs [ UserObjSymbolIndex ] 
) 

{ 
AByte = fgetc ( SrcFileDesc ) ;


fwrite ( 
& 
AByte , 


, 

1 , 

1 , 

DstFileDesc 
) ;


translate_bpc_vpp ! ( i ) 
}


}



return Status ;

}


