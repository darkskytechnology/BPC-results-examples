#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* **********************************************************************
 * NASA Docket No. GSC-18,719-1, and identified as “core Flight System: Bootes”
 *
 * Copyright (c) 2020 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/

pub type Elf32_Addr = u32;

pub type Elf32_Half = u16;

pub type Elf32_Off = u32;

pub type Elf32_Sword = u32;

pub type Elf32_Word = u32;

pub type Elf64_Addr = u64;

pub type Elf64_Off = u64;

pub type Elf64_Half = u16;

pub type Elf64_Word = u32;

pub type Elf64_Sword = u32;

pub type Elf64_Xword = u64;

pub type Elf64_Sxword = u64;

/*
 *    Elf 32 bit Header Format
 */

#[derive(Clone, Default)]
pub struct Elf32_Ehdr {
    pub e_ident: [u8; 16],
    /* < \brief Machine independent data to allow decoding of file */
    pub e_type: Elf32_Half,
    /* < \brief Identifies object file type */
    pub e_machine: Elf32_Half,
    /* < \brief Specifies required architecture for file */
    pub e_version: Elf32_Word,
    /* < \brief Object file version */
    pub e_entry: Elf32_Addr,
    /* < \brief Virtual start address for process */
    pub e_phoff: Elf32_Off,
    /* < \brief File offset to beginning of Program Header Table */
    pub e_shoff: Elf32_Off,
    /* < \brief File offset to beginning of Section Header Table */
    pub e_flags: Elf32_Word,
    /* < \brief Processor specific flags */
    pub e_ehsize: Elf32_Half,
    /* < \brief ELF Header's size, in bytes */
    pub e_phentsize: Elf32_Half,
    /* < \brief Size, in bytes, of each Program Header Table Entry */
    pub e_phnum: Elf32_Half,
    /* < \brief Number of entries the Program Header Table contains */
    pub e_shentsize: Elf32_Half,
    /* < \brief Size, in bytes, of each Section Header Table Entry */
    pub e_shnum: Elf32_Half,
    /* < \brief Number of entries the Section Header Table contains */
    pub e_shstrndx: Elf32_Half,
    /* < \brief Section Header Table index for the Section Name String Table */
}

/*
 *    Elf 64 bit Header Format
 */

#[derive(Clone, Default)]
pub struct Elf64_Ehdr {
    pub e_ident: [u8; 16],
    /* < \brief Machine independent data to allow decoding of file */
    pub e_type: Elf64_Half,
    /* < \brief Identifies object file type */
    pub e_machine: Elf64_Half,
    /* < \brief Specifies required architecture for file */
    pub e_version: Elf64_Word,
    /* < \brief Object file version */
    pub e_entry: Elf64_Addr,
    /* < \brief Virtual start address for process */
    pub e_phoff: Elf64_Off,
    /* < \brief File offset to beginning of Program Header Table */
    pub e_shoff: Elf64_Off,
    /* < \brief File offset to beginning of Section Header Table */
    pub e_flags: Elf64_Word,
    /* < \brief Processor specific flags */
    pub e_ehsize: Elf64_Half,
    /* < \brief ELF Header's size, in bytes */
    pub e_phentsize: Elf64_Half,
    /* < \brief Size, in bytes, of each Program Header Table Entry */
    pub e_phnum: Elf64_Half,
    /* < \brief Number of entries the Program Header Table contains */
    pub e_shentsize: Elf64_Half,
    /* < \brief Size, in bytes, of each Section Header Table Entry */
    pub e_shnum: Elf64_Half,
    /* < \brief Number of entries the Section Header Table contains */
    pub e_shstrndx: Elf64_Half,
    /* < \brief Section Header Table index for the Section Name String Table */
}

pub union Elf_Ehdr {
    pub Ehdr32: std::mem::ManuallyDrop<Elf32_Ehdr>,

    pub Ehdr64: std::mem::ManuallyDrop<Elf64_Ehdr>,
}

impl Default for Elf_Ehdr {
    fn default() -> Elf_Ehdr {
        unsafe { std::mem::MaybeUninit::<Elf_Ehdr>::zeroed().assume_init() }
    }
}

/*
 *    e_type values are as follows:
 */
/*
 *   e_machine values are as follows:
 */
/*
 *    e_version values are as follows:
 */
/*
 *    e_ident[] index values are as follows:
 */
/*
 *   e_ident[ELFMAG0...ELFMAG3] values are as follows:
 */
/*
 *   e_ident[EI_CLASS] values are as follows:
 */
/*
 *   e_ident[EI_DATA] values are as follows:
 */
/*
 *   Special Section Indexes:
 */
/*
 *    32 bit Section Header Format
 */

#[derive(Clone, Default)]
pub struct Elf32_Shdr {
    pub sh_name: Elf32_Word,
    /* < \brief Index into Section Header String Table giving location of section name */
    pub sh_type: Elf32_Word,
    /* < \brief Section type */
    pub sh_flags: Elf32_Word,
    /* < \brief Section attributes */
    pub sh_addr: Elf32_Addr,
    /* < \brief Address at which first byte of section should reside */
    pub sh_offset: Elf32_Off,
    /* < \brief File offset to first byte of Section */
    pub sh_size: Elf32_Word,
    /* < \brief Section size, in bytes */
    pub sh_link: Elf32_Word,
    /* < \brief Section Header Table index link (interpretation depends upon Section Type) */
    pub sh_info: Elf32_Word,
    /* < \brief Extra information (interpretation depends upon Section Type) */
    pub sh_addralign: Elf32_Word,
    /* < \brief Section memory address alignment constraints */
    pub sh_entsize: Elf32_Word,
    /* < \brief Size of an entry for a Section containing a table of fixed size entries */
}

/*
 *    64 bit Section Header Format
 */

#[derive(Clone, Default)]
pub struct Elf64_Shdr {
    pub sh_name: Elf64_Word,
    /* < \brief Index into Section Header String Table giving location of section name */
    pub sh_type: Elf64_Word,
    /* < \brief Section type */
    pub sh_flags: Elf64_Xword,
    /* < \brief Section attributes */
    pub sh_addr: Elf64_Addr,
    /* < \brief Address at which first byte of section should reside */
    pub sh_offset: Elf64_Off,
    /* < \brief File offset to first byte of Section */
    pub sh_size: Elf64_Xword,
    /* < \brief Section size, in bytes */
    pub sh_link: Elf64_Word,
    /* < \brief Section Header Table index link (interpretation depends upon Section Type) */
    pub sh_info: Elf64_Word,
    /* < \brief Extra information (interpretation depends upon Section Type) */
    pub sh_addralign: Elf64_Xword,
    /* < \brief Section memory address alignment constraints */
    pub sh_entsize: Elf64_Xword,
    /* < \brief Size of an entry for a Section containing a table of fixed size entries */
}

pub union Elf_Shdr {
    pub Shdr32: std::mem::ManuallyDrop<Elf32_Shdr>,

    pub Shdr64: std::mem::ManuallyDrop<Elf64_Shdr>,
}

impl Default for Elf_Shdr {
    fn default() -> Elf_Shdr {
        unsafe { std::mem::MaybeUninit::<Elf_Shdr>::zeroed().assume_init() }
    }
}

/*
 *    sh_type values are as follows:
 */
/*
 *    sh_flags values are as follows:
 */
/*
 *    32 bit Symbol Table Entry
 */

#[derive(Clone, Default)]
pub struct Elf32_Sym {
    pub st_name: Elf32_Word,
    /* < \brief String Table Index that gives the symbol name */
    pub st_value: Elf32_Addr,
    /* < \brief Value of associated symbol */
    pub st_size: Elf32_Word,
    /* < \brief Size, in bytes, of symbol */
    pub st_info: u8,
    /* < \brief Symbol's type and binding attributes */
    pub st_other: u8,
    /* < \brief  */
    pub st_shndx: Elf32_Half,
    /* < \brief  */
}

/*
 *    64 bit Symbol Table Entry
 */

#[derive(Clone, Default)]
pub struct Elf64_Sym {
    pub st_name: Elf64_Word,
    /* < \brief String Table Index that gives the symbol name */
    pub st_info: u8,
    /* < \brief Symbol's type and binding attributes */
    pub st_other: u8,
    /* < \brief  */
    pub st_shndx: Elf64_Half,
    /* < \brief  */
    pub st_value: Elf64_Addr,
    /* < \brief Value of associated symbol */
    pub st_size: Elf64_Xword,
    /* < \brief Size, in bytes, of symbol */
}

pub union Elf_Sym {
    pub Sym32: std::mem::ManuallyDrop<Elf32_Sym>,

    pub Sym64: std::mem::ManuallyDrop<Elf64_Sym>,
}

impl Default for Elf_Sym {
    fn default() -> Elf_Sym {
        unsafe { std::mem::MaybeUninit::<Elf_Sym>::zeroed().assume_init() }
    }
}

/*
 *   Extraction and possible values of symbol table entry binding attributes in st_info
 */
/*
 *   Extraction and possible values of symbol table entry type attributes in st_info
 */
