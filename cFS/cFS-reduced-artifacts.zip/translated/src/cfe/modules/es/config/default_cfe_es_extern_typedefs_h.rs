#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::build::inc::cfe_es_extern_typedefs_h::enum_CFE_ES_AppState;
use crate::build::inc::cfe_es_extern_typedefs_h::enum_CFE_ES_AppType;
use crate::build::inc::cfe_es_extern_typedefs_h::enum_CFE_ES_ExceptionAction;
use crate::build::inc::cfe_es_extern_typedefs_h::enum_CFE_ES_LogEntryType;
use crate::build::inc::cfe_es_extern_typedefs_h::enum_CFE_ES_LogMode;
use crate::build::inc::cfe_es_extern_typedefs_h::enum_CFE_ES_RunStatus;
use crate::build::inc::cfe_es_extern_typedefs_h::enum_CFE_ES_SystemState;
use crate::cfe::modules::resourceid::option_inc::cfe_resourceid_simple_h::CFE_ResourceId_t;
use crate::osal::src::os::inc::common_types_h::uint16;
use crate::osal::src::os::inc::common_types_h::uint32;
use crate::osal::src::os::inc::common_types_h::uint8;
// USE STATEMENTS END
/* **********************************************************************
 * NASA Docket No. GSC-18,719-1, and identified as “core Flight System: Bootes”
 *
 * Copyright (c) 2020 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/
/*
 * @file
 *
 * Declarations and prototypes for cfe_es_extern_typedefs module
 */
/*
 * @brief Label definitions associated with CFE_ES_LogMode_Enum_t
 */

pub type enum_CFE_ES_LogMode = i32;

/*
 * @brief Overwrite Log Mode
 */

const CFE_ES_LogMode_OVERWRITE: enum_CFE_ES_LogMode = 0;

/*
 * @brief Discard Log Mode
 */

const CFE_ES_LogMode_DISCARD: enum_CFE_ES_LogMode = 1;

/*
 * @brief Identifies handling of log messages after storage is filled
 *
 * @sa enum CFE_ES_LogMode
 */

pub type CFE_ES_LogMode_Enum_t = uint8;

/*
 * @brief Label definitions associated with CFE_ES_ExceptionAction_Enum_t
 */

pub type enum_CFE_ES_ExceptionAction = i32;

/*
 * @brief Restart application if exception occurs
 */

const CFE_ES_ExceptionAction_RESTART_APP: enum_CFE_ES_ExceptionAction = 0;

/*
 * @brief Restart processor if exception occurs
 */

const CFE_ES_ExceptionAction_PROC_RESTART: enum_CFE_ES_ExceptionAction = 1;

/*
 * @brief Identifies action to take if exception occurs
 *
 * @sa enum CFE_ES_ExceptionAction
 */

pub type CFE_ES_ExceptionAction_Enum_t = uint8;

/*
 * @brief Label definitions associated with CFE_ES_AppType_Enum_t
 */

pub type enum_CFE_ES_AppType = i32;

/*
 * @brief CFE core application
 */

const CFE_ES_AppType_CORE: enum_CFE_ES_AppType = 1;

/*
 * @brief CFE external application
 */

const CFE_ES_AppType_EXTERNAL: enum_CFE_ES_AppType = 2;

/*
 * @brief CFE library
 */

const CFE_ES_AppType_LIBRARY: enum_CFE_ES_AppType = 3;

/*
 * @brief Identifies type of CFE application
 *
 * @sa enum CFE_ES_AppType
 */

pub type CFE_ES_AppType_Enum_t = uint8;

/*
 * @brief Label definitions associated with CFE_ES_RunStatus_Enum_t
 */

pub type enum_CFE_ES_RunStatus = i32;

/*
 * @brief Reserved value, should not be used
 */

const CFE_ES_RunStatus_UNDEFINED: enum_CFE_ES_RunStatus = 0;

/*
 * @brief Indicates that the Application should continue to run
 */

const CFE_ES_RunStatus_APP_RUN: enum_CFE_ES_RunStatus = 1;

/*
 * @brief Indicates that the Application wants to exit normally
 */

const CFE_ES_RunStatus_APP_EXIT: enum_CFE_ES_RunStatus = 2;

/*
 * @brief Indicates that the Application is quitting with an error
 */

const CFE_ES_RunStatus_APP_ERROR: enum_CFE_ES_RunStatus = 3;

/*
 * @brief The cFE App caused an exception
 */

const CFE_ES_RunStatus_SYS_EXCEPTION: enum_CFE_ES_RunStatus = 4;

/*
 * @brief The system is requesting a restart of the cFE App
 */

const CFE_ES_RunStatus_SYS_RESTART: enum_CFE_ES_RunStatus = 5;

/*
 * @brief The system is requesting a reload of the cFE App
 */

const CFE_ES_RunStatus_SYS_RELOAD: enum_CFE_ES_RunStatus = 6;

/*
 * @brief The system is requesting that the cFE App is stopped
 */

const CFE_ES_RunStatus_SYS_DELETE: enum_CFE_ES_RunStatus = 7;

/*
 * @brief Indicates that the Core Application could not Init
 */

const CFE_ES_RunStatus_CORE_APP_INIT_ERROR: enum_CFE_ES_RunStatus = 8;

/*
 * @brief Indicates that the Core Application had a runtime failure
 */

const CFE_ES_RunStatus_CORE_APP_RUNTIME_ERROR: enum_CFE_ES_RunStatus = 9;

/*
 * @brief Reserved value, marker for the maximum state
 */

const CFE_ES_RunStatus_MAX: enum_CFE_ES_RunStatus = CFE_ES_RunStatus_CORE_APP_RUNTIME_ERROR + 1;

/*
 * @brief Run Status and Exit Status identifiers
 *
 * @sa enum CFE_ES_RunStatus
 */

pub type CFE_ES_RunStatus_Enum_t = uint32;

/*
 * @brief Label definitions associated with CFE_ES_SystemState_Enum_t
 */

pub type enum_CFE_ES_SystemState = i32;

/*
 * @brief reserved
 */

const CFE_ES_SystemState_UNDEFINED: enum_CFE_ES_SystemState = 0;

/*
 * @brief single threaded mode while setting up CFE itself
 */

const CFE_ES_SystemState_EARLY_INIT: enum_CFE_ES_SystemState = 1;

/*
 * @brief core apps (CFE_ES_ObjectTable) are starting (multi-threaded)
 */

const CFE_ES_SystemState_CORE_STARTUP: enum_CFE_ES_SystemState = 2;

/*
 * @brief core is ready, starting other external apps/libraries (if any)
 */

const CFE_ES_SystemState_CORE_READY: enum_CFE_ES_SystemState = 3;

/*
 * @brief startup apps have all completed their early init, but not necessarily operational yet
 */

const CFE_ES_SystemState_APPS_INIT: enum_CFE_ES_SystemState = 4;

/*
 * @brief normal operation mode; all apps are RUNNING
 */

const CFE_ES_SystemState_OPERATIONAL: enum_CFE_ES_SystemState = 5;

/*
 * @brief reserved for future use, all apps would be STOPPED
 */

const CFE_ES_SystemState_SHUTDOWN: enum_CFE_ES_SystemState = 6;

/*
 * @brief Reserved value, marker for the maximum state
 */

const CFE_ES_SystemState_MAX: enum_CFE_ES_SystemState = CFE_ES_SystemState_SHUTDOWN + 1;

/*
 * @brief The overall cFE System State
 *
 * These values are used with the #CFE_ES_WaitForSystemState API call to synchronize application startup.
 *
 * @note These are defined in order so that relational comparisons e.g. if (STATEA < STATEB) are possible
 *
 * @sa enum CFE_ES_SystemState
 */

pub type CFE_ES_SystemState_Enum_t = uint32;

/*
 * @brief Label definitions associated with CFE_ES_LogEntryType_Enum_t
 */

pub type enum_CFE_ES_LogEntryType = i32;

/*
 * @brief Log entry from a core subsystem
 */

const CFE_ES_LogEntryType_CORE: enum_CFE_ES_LogEntryType = 1;

/*
 * @brief Log entry from an application
 */

const CFE_ES_LogEntryType_APPLICATION: enum_CFE_ES_LogEntryType = 2;

/*
 * @brief Type of entry in the Error and Reset (ER) Log
 *
 * @sa enum CFE_ES_LogEntryType
 */

pub type CFE_ES_LogEntryType_Enum_t = uint8;

/*
 * @brief Label definitions associated with CFE_ES_AppState_Enum_t
 */

pub type enum_CFE_ES_AppState = i32;

/*
 * @brief Initial state before app thread is started
 */

const CFE_ES_AppState_UNDEFINED: enum_CFE_ES_AppState = 0;

/*
 * @brief App thread has started, app performing early initialization of its own data
 */

const CFE_ES_AppState_EARLY_INIT: enum_CFE_ES_AppState = 1;

/*
 * @brief Early/Local initialization is complete.  First sync point.
 */

const CFE_ES_AppState_LATE_INIT: enum_CFE_ES_AppState = 2;

/*
 * @brief All initialization is complete.  Second sync point.
 */

const CFE_ES_AppState_RUNNING: enum_CFE_ES_AppState = 3;

/*
 * @brief Application is waiting on a Restart/Reload/Delete request
 */

const CFE_ES_AppState_WAITING: enum_CFE_ES_AppState = 4;

/*
 * @brief Application is stopped
 */

const CFE_ES_AppState_STOPPED: enum_CFE_ES_AppState = 5;

/*
 * @brief Reserved entry, marker for the maximum state
 */

const CFE_ES_AppState_MAX: enum_CFE_ES_AppState = CFE_ES_AppState_STOPPED + 1;

/*
 * @brief Application Run State
 *
 * The normal progression of APP states:
 * UNDEFINED -> EARLY_INIT -> LATE_INIT -> RUNNING -> WAITING -> STOPPED
 *
 * @note These are defined in order so that relational comparisons e.g. if (STATEA < STATEB) are possible
 *
 * @sa enum CFE_ES_AppState
 */

pub type CFE_ES_AppState_Enum_t = uint32;

/*
 * @brief A type for Application IDs
 *
 * This is the type that is used for any API accepting or returning an App ID
 */

pub type CFE_ES_AppId_t = CFE_ResourceId_t;

/*
 * @brief A type for Task IDs
 *
 * This is the type that is used for any API accepting or returning a Task ID
 */

pub type CFE_ES_TaskId_t = CFE_ResourceId_t;

/*
 * @brief A type for Library IDs
 *
 * This is the type that is used for any API accepting or returning a Lib ID
 */

pub type CFE_ES_LibId_t = CFE_ResourceId_t;

/*
 * @brief A type for Counter IDs
 *
 * This is the type that is used for any API accepting or returning a Counter ID
 */

pub type CFE_ES_CounterId_t = CFE_ResourceId_t;

/*
 * @brief Memory Handle type
 *
 * Data type used to hold Handles of Memory Pools
 * created via CFE_ES_PoolCreate and CFE_ES_PoolCreateNoSem
 */

pub type CFE_ES_MemHandle_t = CFE_ResourceId_t;

/*
 * @brief CDS Handle type
 *
 * Data type used to hold Handles of Critical Data Stores. See #CFE_ES_RegisterCDS
 */

pub type CFE_ES_CDSHandle_t = CFE_ResourceId_t;

/*
 * @brief Type used for task priority in CFE ES as
 * including the commands/telemetry messages.
 *
 * @note the valid range is only 0-255 (same as OSAL) but
 * a wider type is used for backward compatibility
 * in binary formats of messages.
 */

pub type CFE_ES_TaskPriority_Atom_t = uint16;

/*
 * @brief Type used for memory sizes and offsets in commands and telemetry
 *
 * For backward compatibility with existing CFE code this should be uint32,
 * but all telemetry information will be limited to 4GB in size as a result.
 *
 * On 64-bit platforms this can be a 64-bit value which will allow larger
 * memory objects, but this will break compatibility with existing control
 * systems, and may also change the alignment/padding of messages.
 *
 * In either case this must be an unsigned type.
 */

pub type CFE_ES_MemOffset_t = uint32;

/*
 * @brief Memory Offset initializer wrapper
 *
 * A converter macro to use when initializing a CFE_ES_MemOffset_t
 * from an integer value of a different type.
 */
/*
 * @brief Memory Offset to integer value (size_t) wrapper
 *
 * A converter macro to use when interpreting a CFE_ES_MemOffset_t
 * value as a "size_t" type
 */
/*
 * @brief Type used for memory addresses in command and telemetry messages
 *
 * For backward compatibility with existing CFE code this should be uint32,
 * but if running on a 64-bit platform, addresses in telemetry will be
 * truncated to 32 bits and therefore will not be valid.
 *
 * On 64-bit platforms this can be a 64-bit address which will allow the
 * full memory address in commands and telemetry, but this will break
 * compatibility with existing control systems, and may also change
 * the alignment/padding of messages.
 *
 * In either case this must be an unsigned type.
 *
 * FSW code should access this value via the macros provided, which
 * converts to the native "cpuaddr" type provided by OSAL.  This macro
 * provides independence between the message representation and local
 * representation of a memory address.
 */

pub type CFE_ES_MemAddress_t = uint32;

/*
 * @brief Memory Address initializer wrapper
 *
 * A converter macro to use when initializing a CFE_ES_MemAddress_t
 * from a pointer value of a different type.
 */
/*
 * @brief Memory Address to pointer wrapper
 *
 * A converter macro to use when interpreting a CFE_ES_MemAddress_t
 * as a pointer value.
 */
/*
 * Data Structures shared between API and Message (CMD/TLM) interfaces
 */
/*
 * \brief Application Information
 *
 * Structure that is used to provide information about an app.
 * It is primarily used for the QueryOne and QueryAll Commands.
 *
 * While this structure is primarily intended for Application info,
 * it can also represent Library information where only a subset of
 * the information applies.
 */

#[derive(Clone, Default)]
pub struct CFE_ES_AppInfo_t {
    pub ResourceId: CFE_ResourceId_t,
    /* < \cfetlmmnemonic \ES_APP_ID
    \brief Application or Library ID for this resource */
    pub Type: uint32,
    /* < \cfetlmmnemonic \ES_APPTYPE
    \brief The type of App: CORE or EXTERNAL */
    pub Name: [i8; 20],
    /* < \cfetlmmnemonic \ES_APPNAME
    \brief The Registered Name of the Application */
    pub EntryPoint: [i8; 20],
    /* < \cfetlmmnemonic \ES_APPENTRYPT
    \brief The Entry Point label for the Application */
    pub FileName: [i8; 64],
    /* < \cfetlmmnemonic \ES_APPFILENAME
    \brief The Filename of the file containing the Application */
    pub StackSize: CFE_ES_MemOffset_t,
    /* < \cfetlmmnemonic \ES_STACKSIZE
    \brief The Stack Size of the Application */
    pub AddressesAreValid: uint32,
    /* < \cfetlmmnemonic \ES_ADDRVALID
    \brief Indicates that the Code, Data, and BSS addresses/sizes are valid */
    pub CodeAddress: CFE_ES_MemAddress_t,
    /* < \cfetlmmnemonic \ES_CODEADDR
    \brief The Address of the Application Code Segment*/
    pub CodeSize: CFE_ES_MemOffset_t,
    /* < \cfetlmmnemonic \ES_CODESIZE
    \brief The Code Size of the Application */
    pub DataAddress: CFE_ES_MemAddress_t,
    /* < \cfetlmmnemonic \ES_DATAADDR
    \brief The Address of the Application Data Segment*/
    pub DataSize: CFE_ES_MemOffset_t,
    /* < \cfetlmmnemonic \ES_DATASIZE
    \brief The Data Size of the Application */
    pub BSSAddress: CFE_ES_MemAddress_t,
    /* < \cfetlmmnemonic \ES_BSSADDR
    \brief The Address of the Application BSS Segment*/
    pub BSSSize: CFE_ES_MemOffset_t,
    /* < \cfetlmmnemonic \ES_BSSSIZE
    \brief The BSS Size of the Application */
    pub StartAddress: CFE_ES_MemAddress_t,
    /* < \cfetlmmnemonic \ES_STARTADDR
    \brief The Start Address of the Application */
    pub ExceptionAction: CFE_ES_ExceptionAction_Enum_t,
    /* < \cfetlmmnemonic \ES_EXCEPTNACTN
    \brief What should occur if Application has an exception
    (Restart Application OR Restart Processor) */
    pub Priority: CFE_ES_TaskPriority_Atom_t,
    /* < \cfetlmmnemonic \ES_PRIORITY
    \brief The Priority of the Application */
    pub MainTaskId: CFE_ES_TaskId_t,
    /* < \cfetlmmnemonic \ES_MAINTASKID
    \brief The Application's Main Task ID */
    pub ExecutionCounter: uint32,
    /* < \cfetlmmnemonic \ES_MAINTASKEXECNT
    \brief The Application's Main Task Execution Counter */
    pub MainTaskName: [i8; 20],
    /* < \cfetlmmnemonic \ES_MAINTASKNAME
    \brief The Application's Main Task ID */
    pub NumOfChildTasks: uint32,
    /* < \cfetlmmnemonic \ES_CHILDTASKS
    \brief Number of Child tasks for an App */
}

/*
 * \brief Task Information
 *
 * Structure that is used to provide information about a task. It is primarily
 * used for the Query All Tasks (#CFE_ES_QUERY_ALL_TASKS_CC) command.
 *
 * \note There is not currently a telemetry message directly containing this
 * data structure, but it does define the format of the data file generated
 * by the Query All Tasks command.  Therefore it should be considered
 * part of the overall telemetry interface.
 */

#[derive(Clone, Default)]
pub struct CFE_ES_TaskInfo_t {
    pub TaskId: CFE_ES_TaskId_t,
    /* < \brief Task Id */
    pub ExecutionCounter: uint32,
    /* < \brief Task Execution Counter */
    pub TaskName: [i8; 20],
    /* < \brief Task Name */
    pub AppId: CFE_ES_AppId_t,
    /* < \brief Parent Application ID */
    pub AppName: [i8; 20],
    /* < \brief Parent Application Name */
    pub StackSize: CFE_ES_MemOffset_t,
    /* < Size of task stack */
    pub Priority: CFE_ES_TaskPriority_Atom_t,
    /* < Priority of task */
    pub Spare: [uint8; 2],
    /* < Spare bytes for alignment */
}

/*
 * \brief CDS Register Dump Record
 *
 * Structure that is used to provide information about a critical data store.
 * It is primarily used for the Dump CDS registry (#CFE_ES_DUMP_CDS_REGISTRY_CC)
 * command.
 *
 * \note There is not currently a telemetry message directly containing this
 * data structure, but it does define the format of the data file generated
 * by the Dump CDS registry command.  Therefore it should be considered
 * part of the overall telemetry interface.
 */

#[derive(Clone, Default)]
pub struct CFE_ES_CDSRegDumpRec_t {
    pub Handle: CFE_ES_CDSHandle_t,
    /* < \brief Handle of CDS */
    pub Size: CFE_ES_MemOffset_t,
    /* < \brief Size, in bytes, of the CDS memory block */
    pub Table: _Bool,
    /* < \brief Flag that indicates whether CDS contains a Critical Table */
    pub Name: [i8; (16 + 20 + 4)],
    /* < \brief Processor Unique Name of CDS */
    pub ByteAlignSpare: [uint8; 3],
    /* < \brief Spare bytes to ensure structure size is multiple of 4 bytes */
}

/*
 * \brief Block statistics
 *
 * Sub-Structure that is used to provide information about a specific
 * block size/bucket within a memory pool.
 */

#[derive(Clone, Default)]
pub struct CFE_ES_BlockStats_t {
    pub BlockSize: CFE_ES_MemOffset_t,
    /* < \brief Number of bytes in each of these blocks */
    pub NumCreated: uint32,
    /* < \brief Number of Memory Blocks of this size created */
    pub NumFree: uint32,
    /* < \brief Number of Memory Blocks of this size that are free */
}

/*
 * \brief Memory Pool Statistics
 *
 * Structure that is used to provide information about a memory
 * pool.  Used by the Memory Pool Stats telemetry message.
 *
 * \sa #CFE_ES_SEND_MEM_POOL_STATS_CC
 */

#[derive(Clone, Default)]
pub struct CFE_ES_MemPoolStats {
    pub PoolSize: CFE_ES_MemOffset_t,
    /* < \cfetlmmnemonic \ES_POOLSIZE
    \brief  Size of Memory Pool (in bytes) */
    pub NumBlocksRequested: uint32,
    /* < \cfetlmmnemonic \ES_BLKSREQ
    \brief Number of times a memory block has been allocated */
    pub CheckErrCtr: uint32,
    /* < \cfetlmmnemonic \ES_BLKERRCTR
    \brief Number of errors detected when freeing a memory block */
    pub NumFreeBytes: CFE_ES_MemOffset_t,
    /* < \cfetlmmnemonic \ES_FREEBYTES
    \brief Number of bytes never allocated to a block */
    pub BlockStats: [CFE_ES_BlockStats_t; 17],
    /* < \cfetlmmnemonic \ES_BLKSTATS
    \brief Contains stats on each block size */
}

pub type CFE_ES_MemPoolStats_t = CFE_ES_MemPoolStats;
