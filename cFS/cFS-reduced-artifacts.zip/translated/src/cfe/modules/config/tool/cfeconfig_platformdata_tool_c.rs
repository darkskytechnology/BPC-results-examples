#![allow(unused_variables, non_snake_case, non_camel_case_types, dead_code, unused_imports, unused_parens, non_upper_case_globals)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use cFS_reduced::build::inc::cfe_configid_offset_h::CFE_ConfigIdOffset_Enum_t;
use cFS_reduced::build::src::cfe_configid_nametable_c::CFE_CONFIGID_NAMETABLE;
use cFS_reduced::build::src::cfe_platform_list_c::CFECONFIG_PLATFORMDATA_TABLE;
use cFS_reduced::cfe::modules::config::tool::cfeconfig_platformdata_tool_h::CFE_ConfigTool_DetailBuffer_t;
use cFS_reduced::cfe::modules::config::tool::cfeconfig_platformdata_tool_h::CFE_ConfigTool_DetailEntry_t;
use cFS_reduced::cfe::modules::config::tool::cfeconfig_platformdata_tool_h::CFE_ConfigTool_ListDetail_t;
use cFS_reduced::cfe::modules::config::tool::cfeconfig_platformdata_tool_h::CFE_ConfigTool_PlatformMapEntry_t;
use cFS_reduced::translate_bpc_mmv;
use cFS_reduced::translate_bpc_vpp;
// USE STATEMENTS END

pub type CFE_ConfigTool_RenderFunc_t = fn ( 
// const char *
const _: *const i8 

, 

// const CFE_ConfigTool_DetailBuffer_t *
const CFE_ConfigTool_DetailBuffer_t 
) ;

/*----------------------------------------------------------------
 *
 * Prints command line usage information
 *
 *-----------------------------------------------------------------*/

pub fn CFE_ConfigTool_PrintUsage ( 
cmd : & 'static str 
) { 
fprintf ( 
stderr , 

"Usage: %s [(entrylist|initcode) platform_name]\n\n" , 

cmd 
) ;


fprintf ( 
stderr , 

"If executed without any arguments, generate a list of platform names\n" 
) ;


fprintf ( 
stderr , 

"If a platform name is given on command line,\n" 
) ;


fprintf ( 
stderr , 

" initcode:  generates a \"C\" source chunk for that platform\n" 
) ;


fprintf ( 
stderr , 

" entrylist: generate \"C\" macros for valid entries on that platform\n\n" 
) ;

}


/*----------------------------------------------------------------
 *
 * Renders content structure for a List/Array style platform config entry
 *
 *-----------------------------------------------------------------*/

pub fn CFE_ConfigTool_RenderListContent ( 
prefix : & 'static str , 

detail_ptr : Option < std :: rc :: Rc < std :: cell :: RefCell < CFE_ConfigTool_ListDetail_t > > > 
) { 
// char entry_string[64];
const MAX: usize = 256;
let mut entry_string: [char; MAX] = [\'\\0\'; MAX]; 

let i : i32 = Default :: default ( ) ;


let idv : i32 = Default :: default ( ) ;


let width : i32 = Default :: default ( ) ;


let is_reverse : _Bool = 


detail_ptr 
. options 
& 
0x01 

;


let use_leading_zero : _Bool = 


detail_ptr 
. options 
& 
0x02 

;


width = 1 ;


if 
use_leading_zero 
{ 

i 
= 

detail_ptr 
. num_entries 
;


while i >= 10 { 
i /= 10 ;


translate_bpc_vpp ! ( 
width 
) ;

}


}



snprintf ( 
entry_string , 

std :: mem :: size_of_val ( & entry_string ) 

, 

"CFE_CONFIG_%s_CONTENT" , 

prefix 
) ;


print ! ( "static const {} {}[{}] = {{\n" , 

detail_ptr 
. type_name 

, 

entry_string , 


detail_ptr 
. num_entries 
) ;



i 
= 

detail_ptr 
. num_entries 
;


idv = 0 ;


while i > 0 { 
if 
is_reverse 
{ 
idv = i ;

}



translate_bpc_mmv ! ( 
i 
) ;


if 
! 
is_reverse 

{ 

idv 
= 


detail_ptr 
. num_entries 
- 
i 

;

}



if 


idv 
== 

detail_ptr 
. num_entries 

&& 


detail_ptr 
. custom_max 
. is_some ( ) 

{ /* it is the "max" */

snprintf ( 
entry_string , 

std :: mem :: size_of_val ( & entry_string ) 

, 

"%s" , 


detail_ptr 
. custom_max 
) ;

}



else { 
snprintf ( 
entry_string , 

std :: mem :: size_of_val ( & entry_string ) 

, 

"CFE_%s_%0*d" , 

prefix , 

width , 

idv 
) ;

}



print ! ( "  {}{}\n" , 
entry_string , 

if 
( 
i == 0 
) 
{ 
' ' 
}

else { 
',' 
}


) ;

}



print ! ( "}};\n\n" ) ;

}


/*----------------------------------------------------------------
 *
 * Gets the rendering function for a given detail entry
 * If output should not be rendered at all, returns NULL.
 *
 *-----------------------------------------------------------------*/

pub fn CFE_ConfigTool_GetRenderFunc ( 
cfgid_p : Option < std :: rc :: Rc < std :: cell :: RefCell < CFE_ConfigTool_DetailEntry_t > > > 
) -> CFE_ConfigTool_RenderFunc_t { 
let mut result : CFE_ConfigTool_RenderFunc_t = Default :: default ( ) ;



result 
= None ;


if 


cfgid_p 
. render_style 
== 
CFE_ConfigTool_RenderStyle_ARRAY 

{ /* An array with size of 0 is allowed config-wise but should not be rendered,
         * as it will be a compile error.  Just skip it entirely. */

if 




cfgid_p 
. u 
. list 
. num_entries 
> 
0 

{ 

result 
= 

CFE_ConfigTool_RenderListContent 
as CFE_ConfigTool_RenderFunc_t 
;

}


}



return result ;

}


/*----------------------------------------------------------------
 *
 * Gets the printable name from a config ID offset
 * If the offset is not valid, returns NULL.
 *
 *-----------------------------------------------------------------*/

pub fn CFE_ConfigTool_GetNameFromOffset ( 
offset : CFE_ConfigIdOffset_Enum_t 
) -> & 'static str { 
let result : & 'static str = Default :: default ( ) ;


if 

offset 
> 
0 
&& 
offset 
< 
CFE_ConfigIdOffset_MAX 

{ 

result 
= 

CFE_CONFIGID_NAMETABLE [ offset ] 
. Name 
;

}



else { 

result 
= None ;

}



return result ;

}


/*----------------------------------------------------------------
 *
 * Finds the detail list for the given platform name.
 * If the plaform name is not valid, returns NULL.
 *
 *-----------------------------------------------------------------*/

pub fn CFE_ConfigTool_FindDetailByName ( 
name : & 'static str 
) -> Option < std :: rc :: Rc < std :: cell :: RefCell < CFE_ConfigTool_DetailEntry_t > > > { 
let platform_ptr : Option < std :: rc :: Rc < std :: cell :: RefCell < CFE_ConfigTool_PlatformMapEntry_t > > > = Default :: default ( ) ;


let result_ptr : Option < std :: rc :: Rc < std :: cell :: RefCell < CFE_ConfigTool_DetailEntry_t > > > = Default :: default ( ) ;


platform_ptr = CFECONFIG_PLATFORMDATA_TABLE ;



result_ptr 
= None ;


while 
( 


platform_ptr 
. plat_name 
. is_some ( ) 
) 
{ 
if 

strcasecmp ( 

platform_ptr 
. plat_name 

, 

name 
) 
== 
0 

{ 

result_ptr 
= 

platform_ptr 
. detail_ptr 
;


break ;

}



translate_bpc_vpp ! ( 
platform_ptr 
) ;

}



return result_ptr ;

}


/*----------------------------------------------------------------
 *
 * Renders the full content structure for a given platform name
 * Returns true if successful, or false if it is not able to be rendered
 *
 *-----------------------------------------------------------------*/

pub fn CFE_ConfigTool_WritePlatformCfg ( 
plat_name : & 'static str 
) -> _Bool { 
let detail_ptr : Option < std :: rc :: Rc < std :: cell :: RefCell < CFE_ConfigTool_DetailEntry_t > > > = Default :: default ( ) ;


let mut render_func : CFE_ConfigTool_RenderFunc_t = Default :: default ( ) ;


detail_ptr = CFE_ConfigTool_FindDetailByName ( plat_name ) ;


if 

detail_ptr 
. is_none ( ) 
{ 
fprintf ( 
stderr , 

"%s: platform undefined\n" , 

plat_name 
) ;


return 0 ;

}



print ! ( "/* THIS IS GENERATED CONTENT, DO NOT EDIT */\n\n" ) ;


while 
( 


detail_ptr 
. render_style 
!= 
CFE_ConfigTool_RenderStyle_NONE 

) 
{ 
render_func = CFE_ConfigTool_GetRenderFunc ( detail_ptr ) ;


if 

render_func 
. is_some ( ) 
{ 
render_func ( 
CFE_ConfigTool_GetNameFromOffset ( 

detail_ptr 
. ido 
) 

, 

& 

detail_ptr 
. u 

) ;

}



translate_bpc_vpp ! ( 
detail_ptr 
) ;

}



return 1 ;

}


/*----------------------------------------------------------------
 *
 * Prints a list of config ID entries that are valid for the given platform
 *
 *-----------------------------------------------------------------*/

pub fn CFE_ConfigTool_WriteValidEntries ( 
plat_name : & 'static str 
) -> _Bool { 
let detail_ptr : Option < std :: rc :: Rc < std :: cell :: RefCell < CFE_ConfigTool_DetailEntry_t > > > = Default :: default ( ) ;


let cfgname : & 'static str = Default :: default ( ) ;


detail_ptr = CFE_ConfigTool_FindDetailByName ( plat_name ) ;


if 

detail_ptr 
. is_none ( ) 
{ 
fprintf ( 
stderr , 

"%s: platform undefined\n" , 

plat_name 
) ;


return 0 ;

}



print ! ( "/* THIS IS GENERATED CONTENT, DO NOT EDIT */\n\n" ) ;

/* For the purpose of writing names, just use the first platform entry -
     * they will all be the same in this context, as this only uses names, not values */

while 
( 


detail_ptr 
. render_style 
!= 
CFE_ConfigTool_RenderStyle_NONE 

) 
{ /*
         * Checking the render function - in that if the content wasn't rendered, the
         * reference to it should not be rendered, either (for example an array with 0 entries).
         */

if 

CFE_ConfigTool_GetRenderFunc ( detail_ptr ) 
. is_some ( ) 
{ 
cfgname = CFE_ConfigTool_GetNameFromOffset ( 

detail_ptr 
. ido 
) ;


if 

cfgname 
. is_some ( ) 
{ 
print ! ( "CFE_PLATFORMCFG_ENTRY({})\n" , cfgname ) ;

}


}



translate_bpc_vpp ! ( 
detail_ptr 
) ;

}



return 1 ;

}


/*----------------------------------------------------------------
 *
 * Writes the names of all platforms known to the tool
 *
 *-----------------------------------------------------------------*/

pub fn CFE_ConfigTool_WritePlatformNames ( ) { 
let platform_ptr : Option < std :: rc :: Rc < std :: cell :: RefCell < CFE_ConfigTool_PlatformMapEntry_t > > > = Default :: default ( ) ;


platform_ptr = CFECONFIG_PLATFORMDATA_TABLE ;


while 
( 


platform_ptr 
. plat_name 
. is_some ( ) 
) 
{ 
print ! ( "CFE_PLATFORM_NAME({})\n" , 

platform_ptr 
. plat_name 
) ;


translate_bpc_vpp ! ( 
platform_ptr 
) ;

}


}


/*----------------------------------------------------------------
 *
 * Main routine
 *
 *-----------------------------------------------------------------*/

fn main ( ) -> impl std :: process :: Termination { let argv = std :: env :: args ( ) . collect :: < Vec < _ > > ( ) ;
let argc = argv . len ( ) ;
let retcode = move | | -> u8 { 
let mut success : _Bool = Default :: default ( ) ;


success = 0 ;


if 
argc == 1 
{ 
CFE_ConfigTool_WritePlatformNames ( ) ;


success = 1 ;

}



else if 
argc == 3 
{ 
if 

strcasecmp ( 
argv [ 1 ] 

, 

"entrylist" 
) 
== 
0 

{ 
success = CFE_ConfigTool_WriteValidEntries ( 
argv [ 2 ] 
) ;

}



else if 

strcasecmp ( 
argv [ 1 ] 

, 

"initcode" 
) 
== 
0 

{ 
success = CFE_ConfigTool_WritePlatformCfg ( 
argv [ 2 ] 
) ;

}


}



if 
! 
success 

{ 
CFE_ConfigTool_PrintUsage ( 
argv [ 0 ] 
) ;


return 1 ;

}



return 0 ;

return 0 ;
}

( ) ;
return std :: process :: ExitCode :: from ( retcode ) ;
}


