#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::build::inc::cfe_fs_extern_typedefs_h::enum_CFE_FS_SubType;
use crate::osal::src::os::inc::common_types_h::uint32;
// USE STATEMENTS END
/* **********************************************************************
 * NASA Docket No. GSC-18,719-1, and identified as “core Flight System: Bootes”
 *
 * Copyright (c) 2020 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/
/*
 * @file
 *
 * Declarations and prototypes for cfe_fs_extern_typedefs module
 */
/*
 * @brief File subtypes used within cFE
 *
 * This defines all the file subtypes used by cFE.
 * Note apps can extend as needed but need to
 * avoid conflicts (app context not currently included
 * in the file header).
 */

pub type enum_CFE_FS_SubType = i32;

/*
 * @brief Executive Services Exception/Reset Log Type
 *
 * Executive Services Exception/Reset Log File which is generated in response to a
 * \link #CFE_ES_WRITE_ER_LOG_CC \ES_WRITEERLOG2FILE \endlink
 * command.
 *
 */

const CFE_FS_SubType_ES_ERLOG: enum_CFE_FS_SubType = 1;

/*
 * @brief Executive Services System Log Type
 *
 * Executive Services System Log File which is generated in response to a
 * \link #CFE_ES_WRITE_SYS_LOG_CC \ES_WRITESYSLOG2FILE \endlink
 * command.
 *
 */

const CFE_FS_SubType_ES_SYSLOG: enum_CFE_FS_SubType = 2;

/*
 * @brief Executive Services Information on All Applications File
 *
 * Executive Services Information on All Applications File which is generated in response to a
 * \link #CFE_ES_QUERY_ALL_CC \ES_WRITEAPPINFO2FILE \endlink
 * command.
 *
 */

const CFE_FS_SubType_ES_QUERYALL: enum_CFE_FS_SubType = 3;

/*
 * @brief Executive Services Performance Data File
 *
 * Executive Services Performance Analyzer Data File which is generated in response to a
 * \link #CFE_ES_STOP_PERF_DATA_CC \ES_STOPLADATA \endlink
 * command.
 *
 */

const CFE_FS_SubType_ES_PERFDATA: enum_CFE_FS_SubType = 4;

/*
 * @brief Executive Services Critical Data Store Registry Dump File
 *
 * Executive Services Critical Data Store Registry Dump File which is generated in response to a
 * \link #CFE_ES_DUMP_CDS_REGISTRY_CC \ES_DUMPCDSREG \endlink
 * command.
 *
 */

const CFE_FS_SubType_ES_CDS_REG: enum_CFE_FS_SubType = 6;

/*
 * @brief Table Services Registry Dump File
 *
 * Table Services Registry Dump File which is generated in response to a
 * \link #CFE_TBL_DUMP_REGISTRY_CC \TBL_WRITEREG2FILE \endlink
 * command.
 *
 */

const CFE_FS_SubType_TBL_REG: enum_CFE_FS_SubType = 9;

/*
 * @brief Table Services Table Image File
 *
 * Table Services Table Image File which is generated either on the ground or in response to a
 * \link #CFE_TBL_DUMP_CC \TBL_DUMP \endlink command.
 *
 */

const CFE_FS_SubType_TBL_IMG: enum_CFE_FS_SubType = 8;

/*
 * @brief Event Services Application Data Dump File
 *
 * Event Services Application Data Dump File which is generated in response to a
 * \link #CFE_EVS_WRITE_APP_DATA_FILE_CC \EVS_WRITEAPPDATA2FILE \endlink
 * command.
 *
 */

const CFE_FS_SubType_EVS_APPDATA: enum_CFE_FS_SubType = 15;

/*
 * @brief Event Services Local Event Log Dump File
 *
 * Event Services Local Event Log Dump File which is generated in response to a
 * \link  #CFE_EVS_WRITE_LOG_DATA_FILE_CC \EVS_WRITELOG2FILE \endlink
 * command.
 *
 */

const CFE_FS_SubType_EVS_EVENTLOG: enum_CFE_FS_SubType = 16;

/*
 * @brief Software Bus Pipe Data Dump File
 *
 * Software Bus Pipe Data Dump File which is generated in response to a
 * \link #CFE_SB_WRITE_PIPE_INFO_CC \SB_WRITEPIPE2FILE \endlink
 * command.
 *
 */

const CFE_FS_SubType_SB_PIPEDATA: enum_CFE_FS_SubType = 20;

/*
 * @brief Software Bus Message Routing Data Dump File
 *
 * Software Bus Message Routing Data Dump File which is generated in response to a
 * \link #CFE_SB_WRITE_ROUTING_INFO_CC \SB_WRITEROUTING2FILE \endlink
 * command.
 *
 */

const CFE_FS_SubType_SB_ROUTEDATA: enum_CFE_FS_SubType = 21;

/*
 * @brief Software Bus Message Mapping Data Dump File
 *
 * Software Bus Message Mapping Data Dump File which is generated in response to a
 * \link #CFE_SB_WRITE_MAP_INFO_CC \SB_WRITEMAP2FILE \endlink
 * command.
 *
 */

const CFE_FS_SubType_SB_MAPDATA: enum_CFE_FS_SubType = 22;

/*
 * @brief Executive Services Query All Tasks Data File
 *
 * Executive Services Query All Tasks Data File which is generated in response to a
 * \link #CFE_ES_QUERY_ALL_TASKS_CC \ES_WRITETASKINFO2FILE \endlink
 * command.
 *
 */

const CFE_FS_SubType_ES_QUERYALLTASKS: enum_CFE_FS_SubType = 23;

/*
 * @brief Content descriptor for File Headers
 *
 * @sa enum CFE_FS_SubType
 */

pub type CFE_FS_SubType_Enum_t = uint32;

/*
** \brief Standard cFE File header structure definition
*/

#[derive(Clone, Default)]
pub struct CFE_FS_Header {
    pub ContentType: uint32,
    /* < \brief Identifies the content type (='cFE1'=0x63464531)*/
    pub SubType: uint32,
    /* < \brief Type of \c ContentType, if necessary */
    /* < Standard SubType definitions can be found
                                   \link #CFE_FS_SubType_ES_ERLOG here \endlink */
    pub Length: uint32,
    /* < \brief Length of this header to support external processing */
    pub SpacecraftID: uint32,
    /* < \brief Spacecraft that generated the file */
    pub ProcessorID: uint32,
    /* < \brief Processor that generated the file */
    pub ApplicationID: uint32,
    /* < \brief Application that generated the file */
    pub TimeSeconds: uint32,
    /* < \brief File creation timestamp (seconds) */
    pub TimeSubSeconds: uint32,
    /* < \brief File creation timestamp (sub-seconds) */
    pub Description: [i8; 32],
    /* < \brief File description */
}

pub type CFE_FS_Header_t = CFE_FS_Header;
