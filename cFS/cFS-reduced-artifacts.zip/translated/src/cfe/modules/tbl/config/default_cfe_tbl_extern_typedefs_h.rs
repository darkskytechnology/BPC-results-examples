#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
use crate::build::inc::cfe_tbl_extern_typedefs_h::enum_CFE_TBL_BufferSelect;
use crate::osal::src::os::inc::common_types_h::uint16;
use crate::osal::src::os::inc::common_types_h::uint32;
// USE STATEMENTS END
/* **********************************************************************
 * NASA Docket No. GSC-18,719-1, and identified as “core Flight System: Bootes”
 *
 * Copyright (c) 2020 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/
/*
 * @file
 *
 * Declarations and prototypes for cfe_tbl_extern_typedefs module
 */
/*
 * @brief Label definitions associated with CFE_TBL_BufferSelect_Enum_t
 */

pub type enum_CFE_TBL_BufferSelect = i32;

/*
 * @brief Select the Inactive buffer for validate or dump
 */

const CFE_TBL_BufferSelect_INACTIVE: enum_CFE_TBL_BufferSelect = 0;

/*
 * @brief Select the Active buffer for validate or dump
 */

const CFE_TBL_BufferSelect_ACTIVE: enum_CFE_TBL_BufferSelect = 1;

/*
 * @brief Selects the buffer to operate on for validate or dump commands
 *
 * @sa enum CFE_TBL_BufferSelect
 */

pub type CFE_TBL_BufferSelect_Enum_t = uint16;

/*
 * @brief The definition of the header fields that are included in CFE Table Data files.
 *
 * This header follows the CFE_FS header and precedes the actual table data.
 *
 * @note The Offset and NumBytes fields in the table header are to 32 bits for
 * backward compatibility with existing CFE versions.  This means that even on
 * 64-bit CPUs, individual table files will be limited to 4GiB in size.
 */

#[derive(Clone, Default)]
pub struct CFE_TBL_File_Hdr {
    pub Reserved: uint32,
    /* < Future Use: NumTblSegments in File?   */
    pub Offset: uint32,
    /* < Byte Offset at which load should commence */
    pub NumBytes: uint32,
    /* < Number of bytes to load into table */
    pub TableName: [i8; (16 + 20 + 4)],
    /* < Fully qualified name of table to load */
}

pub type CFE_TBL_File_Hdr_t = CFE_TBL_File_Hdr;
