#![allow(
    unused_variables,
    non_snake_case,
    non_camel_case_types,
    dead_code,
    unused_imports,
    unused_parens,
    non_upper_case_globals
)]
#![deny(unreachable_code)]

// USE STATEMENTS START
// USE STATEMENTS END
/* **********************************************************************
 * NASA Docket No. GSC-18,719-1, and identified as “core Flight System: Bootes”
 *
 * Copyright (c) 2020 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/
/*
 * \file
 *
 *  Purpose:
 *	    Unit specification for common types.
 *
 *  Design Notes:
 *         Assumes make file has defined processor family
 */
/*
** Includes
*/
/*
** Macro Definitions
*/
/*
** Condition = TRUE is ok, Condition = FALSE is error
*/
/*
** Define compiler specific macros
** The __extension__ compiler pragma is required
** for the uint64 type using GCC with the ANSI C90 standard.
** Other macros can go in here as needed.
**
** NOTE: The white-box (coverage) unit testing may need to disable
** these extra attributes.  These test builds define the OSAPI_NO_SPECIAL_ATTRIBS
** macro to disable this.
*/
/*
 * NOTE - NOT DEFINING STRUCT_LOW_BIT_FIRST or STRUCT_HIGH_BIT_FIRST
 * We should not make assumptions about the bit order here
 */

pub type int8 = u8;

pub type int16 = u16;

pub type int32 = u32;

pub type int64 = u64;

pub type uint8 = u8;

pub type uint16 = u16;

pub type uint32 = u32;

pub type uint64 = u64;

pub type intptr = intptr_t;

pub type cpuaddr = uintptr_t;

pub type cpusize = size_t;

pub type cpudiff = ptrdiff_t;

/*
 * A type to be used for OSAL resource identifiers.
 * This typedef is backward compatible with the IDs from older versions of OSAL
 */

pub type osal_id_t = uint32;

/*
 * A type used to represent a number of blocks or buffers
 *
 * This is used with file system and queue implementations.
 */

pub type osal_blockcount_t = size_t;

/*
 * A type used to represent an index into a table structure
 *
 * This is used when referring directly to a table index as
 * opposed to an object ID.  It is primarily intended for
 * internal use, but is also output from public APIs such as
 * OS_ObjectIdToArrayIndex().
 */

pub type osal_index_t = uint32;

/*
 * A type used to represent the runtime type or category of an OSAL object
 */

pub type osal_objtype_t = uint32;

/*
 * The preferred type to represent OSAL status codes defined in osapi-error.h
 */

pub type osal_status_t = int32;

/*
 * @brief General purpose OSAL callback function
 *
 * This may be used by multiple APIS
 */

pub type OS_ArgCallback_t =
    fn(object_id: osal_id_t, arg: Option<std::rc::Rc<std::cell::RefCell<dyn std::any::Any>>>);

/*
 ** Check Sizes
 */

// typedef char TypeUint8WrongSize[(sizeof(uint8) == 1) ? 1 : -1];
const _: () = assert!(std::mem::size_of::<u8>() == 1, "TypeUint8WrongSize");

// typedef char TypeUint16WrongSize[(sizeof(uint16) == 2) ? 1 : -1];
const _: () = assert!(std::mem::size_of::<u16>() == 2, "TypeUint16WrongSize");

// typedef char TypeUint32WrongSize[(sizeof(uint32) == 4) ? 1 : -1];
const _: () = assert!(std::mem::size_of::<u32>() == 4, "TypeUint32WrongSize");

// typedef char TypeUint64WrongSize[(sizeof(uint64) == 8) ? 1 : -1];
const _: [(); 8] = [(); std::mem::size_of::<u64>()];

// typedef char Typeint8WrongSize[(sizeof(int8) == 1) ? 1 : -1];
const _: () = assert!(std::mem::size_of::<i8>() == 1, "Typeint8WrongSize");

// typedef char Typeint16WrongSize[(sizeof(int16) == 2) ? 1 : -1];
const _: () = assert!(std::mem::size_of::<i16>() == 2, "Typeint16WrongSize");

// typedef char Typeint32WrongSize[(sizeof(int32) == 4) ? 1 : -1];
const _: () = assert!(std::mem::size_of::<i32>() == 4, "Typeint32WrongSize");

// typedef char Typeint64WrongSize[(sizeof(int64) == 8) ? 1 : -1];
const _: () = assert!(std::mem::size_of::<i64>() == 8, "Typeint64WrongSize");

// typedef char TypePtrWrongSize[(sizeof(cpuaddr) >= sizeof(void *)) ? 1 : -1];
const _: () = assert!(
    std::mem::size_of::<cpuaddr>() >= std::mem::size_of::<*const ()>(),
    "TypePtrWrongSize"
);
/*
 * Type macros for literals
 *
 * These macros enforce that a literal or other value is
 * interpreted as the intended type.  Although implicit
 * conversions between these types are often possible, using
 * this makes it explicit in the code where a type conversion
 * is expected.
 */
